% create header for txt file that stores the current best parameter
% combination
if exist('params','dir') == 7
    cd 'params'
else
    mkdir params;
    cd 'params';
end
%
if exist('cost.txt','file')>0
    delete('cost.txt')
end
filename = fullfile('cost.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t\n',...
    'genNumb','cost');
fclose(fid);
%

%
if exist('rate_loop_params_traction.txt','file')>0
    delete('rate_loop_params_traction.txt')
end
filename = fullfile('rate_loop_params_traction.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'w0p_traction','w0q_traction','w0r_traction',...
    'Kpp_traction','Kpq_traction','Kpr_traction',...
    'Kip_traction','Kiq_traction','Kir_traction');
fclose(fid);
%
if exist('rate_loop_params_retraction.txt','file')>0
    delete('rate_loop_params_retraction.txt')
end
filename = fullfile('rate_loop_params_retraction.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'w0p_retraction','w0q_retraction','w0r_retraction',...
    'Kpp_retraction','Kpq_retraction','Kpr_retraction',...
    'Kip_retraction','Kiq_retraction','Kir_retraction');
fclose(fid);
%
if exist('att_loop_params_traction.txt','file')>0
    delete('att_loop_params_traction.txt');
end
filename = fullfile('att_loop_params_traction.txt');
fid = fopen(filename, 'wt');
fprintf(fid,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'w0mu_traction','w0a_traction','w0b_traction',...
    'KpMuTrac','KpATrac','KpBTrac',...
    'KiMuTrac','KiATrac','KiBTrac');
fclose(fid);
%
if exist('att_loop_params_retraction.txt','file')>0
    delete('att_loop_params_retraction.txt');
end
filename = fullfile('att_loop_params_retraction.txt');
fid = fopen(filename, 'wt');
fprintf(fid,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'w0mu_retraction','w0a_retraction','w0b_retraction',...
    'KpMu_retraction','KpA_retraction','KpB_retraction',...
    'KiMu_retraction','KiA_retraction','KiB_retraction');
fclose(fid);
%
if exist('path_loop_params_traction.txt','file')>0
    delete('path_loop_params_traction.txt');
end
filename = fullfile('path_loop_params_traction.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'Kp_chi_tau_traction','Kp_gamma_tau_traction',...
    'Kp_chi_tau_trans','Kp_gamma_tau_trans',...
    'Ki_chi_tau_traction','Ki_gamma_tau_traction');
fclose(fid);
%
if exist('path_loop_params_retraction.txt','file')>0
    delete('path_loop_params_retraction.txt');
end
filename = fullfile('path_loop_params_retraction.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'w0_chi_retraction','w0_gamma_retraction',...
    'Kp_chi_retraction','Kp_gamma_retraction',...
    'Ki_chi_retraction','Ki_gamma_retraction');
fclose(fid);
%
if exist('general_cycle_params.txt','file')>0
    delete('general_cycle_params.txt');
end
filename = fullfile('general_cycle_params.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n',...
    'a_booth','b_booth',...
    'phi0_booth','F_T_traction_set',...
    'gamma_retract_opt', 'F_set_retraction',...
    'l_tether_max','l_tether_min',...
    'alpha_star_flag','alpha_star',...
    'w0_ftset_filters');
fclose(fid);
%
if exist('winchControls_params.txt','file')>0
    delete('winchControls_params.txt');
end
filename = fullfile('winchControls_params.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t\n',...
    'kp_w_trac',...
    'ki_w_trac',...
    'kp_w_retrac',...
    'ki_w_retrac');
fclose(fid);


cd ..