function analyzingClosedLoopPerformanceLat( G, K )
% in case of LQR with servo: we have state feedback 
S = inv(eye(7)+G*K); 

sum_ = 0; 

bodemag( S(6,6 ) 

end