function  [chi_K_des,p_VT_E,e_2] = getTargetPointOnCircle(left_top_abs_E, M_NE_left,p_circO1_E, p_test, r_SE, deltaAlpha)

long_leftTop = atan( left_top_abs_E(2)/ left_top_abs_E(1) );
p_test = p_test / norm(p_test);
long_p = atan( p_test(2)/p_test(1) );

M_circE = M_NE_left; 

% Transform the current kite position into the circ frame
% and project it into the circle plane
p_test_circ = M_circE * (p_test - p_circO1_E);
p_test_circ(3) = 0; % project in the plane.
% project kite now onto the circle
% First, calculate the vector from the circle origin to the projected
% position.
r_circ02KiteProj = p_test_circ/norm(p_test_circ)*r_SE;

% Now rotate this point around the z axis to create the carrot
RotM = [cos(deltaAlpha), -sin(deltaAlpha), 0;
    sin(deltaAlpha), cos(deltaAlpha), 0;
    0, 0, 1];
carrot_circ_circ =  RotM *r_circ02KiteProj;
carrot_circ_E = M_circE' * carrot_circ_circ + p_circO1_E;

if abs(long_p) < abs(long_leftTop)
    left_top_abs_E_plus = M_circE' *  RotM * M_circE * (left_top_abs_E-p_circO1_E) + p_circO1_E;
    p_VT_E = left_top_abs_E_plus;
     % Calculate tracking error 
   % e_track(cnt) = acos( p_VT_E' * p_test) ;
else
    p_VT_E = carrot_circ_E; %%%
    % Calculate tracking error 
    %e_track(cnt) = acos( mappedPosition_E' * p_test) ; 
end

e_1 = cross(  p_VT_E, p_test);
e_1 = e_1/norm(e_1);
e_2 = cross( p_test, e_1); 
e_2 = e_2/norm(e_2); % Bearing vector!

% Course angle is defined between the NED and the K system
% the orthonormal basis of the NED system is defined by longitude and
% latitude of the current position:
e_z_O_E = -p_test/norm(p_test);
% Now using the definition of the transformation M_EO matirix:
%% TO-DO: Change E to W and O to T! Because the tether plane corresponds to NED
% and the inertial frame is the windframe.

lat_p = -asin( e_z_O_E(3) );
long_p = atan( e_z_O_E(2) / e_z_O_E(1) );
e_x_O_E = [-sin(lat_p)*cos(long_p); -sin(lat_p)*sin(long_p); cos(lat_p)];

e_z_0K = cross( e_2, e_x_O_E);

chi_K_des = acos(e_x_O_E'*e_2) * sign(e_z_0K(3) );   % desired course angle


end