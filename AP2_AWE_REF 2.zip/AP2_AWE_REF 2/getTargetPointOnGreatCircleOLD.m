function [chi_K_des, p_VT_E,e_2] = getTargetPointOnGreatCircle(right_bottom_abs_E, left_top_abs_E, p_test, l_tether, deltaGC,wpSwitchBound)

p_test = p_test / norm(p_test);

e1 = cross( left_top_abs_E, right_bottom_abs_E);
e1 = e1/norm(e1);
e2 = cross(e1, left_top_abs_E);
e3 = left_top_abs_E;

M_Gc1E = [e3'; e2'; e1'];

% Transform the position into the GC1 frame
p_test_Gc1 = M_Gc1E * p_test;
% Remove third component
p_test_Gc1(3) = 0;
p_test_Gc1 = p_test_Gc1/norm(p_test_Gc1); %% moving the position onto the circle
% Transform back to E
%p_test_proj = M_Gc1E' * p_test_Gc1;
% Move the carrot a little bit further -->
% test
%deltaLambda = acos( left_top_abs_E' * p_test_proj / norm(p_test_proj) );
% take a fraction of it
%lambdaCarrot = min(-deltaGC * deltaLambda, -1*pi/180); % towards the upper point is a negative rotation!
%lambdaCarrot = min(-5*pi/180 * sign(deltaLambda), -1*pi/180); % towards the upper point is a negative rotation!
lambdaCarrot = -5*pi/180; 
% Move the projection with this angle along the great circle (which is a
% simple rotation!)
M_gc_z = [cos(lambdaCarrot), -sin(lambdaCarrot),0;
    sin(lambdaCarrot), cos(lambdaCarrot),0;
    0, 0, 1];
carrot_Gc1 = M_gc_z * p_test_Gc1;
carrot_E =  M_Gc1E' * carrot_Gc1;

p_VT_E = carrot_E;

long_carrot = atan( carrot_E(2)/carrot_E(1) );
if 1 
    % longtitude right bottom wp
    long_right_bottom_wp = atan( right_bottom_abs_E(2)/right_bottom_abs_E(1));
    if long_right_bottom_wp > 0
        if long_carrot < long_right_bottom_wp
            p_VT_E = right_bottom_abs_E;
        end
    else
        if long_carrot < long_right_bottom_wp
            p_VT_E = right_bottom_abs_E;
        end
    end
end
%% Next: we have to calculate the desired course angle
% We use the following algorithm: 1) Calculate heading vector in NED 2)
% Calculate course vector in NED 3) Calculate the angle between these
% two vectors with the correct sign
% Calculate an orthonormal basis in the current position
e_1 = cross(  carrot_E, p_test);
e_1 = e_1/norm(e_1);
e_2 = cross( p_test, e_1); % Course direction
e_2 = e_2/norm(e_2);

% Course angle is defined between the NED and the K system
% the orthonormal basis of the NED system is defined by longitude and
% latitude of the current position:
e_z_O_E = -p_test/norm(p_test);
% Now using the definition of the transformation M_EO matirix:
lat_p = -asin( e_z_O_E(3) );
long_p = atan( e_z_O_E(2) / e_z_O_E(1) );
e_x_O_E = [-sin(lat_p)*cos(long_p); -sin(lat_p)*sin(long_p); cos(lat_p)]; % bearing

% Course angle calculation:
% to determine the sign of the course angle calculate the normal of the
% plane spanned by the x0 and the xK axis. If the sign is negative the course angle is negative:
e_z_0K = cross( e_2, e_x_O_E);
chi_K_des = acos(e_x_O_E'*e_2) * sign(e_z_0K(3) );   % desired course angle

