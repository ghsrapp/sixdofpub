function yOUT = runOneGeneration_lat(xIN)

global runID;

if numel(runID) == 0
	runID = 0;
end

nInd = size(xIN, 2); % number of individuals
nRetvals = 6; % number of outputs (of the coust function?)

optsIN = xIN;

try
	load('list_old_individuals.mat'); % [runID; parameters; retval]
catch
	list_old_individuals = ones(size(optsIN,1)+nRetvals,0);
end

szList_old_individuals = size(list_old_individuals, 2);
list_old_individuals = [list_old_individuals, NaN(size(optsIN,1)+nRetvals, nInd)]; %%%%%%%%% Concatenation involves an empty array with an incorrect number of rows.

fprintf(1, 'Adding %d jobs\n', nInd);
lastResume = 0;
foundMatch = [];

% Load the state space models 
load('sys_trim.mat'); 

for i = 1:nInd
	curResults(i).retval = [];
	stopSearching = 0;
	foundMatch(i) = 0;
	% try to figure out if that individual did already run
	for jj = 1:szList_old_individuals
		j = lastResume + jj;
		if j > szList_old_individuals
			j = j - szList_old_individuals;
		end
		if sum(optsIN(:, i) ~= list_old_individuals(1:(end-nRetvals), j)) == 0 && stopSearching == 0
			if ~isinf(list_old_individuals(end, j))
				% if it was analyzed
				results(i).retval = list_old_individuals((end-nRetvals+1):end, j);
				curResults(i) = results(i);
%                 list_old_individuals(:, szList_old_individuals+i) = [runID; optsIN(:, i); results(i).retval(:)];
				foundMatch(i) = 1;
				stopSearching = 1;
				lastResume = j;
				break;
			else
				% it was never analyzed
				foundMatch(i) = 0;
				stopSearching = 1;
				break;
			end
		end
	end
end

%% 
for i = 1:size(optsIN,2)
    A_lat = sys_trim.A_lat; 
    B_lat = sys_trim.B_lat; 

    opt_params = optsIN(1:6,i); 
    K_lat(:,:,i) = doEigenstructureAssignment( A_lat, B_lat, opt_params );
end
[time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();
%% run simulations
if sum(foundMatch) ~= nInd
    yOUTlog  = get_robustification_cost_lat( time_domain_ref_lat, frequ_domain_ref_lat, A_lat, B_lat, K_lat );
    list_old_individuals(:, szList_old_individuals+(1:nInd)) = [optsIN; yOUTlog];
else
    yOUTlog = list_old_individuals(end-nRetvals+1:end,runID+(1:nInd));
    list_old_individuals(:,(end-nInd+1):end) = []; % delete NaN
end
figure(1); clf; 
plot( list_old_individuals(end,:) , '.'); 
figure(2); clf; 
[val, idx] = min(list_old_individuals(end,:) ); 

% A_cl = A_lat - B_lat * K_lat;
% sys = ss( A_cl, [zeros(4,1);1], [0,1,0,0,0], [] );
% step(sys);
% stepinfo(sys)
% drawnow;
figure(3); clf; 
plot( list_old_individuals(end-2,:) , '.'); 
yOUT = yOUTlog(end,:);


Simulink.sdi.clear

save('list_old_individuals.mat', 'list_old_individuals');

runID = runID + nInd;
fprintf(1, ' done\n');
end