function cost = costFunctionAP2(x, max_bandwidth,TSIM, paramStruct, gs, alpha_a_max )%COSTFUNCTION Summary of this function goes here
%   Detailed explanation goes her
x(1:18) = x(1:18)/10;  % to get the right accuracy
assignOptVariables2SimWorkspace;

% simulate
disp(['Height path: ', num2str(x(19)*0.1*x(20)),...
    ' | Width path: ', num2str(x(20)), ' | Mean elevation path: ', num2str(x(21)),...
    ' | Tether force: ', num2str(x(22))]);

simOut = sim('testAWE_Testbed_opt4b', 'CaptureErrors','on');

if simOut.sim_time(end) < TSIM
    cost = 1e15/simOut.sim_time(end) ;
    disp(['Current cost: ', num2str(cost)]);
else
    cost = 20*pi/180*norm( simOut.alpha_a_save.Data(:,1) - simOut.alpha_a_save.Data(:,3) )+...
        10*pi/180*norm( simOut.beta_a_save.Data(:,1) - simOut.beta_a_save.Data(:,3) ) +...
        1*pi/180*norm( simOut.eta_tether.Data(:,1) ) +...
        norm( simOut.course_tau_traction.Data(:,2) - simOut.course_tau_traction.Data(:,1) ) +...
        5*norm(simOut.delta_a_meas.Data) + ...
        5*norm(simOut.delta_e_meas.Data) + ...
        5*norm(simOut.delta_r_meas.Data) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,1)/max(simOut.omega_OB_rad.Data(:,1)) ) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,2)/max(simOut.omega_OB_rad.Data(:,2)) ) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,3)/max(simOut.omega_OB_rad.Data(:,3)) ) + ...
        norm( x(22)  - simOut.power_vr_tether.Data(:,3) )/1000;
    
    % Penalize additionally if sim violates certain constraints
    if max( simOut.power_vr_tether.Data(:,3) ) > gs.F_T_max
        cost = cost + 1000; %sum( power_vr_tether.Data(:,3)  > gs.F_T_max )/100;
    end
    
    if max( simOut.alpha_a_save.Data(:,3) ) > alpha_a_max*180/pi
        cost = cost + 1000;
    end
    
    mean_power = mean( simOut.power_vr_tether.Data(:,1) );
    cost = cost - mean_power;
    disp(['Current cost: ', num2str(cost)]);
end

end

