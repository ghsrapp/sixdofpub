%% ---------------------------- TRACTION ----------------------------
% Bandwidths
paramStruct.w0_mu_traction=w0_mu_traction;
paramStruct.w0_alpha_traction=w0_alpha_traction;
paramStruct.w0_beta_traction=w0_beta_traction;

paramStruct.w0_p_traction=w0_p_traction;
paramStruct.w0_q_traction=w0_q_traction;
paramStruct.w0_r_traction=w0_r_traction;

% Gains
paramStruct.Kp_chi_tau_traction=Kp_chi_tau_traction;
paramStruct.Ki_chi_tau_traction=Ki_chi_tau_traction;
paramStruct.Kp_chi_tau_trans=Kp_chi_tau_trans;
paramStruct.Kp_gamma_tau_trans=Kp_gamma_tau_trans;
paramStruct.Kp_gamma_tau_traction=Kp_gamma_tau_traction;
paramStruct.Ki_gamma_tau_traction=Ki_gamma_tau_traction;

paramStruct.Kp_mu_traction=Kp_mu_traction;
paramStruct.Kp_alpha_traction=Kp_alpha_traction;
paramStruct.Kp_beta_traction=Kp_beta_traction;
paramStruct.Ki_mu_traction=Ki_mu_traction;
paramStruct.Ki_alpha_traction=Ki_alpha_traction;
paramStruct.Ki_beta_traction=Ki_beta_traction;

paramStruct.Kp_p_traction=Kp_p_traction;
paramStruct.Kp_q_traction=Kp_q_traction;
paramStruct.Kp_r_traction=Kp_r_traction;
paramStruct.Ki_p_traction=Ki_p_traction;
paramStruct.Ki_q_traction=Ki_q_traction;
paramStruct.Ki_r_traction=Ki_r_traction;

paramStruct.a_booth=a_booth; %0.7;
paramStruct.b_booth=b_booth;% 90/100;
paramStruct.phi0_booth=phi0_booth;
paramStruct.F_T_traction_set= F_T_traction_set;

save('paramStruct.mat', 'paramStruct'); 