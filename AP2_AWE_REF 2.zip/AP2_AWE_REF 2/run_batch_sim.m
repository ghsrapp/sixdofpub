clear all
close all
clc

nav.t0transCirc = 5; % absolute distance
nav.gamma_t_cmd = 0;

ds_vec = 0.1 : 0.1 : 0.5; 
t0trac = 0.1 : 0.1 : 1.5; 

for n = 1 : length(ds_vec)
    for j = 1 : length(t0trac)
        close all
        disp(['Start run: ',num2str(n),num2str(j),'.']);
        nav.ds = ds_vec(n);
        nav.t0trac = t0trac(j); % velocity dependent
        init;
        sim('AWE_Testbed_02.slx');
        savefig([figure(1)],[pwd '/res/','TrajFile',num2str(n),num2str(j),'.fig']);
        disp(['Run: ',num2str(n),num2str(j),' completed.']);
    end
end