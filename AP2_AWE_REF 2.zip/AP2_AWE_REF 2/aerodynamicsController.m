magnitude_error = 0.1; 
P_control.b = (1+magnitude_error*(2*rand(1,1)-1))*P.b;
P_control.c = (1+magnitude_error*(2*rand(1,1)-1))*P.c;
P_control.S_wing = (1+magnitude_error*(2*rand(1,1)-1))*0.7879;%0.55;

magnitude_error = 0.2; % without actuator 0.2; 


% Pitch moment coefficient
P_control.C_m_0         = (1+magnitude_error*(2*rand(1,1)-1))* 0.0351; % compared to: -0.02338;
P_control.C_m_alpha     = (1+magnitude_error*(2*rand(1,1)-1))*-0.667; % check. % compared to: -0.38;
P_control.C_m_delta_e   = (1+magnitude_error*(2*rand(1,1)-1))*-0.01545547*180/pi; 
P_control.C_m_q         = (1+magnitude_error*(2*rand(1,1)-1))*-16.374;

% Rollmoment coefficient
P_control.C_ell_0       = 0.0;
P_control.C_ell_beta    = (1+magnitude_error*(2*rand(1,1)-1))*-0.0640; % compared to -0.12;
P_control.C_ell_p       =(1+magnitude_error*(2*rand(1,1)-1))* -0.645; % compared to -0.26;
P_control.C_ell_r       =(1+magnitude_error*(2*rand(1,1)-1))* 0.219; % compared to 0.14;
P_control.C_ell_delta_r =(1+magnitude_error*(2*rand(1,1)-1))* 0.000102864*180/pi; % compared to 0.105;
P_control.C_ell_delta_a = (1+magnitude_error*(2*rand(1,1)-1))*-0.008534465*180/pi;

% Yaw moment coeffcient
P_control.C_n_0         = 0.0;
P_control.C_n_delta_a   = (1+magnitude_error*(2*rand(1,1)-1))*0.000172983259710744*180/pi; % compared to 0.06;
P_control.C_n_delta_r   = (1+magnitude_error*(2*rand(1,1)-1))*-0.000985*180/pi; % compared to -0.032;
P_control.C_n_beta      = (1+magnitude_error*(2*rand(1,1)-1))*0.00103 * 180/pi; % compared to 0.25; !!! 
P_control.C_n_p         = (1+magnitude_error*(2*rand(1,1)-1))*-0.131; % compared to 0.022;  !!!
P_control.C_n_r         = (1+magnitude_error*(2*rand(1,1)-1))*-0.0335; % compared to -0.35; !!!

P_control.Cmu = [P_control.C_ell_delta_a, 0, P_control.C_ell_delta_r; 
                0, P_control.C_m_delta_e, 0; 
                P_control.C_n_delta_a, 0, P_control.C_n_delta_r];      
P_control.Cmu_inv = pinv( P_control.Cmu) ; 

%% Inertia Tensor 
P.Jcontroller = P.J .* (1+magnitude_error*(2*rand(3,3)-1)) ; 
P.Jcontrollerinv = inv(P.Jcontroller); 
