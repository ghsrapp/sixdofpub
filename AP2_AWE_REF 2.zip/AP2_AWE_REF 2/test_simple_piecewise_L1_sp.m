
function [HmInvHum, Ke_L1, C1, Ts, F, K, Am, Bp_um] = test_simple_piecewise_L1_sp(Ap, Bp, K) 

% Ap = [ -0.3335   36.2304  -50.0040   -0.3493;
%    -0.0745   -8.4502    0.0591    0.8967;
%     0.0033   -0.0088    0.0088    0.9858;
%    -0.0148  -24.4208         0   -3.5059];
% 
% 
% Bp = [ -1.1278;
%    -0.5608;
%          0;
%   -42.0146];

Q = eye(2); 
R = 1; 
 K = lqr( Ap, Bp, Q, R ); 
Am = Ap - Bp*K; 

% 
 Cc = [1,0];
 MxMu =  ([Ap, Bp; Cc, 0 ] ) \ [zeros(2,1); 1] ; 
 Mx = MxMu(1:end-1);
 Mu = MxMu(end); 
F = K*Mx+Mu;

sys = ss( Am, Bp*F, [1,0], [] ); 
figure; 
step(sys); 

% nullspace of bp_plus:
s = 1; 
v1 = [(-Bp(2)*s)/Bp(1);1];
Bp_um = [v1];

%% L1 Piecewise constant update law
s = tf('s'); 
%Bm = Bp*F; 
Hm = Cc* ( (s*eye(2)-Am)\Bp ) ; 
Hum = Cc* ( (s*eye(2)-Am)\Bp_um ) ;


HmInvHum = 1/Hm*Hum; 

Ts = 0.01; 
B = [Bp, Bp_um]; 
% Ke_L1 =( B \  ( (Am\(expm(Am*Ts)-eye(size(Am,1)))) )) \expm(Am*Ts) ; 
C1 = tf( [0, 30], [1, 30] ); 
Ke_L1 =  -inv(B) * inv( expm(Am*Ts) - eye(size(Am,1) ) ) * Am * expm(Am*Ts) ; 

 
 