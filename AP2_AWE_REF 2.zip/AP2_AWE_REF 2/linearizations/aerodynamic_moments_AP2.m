alpha = 5*pi/180; 
Va = 30; 

% Cm
Cm_0 = P_AP2.Cm_0_0  + P_AP2.Cm_0_alpha * alpha + P_AP2.Cm_0_alpha2 * alpha^2; 
Cm_q = P_AP2.Cm_q_0  + P_AP2.Cm_q_alpha * alpha + P_AP2.Cm_q_alpha2 * alpha^2; 
Cm_deltaE = P_AP2.Cm_deltaE_0  + P_AP2.Cm_deltaE_alpha * alpha + P_AP2.Cm_deltaE_alpha2 * alpha^2; 
%Cm = Cm_0 + Cm_q*P_AP2.c*q/(2*Va) + Cm_deltaE*delta_e; 

DCmDq =  Cm_q*P_AP2.c/(2*Va); 
DCmDdelta_e = Cm_deltaE; 

% Cl calculation
Cl_beta = P_AP2.Cl_beta_0 + P_AP2.Cl_beta_alpha * alpha + P_AP2.Cl_beta_alpha2 * alpha^2; 
Cl_p = P_AP2.Cl_p_0  +  P_AP2.Cl_p_alpha * alpha + P_AP2.Cl_p_alpha2 * alpha^2;  
Cl_r = P_AP2.Cl_r_0  + P_AP2.Cl_r_alpha * alpha + P_AP2.Cl_r_alpha2 * alpha^2;  
Cl_deltaA =P_AP2.Cl_deltaA_0 + P_AP2.Cl_deltaA_alpha * alpha + P_AP2.Cl_deltaA_alpha2 * alpha^2;  
Cl_deltaR =P_AP2.Cl_deltaR_0 + P_AP2.Cl_deltaR_alpha * alpha + P_AP2.Cl_deltaR_alpha2 * alpha^2;  
%Cl = Cl_beta*beta + Cl_p*P_AP2.b*p/(2*Va) + Cl_r*P_AP2.b*r/(2*Va) + Cl_deltaA*delta_a + Cl_deltaR*delta_r;

DClDp =  Cl_p*P_AP2.b/(2*Va); 
DClDr = Cl_r*P_AP2.b/(2*Va); 
DClDdelta_a = Cl_deltaA; 
DClDdelta_r = Cl_deltaR;

% Cn calculation
Cn_beta = P_AP2.Cn_beta_0 + P_AP2.Cn_beta_alpha * alpha + P_AP2.Cn_beta_alpha2 * alpha^2; 
Cn_p = P_AP2.Cn_p_0  + P_AP2.Cn_p_alpha * alpha + P_AP2.Cn_p_alpha2 * alpha^2;  
Cn_r = P_AP2.Cn_r_0  + P_AP2.Cn_r_alpha * alpha + P_AP2.Cn_r_alpha2 * alpha^2;  
Cn_deltaA =P_AP2.Cn_deltaA_0 + P_AP2.Cn_deltaA_alpha * alpha + P_AP2.Cn_deltaA_alpha2 * alpha^2;  
Cn_deltaR =P_AP2.Cn_deltaR_0 + P_AP2.Cn_deltaR_alpha * alpha + P_AP2.Cn_deltaR_alpha2 * alpha^2;  
%Cn = Cn_beta*beta + Cn_p*P_AP2.b*p/(2*Va) + Cn_r*P_AP2.b*r/(2*Va) + Cn_deltaA*delta_a + Cn_deltaR*delta_r;

DCnDp = Cn_p*P_AP2.b/(2*Va); 
DCnDr = Cn_r*P_AP2.b/(2*Va); 
DCnDdelta_a = Cn_deltaA; 
DCnDdelta_r = Cn_deltaR; 

                                 
%% ===================================== Linearized Rotational Dynamics =====================================                              
A_rot = P_AP2.Jinv*[DClDp, 0, DClDr; 
        0, DCmDq, 0; 
        DCnDp, 0, DCnDr]*diag([P_AP2.b,P_AP2.c,P_AP2.b])*0.5*Va^2*P_AP2.S_ref*1.225; 
    
B_rot = P_AP2.Jinv*[DClDdelta_a, 0, DClDdelta_r; 
        0, DCmDdelta_e, 0; 
        DCnDdelta_a, 0, DCnDdelta_r]*diag([P_AP2.b,P_AP2.c,P_AP2.b])*0.5*Va^2*P_AP2.S_ref*1.225; 
%%
A_rot_s = [A_rot, zeros(3); 
           -eye(3), zeros(3)]; 
B_rot_s = [B_rot; 
           zeros(3)];
    
%%
Q = blkdiag(eye(3),100*eye(3)); 
R = blkdiag(eye(3)); 
Klqr = lqr( A_rot_s, B_rot_s, Q, R); 
    
    
    
    
    