clear all 
close all
clc

%% Store rate loop parameters
if exist('rate_loop_params.txt')>0
    delete('rate_loop_params.txt')
end
filename = fullfile('rate_loop_params.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n','w0p_traction','w0q_traction','w0r_traction','Kpp_traction','Kpq_traction','Kpr_traction','Kip_traction','Kiq_traction','Kir_traction');
fclose(fid);
dlmwrite(filename,10000*rand(1,9),'delimiter','\t','precision',3,'-append');

%% Store attitude loop parameters 
if exist('att_loop_params.txt')>0
    delete('att_loop_params.txt');
end
filename = fullfile('att_loop_params.txt');
fid = fopen(filename, 'wt');
fprintf(fid,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n','w0mu_traction','w0a_traction','w0b_traction','KpMuTrac','KpATrac','KpBTrac','KiMuTrac','KiATrac','KiBTrac');
fclose(fid);
dlmwrite(filename,10000*rand(1,9),'delimiter','\t','precision',3,'-append');

%% Store path loop parameters 
if exist('path_loop_params.txt')>0
    delete('path_loop_params.txt');
end
filename = fullfile('path_loop_params.txt');
fid = fopen(filename, 'wt');
fprintf(fid, '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n','KpChiTrac','KiChiTrac','KpChiTrans','KpGTrans','KpGTrac','KiGTrac','a_booth','b_booth','phi_booth','Ft_traction');
fclose(fid);
dlmwrite(filename,10000*rand(1,10),'delimiter','\t','precision',3,'-append');






