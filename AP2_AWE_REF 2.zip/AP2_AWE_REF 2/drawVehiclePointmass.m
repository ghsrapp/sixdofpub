function drawVehiclePointmass(uu, V, F, patchcolors)
% process input to function
pn = uu(1); % inertial North position
pe = uu(2); % inertial East position
pd = uu(3); % inertial down position

t = uu(4);

p_VT_W = uu(5:7);

complex_tether_flag =0;

LemPsRef.AlambdaRef =  uu(8);
LemPsRef.AphiRef = uu(9);
LemPsRef.blambdaRef = uu(10);
LemPsRef.bphiRef =  uu(11);
LemPsRef.phi0 =  uu(12);
LemPsRef.deltaSol =  uu(13);

persistent vehicle_handle;
persistent Vertices
persistent Faces
persistent facecolors
persistent pathpoints
persistent tether_handle
persistent counter
persistent p_VT_W_handle
persistent referencePath
persistent handleParticles
persistent handleTempPath

if t==0
    figure(1), %clf
    counter = 1;
    [Vertices, Faces, facecolors] = defineVehicleBody;
    
    if complex_tether_flag
        tether_handle = [];
      %  handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z,[]); hold on
    else
        tether_handle = drawTether(pn, pe, pd, []); hold on
        handleParticles = [];
    end

    p_VT_W_handle = drawVirtualTarget(p_VT_W, []);
    
    pathpoints = animatedline('color', [0.5 0.5 0.5], 'Linewidth', 1);

    %======== lissajous figure ========
    if 0
    l_tether = norm(uu(1:3));
    [ LemPs ] = updateLissajous( l_tether, LemPsRef );
    Alambda = LemPs.Alambda ;
    Aphi = LemPs.Aphi;
    blambda = LemPs.blambda;
    bphi = LemPs.bphi;
    phi0 = LemPs.phi0;
    theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
    L = [Alambda * sin(blambda*theta_vec');
        Aphi    * sin(bphi*theta_vec') + phi0];
    L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))]*l_tether;
    end
    %=================================
    %handleTempPath = drawTempPath(temp_path_x,temp_path_y,temp_path_z, []);

    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), []);
    xlabel('Downwind')
   % ylabel('East')
    zlabel('Up')
    grid on
    axis equal; hold on;
    %view(90,20); % set the vieew angle for figure
    axis([-10 500 -200 200 0 500]); hold on
else 

    addpoints(pathpoints, -pn, pe, -pd);
      
    if complex_tether_flag
      % handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles);
    else
       tether_handle = drawTether(pn, pe, pd, tether_handle); 
    end

   % p_VT_W_handle = drawVirtualTarget(p_VT_W, p_VT_W_handle);
    
    deltaC = 1;
    if mod(counter-1, deltaC) == 0
        if counter == 1
         %      print([eval('pwd'),'/video/','vidPic_',num2str(counter)], '-dpng', '-r300');
        else
         %     print([eval('pwd'),'/video/','vidPic_',num2str((counter-1)/deltaC)], '-dpng', '-r300');
        end
    end
    
    %======== lissajous figure ========
    if 0 
    l_tether = norm(uu(1:3));
    [ LemPs ] = updateLissajous( l_tether, LemPsRef );
    Alambda = LemPs.Alambda ;
    Aphi = LemPs.Aphi;
    blambda = LemPs.blambda;
    bphi = LemPs.bphi;
    phi0 = LemPs.phi0;
    theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
    L = [Alambda * sin(blambda*theta_vec');
        Aphi    * sin(bphi*theta_vec') + phi0];
    L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))]*l_tether;
    end
    %=================================

    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), referencePath);
    handleTempPath = [];%drawTempPath(temp_path_x,temp_path_y,temp_path_z, handleTempPath);
    counter = counter + 1;
end
end
% function handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles)
% if isempty(handleParticles)
%     handleParticles = plot3( p_t_x, p_t_y,p_t_z , '-o', 'color', [0.1 0.1 0.1], 'Markersize',3, 'Linewidth', 1.5, 'MarkerFaceColor', [0.3 0.3 0.3]); hold on;
% else
%      set(handleParticles,'XData',p_t_x,'YData',p_t_y,'ZData',p_t_z);
% end
% drawnow;
% end

% function handleTempPath = drawTempPath(x,y,z, handleTempPath)
% if isempty(handleTempPath)
%     handleTempPath = plot3( x, y,z , '-', 'color', [0 0 0.6],'Linewidth', 2); hold on;
% else
%      set(handleTempPath,'XData',x,'YData',y,'ZData',z);
% end
% drawnow;
% end



% function referencePath = drawReferencePath(x,y,z, referencePath)
% if isempty(referencePath)
%     referencePath = plot3( x, y,z , '-', 'color', [0.3 0.3 0.3],'Linewidth', 1.5); hold on;
% else
%      set(referencePath,'XData',x,'YData',y,'ZData',z);
% end
% drawnow;
% end



function handleT = drawTether(pn, pe, pd, handleT)
M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
pts = M_EO * [pn;pe;pd];
if isempty(handleT),
    handleT = plot3([0 pts(1)], [0 pts(2)], [0 pts(3)], '-k');
else
    set(handleT,'XData',[0 pts(1)],'YData',[0 pts(2)],'ZData',[0 pts(3)] );
end
    drawnow;
end

function p_VT_W_handle = drawVirtualTarget(p_VT_W, p_VT_W_handle)
if isempty(p_VT_W_handle)
    p_VT_W_handle = plot3(p_VT_W(1), p_VT_W(2), p_VT_W(3), '*g');
else
    set(p_VT_W_handle,'XData',p_VT_W(1),'YData',p_VT_W(2),'ZData',p_VT_W(3));
end
    drawnow;
end

function handle = drawVehicleBody(V,F,patchcolors,...
    pn, pe, pd, phi, theta, psi,...
    handle,mode)
V = rotate(V, phi, theta, psi); % body frame into NED frame
V = translate(V, pn , pe, pd);

M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
%V = M_ON * V; % Transform from N to NED frame
V = M_EO*V; % Transform from NED into E frame
if isempty(handle),
    handle = patch('Vertices', V', 'Faces', F, ....
        'FaceVertexCData', patchcolors,...
        'FaceColor', 'flat');%,...
    %'EraseMode', mode);
else
    set(handle,'Vertices', V', 'Faces', F);
    drawnow
end
end

function pts = rotate(pts, phi, theta, psi)

% From B 2 O
pts = [ cos(psi)*cos(theta), cos(psi)*sin(phi)*sin(theta) - cos(phi)*sin(psi), sin(phi)*sin(psi) + cos(phi)*cos(psi)*sin(theta);
    cos(theta)*sin(psi), cos(phi)*cos(psi) + sin(phi)*sin(psi)*sin(theta), cos(phi)*sin(psi)*sin(theta) - cos(psi)*sin(phi);
    -sin(theta),                              cos(theta)*sin(phi),                              cos(phi)*cos(theta)] * pts;
end

function pts = translate(pts, pn, pe, pd)
pts = pts + repmat([pn;pe;pd], 1, size(pts,2));
end

function [V,F,facecolors] = defineVehicleBody
scale = 12;
b_wing = 3.7*scale;
c_wing = 0.22*scale;
L_fuse = 1*scale;
b_fuse = 0.1*scale;
c_emp = 0.1*scale;
b_emp = 0.4*scale;
h_rud = 0.3*scale;
h_fuse = 0.1*scale;
x_nose = 0.5*scale;
x_tail = 1.5*scale;
b_fuse = 0.1*scale;
xp = 0.1*scale;
x_LE = 0.1*scale;
c_rud = 0.1*scale;
V = [...
    x_nose, 0, 0; %1
    x_nose-xp, b_fuse/2, -h_fuse/2; %2
    x_nose-xp, b_fuse/2, +h_fuse/2; %3
    x_nose-xp, -b_fuse/2, +h_fuse/2; %4
    x_nose-xp, -b_fuse/2, -h_fuse/2; %5
    -x_tail, 0, 0; %6
    x_LE, b_wing/2, 0;%7
    x_LE-c_wing, b_wing/2, 0;%8
    x_LE-c_wing, -b_wing/2, 0; %9
    x_LE, -b_wing/2, 0;  %10
    -x_tail, -b_emp/2, 0;... % 11
    -(x_tail+c_emp), -b_emp/2, 0;...% 12
    -(x_tail+c_emp), b_emp/2, 0;...% 13
    -x_tail, b_emp/2, 0;...% 14
    -(x_tail+c_emp), 0, 0;... % 15
    -(x_tail+c_emp+c_rud), 0, 0;...% 16
    -(x_tail+c_emp+c_rud), 0, -h_rud;...% 17
    -(x_tail+c_emp), 0, -h_rud;...% 18
    ]';
F = [...
    1,2,3,3;... % pyramid
    3,4,1,1;...
    1,4,5,5;...
    1,2,5,5;...
    3,4,6,6;...
    4,5,6,6;...
    2,5,6,6;...
    2,3,6,6;...
    2,5,6,6;...
    7,8,9,10;...
    11,12,13,14;...
    15,16,17,18;...
    ];
facecolors = [1,0,0];
end
