

function G_scaled_min = analyseSVsMIMO( sys,  constr, act, col )

G_tot = tf( sys );
G = G_tot;
%  Gd{j} = G_tot(1:3,4);

De = diag([30,20*pi/180, constr.alpha_a_max,constr.phi_tau_max]); 
Du = diag([act.aileron.max_deflection,act.elevator.max_deflection, act.rudder.max_deflection, constr.F_T_max]);  

%
omegas = linspace( 0 , 30 , 1e4 );
G_scaled = inv(De)*G*Du;

G_scaled_min = minreal( G_scaled );


frequ_resp = freqresp( G_scaled_min, omegas );
for k = 1 : length( omegas )
    [U,S,V] = svd( frequ_resp(:,:,k) );
    min_sv(k) = S(end, end);
    max_sv(k) = S(1, 1);
    condi_sv(k) =max_sv(k)./ min_sv(k);
end


figure(3);
%set(0, 'DefaultFigureRenderer', 'painters');
subplot(311);
semilogx( omegas,  max_sv, 'color', col, 'Linewidth', 1.2); hold on
ylabel('\sigma_{max} (G)');
subplot(312);
semilogx( omegas,  min_sv , 'color', col, 'Linewidth', 1.2); hold on
ylabel('\sigma_{min}(G)');
subplot(313);
semilogx( omegas, condi_sv, 'color', col, 'Linewidth', 1.2); hold on
ylabel('\kappa(G)');
xlabel('\omega (rad/s)');
drawnow;