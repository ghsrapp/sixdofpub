clear all 
close all
clc

TSIM = 140; 
% call init script 
init_new;
close all;
maxBandwidth = aileron.w0; 
FitnessFunction = @(x)costFunction(x,maxBandwidth,TSIM); 
numberOfVariables = 34;

% lb_gains = 0.1; 
% ub_gains = 50;
% lb_gain_chi_tau = 0.1;
% ub_gain_chi_tau = 5;
% lb_w0_fac = 0.1; 
% ub_w0_fac = 0.75;

lb_gains = 1; 
ub_gains = 500;
lb_gain_chi_tau = 1;
lb_a_booth = 2; % a fraction of b
lb_b_booth = 60; 
lb_phi0 = 30; 

ub_gain_chi_tau = 30;
lb_w0_fac = 1; 
ub_w0_fac = 8;
ub_a_booth = 10; 
ub_b_booth = 120; 
ub_phi0 = 35; 

lb_gain_chi_tau_i = 0;
ub_gain_chi_tau_i = 10;

lb_factor_f_t_set = 0;
ub_factor_f_t_set = 8;

lb_gain_chi_tau_trans = 1; 
ub_gain_chi_tau_trans = 5;

lb_gain_gamma_tau_trans = 1; 
ub_gain_gamma_tau_trans = 5;

lb_gain_gamma_tau = 1;
ub_gain_gamma_tau = 30;

lb_gain_gamma_tau_i = 0;
ub_gain_gamma_tau_i = 10;

%% Retraction controller
lb_gain_chi_retract = 1;
ub_gain_chi_retract = 30;
lb_gain_chi_retract_i = 0;
ub_gain_chi_retract_i = 10;

lb_gain_gamma_retract = 1;
ub_gain_gamma_retract = 30;
lb_gain_gamma_retract_i = 0;
ub_gain_gamma_retract_i = 10;

lb_v_retraction_opt = -25;
ub_v_retraction_opt = -10; 

ub_gamma_retract_opt = 0;
lb_gamma_retract_opt = -30;

numPop = 20;%20; % lets see

lb = [lb_gains*ones(1,12),lb_gain_chi_tau,lb_w0_fac*ones(1,6),...
     lb_a_booth,lb_b_booth,lb_phi0,lb_gain_chi_tau_i,lb_factor_f_t_set,...
     lb_gain_chi_tau_trans,lb_gain_gamma_tau_trans,lb_gain_gamma_tau,lb_gain_gamma_tau_i,...
     lb_gain_chi_retract,lb_gain_chi_retract_i,lb_gain_gamma_retract,lb_gain_gamma_retract_i,...
     lb_v_retraction_opt,lb_gamma_retract_opt]; % vector with all the lower bounds
ub = [ub_gains*ones(1,12),ub_gain_chi_tau,ub_w0_fac*ones(1,6),...
    ub_a_booth,ub_b_booth,ub_phi0,ub_gain_chi_tau_i,ub_factor_f_t_set,...
    ub_gain_chi_tau_trans,ub_gain_gamma_tau_trans,ub_gain_gamma_tau,ub_gain_gamma_tau_i,...
    ub_gain_chi_retract,ub_gain_chi_retract_i,ub_gain_gamma_retract,ub_gain_gamma_retract_i,...
    ub_v_retraction_opt,ub_gamma_retract_opt]; % vector with all the upper bounds



%init_pop = [ (ub_gains-lb_gains)*rand( numPop, 13) + lb_gains, ...
%     (ub_factor_f_t_set-lb_factor_f_t_set)*rand( numPop, 6) + lb_w0_fac];
%load('population_solution8.mat');
%load('population_solution13.mat');
load('x_best_trac_tmp1.mat');
population = repmat(x,20,1);

%factor_f_t_set_init = (ub_factor_f_t_set- lb_factor_f_t_set) * randi(  numPop,1 ) + lb_factor_f_t_set*ones(numPop,1);     
gain_chi_tau_trans_init = randi( [lb_gain_chi_retract,ub_gain_chi_retract], size(population,1), 1 );
gain_gamma_tau_trans_init = randi( [lb_gain_chi_retract_i,ub_gain_chi_retract_i], size(population,1), 1 );
gain_gamma_tau_init =       randi( [lb_gain_gamma_retract,      ub_gain_gamma_retract], size(population,1), 1 );
gain_gamma_tau_i_init =     randi( [lb_gain_gamma_retract_i,    ub_gain_gamma_retract_i], size(population,1), 1 );
v_retraction_opt_init =  randi( [lb_v_retraction_opt,    ub_v_retraction_opt], size(population,1), 1 );
gamma_retract_opt_init = randi( [lb_gamma_retract_opt,    ub_gamma_retract_opt], size(population,1), 1 );

population = [population,gain_chi_tau_trans_init,...
    gain_gamma_tau_trans_init,gain_gamma_tau_init,...
    gain_gamma_tau_i_init,v_retraction_opt_init,gamma_retract_opt_init];                    
                    
opts = optimoptions('ga', ...
                    'UseParallel',false,...
                    'PopulationSize', numPop, ...
                    'MaxGenerations', 50, ...
                    'EliteCount', 1, ...
                   'FunctionTolerance', 1e-16, ...
                    'PlotFcn', @myPlotFunc, ...
                     'InitialPopulation',population);                    
                 
%%
IntCon = 1 : numberOfVariables; 
%parpool('local');
%pctRunOnAll(['addpath ', pwd]);
%addAttachedFiles(myPool,{'AWE_Testbed_opt.slx'});
%parfevalOnAll(@load_system,0,'AWE_Testbed_opt');

[x,fval,exitflag,output,population,scores] = ga(FitnessFunction, numberOfVariables, [],[],[],[], lb,ub, [],IntCon,opts);
save('population_solution14.mat', 'population');
save('opt_control14.mat', 'x');

%delete(gcp);