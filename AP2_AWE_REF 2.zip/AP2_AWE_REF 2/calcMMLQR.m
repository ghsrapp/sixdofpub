function K_MM_LQR = calcMMLQR( A_s, B_s, Q, R )


numb_sys = size( A_s, 3);

n = size( A_s(:,:,1), 1); 
m = size( B_s(:,:,1), 2); 

W = sdpvar( n + m, n + m ); 
P = sdpvar( n, n ); 
Z = sdpvar( m, n ); 

Cz = [sqrt(Q); zeros(m, n)]; 
Dz = [zeros(n,m); sqrt(R)]; 

%% Formulate the LMIS
F = [];

F = [F, P>=0]; 

F = [F, [P, (Cz*P+Dz*Z)'; 
Cz*P+Dz*Z, W]>=0];

for ii = 1 : numb_sys
    
    F = [F, (A_s(:,:,ii)*P+B_s(:,:,ii)*Z)'+(A_s(:,:,ii)*P+B_s(:,:,ii)*Z)<=-eye(n)]
    
end
gamma = trace( W );

sol = solvesdp(F,gamma);

K_MM_LQR = -double(Z) / double(P); % with negative sign to have the same feedback