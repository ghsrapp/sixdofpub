function [rt_alpha_95,os_alpha_95,st_alpha_95, rt_alpha_nom, os_alpha_nom, st_alpha_nom] = drawStepResponseLong(CL, save_flag, name_alpha, alpha_lvl,lw, n_MC)

opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
tvec = 0 : 0.1 : 12;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];

%% alpha
% h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);

rt_alpha = zeros( n_MC,1 ); 
os_alpha= zeros( n_MC,1 );
st_alpha= zeros( n_MC,1 );
G_s =  usample(CL, n_MC); 
sum_A = zeros( 5,5 ); 
for n = 1 : n_MC
    G = G_s(:,:,n); 
    sum_A = G.A + sum_A; 
    s_alpha = stepinfo(G(1,1),'RiseTimeLimits',[0,0.95]);
    
    rt_alpha(n) = s_alpha.RiseTime;
    os_alpha(n) = s_alpha.Overshoot;
    st_alpha(n) = s_alpha.SettlingTime;
    
    [y,t] = step(G,tvec,opt);

    if save_flag
        figure(1);
        ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', lw, 'color', col1); hold on
        xlabel('Time (s)');
        ylabel('$\alpha_\mathrm{a}$ (deg)');
        ph1.Color(4) = alpha_lvl;
    end
    
end
[y,t] = step( CL.NominalValue,tvec,opt);
figure(1);
plot( t, t./t*10, '--', 'Linewidth', 1.2, 'color', col2); hold on
ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', 1.2, 'color', 'c'); hold on
axis([0 12 0 12]); hold on
yticks([0 2 4 6 8 10 12])
box on ;

if 1
    cd('Trim_results/');
    Plot2LaTeX2(h1,name_alpha);
    cd ..
end


s_alpha = stepinfo( CL.NominalValue(1,1),'RiseTimeLimits',[0,0.95]);

rt_alpha_nom(1) = s_alpha.RiseTime;
os_alpha_nom(1) = s_alpha.Overshoot;
st_alpha_nom(1) = s_alpha.SettlingTime;

% interesting is also the 95% quantile two sided for alpha (97.5 below or
% 97.5 above)
n_95 = ( 0.95*n_MC );

rt_alpha_sort = sort( rt_alpha, 'ascend' );
rt_alpha_95 = rt_alpha_sort(n_95);

os_alpha_sort = sort( os_alpha, 'ascend' );
os_alpha_95 = os_alpha_sort(n_95);

st_alpha_sort = sort( st_alpha, 'ascend' );
st_alpha_95 = st_alpha_sort(n_95);
%

