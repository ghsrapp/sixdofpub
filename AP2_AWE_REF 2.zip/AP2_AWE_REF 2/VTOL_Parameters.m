% ================ VTOL parameters 

VTOL.idxInitWp = 2;

% Actuator limits
P.delta_a_max = 30 * pi/180; 
P.delta_e_max = 30 * pi/180; 
P.delta_r_max = 30 * pi/180; 


% Outer Loop
VTOL.A_ref_course = -1;
VTOL.B_ref_course = 1;
VTOL.A_ref_path = -1;
VTOL.B_ref_path = 1;
VTOL.A_ref_V = -2;
VTOL.B_ref_V = 2;

% Translational dynamics
omega_test = 3;
xi_test = 0.8;
VTOL.A_t_test = [zeros(3), eye(3);
    -omega_test^2* eye(3), -2 * omega_test * xi_test * eye(3)];
VTOL.B_t_test = [zeros(3);
    omega_test^2*eye(3)];


% Rate
lambda_rate = -30;
VTOL.A_rate_ref = diag([lambda_rate, lambda_rate, lambda_rate/2]);
VTOL.B_rate_ref = diag([-lambda_rate, -lambda_rate , -lambda_rate/2]);

lambda_rate = -omega_att_ref;
TRANS.A_rate_ref = diag([lambda_rate, lambda_rate, lambda_rate]);
TRANS.B_rate_ref = diag([-lambda_rate, -lambda_rate , -lambda_rate]);


% Attitude
lambda_euler = lambda_rate/2;
VTOL.A_ref_att =  diag([lambda_euler,lambda_euler,lambda_euler/10]);
VTOL.B_ref_att =  diag([-lambda_euler,-lambda_euler, -lambda_euler/10]);

% Rate Error controller
VTOL.Kp_rate = diag([20, 20, 20]);
VTOL.Ki_rate = diag([10, 10, 10]);
TRANS.Kp_rate = diag([20, 20, 20]);
TRANS.Ki_rate = diag([20, 20, 20]);

% Attitude
VTOL.Kp_att = diag([10, 10, 10]);

%% Setpoint tracking for the parking mode 
%% Setpoint tracking
VTOL.v_k = 0.5;
VTOL.v_k_landing = 1; 
VTOL.A_ref_ph = zeros(6);
VTOL.A_ref_ph(1:3, 4:6) = eye(3);
VTOL.omega_ref = 1;
VTOL.damp_ref = 0.8;
VTOL.A_ref_ph(4:6, 1:3) = -VTOL.omega_ref^2 * eye(3);
VTOL.A_ref_ph(4:6, 4:6) = -2*VTOL.damp_ref * VTOL.omega_ref * eye(3);
VTOL.B_ref_ph = zeros(6,3);
VTOL.B_ref_ph(4:6, :) = VTOL.omega_ref^2*eye(3);
VTOL.Kp_setpoint = [3,0,0; 0, 3, 0; 0, 0, 7];
VTOL.Kd_setpoint = diag([5,5,20]);
VTOL.elevLandingTrigger = 85; % the elevation that triggers the VTOL

%% Launching path

%% Pathfollowing stuff
VTOL.climbAng = 30*pi/180;
VTOL.hFinal = 200;
VTOL.dFinal = 1;

% Launching Path
hz_init = 100;
waypoint_mat =   [0,0,0;
    0,0,-hz_init; % clear height
    (VTOL.hFinal-hz_init)/tan(VTOL.climbAng)-cos(VTOL.climbAng)*VTOL.dFinal, 0, -(VTOL.hFinal-sin(VTOL.climbAng)*VTOL.dFinal);
    (VTOL.hFinal-hz_init)/tan(VTOL.climbAng),0, -VTOL.hFinal];
VTOL.numb_wp = length( waypoint_mat );
waypoint_mat(:,1) = waypoint_mat(:,1)*(-1);
l_tether_park = norm( waypoint_mat(end,:) );
theta_des_park = atan( waypoint_mat(end,3)/waypoint_mat(end,1));


% Carrot
VTOL.epsilon_path = VTOL.v_k;
VTOL.delta = 2;

% % intial values filter for setpoint tracking
 filterSPInit = [waypoint_mat(end-1,1)+VTOL.delta*cos(VTOL.climbAng),...
     waypoint_mat(end-1,2),...
     waypoint_mat(end-1,3)+VTOL.delta*sin(VTOL.climbAng)];
 
%% Landing Path
hmax = 600;
gammaLandApproach = 85 * pi/180; 
hWpInitLand = 600 * sin( gammaLandApproach ) + 15; 
downWindWpInitLand = 600 * cos( gammaLandApproach ); 

waypoint_landing_W = [-downWindWpInitLand, 0, -hWpInitLand;
                      0, 0, -15;
                      0, 0, -10; 
                      0, 0, -0.1];
VTOL.d_decel = norm(waypoint_landing_W(1,:)-waypoint_landing_W(2,:) ); 

 