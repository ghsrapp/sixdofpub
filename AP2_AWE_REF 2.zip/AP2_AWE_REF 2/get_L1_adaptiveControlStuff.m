function get_L1_adaptiveControlStuff( A_long, B_long, K_long )

% Bandwidths 
wc1 = 10; 
wc2 = 10; 

MxMu =  ([A_long, B_long; C, 0 ] ) \ [zeros(4,1); 1] ; 
Mx = MxMu(1:end-1);
Mu = MxMu(end); 


n = size(A_long,1); 
Cc = zeros(1,n); 
Cc(2) = 1; 
Ap_plus = [A_long, zeros(n,1); 
           -Cc, 0]; 
bp_plus = [B_long;0]; 
br_plus = zeros(n+1,1); 
br_plus(end) = 1; 

% nullspace of bp_plus:
s = 1; t = 0; %
x4 = (-bp_plus(1)*s-bp_plus(2)*t)/bp_plus(4);
v1 = [s;t;1;x4;0]; 

s = 0; t = 1; % x3 and x5 can be set to zero
x4 = (-bp_plus(1)*s-bp_plus(2)*t)/bp_plus(4);
v2 = [s;t;0;x4;0]; 

s = 1; t = 1; % x3 and x5 can be set to zero
x4 = (-bp_plus(1)*s-bp_plus(2)*t)/bp_plus(4);
v3 = [s;t;0;x4;0]; 

s = 0; t = 0; % x3 and x5 can be set to zero
x4 = (-bp_plus(1)*s-bp_plus(2)*t)/bp_plus(4);
v4 = [s;t;0;x4;1]; 

Bp_um_plus = [v1, v2, v3, v4]; % nullspace of bp_plus
Bp_um = Bp_um_plus(1:4,1:3); 

%% Generate reference model (LQR with feedforward)
Q = eye(4); 
Q(1,1) = 0; 
R_long = 10; 
 
R_long = 1; 
Q_long_s = mdiag( Q, 1 ); 
K_long = lqr( Ap_plus, bp_plus, Q_long_s, R_long );
% Feedforward filter 
% MxMu =  ([A_long, B_long; Cc, 0 ] ) \ [zeros(4,1); 1] ; 
% Mx = MxMu(1:end-1);
% Mu = MxMu(end); 
F = K_long(1:end-1)*Mx+Mu;
Am = A_long - B_long*K_long(1:end-1);
Am_plus = Ap_plus - bp_plus*K_long; 

sys = ss(Am, Bm, Cc, [] )
step(sys)




%%
%Am_plus = Ap_plus - bp_plus*K_long(1:end-1);
% Filters 
C1 = wc1/(s+wc1); 
C2 = wc2/(s+wc2); 

s = tf('s'); 
Hm = [Cc,0]*((s*eye(n+1) - Am_plus)\br_plus); 
Hm = [Cc,0]*( (s*eye(n+1) - Am_plus)\(bp_plus*F) ); 
HmInv = 1/Hm;
Hum =  [Cc,0]*((s*eye(n+1) - Am_plus)\Bp_um_plus) ; 

HmInvHum = HmInv*Hum;

C2_H_InvUm = (C1* HmInv*Hum ) 

B_plus = [bp_plus, Bp_um_plus]; 
B = [B_long, Bp_um]; 
Ts = 0.001; 
%Ke_L1 = B_plus \ ( ( (Am_plus\(expm(Am_plus*Ts)-eye(size(Am_plus,1)))) )\expm(Am_plus*Ts) ); 
%Ke_L1 =  inv(B_plus) * inv( expm(Am_plus*Ts) - eye(size(Am_plus,1) ) ) * Am_plus * expm(Am_plus*Ts) ; 

Ke_L1 = inv(B_plus) * inv( ( (inv(Am_plus)*(expm(Am_plus*Ts)-eye(size(Am_plus,1)))) ) ) * expm(Am_plus*Ts) ; 

