function cost = costFunction(x, max_bandwidth,TSIM )%COSTFUNCTION Summary of this function goes here
%   Detailed explanation goes her
x(1:20) = x(1:20)/10; % to get the right accuracy
%% ====== Controller Gains ======
% load opt traction phase controller
x_opt_traction = load('x_best_trac_tmp1.mat');
x(1:28) = x_opt_traction.x;

assignin('base','Kp_mu_traction',x(1));
assignin('base','Kp_alpha_traction',x(2));
assignin('base','Kp_beta_traction',x(3));

assignin('base','Ki_mu_traction',x(4));
assignin('base','Ki_alpha_traction',x(5));
assignin('base','Ki_beta_traction',x(6));

assignin('base','Kp_p',x(7));
assignin('base','Kp_q',x(8));
assignin('base','Kp_r',x(9));

assignin('base','Ki_p',x(10));
assignin('base','Ki_q',x(11));
assignin('base','Ki_r',x(12));

assignin('base','Kp_chi_tau',x(13));

%% ====== Filter Definition ======
assignin('base','w0_mu_traction',x(14)*x(17)*max_bandwidth);
assignin('base','w0_alpha_traction',x(15)*x(18)*max_bandwidth);
assignin('base','w0_beta_traction',x(16)*x(19)*max_bandwidth);

assignin('base','w0_p',x(17)*max_bandwidth);
assignin('base','w0_q',x(18)*max_bandwidth);
assignin('base','w0_r',x(19)*max_bandwidth);

%% ==== Path definitions ====
assignin('base','a_booth',x(20));
assignin('base','b_booth',x(21));
assignin('base','phi0_booth',x(22));

assignin('base','Ki_chi_tau',1*x(23)/10);

assignin('base','F_T_traction_set',5*100+1000);

assignin('base','Kp_chi_tau_trans',x(25)/100);

assignin('base','Kp_gamma_tau_trans',x(26)/100);
assignin('base','Kp_gamma_tau',x(27)/10);
assignin('base','Ki_gamma_tau',x(28)/10);

% retraction
assignin('base','Kp_chi_retract',x(29)/10);
assignin('base','Ki_chi_retract',x(30)/10);

assignin('base','Kp_gamma_retract',x(31)/10);
assignin('base','Ki_gamma_retract',x(32)/10);

assignin('base','v_retraction_opt',x(33));
assignin('base','gamma_retract_opt',x(34));

simOut = sim('AWE_Testbed_opt4', 'CaptureErrors','on');
if simOut.sim_time(end) < TSIM
    cost = 1e15/(simOut.sim_time(end)+1) ;
else
    % cost function as a function of the output of the simulink simulation
    cost = 2*pi/180*norm( simOut.alpha_a_save.Data(:,2) - simOut.alpha_a_save.Data(:,3) )+...
        1*pi/180*norm( simOut.beta_a_save.Data(:,2) - simOut.beta_a_save.Data(:,3) ) +...
        0*pi/180*norm( simOut.eta_tether.Data(:,1) ) +...
        pi/180*norm( simOut.gamma_a_retraction.Data(:,3)-simOut.gamma_a_retraction.Data(:,2)) + ...
         pi/180*norm( simOut.chi_a_retraction.Data(:,3)-simOut.chi_a_retraction.Data(:,2)) + ...
        0.2*norm( simOut.course_tau_traction.Data(:,2) - simOut.course_tau_traction.Data(:,1) ) +...
        norm(simOut.delta_a_meas.Data) + ...
        norm(simOut.delta_e_meas.Data) + ...
        norm(simOut.delta_r_meas.Data) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,1)/max(simOut.omega_OB_rad.Data(:,1))) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,2)/max(simOut.omega_OB_rad.Data(:,2))) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,3)/max(simOut.omega_OB_rad.Data(:,3))); %/length(simOut.sim_time);
    disp(['Current x: ', num2str(x)]);
    disp(['Current cost: ', num2str(cost)]);
    % Sim current controller
    Lbooth.a = x(20)*x(21);
    Lbooth.b = x(21);
    Lbooth.phi0 = x(22)*pi/180;
   % figure(9);
   % clf; drawnow;
   % visualization_stuff = simOut.visualization_stuff;
   % assignin('base','visualization_stuff',visualization_stuff);
   % addpath('Visualization_Offline/')
   % sim('visualize_offline_v2');
   % title(num2str(cost));
    
end


end

