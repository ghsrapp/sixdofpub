function [G_dFt_to_beta, G_dFt_to_beta_unc, So, To ] = getTransferfunctionFromFt_to_beta( path2models, sim_with_indx_vec, K_lat )


load([path2models,'/G_save.mat']);

for k = 1 : length( sim_with_indx_vec )
    ii = sim_with_indx_vec(k);
    
    A = G_save{ii}.A(1:9, 1:9);
    B = G_save{ii}.B(1:9, 1:4);
    A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9);
        A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9);
        A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9);
        A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9);
        A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];
    
    B_lat = [B(2,1),B(2,3);...
        B(4,1),B(4,3);...
        B(6,1),B(6,3);...
        B(7,1),B(7,3);...
        B(9,1),B(9,3)];
    A_lat(3,:) = [];
    A_lat(:,3) = [];
    B_lat(3,:) = [];
    
    %C = zeros(2, 5);
    C = zeros(2, size(B_lat,1));
    C(1,1) = 1;
    C(2,2) = 1;
    
    
    A_lat_s(:,:,k) = [A_lat, zeros(size(A_lat,1),2);
        -C, zeros(2)];
    B_lat_s(:,:,k) = [B_lat; zeros(2)];
    
    
    G_aug = ss( A_lat_s, B_lat_s, eye( size(A_lat_s,1) ), [] ); 
    Li = K_lat*G_aug; 
  %  [gm,ph] = margin( Li ); 
   % gm_save(k) = gm;
   % ph_save(k) = ph;
    
    dFt_max = 1; % for scaling
    E_lat = [B(2,4);B(4,4);B(7,4);B(9,4)]*dFt_max;
   % E_prime = ( ( B_long'*B_long )\B_long' )*E_long; 

    Kp = K_lat(:,1:end-2); 
    s = tf('s');
    Ki = -K_lat(:,1:2)/s; 
    C_cl = C; 
    A_cl = A_lat - B_lat*Kp; 
    B_cl = B_lat; 
    G_prime = ss( A_cl, B_cl, C_cl, [] ); 
   
   % C_cl = C_cl(1,:); 
    Gd =  C_cl * 1/(s*eye( size(A_cl,1) ) - A_cl )*E_lat; 
    
    Lo = G_prime * Ki; 
    So{k} = 1/(eye(2)+G_prime*Ki); 
    To{k} = eye(2) - So{k}; 
    
    G_dFt_to_beta{k} =  So{k}*Gd; 
    G_dFt_to_beta_unc{k} = ss( A_lat, E_lat, C_cl, [] ); 
end


