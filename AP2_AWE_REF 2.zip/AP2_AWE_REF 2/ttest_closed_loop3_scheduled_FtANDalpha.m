clear all
%close all
clc

sim_with_indx = 1;
min_trim_indx = 1;
max_trim_indx = 12;

Simulink.sdi.clear;
trim_test_flag = 0;
EA_Flag = 1;
get_controller_set_flag = 1;
opt_flag = 1;
converged_flag = 0;
addpath(genpath('MiscFiles'))

addpath(genpath('AWESTRIM'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))
s = [pi/2, 2*pi];

% ============== Initialize the simulation ==================================================================================================
%path_with_gains = 'Trim_results/case_1_test03'; % works with these models
path_with_gains = 'Trim_results/case_1_phi35_mix_ft_and_alpha';
%path_with_gains = 'Trim_results/case_1_phi35_mix_ft_and_denser_alpha';

addpath(path_with_gains);

load('G_save.mat');
load('rps_st.mat');
load('x0_save.mat');
load('u0_save.mat');
load('M_OB_init.mat');

sim_with_indx = min_trim_indx;   % 2;
x0_sim = x0_save(:,sim_with_indx);
u0_sim = u0_save(:,sim_with_indx);

if trim_test_flag % for trim test
    lat_in = x0_sim(11); %80*pi/180;
else
    lat_in = 80*pi/180; %
end
% Initialze position at higher elevation angles.

x0_sim(11) = lat_in;
x0_sim(12) = 300;

pos_init_W = [cos( x0_sim(10) ) * cos( lat_in );
    sin( x0_sim(10) ) * cos( lat_in );
    sin( lat_in )]*x0_sim(12);

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams_variable_p_init_W(pos_init_W);

opt_cnt = 1;

% bounds for longi PI-LQR
qs = [0, 30, 0, 0, 50];
qs = [30,0,0,50];
qs_lbounds = 0*ones( length( qs ),1);
qs_lbounds(end) = 1;
qs_ubounds = 100*ones( length( qs ),1);
Q_long = diag( [0, qs] );
R_long = 1;

% bounds
% T_R_Des = opt_params(1); % Rolltime constant
% T_S_Des = opt_params(2); %1/5; %1/w0s(end); % spiral mode
% zeta_DR_des = opt_params(3); %1/sqrt(2);
% w0_DR_des = opt_params(4); %w0s(2);

lat_low_bounds = [1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3];
lat_up_bounds = [10; 10; 1; 10; 10; 10];
lat_p_init = [0.04; 1/5; 1/sqrt(2); 3.86;4;4];
cnt = 1;
[time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();

if get_controller_set_flag % adaptive part is not schedulable at the moment
    %%
    for alpha_c = 1 : 6
        for ft_c = 1 : 3
            
            [x0_trim,u0_trim,K_long,K_lat, A_long, B_long, A_lat, B_lat] =  generateTractionPhaseController( cnt, EA_Flag, act, path_with_gains, Q_long, R_long );
            sys_trim.A_long = A_long;
            sys_trim.B_long = B_long;
            sys_trim.A_lat = A_lat;
            sys_trim.B_lat = B_lat;
            
            save('sys_trim.mat', 'sys_trim');
            
            K_long_mat(ft_c, alpha_c, :) = K_long;
            
            K_lat_aileron_mat(ft_c, alpha_c, :)  = K_lat(1,:);
            K_lat_rudder_mat(ft_c, alpha_c, :)  = K_lat(2,:);
            
            A_long_save(:,:,cnt) = A_long;
            B_long_save(:,:,cnt) = B_long;
            
            lambdas_long(:,cnt) = eig( A_long - B_long * K_long );
            
            A_lat_save(:,:,cnt) = A_lat;
            B_lat_save(:,:,cnt) = B_lat;
            
            lambdas_lat(:,cnt) = eig( A_lat - B_lat * K_lat );
            
            opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
            [stabmarg, CL] = getRobStabMargin_long( A_long, B_long, squeeze( K_long_mat(ft_c, alpha_c, :) )', [0,1,0,0,0], opts, frequ_domain_ref_long);
            stabmarg
            %margins = getRobStabMargin_lat( A_lat, B_lat, K_lat, [1,0,0,0,0,0;
            %   0,1,0,0,0,0], opts ); 
            figure; 
            step( CL.NominalValue ); drawnow; 
            cnt = cnt + 1;
        end
    end
    x0_save_res(1,:,:) = x0_save(:,1:6)';
    x0_save_res(2,:,:) = x0_save(:,7:12)';
    x0_save_res(3,:,:) = x0_save(:,13:18)';
    
    u0_save_res(1,:,:) = u0_save(:,1:6)';
    u0_save_res(2,:,:) = u0_save(:,7:12)';
    u0_save_res(3,:,:) = u0_save(:,13:18)';
    %%
%      x0_save_res(1,:,:) = x0_save(:,1:11)';
%     x0_save_res(2,:,:) = x0_save(:,12:22)';
%     x0_save_res(3,:,:) = x0_save(:,23:33)';
%      x0_save_res(4,:,:) = x0_save(:,34:44)';
%     x0_save_res(5,:,:) = x0_save(:,45:55)';
%     x0_save_res(6,:,:) = x0_save(:,56:66)';
%      x0_save_res(7,:,:) = x0_save(:,67:77)';
%     x0_save_res(8,:,:) = x0_save(:,78:88)';
%     
%     u0_save_res(1,:,:) = u0_save(:,1:11)';
%     u0_save_res(2,:,:) = u0_save(:,12:22)';
%     u0_save_res(3,:,:) = u0_save(:,23:33)';
%     u0_save_res(4,:,:) = u0_save(:,34:44)';
%     u0_save_res(5,:,:) = u0_save(:,45:55)';
%     u0_save_res(6,:,:) = u0_save(:,56:66)';
%     u0_save_res(7,:,:) = u0_save(:,67:77)';
%     u0_save_res(8,:,:) = u0_save(:,78:88)';
    
    %% get the paramter bounds
    % C = [0, 1, 0, 0, 0];
    %  margins = getRobStabMargin_2( A_long_save, B_long_save, K_long,  C );
    % s = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95])
    
else
    sim_with_indx = 8;
    [x0_trim,u0_trim,K_long,K_lat, A_long, B_long, A_lat, B_lat] =  generateTractionPhaseController( sim_with_indx, EA_Flag, act, path_with_gains,  Q_long, R_long );
    opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
    [stabmarg, CL] = getRobStabMargin_long( A_long, B_long,K_long, [0,1,0,0,0], opts, frequ_domain_ref_long);
    s = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
end


%[x0_trim,u0_trim,K_long,F_long, HmInvHum, Ke_L1, Ts, Am, Bp_um, B_aug, Bm] =  generateTractionPhaseController_FF( sim_with_indx );

%%
sim_with_indx = 1;


[x0_trim_retract,u0_trim_retract,K_long_retract,K_lat_retract, HmInvHum_retract,...
    Ke_L1_retract, C1, Ts, F_long_retract, Kbl_retract, Am_retract, Bp_um_retract, B_aug_retract, Br_retract, A_long_aug, B_long_aug, A_lat_aug, B_lat_aug] =  generateRetractionPhaseController( sim_with_indx );



%%
%%
l_tether = x0_sim(12);
Lbooth.init_sol = s(sim_with_indx);
windDirection_rad = ENVMT.windDirection_rad;
gamma_tau = 0;
vel_w_W = [9;0;0];
M_OW = [cos(windDirection_rad), sin(windDirection_rad), 0;
    sin(windDirection_rad), -cos(windDirection_rad), 0;
    0, 0, -1];
%M_OB = M_OB_init{sim_with_indx};
M_tauW = [-sin(lat_in)*cos(x0_sim(10)), -sin(lat_in)*sin(x0_sim(10)), cos(lat_in);
    -sin(x0_sim(10)), cos(x0_sim(10)), 0;
    -cos(lat_in)*cos(x0_sim(10)), -cos(lat_in)*sin(x0_sim(10)), -sin(lat_in)];
phi_t = x0_sim(4); theta_t = x0_sim(5); psi_t = x0_sim(6);
M_tauB = [ cos(psi_t)*cos(theta_t), cos(psi_t)*sin(phi_t)*sin(theta_t) - cos(phi_t)*sin(psi_t), sin(phi_t)*sin(psi_t) + cos(phi_t)*cos(psi_t)*sin(theta_t);
    cos(theta_t)*sin(psi_t), cos(phi_t)*cos(psi_t) + sin(phi_t)*sin(psi_t)*sin(theta_t), cos(phi_t)*sin(psi_t)*sin(theta_t) - cos(psi_t)*sin(phi_t);
    -sin(theta_t),                              cos(theta_t)*sin(phi_t),                              cos(phi_t)*cos(theta_t)];
M_OB = M_OW * M_tauW' * M_tauB;
M_BO = M_OB';
phi = atan2( M_OB(3,2) , M_OB(3,3) );
theta = -asin( M_OB(3,1) );
psi = atan2( M_OB(2,1) , M_OB(1,1) );
EULER_init = [phi;theta;psi];

params.a_booth = 0.5;
params.b_booth = 160;
params.phi0_booth =  30*pi/180;

vel_w_B = M_BO*M_OW*vel_w_W;
alpha = x0_sim(3);
beta = x0_sim(2);
Va = x0_sim(1);
M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
    -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
    -sin(alpha), 0, cos(alpha)];
M_BA = M_AB';
v_k_B_init = vel_w_B + M_BA*[Va;0;0];
v_k_O_init = M_OB*v_k_B_init;
v_a_O = v_k_O_init - transformFromWtoO( windDirection_rad, vel_w_W );
v_k_W_init = M_OW'*v_k_O_init;
pathangles_k_init(1) = atan2( v_k_O_init(2), v_k_O_init(1) );
pathangles_k_init(2) = -asin( v_k_O_init(3)/norm(v_k_O_init) );
chi_a = atan2( v_a_O(2), v_a_O(1) );
gamma_a = -asin( v_a_O(3)/norm(v_a_O) );
pathangles_a = [chi_a; gamma_a];
mu_a_init = asin( max( min( (cos(EULER_init(2))*sin(EULER_init(1)))/(cos(gamma_a)*cos(0)) + tan(gamma_a) * tan(0), 1),-1) );

%
Phi_traction_vec = 35*pi/180;%[30, 40]*pi/180;
Ft_set_vec = 1800;%[800,1300,1800];
base_windspeed_vec = 10;%[4, 7, 10]; %[4,10];
adaptive_controller_flag_vec = 0;
cnt = 1;
cnta = 1;
params_mat = [];
%%
if trim_test_flag
    phi_trac = x0_save(11);
    ad_flag = 0;
    Ft_set = u0_save(4);
    base_windspeed = 10;
    close all;
    yout = sim('AWES3_CL_BL_designModelTraction','ReturnWorkspaceOutputs','on');
else
    for n = 1 : length( adaptive_controller_flag_vec )
        ad_flag = adaptive_controller_flag_vec(n);
        for k = 1 : length( Phi_traction_vec )
            phi_trac = Phi_traction_vec(k);
            
            for l = 1 : length( Ft_set_vec )
                Ft_set = Ft_set_vec(l);
                for z = 1 : length( base_windspeed_vec )
                    base_windspeed = base_windspeed_vec(z);
                    %break;
                    ad_flag = 0;
                    close all;
                    fprintf('Simulation running...');
                    yout = sim('AWES3_CL_wTether_v2','ReturnWorkspaceOutputs','on');s
                    if ad_flag == 0
                        yout_baseline{cnt} = yout;
                        fprintf('Done %.1f \n', cnt );
                        cnt = cnt + 1;
                    else
                        yout_adaptive{cnta} = yout;
                        fprintf('Adaptive sim done %.1f \n', cnta );
                        cnta = cnta + 1;
                    end
                    params_mat = [params_mat; [ad_flag, phi_trac*180/pi, Ft_set/1000, base_windspeed]];
                end
            end
        end
    end
    %%
    close all;
    folder_name_results = 'case_SLQR_diffWS';
    lw = 1.2;
    col1 =  [ 57/255, 106/255, 177/255  ];
    col2 =  [218/255, 124/255, 48/255 ];
    col3 =  [62/255, 150/255, 81/255 ];
    col4 =  [255/255, 102/255, 102/255];
    alpha_lvl = 1;
    for cnt = 1 : length( base_windspeed_vec )
        N = length( yout_baseline{cnt}.TetherForce.Data(:,1) );
        samplesPerCycle = floor( N/yout_baseline{cnt}.cycleCounter.Data(end) );
        numbConsideredCycles = 1;
        from_sample = max( N - samplesPerCycle*numbConsideredCycles, 1);
        cd Trim_results
        if ~exist( folder_name_results )
            mkdir( folder_name_results );
        end
        cd(folder_name_results);
        sim_out = yout_baseline{cnt};
        save(['sim_out_',num2str(base_windspeed_vec(cnt)),'.mat'], 'sim_out');
        
        h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,2)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        axis([ yout_baseline{cnt}.alpha_save.Time(from_sample), yout_baseline{cnt}.alpha_save.Time(end), -10 15]);
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
        
        h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.sideslip.Time(from_sample:end), yout_baseline{cnt}.sideslip.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$\beta_a$ $(deg)$');
        axis([ yout_baseline{cnt}.sideslip.Time(from_sample), yout_baseline{cnt}.sideslip.Time(end), -15 15]);
        
        h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$F_t$ $(N)$');
        axis([yout_baseline{cnt}.TetherForce.Time(from_sample) yout_baseline{cnt}.TetherForce.Time(end) 0 2]);
        
        h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$x_W$ $(m)$');
        ylabel('$z_W$ $(m)$');
        axis tight
        
        
        h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$x_W$ $(m)$');
        ylabel('$y_W$ $(m)$');
        axis tight
        
        h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,1), 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,1), 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$x_W$ $(m)$');
        axis tight
        
        h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$y_W$ $(m)$');
        axis tight
        
        h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$z_W$ $(m)$');
        axis tight
        
        
        Plot2LaTeX(h1,['angleofattack_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        Plot2LaTeX(h2,['sideslip_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        Plot2LaTeX(h3,['Tetherforce_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        
        Plot2LaTeX(h4,['path_xz',num2str(base_windspeed_vec(cnt) ) ]);
        Plot2LaTeX(h5,['path_xy',num2str(base_windspeed_vec(cnt) ) ]);
        
        Plot2LaTeX(h6,['path_x_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        Plot2LaTeX(h7,['path_y_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        Plot2LaTeX(h8,['path_z_vw_',num2str(base_windspeed_vec(cnt) ) ]);
        cd ..
        cd ..
    end
    
    
end




%%
%close all
if 0
    cnt_idx = [1,2, 11, 12];
    cd Trim_results
    if 1
        load('yout_baseline.mat');
        load('yout_adaptive.mat');
    end
    
    for k = 1 : length( cnt_idx )
        close all;
        cnt = cnt_idx(k);
        h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
        axis tight
        % figure;
        % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        % h_bl_ref.Color(4) = alpha_lvl;
        % h_bl.Color(4) = alpha_lvl;
        % xlabel('$Time$ $(s)$');
        % ylabel('$F_t$ $(kN)$');
        
        h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on;
        h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2); hold on;
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
        axis tight
        
        h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl_ref.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$F_t$ $(kN)$');
        axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
        
        h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl_ref.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$F_t$ $(kN)$');
        axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
        
        h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_baseline{cnt}.target_pos.Data(:,1),...
            yout_baseline{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_baseline{cnt}.pos_W.Data(:,1),...
            yout_baseline{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 -300 300 ])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$y_W$ $(m)$');
        
        h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
            yout_adaptive{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
            yout_adaptive{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([ 0 600 -300 300])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$y_W$ $(m)$');
        
        h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_baseline{cnt}.target_pos.Data(:,1),...
            yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_baseline{cnt}.pos_W.Data(:,1),...
            yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 100 500])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$z_W$ $(m)$');
        
        h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
            yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
            yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 100 500])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$z_W$ $(m)$');
        
        
        Plot2LaTeX(h1,['only_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h2,['only_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h3,['Ftonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h4,['Ftonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        
        Plot2LaTeX(h5,['xyonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h6,['xyonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h7,['xzonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h8,['xzonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        
        
        
        
    end
    cd ..
    % figure;
    % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    % h_bl_ref.Color(4) = alpha_lvl;
    % h_bl.Color(4) = alpha_lvl;
    % xlabel('$Time$ $(s)$');
    % ylabel('$F_t$ $(kN)$');
    % %
    % figure;
    % h_bl_ref = plot3( yout_baseline{cnt}.target_pos.Data(:,1),...
    %     yout_baseline{cnt}.target_pos.Data(:,2),...
    %     yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot3( yout_baseline{cnt}.pos_W.Data(:,1),...
    %     yout_baseline{cnt}.pos_W.Data(:,2),...
    %     yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
    % axis equal
    
    % figure;
    % h_bl_ref = plot3( yout_adaptive{cnt}.target_pos.Data(:,1),...
    %     yout_adaptive{cnt}.target_pos.Data(:,2),...
    %     yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot3( yout_adaptive{cnt}.pos_W.Data(:,1),...
    %     yout_adaptive{cnt}.pos_W.Data(:,2),...
    %     yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
end