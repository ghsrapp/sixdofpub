%% Groundstation
winchParameter.radius = 0.1;
winchParameter.inertia = 0.08;
winchParameter.friction = 0.6;
winchParameter.slackKonstant = 1; %pi*winchParameter.radius;%0.3; 0.3;
winchParameter.omega = 10;
winchParameter.damp = 0.9;
winchParameter.Aref = [0, 1; -winchParameter.omega^2,-2*winchParameter.damp * winchParameter.omega ];
winchParameter.Bref = [0;winchParameter.omega^2];
winchParameter.Kp = 1;
winchParameter.Kd = 60;
winchParameter.Ki = 20;
winch_angle_init = tether_inital_lenght/winchParameter.radius;


%% Winch Controller
% LQR control
Q = diag([0.5,0.5]);% was 10 20
R = 0.1;2;

winchParameter.A = [-winchParameter.friction*0/winchParameter.inertia, 0;
    -1, 0];
winchParameter.B = [1/winchParameter.inertia ;0];

winchParameter.K_lqr = lqr( winchParameter.A, winchParameter.B, Q, R ); % Baseline controller?

winchParameter.Bref = [0;1]; 
winchParameter.Aref = winchParameter.A  - winchParameter.B * winchParameter.K_lqr; 

winchParameter.N = -inv( [-0/winchParameter.inertia, 1/winchParameter.inertia; 1, 0] ) * [winchParameter.radius/winchParameter.inertia; 0]; % dyn. disturbance compensation 

winchParameter.Nu = winchParameter.N(2); 

%% Feedforward LQR
Qs = 0.1*eye(2);
%Qs(2,2) = 0.5; 
Rs = 1; 
winchParameter.Klqr_s_ff = lqr(winchParameter.A ,winchParameter.B,Qs,Rs); 
%winchParameter.omega_max = 5/winchParameter.radius;
%winchParameter.omega_min = gs.va_retract/winchParameter.radius;



