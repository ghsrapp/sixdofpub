function Gd_scaled = extractDisturbanceGd( A_long, B_long_wFt, constr, act )

% extract Gd 
sys = ss( A_long, B_long_wFt, [0, 1, 0, 0], [] ); 

Gtot = tf(sys); 

G = Gtot(1); 

Gd = Gtot(2); 

% scaling
De = diag([constr.alpha_a_max]); 
Du = diag([act.elevator.max_deflection]); 
Dd = 200; 
G_scaled = inv(De)*G*Du;
Gd_scaled = inv(De)*Gd*Dd;
