function [ element_all ] = createBusElement(element_all,  name, dim )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

element = Simulink.BusElement;
element.Name = name;
element.Dimensions = dim;
element.DimensionsMode = 'Fixed';
element.DataType = 'double';
element.SampleTime = -1;
element.Complexity = 'real';

element_all = [element_all, element];

end

