%clear switchSolver3; % clear the persistent variables in switchSolver3

init_new_AP2;
TSIM = 500; 

load('paramStruct.mat');
load('pop_current.mat');
x = pop_current(1,:);

x(1:18) = x(1:18)/10;  % to get the right accuracy
assignOptVariables2SimWorkspace;

%allocateOptVariables2Struct;

% Test
Lbooth.a = paramStruct.a_booth*paramStruct.b_booth;
Lbooth.b = paramStruct.b_booth;
Lbooth.phi0 = paramStruct.phi0_booth; 

%% simulate
sim('testAWE_Testbed_opt4b');
assignin('base', 'visualization_stuff', visualization_stuff );

%% Visualize
addpath('Visualization_Offline');
sim('visualize_offline_v2');
drawBooth;
rmpath('Visualization_Offline\');


%% print some results + high level set points
clc
disp(['Mean power output: ', num2str(mean( power_vr_tether.Data(:,1))/1000), ' kW' ]);
disp(['Tether force set point: ', num2str( paramStruct.F_T_traction_set), ' N' ]);
disp(['Mean elevation angle: ', num2str(paramStruct.phi0_booth*180/pi), ' degrees' ]);
disp(['path height: ', num2str(paramStruct.a_booth*paramStruct.b_booth), ' m' ]);
disp(['path width: ', num2str(paramStruct.b_booth), '  m' ]);

