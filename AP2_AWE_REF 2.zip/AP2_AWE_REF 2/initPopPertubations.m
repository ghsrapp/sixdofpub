Kp_p_traction_pert = max( min( Kp_p_traction*10 + randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);
Kp_q_traction_pert = max( min( Kp_q_traction*10 + randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);
Kp_r_traction_pert = max( min( Kp_r_traction*10 + randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);

Ki_p_traction_pert = max( min( Ki_p_traction*10+ randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);
Ki_q_traction_pert = max( min( Ki_q_traction*10 + randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);
Ki_r_traction_pert = max( min( Ki_r_traction*10 + randi([-delta_gains_rates,delta_gains_rates],numPop,1), max_gains_rates), min_gains_rates);

w0_p_traction_pert = max( min( w0_p_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);
w0_q_traction_pert = max( min( w0_q_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);
w0_r_traction_pert = max( min( w0_r_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);

w0_mu_traction_pert = max( min( w0_mu_traction/w0_p_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);
w0_alpha_traction_pert = max( min( w0_alpha_traction/w0_q_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);
w0_beta_traction_pert = max( min( w0_beta_traction/w0_r_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);

Kp_chi_tau_traction_pert = max( min( Kp_chi_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);
Ki_chi_tau_traction_pert = max( min( Kp_chi_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);
Kp_chi_tau_trans_pert = max( min(    Kp_chi_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);

Kp_gamma_tau_traction_pert = max( min( Kp_gamma_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);
Ki_gamma_tau_traction_pert = max( min(  Kp_gamma_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);
Kp_gamma_tau_trans_pert = max( min(    Kp_gamma_tau_traction*100 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_path), min_Kp_path);

Kp_mu_traction_pert = max( min( Kp_mu_traction*10 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_att), min_Kp_att);
Kp_alpha_traction_pert = max( min(  Kp_alpha_traction*10 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_att), min_Kp_att);
Kp_beta_traction_pert = max( min(    Kp_beta_traction*10 + randi([-10,10],numPop,1) ,max_Kp_att), min_Kp_att);

Ki_mu_traction_pert = max( min( Ki_mu_traction*10 + randi([-delta_pert_path,delta_pert_path],numPop,1), max_Kp_att), min_Kp_att);
Ki_alpha_traction_pert = max( min(  Ki_alpha_traction*10 + randi([-delta_pert_path,delta_pert_path],numPop,1), max_Kp_att), min_Kp_att);
Ki_beta_traction_pert = max( min(    Ki_beta_traction*10 + randi([-delta_pert_path,delta_pert_path],numPop,1) ,max_Kp_att), min_Kp_att);

a_booth_pert = max( min( a_booth*10 + randi([-delta_a_booth,delta_a_booth],numPop,1), max_a_booth), min_a_booth);
b_booth_pert = max( min( b_booth + randi([-delta_b_booth,delta_b_booth],numPop,1), max_b_booth), min_b_booth);
phi_booth_pert = max( min(   phi0_booth*180/pi + randi([-delta_phi,delta_phi],numPop,1) ,max_phi), min_phi);

F_t_pert = max( min(   F_T_traction_set + randi([-delta_F_t,delta_F_t],numPop,1) ,max_F_t), min_F_t);
