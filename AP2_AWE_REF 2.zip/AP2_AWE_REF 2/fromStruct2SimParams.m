%% ---------------------------- TRACTION ----------------------------
% Bandwidths
assignin('base','w0_mu_traction',paramStruct.w0_mu_traction);
assignin('base','w0_alpha_traction',paramStruct.w0_alpha_traction);
assignin('base','w0_beta_traction',paramStruct.w0_beta_traction);

assignin('base','w0_p_traction',paramStruct.w0_p_traction);
assignin('base','w0_q_traction',paramStruct.w0_q_traction);
assignin('base','w0_r_traction',paramStruct.w0_r_traction);

% Gains
assignin('base','Kp_chi_tau_traction',paramStruct.Kp_chi_tau_traction);
assignin('base','Ki_chi_tau_traction',paramStruct.Ki_chi_tau_traction);
assignin('base','Kp_chi_tau_trans',paramStruct.Kp_chi_tau_trans);
assignin('base','Kp_gamma_tau_trans',paramStruct.Kp_gamma_tau_trans);
assignin('base','Kp_gamma_tau_traction',paramStruct.Kp_gamma_tau_traction);
assignin('base','Ki_gamma_tau_traction',paramStruct.Ki_gamma_tau_traction);

assignin('base','Kp_mu_traction',paramStruct.Kp_mu_traction);
assignin('base','Kp_alpha_traction',paramStruct.Kp_alpha_traction);
assignin('base','Kp_beta_traction',paramStruct.Kp_beta_traction);
assignin('base','Ki_mu_traction',paramStruct.Ki_mu_traction);
assignin('base','Ki_alpha_traction',paramStruct.Ki_alpha_traction);
assignin('base','Ki_beta_traction',paramStruct.Ki_beta_traction);

assignin('base','Kp_p_traction',paramStruct.Kp_p_traction);
assignin('base','Kp_q_traction',paramStruct.Kp_q_traction);
assignin('base','Kp_r_traction',paramStruct.Kp_r_traction);
assignin('base','Ki_p_traction',paramStruct.Ki_p_traction);
assignin('base','Ki_q_traction',paramStruct.Ki_q_traction);
assignin('base','Ki_r_traction',paramStruct.Ki_r_traction);

assignin('base','a_booth',paramStruct.a_booth); %0.7;
assignin('base','b_booth',paramStruct.b_booth);% 90/100;
assignin('base','phi0_booth',paramStruct.phi0_booth);
assignin('base','F_T_traction_set',paramStruct.F_T_traction_set)