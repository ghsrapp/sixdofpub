
if 0 % lissajous
% Create initial population
FCS.Kp_chi_predictive = par(cnt,1);
FCS.Kp_mu_traction = par(cnt, 2);
FCS.Ki_mu_traction =  par(cnt, 3) ;
FCS.Kp_p =  par(cnt, 4);
FCS.Ki_p =  par(cnt, 5);
FCS.Kp_alpha_traction =  par(cnt, 6);
FCS.Ki_alpha_traction =  par(cnt, 7);
FCS.Kp_q =   par(cnt, 8);
FCS.Ki_q =  par(cnt, 9);
FCS.Kp_beta =   par(cnt, 10);
FCS.Ki_beta =   par(cnt, 11);
FCS.Kp_r = par(cnt, 12);
FCS.Ki_r =  par(cnt, 13);

FCS.w0_p = par(cnt, 14);%35;%factor_w0_p;
FCS.w0_q =  par(cnt, 15);
FCS.w0_r =  par(cnt, 16);

FCS.w0_mu_traction =  par(cnt, 17)*FCS.w0_p;
FCS.w0_alpha_traction =  par(cnt, 18)*FCS.w0_q ;
FCS.w0_beta =  par(cnt, 19)*FCS.w0_r;

else
    % Create initial population
FCS.Kp_chi_predictive = par(cnt,1);
FCS.Kp_mu_traction = par(cnt, 2);
FCS.Ki_mu_traction =  par(cnt, 3) ;
FCS.Kp_p =  par(cnt, 4);
FCS.Ki_p =  par(cnt, 5);
FCS.Kp_alpha_traction =  par(cnt, 6);
FCS.Ki_alpha_traction =  par(cnt, 7);
FCS.Kp_q =   par(cnt, 8);
FCS.Ki_q =  par(cnt, 9);
FCS.Kp_beta =   par(cnt, 10);
FCS.Ki_beta =   par(cnt, 11);
FCS.Kp_r = par(cnt, 12);
FCS.Ki_r =  par(cnt, 13);

FCS.w0_p = par(cnt, 14);%35;%factor_w0_p;
FCS.w0_q =  par(cnt, 15);
FCS.w0_r =  par(cnt, 16);

FCS.w0_mu_traction =  par(cnt, 17)*FCS.w0_p;
FCS.w0_alpha_traction =  par(cnt, 18)*FCS.w0_q ;
FCS.w0_beta =  par(cnt, 19)*FCS.w0_r;
  
FCS.w0_chi = par(cnt, 20)*FCS.w0_mu_traction;
FCS.w0_gamma = par(cnt, 21)*FCS.w0_alpha_traction;

FCS.Kp_chi = par(cnt, 22);
FCS.Ki_chi = par(cnt, 23);

FCS.Kp_gamma = par(cnt, 24);
FCS.Ki_gamma = par(cnt, 25);


end