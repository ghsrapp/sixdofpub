clear all
close all
clc

init_new_AP2; % initializes the simulation (needs to be called once)
TSIM = 100; % simulation time
load('pop_current'); % initial working set of parameters 
assignOptVariables2SimWorkspace2(max_bandwidth,x); % allocate opt variables to sim variable names
[lb,ub] = initOptParamsBounds(); % init upper and lower bounds of the parameters
logOptParams; % basically creates a folder to log best individuals

% test if simulation runs 
testOptimizedController_v3; 



% to be optimized parameters are in x, the rest are just parameters.
% funtion returns the current cost.
FitnessFunction = @(x)costFunctionAP2b(x,maxBandwidth,TSIM, gs, alpha_a_max);

% should be called after one generation is simulated and ranked. The
% function exports the currently best individuum to a text file. 
cd 'params'
exportTmpBestParams2;
cd .. 