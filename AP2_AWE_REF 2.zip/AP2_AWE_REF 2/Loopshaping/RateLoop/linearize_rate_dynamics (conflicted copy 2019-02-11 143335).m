
sys = 'rate_dynamics';
open_system(sys); 

Va_trim = 60; 
alpha_trim = 0; 

io(1) = linio('rate_dynamics/Constant2',1,'input');
io(2) = linio('rate_dynamics/Integrator',1,'output');
linsys1 = linearize(sys,io); 

%% Servo PI controller for tracking rates
A = linsys1.A; 
B = linsys1.B; 
C = linsys1.C; 
D = linsys1.D; 

As = [A,zeros(3); 
      -C, zeros(3)];
Bs = [B;zeros(3)];

Q = diag([1,1,1,10,10,10]); 
R = 100*diag([1,1,1]); 

Klqr_s = lqr(As,Bs,Q,R); 


