klqr_high = load('Klqr_s_high.mat'); 
klqr_low = load('Klqr_s_low.mat');

Va_max = 60; 
Va_middle = 45;
Va_min = 35; 
sys = 'rate_dynamics';
open_system(sys); 
x_init = zeros(3,1); 


alpha_trim = 0; 
io(1) = linio('rate_dynamics/Constant2',1,'input');
io(2) = linio('rate_dynamics/Integrator',1,'output');
Va_trim = Va_max; 
linsys1 = linearize(sys,io); 

p = [-40;
   -15;
   -5;
   -20.9413;
   -100.9444;
  -93.7472;];



%% Servo PI controller for tracking rates
Ahigh = linsys1.A; 
Bhigh = linsys1.B; 
Chigh = linsys1.C; 
Dhigh = linsys1.D; 
As_high = [Ahigh,zeros(3); 
      -Chigh, zeros(3)];
Bs_high = [Bhigh;zeros(3)];

Q = diag([1,10,10,100,300,250]); 
R = 4*diag([1,4,1]); 
%Klqr_s = lqr(As_high,Bs_high,Q,R); 

Klqr_s = place( As_high, Bs_high, p ); 

save('Klqr_s_high.mat', 'Klqr_s'); 
klqr_high = load('Klqr_s_high'); 

eig(As_high - Bs_high*Klqr_s)

%%  middle loop
%% Servo PI controller for tracking rates
Va_trim = Va_middle; 
linsys3 = linearize(sys,io); 
Amid = linsys3.A; 
Bmid = linsys3.B; 
Cmid = linsys3.C; 
Dmid = linsys3.D; 
As_mid = [Amid,zeros(3); 
      -Cmid, zeros(3)];
Bs_mid = [Bmid;zeros(3)];

Q = diag([1,10,10,100,300,250]); 
R = 4*diag([1,4,1]); 
Klqr_s = place( As_mid, Bs_mid, p ); 

save('Klqr_s_mid.mat', 'Klqr_s'); 
klqr_mid = load('Klqr_s_mid'); 

eig(As_mid - Bs_mid*Klqr_s)

%% Servo PI controller for tracking rates
Va_trim = Va_min; 
alpha_trim = 0; 
linsys2 = linearize(sys,io); 
Alow = linsys2.A; 
Blow = linsys2.B; 
Clow = linsys2.C; 
Dlow = linsys2.D; 
As_low = [Alow,zeros(3); 
      -Clow, zeros(3)];
Bs_low = [Blow;zeros(3)];
Q = diag([1,10,12,150,350,250]); 
R = 0.3*diag([1,1,1]); 
%Klqr_s = lqr(As_low,Bs_low,Q,R); 
Klqr_s  = place( As_low, Bs_low, p ); 


save('Klqr_s_low.mat', 'Klqr_s'); 

eig(As_low - Bs_low*Klqr_s)
%damp(As_low - Bs_low*Klqr_s)

klqr_low = load('Klqr_s_low'); 


