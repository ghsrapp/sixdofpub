
sys = 'rate_dynamics';
open_system(sys); 
%u = zeros(3,1); 
%x = zeros(3,1); 
%x = Simulink.BlockDiagram.getInitialState(sys);
%[A,B,C,D] = linmod('rate_dynamics',x,u);


io(1) = linio('rate_dynamics/input',1,'input');
io(2) = linio('rate_dynamics/output',1,'openoutput');
linsys1 = linearize(sys,io); 