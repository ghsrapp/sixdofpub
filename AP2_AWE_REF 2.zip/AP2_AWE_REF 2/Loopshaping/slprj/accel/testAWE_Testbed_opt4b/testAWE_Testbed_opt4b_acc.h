#include "__cf_testAWE_Testbed_opt4b.h"
#ifndef RTW_HEADER_testAWE_Testbed_opt4b_acc_h_
#define RTW_HEADER_testAWE_Testbed_opt4b_acc_h_
#include <stddef.h>
#include <float.h>
#include <string.h>
#ifndef testAWE_Testbed_opt4b_acc_COMMON_INCLUDES_
#define testAWE_Testbed_opt4b_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "testAWE_Testbed_opt4b_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T B_76_0_0 ; real_T B_76_1_0 ; real_T B_76_2_0 ; real_T
B_76_3_0 ; real_T B_76_5_0 [ 4 ] ; real_T B_76_7_0 [ 3 ] ; real_T B_76_8_0 ;
real_T B_76_11_0 ; real_T B_76_16_0 [ 3 ] ; real_T B_76_18_0 [ 3 ] ; real_T
B_76_25_0 ; real_T B_76_30_0 ; real_T B_76_34_1 ; real_T B_76_37_0 [ 3 ] ;
real_T B_76_38_0 ; real_T B_76_46_0 ; real_T B_76_53_0 ; real_T B_76_54_0 ;
real_T B_76_55_0 [ 3 ] ; real_T B_76_56_0 [ 3 ] ; real_T B_76_57_0 [ 3 ] ;
real_T B_76_58_0 ; real_T B_76_60_0 ; real_T B_76_62_0 [ 3 ] ; real_T
B_76_63_0 [ 3 ] ; real_T B_76_70_0 [ 3 ] ; real_T B_76_73_0 ; real_T
B_76_75_0 ; real_T B_76_76_0 ; real_T B_76_80_0 [ 3 ] ; real_T B_76_82_0 [ 3
] ; real_T B_76_84_0 ; real_T B_76_86_0 ; real_T B_76_89_0 ; real_T B_76_90_0
; real_T B_76_92_0 ; real_T B_76_93_0 ; real_T B_76_94_0 ; real_T B_76_95_0 [
3 ] ; real_T B_76_97_0 ; real_T B_76_99_0 ; real_T B_76_101_0 ; real_T
B_76_102_0 [ 3 ] ; real_T B_76_106_0 ; real_T B_76_107_0 ; real_T B_76_108_0
; real_T B_76_110_0 ; real_T B_76_112_0 ; real_T B_76_113_0 ; real_T
B_76_114_0 ; real_T B_76_116_0 ; real_T B_76_118_0 ; real_T B_76_119_0 [ 3 ]
; real_T B_76_120_0 [ 3 ] ; real_T B_76_121_0 ; real_T B_76_122_0 ; real_T
B_76_124_0 ; real_T B_76_125_0 [ 3 ] ; real_T B_76_126_0 [ 3 ] ; real_T
B_76_127_0 [ 3 ] ; real_T B_76_128_0 [ 3 ] ; real_T B_76_129_0 [ 3 ] ; real_T
B_76_131_0 ; real_T B_76_140_0 [ 3 ] ; real_T B_76_143_0 [ 9 ] ; real_T
B_76_147_0 [ 3 ] ; real_T B_76_148_0 [ 3 ] ; real_T B_76_149_0 [ 15 ] ;
real_T B_76_150_0 [ 15 ] ; real_T B_76_151_0 ; real_T B_76_152_0 ; real_T
B_76_153_0 ; real_T B_76_155_0 ; real_T B_76_161_0 ; real_T B_76_163_0 ;
real_T B_76_164_0 [ 5 ] ; real_T B_76_166_0 ; real_T B_76_167_0 [ 15 ] ;
real_T B_76_169_0 [ 3 ] ; real_T B_76_170_0 [ 3 ] ; real_T B_76_172_0 ;
real_T B_76_173_0 ; real_T B_76_174_0 [ 9 ] ; real_T B_76_180_0 [ 3 ] ;
real_T B_76_181_0 ; real_T B_76_182_0 ; real_T B_76_184_0 ; real_T B_76_188_0
; real_T B_76_190_0 ; real_T B_76_193_0 ; real_T B_76_194_0 ; real_T
B_76_197_0 [ 3 ] ; real_T B_76_198_0 [ 3 ] ; real_T B_76_199_0 [ 3 ] ; real_T
B_76_205_0 ; real_T B_76_208_0 ; real_T B_76_209_0 ; real_T B_76_210_0 ;
real_T B_76_211_0 ; real_T B_76_212_0 ; real_T B_76_213_0 ; real_T B_76_214_0
[ 3 ] ; real_T B_76_215_0 [ 3 ] ; real_T B_76_216_0 ; real_T B_76_217_0 ;
real_T B_76_219_0 [ 3 ] ; real_T B_76_220_0 [ 3 ] ; real_T B_76_223_0 ;
real_T B_76_224_0 [ 5 ] ; real_T B_76_225_0 [ 5 ] ; real_T B_76_226_0 [ 5 ] ;
real_T B_76_227_0 ; real_T B_76_228_0 ; real_T B_76_229_0 [ 6 ] ; real_T
B_76_230_0 [ 6 ] ; real_T B_76_233_0 ; real_T B_76_234_0 ; real_T B_76_235_0
; real_T B_76_236_0 [ 2 ] ; real_T B_76_237_0 [ 2 ] ; real_T B_76_238_0 ;
real_T B_76_240_0 ; real_T B_76_241_0 ; real_T B_76_243_0 ; real_T B_76_244_0
[ 3 ] ; real_T B_76_246_0 ; real_T B_76_247_0 ; real_T B_76_248_0 ; real_T
B_76_249_0 ; real_T B_76_251_0 ; real_T B_76_252_0 ; real_T B_76_254_0 ;
real_T B_76_256_0 ; real_T B_76_259_0 ; real_T B_76_261_0 ; real_T B_76_262_0
; real_T B_76_263_0 ; real_T B_76_264_0 ; real_T B_76_265_0 ; real_T
B_76_268_0 ; real_T B_76_269_0 ; real_T B_76_270_0 ; real_T B_76_272_0 ;
real_T B_76_273_0 ; real_T B_76_275_0 ; real_T B_76_280_0 ; real_T B_76_281_0
; real_T B_76_282_0 ; real_T B_76_284_0 ; real_T B_76_285_0 ; real_T
B_76_287_0 ; real_T B_76_292_0 ; real_T B_76_293_0 ; real_T B_76_295_0 ;
real_T B_76_296_0 ; real_T B_76_298_0 ; real_T B_76_303_0 ; real_T B_76_304_0
; real_T B_76_311_0 ; real_T B_76_313_0 [ 3 ] ; real_T B_76_315_0 [ 3 ] ;
real_T B_76_317_0 ; real_T B_76_321_0 [ 3 ] ; real_T B_76_324_0 [ 3 ] ;
real_T B_76_325_0 [ 3 ] ; real_T B_76_326_0 [ 3 ] ; real_T B_76_327_0 [ 3 ] ;
real_T B_76_328_0 [ 3 ] ; real_T B_76_333_0 ; real_T B_76_334_0 ; real_T
B_76_336_0 ; real_T B_76_337_0 ; real_T B_76_338_0 ; real_T B_76_340_0 ;
real_T B_76_344_0 ; real_T B_76_348_0 ; real_T B_76_349_0 ; real_T B_76_353_0
; real_T B_76_357_0 ; real_T B_76_358_0 ; real_T B_76_362_0 ; real_T
B_76_366_0 ; real_T B_76_367_0 ; real_T B_76_368_0 ; real_T B_76_369_0 ;
real_T B_76_371_0 ; real_T B_76_372_0 [ 3 ] ; real_T B_76_375_0 [ 2 ] ;
real_T B_76_379_0 ; real_T B_76_381_0 [ 3 ] ; real_T B_76_382_0 [ 3 ] ;
real_T B_76_384_0 ; real_T B_76_385_0 ; real_T B_76_386_0 ; real_T B_76_388_0
; real_T B_76_389_0 ; real_T B_76_390_0 ; real_T B_76_392_0 ; real_T
B_76_393_0 ; real_T B_76_398_0 [ 3 ] ; real_T B_76_399_0 [ 3 ] ; real_T
B_76_404_0 ; real_T B_76_408_0 [ 3 ] ; real_T B_76_409_0 [ 3 ] ; real_T
B_76_415_0 ; real_T B_76_418_0 ; real_T B_76_421_0 ; real_T B_76_422_0 [ 15 ]
; real_T B_76_423_0 [ 3 ] ; real_T B_76_425_0 [ 3 ] ; real_T B_76_426_0 [ 3 ]
; real_T B_76_429_0 ; real_T B_76_431_0 ; real_T B_76_432_0 ; real_T
B_76_433_0 ; real_T B_76_435_0 ; real_T B_76_437_0 ; real_T B_76_450_0 ;
real_T B_76_451_0 ; real_T B_76_452_0 ; real_T B_76_453_0 ; real_T B_76_456_0
; real_T B_76_459_0 ; real_T B_76_460_0 ; real_T B_76_461_0 ; real_T
B_76_464_0 ; real_T B_76_469_0 ; real_T B_76_471_0 ; real_T B_76_474_0 ;
real_T B_76_475_0 ; real_T B_76_482_0 ; real_T B_76_484_0 ; real_T B_76_486_0
; real_T B_76_495_0 ; real_T B_76_502_0 ; real_T B_76_506_0 ; real_T
B_76_508_0 ; real_T B_76_510_0 ; real_T B_76_511_0 ; real_T B_76_513_0 ;
real_T B_76_515_0 ; real_T B_75_0_1 [ 3 ] ; real_T B_75_0_2 [ 3 ] ; real_T
B_69_0_0 [ 3 ] ; real_T B_69_1_1 ; real_T B_69_1_2 ; real_T B_69_1_3 ; real_T
B_68_0_1 [ 3 ] ; real_T B_67_0_1 ; real_T B_67_0_2 ; real_T B_67_0_3 ; real_T
B_66_0_1 [ 15 ] ; real_T B_65_9_0 ; real_T B_65_12_0 ; real_T B_62_9_0 ;
real_T B_62_12_0 ; real_T B_59_2_0 ; real_T B_59_7_0 [ 2 ] ; real_T B_59_9_0
[ 2 ] ; real_T B_58_2_0 ; real_T B_58_7_0 [ 2 ] ; real_T B_58_9_0 [ 2 ] ;
real_T B_57_2_0 ; real_T B_57_7_0 [ 2 ] ; real_T B_57_9_0 [ 2 ] ; real_T
B_56_0_0 ; real_T B_56_1_0 ; real_T B_56_5_0 [ 2 ] ; real_T B_56_7_0 [ 2 ] ;
real_T B_56_10_0 [ 2 ] ; real_T B_55_0_0 ; real_T B_55_1_0 ; real_T B_55_5_0
[ 2 ] ; real_T B_55_7_0 [ 2 ] ; real_T B_55_10_0 [ 2 ] ; real_T B_54_0_0 ;
real_T B_54_5_0 ; real_T B_54_6_0 ; real_T B_54_7_0 ; real_T B_54_15_0 [ 2 ]
; real_T B_54_17_0 [ 2 ] ; real_T B_53_3_0 ; real_T B_52_0_1 [ 3 ] ; real_T
B_51_0_1 [ 3 ] ; real_T B_51_0_2 [ 3 ] ; real_T B_51_0_3 ; real_T B_51_0_4 ;
real_T B_51_0_5 ; real_T B_48_0_1 [ 3 ] ; real_T B_48_0_2 ; real_T B_48_0_3 ;
real_T B_48_0_4 [ 3 ] ; real_T B_47_0_1 [ 15 ] ; real_T B_47_0_2 ; real_T
B_47_0_3 [ 3 ] ; real_T B_47_0_4 [ 3 ] ; real_T B_46_0_1 [ 3 ] ; real_T
B_46_0_2 [ 3 ] ; real_T B_45_0_1 [ 3 ] ; real_T B_45_0_2 [ 3 ] ; real_T
B_43_0_1 [ 3 ] ; real_T B_42_0_1 [ 9 ] ; real_T B_41_0_1 [ 3 ] ; real_T
B_41_0_2 [ 3 ] ; real_T B_40_0_1 [ 3 ] ; real_T B_40_0_2 [ 3 ] ; real_T
B_40_0_3 [ 3 ] ; real_T B_40_0_4 [ 4 ] ; real_T B_39_0_1 [ 3 ] ; real_T
B_38_0_1 [ 3 ] ; real_T B_38_0_2 [ 2 ] ; real_T B_37_0_0 [ 2 ] ; real_T
B_37_1_1 ; real_T B_37_1_2 ; real_T B_37_1_3 ; real_T B_36_0_1 ; real_T
B_36_0_2 ; real_T B_35_0_1 [ 3 ] ; real_T B_34_0_1 ; real_T B_34_0_2 ; real_T
B_33_0_0 ; real_T B_33_2_0 ; real_T B_33_3_0 ; real_T B_33_5_0 ; real_T
B_33_6_0 [ 3 ] ; real_T B_33_7_0 ; real_T B_33_9_0 ; real_T B_33_11_0 ;
real_T B_33_13_0 ; real_T B_33_20_0 ; real_T B_33_21_0 ; real_T B_33_22_0 ;
real_T B_33_24_0 ; real_T B_33_30_0 ; real_T B_33_31_0 ; real_T B_33_33_0 ;
real_T B_33_34_0 ; real_T B_33_38_0 ; real_T B_33_40_0 ; real_T B_33_41_0 ;
real_T B_33_42_0 ; real_T B_33_44_0 ; real_T B_33_48_0 ; real_T B_33_50_0 ;
real_T B_33_54_0 ; real_T B_33_57_0 ; real_T B_33_58_0 ; real_T B_33_59_0 ;
real_T B_33_63_0 ; real_T B_33_69_0 ; real_T B_33_71_0 ; real_T B_33_75_0 ;
real_T B_33_79_0 ; real_T B_33_81_0 ; real_T B_33_83_0 ; real_T B_33_86_0 ;
real_T B_33_87_0 ; real_T B_33_88_0 ; real_T B_33_93_0 ; real_T B_33_94_0 ;
real_T B_33_98_0 ; real_T B_33_100_0 ; real_T B_33_101_0 ; real_T B_33_102_0
; real_T B_33_103_0 ; real_T B_33_104_0 [ 3 ] ; real_T B_33_105_0 [ 3 ] ;
real_T B_33_106_0 [ 3 ] ; real_T B_33_110_0 [ 2 ] ; real_T B_33_112_0 ;
real_T B_33_115_0 ; real_T B_33_116_0 ; real_T B_33_119_0 ; real_T B_32_0_1 ;
real_T B_27_0_0 [ 2 ] ; real_T B_27_1_1 ; real_T B_27_1_2 ; real_T B_26_0_1 [
3 ] ; real_T B_26_0_2 ; real_T B_26_0_3 ; real_T B_26_0_4 [ 3 ] ; real_T
B_26_0_5 [ 3 ] ; real_T B_26_0_6 ; real_T B_26_0_7 ; real_T B_26_0_8 ; real_T
B_26_0_9 ; real_T B_25_0_0 [ 3 ] ; real_T B_25_1_1 ; real_T B_25_1_2 ; real_T
B_25_1_3 ; real_T B_25_1_4 ; real_T B_25_1_5 ; real_T B_24_0_1 ; real_T
B_24_0_2 ; real_T B_23_0_0 [ 3 ] ; real_T B_23_1_1 ; real_T B_22_0_0 [ 3 ] ;
real_T B_22_1_1 [ 3 ] ; real_T B_22_1_2 [ 3 ] ; real_T B_21_0_1 ; real_T
B_20_0_1 ; real_T B_20_0_2 ; real_T B_20_0_3 ; real_T B_19_0_1 ; real_T
B_19_0_2 ; real_T B_18_0_1 [ 9 ] ; real_T B_18_0_2 [ 9 ] ; real_T B_17_0_0 ;
real_T B_17_2_0 ; real_T B_17_3_0 ; real_T B_17_4_0 ; real_T B_17_5_0 ;
real_T B_17_10_0 ; real_T B_17_12_0 ; real_T B_17_14_0 ; real_T B_17_18_0 ;
real_T B_17_19_0 ; real_T B_17_20_0 ; real_T B_17_25_0 ; real_T B_17_27_0 ;
real_T B_17_28_0 ; real_T B_17_33_0 ; real_T B_17_35_0 ; real_T B_17_36_0 ;
real_T B_17_37_0 ; real_T B_17_39_0 ; real_T B_17_43_0 ; real_T B_17_44_0 ;
real_T B_17_45_0 ; real_T B_17_49_0 ; real_T B_17_50_0 ; real_T B_17_51_0 ;
real_T B_17_52_0 ; real_T B_17_53_0 ; real_T B_17_57_0 ; real_T B_17_59_0 ;
real_T B_17_63_0 ; real_T B_17_65_0 ; real_T B_17_69_0 ; real_T B_17_73_0 ;
real_T B_17_75_0 ; real_T B_17_77_0 ; real_T B_17_80_0 ; real_T B_17_84_0 ;
real_T B_17_86_0 ; real_T B_17_87_0 ; real_T B_17_91_0 ; real_T B_17_93_0 ;
real_T B_17_94_0 ; real_T B_17_95_0 ; real_T B_17_96_0 ; real_T B_17_97_0 [ 3
] ; real_T B_17_98_0 [ 3 ] ; real_T B_17_99_0 [ 3 ] ; real_T B_17_101_0 ;
real_T B_17_102_0 ; real_T B_17_104_0 ; real_T B_17_105_0 ; real_T B_17_108_0
[ 3 ] ; real_T B_17_110_0 [ 3 ] ; real_T B_17_114_0 ; real_T B_17_117_0 ;
real_T B_17_119_0 ; real_T B_17_121_0 ; real_T B_17_125_0 ; real_T B_17_127_0
; real_T B_17_129_0 ; real_T B_17_130_0 ; real_T B_17_131_0 ; real_T B_16_0_0
[ 2 ] ; real_T B_16_1_1 ; real_T B_16_1_2 ; real_T B_16_1_3 [ 3 ] ; real_T
B_15_0_1 [ 3 ] ; real_T B_14_0_1 ; real_T B_14_0_2 ; real_T B_13_0_1 ; real_T
B_12_0_1 ; real_T B_11_0_1 ; real_T B_10_0_0 [ 3 ] ; real_T B_10_1_1 ; real_T
B_10_1_2 ; real_T B_9_0_1 ; real_T B_9_0_2 ; real_T B_8_0_1 ; real_T B_7_0_1
; real_T B_7_0_2 ; real_T B_7_0_3 ; real_T B_6_0_1 ; real_T B_6_0_2 ; real_T
B_5_1_0 [ 3 ] ; real_T B_4_0_0 [ 3 ] ; real_T B_4_1_1 [ 3 ] ; real_T B_4_1_2
[ 3 ] ; real_T B_3_0_0 [ 3 ] ; real_T B_3_1_1 [ 3 ] ; real_T B_2_0_1 ; real_T
B_2_0_2 ; real_T B_2_0_3 ; real_T B_1_0_0 [ 3 ] ; real_T B_1_1_1 [ 3 ] ;
real_T B_1_1_2 [ 3 ] ; real_T B_0_0_1 [ 3 ] ; real_T B_76_146_0 [ 3 ] ;
real_T B_76_266_0 [ 39 ] ; real_T B_76_323_0 [ 3 ] ; real_T B_76_467_0 [ 6 ]
; real_T B_17_29_0 [ 3 ] ; real_T B_76_330_0 [ 3 ] ; real_T B_53_1_0 [ 3 ] ;
uint32_T B_76_34_0 ; boolean_T B_76_77_0 ; boolean_T B_76_186_0 ; boolean_T
B_76_195_0 ; boolean_T B_76_454_0 ; boolean_T B_76_470_0 ; boolean_T B_33_1_0
; boolean_T B_33_8_0 ; boolean_T B_33_14_0 ; boolean_T B_33_25_0 ; boolean_T
B_17_1_0 ; boolean_T B_17_16_0 ; char_T pad_B_17_16_0 [ 1 ] ; }
B_testAWE_Testbed_opt4b_T ; typedef struct { real_T
DiscreteTimeIntegrator3_DSTATE [ 4 ] ; real_T Integrator4_DSTATE [ 3 ] ;
real_T DiscreteTimeIntegrator_DSTATE [ 3 ] ; real_T
DiscreteTimeIntegrator2_DSTATE [ 3 ] ; real_T Delay1_DSTATE [ 3 ] ; real_T
Delay2_DSTATE [ 3 ] ; real_T Delay4_DSTATE ; real_T Delay1_DSTATE_a ; real_T
Delay2_DSTATE_b ; real_T Delay3_DSTATE ; real_T
DiscreteTimeIntegrator1_DSTATE [ 15 ] ; real_T DiscreteTimeIntegrator4_DSTATE
[ 15 ] ; real_T DiscreteTimeIntegrator3_DSTATE_p ; real_T
DiscreteTimeIntegrator5_DSTATE ; real_T DiscreteTimeIntegrator1_DSTATE_h ;
real_T DiscreteTimeIntegrator1_DSTATE_a ; real_T
DiscreteTimeIntegrator_DSTATE_m ; real_T DiscreteTimeIntegrator1_DSTATE_j ;
real_T DiscreteTimeIntegrator1_DSTATE_p ; real_T
DiscreteTimeIntegrator_DSTATE_n ; real_T DiscreteTimeIntegrator1_DSTATE_b ;
real_T DiscreteTimeIntegrator_DSTATE_j ; real_T
DiscreteTimeIntegrator1_DSTATE_n ; real_T DiscreteTimeIntegrator1_DSTATE_l ;
real_T DiscreteTimeIntegrator_DSTATE_nj ; real_T
DiscreteTimeIntegrator_DSTATE_h ; real_T DiscreteTimeIntegrator_DSTATE_njz ;
real_T DiscreteTimeIntegrator1_DSTATE_n0 ; real_T
DiscreteTimeIntegrator_DSTATE_a ; real_T DiscreteTimeIntegrator1_DSTATE_k ;
real_T DiscreteTimeIntegrator2_DSTATE_g ; real_T
DiscreteTimeIntegrator2_DSTATE_k ; real_T DiscreteTimeIntegrator2_DSTATE_k1 ;
real_T DiscreteTimeIntegrator1_DSTATE_f ; real_T UnitDelay_DSTATE [ 2 ] ;
real_T UnitDelay_DSTATE_p [ 2 ] ; real_T UnitDelay_DSTATE_k [ 2 ] ; real_T
UnitDelay_DSTATE_n [ 2 ] ; real_T UnitDelay1_DSTATE [ 2 ] ; real_T
UnitDelay_DSTATE_a [ 2 ] ; real_T UnitDelay1_DSTATE_c [ 2 ] ; real_T
UnitDelay_DSTATE_m [ 2 ] ; real_T DiscreteTimeIntegrator2_DSTATE_p ; real_T
DiscreteTimeIntegrator3_DSTATE_m ; real_T Delay1_DSTATE_o ; real_T
DiscreteTimeIntegrator_DSTATE_e ; real_T DiscreteTimeIntegrator_DSTATE_ha ;
real_T DiscreteTimeIntegrator1_DSTATE_i ; real_T
DiscreteTimeIntegrator_DSTATE_f ; real_T DiscreteTimeIntegrator1_DSTATE_k1 ;
real_T DiscreteTimeIntegrator2_DSTATE_i ; real_T
DiscreteTimeIntegrator1_DSTATE_e ; real_T DiscreteTimeIntegrator_DSTATE_ab ;
real_T DiscreteTimeIntegrator3_DSTATE_i ; real_T
DiscreteTimeIntegrator_DSTATE_l ; real_T DiscreteTimeIntegrator1_DSTATE_o ;
real_T DiscreteTimeIntegrator1_DSTATE_ki ; real_T
DiscreteTimeIntegrator_DSTATE_c ; real_T DiscreteTimeIntegrator_DSTATE_fh ;
real_T DiscreteTimeIntegrator1_DSTATE_d ; real_T
DiscreteTimeIntegrator_DSTATE_mp ; real_T DiscreteTimeIntegrator1_DSTATE_ku ;
real_T DiscreteTimeIntegrator3_DSTATE_pk ; real_T
DiscreteTimeIntegrator2_DSTATE_h ; real_T DiscreteTimeIntegrator1_DSTATE_c ;
real_T DiscreteTimeIntegrator2_DSTATE_j ; real_T
DiscreteTimeIntegrator3_DSTATE_n ; real_T DiscreteTimeIntegrator2_DSTATE_it ;
real_T DiscreteTimeIntegrator3_DSTATE_mj ; real_T NextOutput [ 3 ] ; real_T
NextOutput_j ; real_T NextOutput_a ; real_T Memory3_PreviousInput ; real_T
Memory1_PreviousInput ; real_T Memory2_PreviousInput ; real_T
Memory_PreviousInput [ 3 ] ; real_T NextOutput_i ; struct { real_T
modelTStart ; } TransportDelay_RWORK ; struct { real_T modelTStart ; }
TransportDelay_RWORK_m ; struct { real_T modelTStart ; }
TransportDelay2_RWORK ; struct { real_T modelTStart ; }
TransportDelay2_RWORK_l ; struct { real_T modelTStart ; }
TransportDelay1_RWORK ; struct { real_T modelTStart ; }
TransportDelay_RWORK_b ; void * ToWorkspace11_PWORK ; void *
ToWorkspace12_PWORK ; void * ToWorkspace13_PWORK ; void * ToWorkspace28_PWORK
; void * ToWorkspace3_PWORK ; void * ToWorkspace10_PWORK ; struct { void *
TUbufferPtrs [ 2 ] ; } TransportDelay_PWORK ; struct { void * TUbufferPtrs [
2 ] ; } TransportDelay_PWORK_k ; struct { void * TUbufferPtrs [ 6 ] ; }
TransportDelay2_PWORK ; void * Scope1_PWORK [ 3 ] ; void *
ToWorkspace27_PWORK ; void * ToWorkspace29_PWORK ; void * ToWorkspace30_PWORK
; void * ToWorkspace31_PWORK ; struct { void * TUbufferPtrs [ 4 ] ; }
TransportDelay2_PWORK_k ; struct { void * TUbufferPtrs [ 6 ] ; }
TransportDelay1_PWORK ; void * ToWorkspace_PWORK ; void * Scope_PWORK [ 3 ] ;
void * ToWorkspace11_PWORK_j ; void * ToWorkspace_PWORK_b ; void *
ToWorkspace1_PWORK ; void * ToWorkspace2_PWORK ; void * ToWorkspace3_PWORK_l
; struct { void * TUbufferPtrs [ 6 ] ; } TransportDelay_PWORK_l ; void *
ToWorkspace1_PWORK_l ; void * ToWorkspace2_PWORK_h ; void *
ToWorkspace28_PWORK_d ; void * ToWorkspace_PWORK_l ; void *
ToWorkspace1_PWORK_e ; void * ToWorkspace_PWORK_g ; struct { void * AQHandles
; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_WinchController1_at_outport_1_PWORK ; void *
Scope_PWORK_l [ 3 ] ; void * Scope1_PWORK_p [ 3 ] ; void *
ToWorkspace_PWORK_a ; void * ToWorkspace1_PWORK_f ; struct { void * AQHandles
; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_LissajousFigure8Following_at_outport_8_PWORK ;
void * ToWorkspace_PWORK_d ; void * Scope_PWORK_c ; void * Scope1_PWORK_k ;
void * Scope2_PWORK ; void *
Synthesized_Atomic_Subsystem_For_Alg_Loop_1_AlgLoopData ; int32_T
MATLABFunction_sysIdxToRun ; int32_T PrintSimTime2CW_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitchInport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch1Inport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch1Inport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch2Inport3_sysIdxToRun ; int32_T
StateMachine_sysIdxToRun ; int32_T MATLABFunction_sysIdxToRun_b ; int32_T
Standardatmosphere_ISO2533_sysIdxToRun ; int32_T MATLABFunction_sysIdxToRun_j
; int32_T Interpolatevelocities_sysIdxToRun ; int32_T
MediumHighaltitudevelocities_sysIdxToRun ; int32_T
Lowaltitudevelocities_sysIdxToRun ; int32_T Interpolaterates_sysIdxToRun ;
int32_T MediumHighaltituderates_sysIdxToRun ; int32_T
Lowaltituderates_sysIdxToRun ; int32_T Hwgwz_sysIdxToRun ; int32_T
Hvgwz_sysIdxToRun ; int32_T Hugwz_sysIdxToRun ; int32_T Hrgw_sysIdxToRun ;
int32_T Hqgw_sysIdxToRun ; int32_T Hpgw_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch2Inport1_sysIdxToRun ; int32_T
TransformationFromB2O_sysIdxToRun ; int32_T Sensors1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtNoise_onInport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtNoise_onInport1_sysIdxToRun_a ; int32_T GPS1_sysIdxToRun ;
int32_T Tethermodel_sysIdxToRun ; int32_T
allForcesTorques_exceptAero_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun_f ; int32_T
TmpAtomicSubsysAtSwitchInport3_sysIdxToRun_m ; int32_T
getEulerAngles1_sysIdxToRun ; int32_T getDCM_sysIdxToRun ; int32_T
calculate_pos_vel_in_W_sysIdxToRun ; int32_T MATLABFunction2_sysIdxToRun ;
int32_T MATLABFunction1_sysIdxToRun ; int32_T GetAirdata_sysIdxToRun ;
int32_T MATLABFunction1_sysIdxToRun_e ; int32_T MATLABFunction_sysIdxToRun_e
; int32_T TransformationFromB2O_sysIdxToRun_b ; int32_T
EstimateAeropathAngles_sysIdxToRun ; int32_T Traction_OuterLoop_sysIdxToRun ;
int32_T calcualteCourseErrorAndWrap1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch1Inport1_sysIdxToRun_d ; int32_T
TmpAtomicSubsysAtSwitch1Inport3_sysIdxToRun_e ; int32_T
TmpAtomicSubsysAtSwitch1Inport1_sysIdxToRun_dv ; int32_T
TmpAtomicSubsysAtSwitch1Inport3_sysIdxToRun_ei ; int32_T
MATLABFunction1_sysIdxToRun_f ; int32_T LissajousFigure8Following_sysIdxToRun
; int32_T inversionPathDynamics_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun_n ; int32_T EstimateAerodynamicForce_sysIdxToRun ;
int32_T inversionAttitude_sysIdxToRun ; int32_T estimateBankAngle_sysIdxToRun
; int32_T estimateBankAngle_sysIdxToRun_m ; int32_T
EstimateGammaDot_sysIdxToRun ; int32_T MATLABFunction_sysIdxToRun_k ; int32_T
Retraction_OuterLoop_sysIdxToRun ; int32_T Retraction_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun_c ; int32_T TrafoPathKin2PathAero_sysIdxToRun ;
int32_T wrapCourse_sysIdxToRun ; int32_T wrap2pi2_sysIdxToRun ; int32_T
calcualteCourseErrorAndWrap_sysIdxToRun ; int32_T
inversionPathDynamics_sysIdxToRun_c ; int32_T MATLABFunction_sysIdxToRun_n4 ;
int32_T estimateBankAngle_sysIdxToRun_c ; int32_T
estimateBankAngle_sysIdxToRun_a ; int32_T EstimateGammaDot_sysIdxToRun_h ;
int32_T Synthesized_Atomic_Subsystem_For_Alg_Loop_1_sysIdxToRun ; int32_T
Synthesized_Atomic_Subsystem_For_Alg_Loop_1_blkIdxToRun ; int32_T
Synthesized_Atomic_Subsystem_For_Alg_Loop_1_parentSysIdxToRun ; int32_T
inversionAttitude_sysIdxToRun_b ; int32_T
InversionRotationalDynamics_sysIdxToRun ; int32_T
InversionRotationalDynamics1_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun_h ; int32_T allocation_sysIdxToRun ; uint32_T
PreLookUpIndexSearchaltitude_DWORK1 ; uint32_T
PreLookUpIndexSearchprobofexceed_DWORK1 ; uint32_T RandSeed [ 3 ] ; uint32_T
RandSeed_l ; uint32_T RandSeed_p ; uint32_T RandSeed_k ; struct { int_T Tail
; int_T Head ; int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
TransportDelay_IWORK ; struct { int_T Tail ; int_T Head ; int_T Last ; int_T
CircularBufSize ; int_T MaxNewBufSize ; } TransportDelay_IWORK_g ; struct {
int_T Tail [ 3 ] ; int_T Head [ 3 ] ; int_T Last [ 3 ] ; int_T
CircularBufSize [ 3 ] ; int_T MaxNewBufSize ; } TransportDelay2_IWORK ;
struct { int_T Tail [ 2 ] ; int_T Head [ 2 ] ; int_T Last [ 2 ] ; int_T
CircularBufSize [ 2 ] ; int_T MaxNewBufSize ; } TransportDelay2_IWORK_c ;
struct { int_T Tail [ 3 ] ; int_T Head [ 3 ] ; int_T Last [ 3 ] ; int_T
CircularBufSize [ 3 ] ; int_T MaxNewBufSize ; } TransportDelay1_IWORK ;
struct { int_T Tail [ 3 ] ; int_T Head [ 3 ] ; int_T Last [ 3 ] ; int_T
CircularBufSize [ 3 ] ; int_T MaxNewBufSize ; } TransportDelay_IWORK_d ;
int8_T ifHeightMaxlowaltitudeelseifHeightMinisotropicaltitude_ActiveSubsystem
; int8_T
ifHeightMaxlowaltitudeelseifHeightMinisotropicaltitude_ActiveSubsystem_p ;
int8_T DiscreteTimeIntegrator1_PrevResetState ; int8_T
DiscreteTimeIntegrator2_PrevResetState ; int8_T
DiscreteTimeIntegrator2_PrevResetState_d ; int8_T
DiscreteTimeIntegrator1_PrevResetState_j ; int8_T
Interpolatevelocities_SubsysRanBC ; int8_T
MediumHighaltitudevelocities_SubsysRanBC ; int8_T
Lowaltitudevelocities_SubsysRanBC ; int8_T Interpolaterates_SubsysRanBC ;
int8_T MediumHighaltituderates_SubsysRanBC ; int8_T
Lowaltituderates_SubsysRanBC ; int8_T Hwgwz_SubsysRanBC ; int8_T
Hvgwz_SubsysRanBC ; int8_T Hugwz_SubsysRanBC ; int8_T Hrgw_SubsysRanBC ;
int8_T Hqgw_SubsysRanBC ; int8_T Hpgw_SubsysRanBC ; int8_T
Traction_OuterLoop_SubsysRanBC ; int8_T
DiscreteTimeIntegrator2_PrevResetState_n ; int8_T
DiscreteTimeIntegrator3_PrevResetState ; int8_T
DiscreteTimeIntegrator_PrevResetState ; int8_T
DiscreteTimeIntegrator_PrevResetState_c ; int8_T
DiscreteTimeIntegrator1_PrevResetState_c ; int8_T
DiscreteTimeIntegrator_PrevResetState_a ; int8_T
DiscreteTimeIntegrator1_PrevResetState_m ; int8_T
DiscreteTimeIntegrator2_PrevResetState_a ; int8_T
DiscreteTimeIntegrator1_PrevResetState_d ; int8_T
DiscreteTimeIntegrator_PrevResetState_b ; int8_T
DiscreteTimeIntegrator3_PrevResetState_i ; int8_T
Retraction_OuterLoop_SubsysRanBC ; int8_T
DiscreteTimeIntegrator_PrevResetState_ch ; int8_T
DiscreteTimeIntegrator1_PrevResetState_l ; int8_T
DiscreteTimeIntegrator_PrevResetState_l ; int8_T
DiscreteTimeIntegrator1_PrevResetState_b ; int8_T
DiscreteTimeIntegrator3_PrevResetState_p ; int8_T
DiscreteTimeIntegrator2_PrevResetState_k ; int8_T
DiscreteTimeIntegrator1_PrevResetState_h ; int8_T
DiscreteTimeIntegrator2_PrevResetState_h ; int8_T
DiscreteTimeIntegrator3_PrevResetState_n ; int8_T
DiscreteTimeIntegrator2_PrevResetState_f ; int8_T
DiscreteTimeIntegrator3_PrevResetState_g ; uint8_T
DiscreteTimeIntegrator_IC_LOADING ; uint8_T
DiscreteTimeIntegrator_IC_LOADING_g ; uint8_T
DiscreteTimeIntegrator_IC_LOADING_i ; boolean_T Hwgwz_MODE ; boolean_T
Hvgwz_MODE ; boolean_T Hugwz_MODE ; boolean_T Hrgw_MODE ; boolean_T Hqgw_MODE
; boolean_T Hpgw_MODE ; boolean_T Traction_OuterLoop_MODE ; boolean_T
Retraction_OuterLoop_MODE ; char_T pad_Retraction_OuterLoop_MODE [ 3 ] ; }
DW_testAWE_Testbed_opt4b_T ; typedef struct { real_T
AngleOfAttackMeasurement1_CSTATE [ 2 ] ; real_T Sideslip_CSTATE [ 2 ] ;
real_T TransferFcn_CSTATE ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE_o ; real_T TransferFcn1_CSTATE_b ; real_T
TransferFcn2_CSTATE ; real_T Integrator1_CSTATE [ 3 ] ; real_T
TransferFcn_CSTATE_n [ 2 ] ; real_T TransferFcn2_CSTATE_j [ 2 ] ; real_T
TransferFcn3_CSTATE [ 2 ] ; real_T TransferFcn_CSTATE_b [ 2 ] ; real_T
TransferFcn2_CSTATE_m [ 2 ] ; real_T TransferFcn3_CSTATE_p [ 2 ] ; }
X_testAWE_Testbed_opt4b_T ; typedef struct { real_T
AngleOfAttackMeasurement1_CSTATE [ 2 ] ; real_T Sideslip_CSTATE [ 2 ] ;
real_T TransferFcn_CSTATE ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE_o ; real_T TransferFcn1_CSTATE_b ; real_T
TransferFcn2_CSTATE ; real_T Integrator1_CSTATE [ 3 ] ; real_T
TransferFcn_CSTATE_n [ 2 ] ; real_T TransferFcn2_CSTATE_j [ 2 ] ; real_T
TransferFcn3_CSTATE [ 2 ] ; real_T TransferFcn_CSTATE_b [ 2 ] ; real_T
TransferFcn2_CSTATE_m [ 2 ] ; real_T TransferFcn3_CSTATE_p [ 2 ] ; }
XDot_testAWE_Testbed_opt4b_T ; typedef struct { boolean_T
AngleOfAttackMeasurement1_CSTATE [ 2 ] ; boolean_T Sideslip_CSTATE [ 2 ] ;
boolean_T TransferFcn_CSTATE ; boolean_T TransferFcn1_CSTATE ; boolean_T
TransferFcn_CSTATE_o ; boolean_T TransferFcn1_CSTATE_b ; boolean_T
TransferFcn2_CSTATE ; boolean_T Integrator1_CSTATE [ 3 ] ; boolean_T
TransferFcn_CSTATE_n [ 2 ] ; boolean_T TransferFcn2_CSTATE_j [ 2 ] ;
boolean_T TransferFcn3_CSTATE [ 2 ] ; boolean_T TransferFcn_CSTATE_b [ 2 ] ;
boolean_T TransferFcn2_CSTATE_m [ 2 ] ; boolean_T TransferFcn3_CSTATE_p [ 2 ]
; } XDis_testAWE_Testbed_opt4b_T ; typedef struct { ZCSigState
Delay1_Reset_ZCE ; } PrevZCX_testAWE_Testbed_opt4b_T ; struct
P_testAWE_Testbed_opt4b_T_ { real_T P_0 [ 2 ] ; struct_l2bbyVwOb8asqLFc6mGQ4B
P_1 ; real_T P_2 [ 2 ] ; struct_l2bbyVwOb8asqLFc6mGQ4B P_3 ; real_T P_4 [ 2 ]
; struct_l2bbyVwOb8asqLFc6mGQ4B P_5 ; real_T P_6 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_7 ; real_T P_8 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_9 ; real_T P_10 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_11 ; real_T P_12 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_13 ; real_T P_14 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_15 ; real_T P_16 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_17 ; real_T P_18 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_19 ; real_T P_20 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_21 ; real_T P_22 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_23 ; real_T P_24 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_25 ; real_T P_26 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_27 ; real_T P_28 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_29 ; real_T P_30 [ 2 ] ;
struct_l2bbyVwOb8asqLFc6mGQ4B P_31 ; real_T P_32 [ 2 ] ;
struct_e24UZuYdRCmWqnwLx4iKq P_33 ; real_T P_34 [ 2 ] ;
struct_e24UZuYdRCmWqnwLx4iKq P_35 ; real_T P_36 [ 2 ] ;
struct_nMRMB5qj13SdWFHXuruB9F P_37 ; real_T P_38 [ 2 ] ;
struct_nMRMB5qj13SdWFHXuruB9F P_39 ; real_T P_40 [ 2 ] ;
struct_tsATL4x2pPPJwZkYY6vf3F P_41 ; real_T P_42 [ 2 ] ;
struct_r31hl1KcaKVWraMCRB46AE P_43 ; real_T P_44 [ 2 ] ;
struct_r31hl1KcaKVWraMCRB46AE P_45 ; real_T P_46 [ 2 ] ;
struct_vYwCFuiAwYvnYUbjQrt9LE P_47 ; real_T P_48 [ 2 ] ;
struct_WA4b5EzbzxH6pRtlcnkbbD P_49 ; real_T P_50 [ 2 ] ;
struct_WA4b5EzbzxH6pRtlcnkbbD P_51 ; real_T P_52 [ 2 ] ;
struct_WA4b5EzbzxH6pRtlcnkbbD P_53 ; real_T P_54 [ 2 ] ;
struct_Unit6gTlhQcDbqhGR3ex7C P_55 ; real_T P_56 ; real_T P_57 ; real_T P_58
[ 2 ] ; real_T P_59 ; real_T P_60 [ 2 ] ; real_T P_61 ; real_T P_62 [ 2 ] ;
real_T P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T
P_68 ; real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ;
real_T P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T
P_79 ; real_T P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ; real_T P_84 ;
real_T P_85 ; real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T P_89 ; real_T
P_90 ; real_T P_91 ; real_T P_92 ; real_T P_93 ; real_T P_94 ; real_T P_95 ;
real_T P_96 ; real_T P_97 ; real_T P_98 ; real_T P_99 ; real_T P_100 ; real_T
P_101 ; real_T P_102 ; real_T P_103 ; real_T P_104 ; real_T P_105 ; real_T
P_106 ; real_T P_107 ; real_T P_108 ; real_T P_109 ; real_T P_110 ; real_T
P_111 ; real_T P_112 ; real_T P_113 ; real_T P_114 ; real_T P_115 ; real_T
P_116 ; real_T P_117 ; real_T P_118 ; real_T P_119 ; real_T P_120 ; real_T
P_121 ; real_T P_122 ; real_T P_123 ; real_T P_124 ; real_T P_125 ; real_T
P_126 ; real_T P_127 ; real_T P_128 ; real_T P_129 ; real_T P_130 ; real_T
P_131 ; real_T P_132 ; real_T P_133 ; real_T P_134 ; real_T P_135 ; real_T
P_136 ; real_T P_137 ; real_T P_138 [ 2 ] ; real_T P_139 [ 2 ] ; real_T P_140
[ 2 ] ; real_T P_141 [ 2 ] ; real_T P_142 [ 2 ] ; real_T P_143 [ 2 ] ; real_T
P_144 ; real_T P_145 ; real_T P_146 ; real_T P_147 ; real_T P_148 ; real_T
P_149 ; real_T P_150 ; real_T P_151 ; real_T P_152 ; real_T P_153 ; real_T
P_154 ; real_T P_155 ; real_T P_156 ; real_T P_157 ; real_T P_158 ; real_T
P_159 ; real_T P_160 ; real_T P_161 ; real_T P_162 ; real_T P_163 ; real_T
P_164 ; real_T P_165 ; real_T P_166 ; real_T P_167 ; real_T P_168 ; real_T
P_169 ; real_T P_170 ; real_T P_171 ; real_T P_172 ; real_T P_173 ; real_T
P_174 ; real_T P_175 ; real_T P_176 ; real_T P_177 ; real_T P_178 ; real_T
P_179 [ 2 ] ; real_T P_180 ; real_T P_181 [ 2 ] ; real_T P_182 ; real_T P_183
[ 2 ] ; real_T P_184 ; real_T P_185 [ 2 ] ; real_T P_186 ; real_T P_187 [ 2 ]
; real_T P_188 ; real_T P_189 [ 2 ] ; real_T P_190 ; real_T P_191 [ 2 ] ;
real_T P_192 ; real_T P_193 [ 2 ] ; real_T P_194 ; real_T P_195 ; real_T
P_196 ; real_T P_197 ; real_T P_198 ; real_T P_199 ; real_T P_200 ; real_T
P_201 ; real_T P_202 ; real_T P_203 ; real_T P_204 ; real_T P_205 ; real_T
P_206 ; real_T P_207 ; real_T P_208 ; real_T P_209 ; real_T P_210 ; real_T
P_211 ; real_T P_212 ; real_T P_213 ; real_T P_214 ; real_T P_215 ; real_T
P_216 ; real_T P_217 ; real_T P_218 ; real_T P_219 ; real_T P_220 ; real_T
P_221 ; real_T P_222 ; real_T P_223 ; real_T P_224 ; real_T P_225 ; real_T
P_226 ; real_T P_227 ; real_T P_228 ; real_T P_229 ; real_T P_230 ; real_T
P_231 ; real_T P_232 ; real_T P_233 ; real_T P_234 ; real_T P_235 ; real_T
P_236 ; real_T P_237 ; real_T P_238 ; real_T P_239 ; real_T P_240 ; real_T
P_241 ; real_T P_242 ; real_T P_243 ; real_T P_244 ; real_T P_245 ; real_T
P_246 ; real_T P_247 ; real_T P_248 ; real_T P_249 ; real_T P_250 ; real_T
P_251 ; real_T P_252 ; real_T P_253 ; real_T P_254 ; real_T P_255 ; real_T
P_256 ; real_T P_257 ; real_T P_258 [ 2 ] ; real_T P_259 [ 2 ] ; real_T P_260
[ 2 ] ; real_T P_261 [ 2 ] ; real_T P_262 [ 2 ] ; real_T P_263 [ 2 ] ; real_T
P_264 ; real_T P_265 ; real_T P_266 ; real_T P_267 ; real_T P_268 ; real_T
P_269 ; real_T P_270 ; real_T P_271 ; real_T P_272 ; real_T P_273 ; real_T
P_274 ; real_T P_275 ; real_T P_276 ; real_T P_277 ; real_T P_278 ; real_T
P_279 ; real_T P_280 ; real_T P_281 ; real_T P_282 ; real_T P_283 ; real_T
P_284 [ 2 ] ; real_T P_285 ; real_T P_286 [ 2 ] ; real_T P_287 ; real_T P_288
[ 2 ] ; real_T P_289 ; real_T P_290 [ 2 ] ; real_T P_291 ; real_T P_292 ;
real_T P_293 ; real_T P_294 ; real_T P_295 ; real_T P_296 ; real_T P_297 ;
real_T P_298 [ 2 ] ; real_T P_299 ; real_T P_300 ; real_T P_301 ; real_T
P_302 ; real_T P_303 ; real_T P_304 ; real_T P_305 ; real_T P_306 ; real_T
P_307 ; real_T P_308 ; real_T P_309 ; real_T P_310 ; real_T P_311 ; real_T
P_312 ; real_T P_313 ; real_T P_314 ; real_T P_315 ; real_T P_316 ; real_T
P_317 ; real_T P_318 ; real_T P_319 ; real_T P_320 ; real_T P_321 ; real_T
P_322 ; real_T P_323 ; real_T P_324 ; real_T P_325 ; real_T P_326 ; real_T
P_327 ; real_T P_328 ; real_T P_329 ; real_T P_330 ; real_T P_331 ; real_T
P_332 ; real_T P_333 ; real_T P_334 ; real_T P_335 ; real_T P_336 ; real_T
P_337 ; real_T P_338 ; real_T P_339 ; real_T P_340 ; real_T P_341 ; real_T
P_342 ; real_T P_343 ; real_T P_344 ; real_T P_345 ; real_T P_346 ; real_T
P_347 [ 2 ] ; real_T P_348 ; real_T P_349 [ 2 ] ; real_T P_350 ; real_T P_351
; real_T P_352 ; real_T P_353 ; real_T P_354 ; real_T P_355 ; real_T P_356 [
2 ] ; real_T P_357 ; real_T P_358 [ 2 ] ; real_T P_359 ; real_T P_360 ;
real_T P_361 ; real_T P_362 [ 4 ] ; real_T P_363 ; real_T P_364 [ 3 ] ;
real_T P_365 ; real_T P_366 ; real_T P_367 ; real_T P_368 ; real_T P_369 ;
real_T P_370 ; real_T P_371 [ 3 ] ; real_T P_372 ; real_T P_373 ; real_T
P_374 ; real_T P_375 ; real_T P_376 ; real_T P_377 ; real_T P_378 ; real_T
P_379 [ 12 ] ; real_T P_380 ; real_T P_381 [ 7 ] ; real_T P_382 [ 84 ] ;
real_T P_383 ; real_T P_384 ; real_T P_385 [ 3 ] ; real_T P_386 [ 3 ] ;
real_T P_387 ; real_T P_388 ; real_T P_389 ; real_T P_390 ; real_T P_391 ;
real_T P_392 ; real_T P_393 [ 3 ] ; real_T P_394 [ 3 ] ; real_T P_395 ;
real_T P_396 ; real_T P_397 ; real_T P_398 ; real_T P_399 ; real_T P_400 [ 3
] ; real_T P_401 ; real_T P_402 ; real_T P_403 ; real_T P_404 [ 3 ] ; real_T
P_405 [ 3 ] ; real_T P_406 ; real_T P_407 ; real_T P_408 ; real_T P_409 ;
real_T P_410 ; real_T P_411 ; real_T P_412 ; real_T P_413 ; real_T P_414 ;
real_T P_415 ; real_T P_416 ; real_T P_417 ; real_T P_418 ; real_T P_419 ;
real_T P_420 ; real_T P_421 ; real_T P_422 ; real_T P_423 ; real_T P_424 ;
real_T P_425 ; real_T P_426 ; real_T P_427 [ 2 ] ; real_T P_428 [ 2 ] ;
real_T P_429 ; real_T P_430 ; real_T P_431 ; real_T P_432 ; real_T P_433 ;
real_T P_434 ; real_T P_435 [ 2 ] ; real_T P_436 [ 2 ] ; real_T P_437 ;
real_T P_438 ; real_T P_439 ; real_T P_440 ; real_T P_441 ; real_T P_442 ;
real_T P_443 ; real_T P_444 ; real_T P_445 ; real_T P_446 ; real_T P_447 ;
real_T P_448 ; real_T P_449 ; real_T P_450 ; real_T P_451 ; real_T P_452 [ 3
] ; real_T P_453 ; real_T P_454 [ 15 ] ; real_T P_455 ; real_T P_456 [ 15 ] ;
real_T P_457 ; real_T P_458 ; real_T P_459 ; real_T P_460 ; real_T P_461 ;
real_T P_462 ; real_T P_463 ; real_T P_464 ; real_T P_465 ; real_T P_466 ;
real_T P_467 ; real_T P_468 ; real_T P_469 ; real_T P_470 ; real_T P_471 ;
real_T P_472 ; real_T P_473 ; real_T P_474 ; real_T P_475 ; real_T P_476 ;
real_T P_477 ; real_T P_478 ; real_T P_479 ; real_T P_480 ; real_T P_481 ;
real_T P_482 ; real_T P_483 ; real_T P_484 ; real_T P_485 ; real_T P_486 ;
real_T P_487 ; real_T P_488 [ 6 ] ; real_T P_489 ; real_T P_490 ; real_T
P_491 [ 2 ] ; real_T P_492 ; real_T P_493 ; real_T P_494 ; real_T P_495 ;
real_T P_496 ; real_T P_497 ; real_T P_498 ; real_T P_499 [ 3 ] ; real_T
P_500 ; real_T P_501 ; real_T P_502 ; real_T P_503 ; real_T P_504 ; real_T
P_505 ; real_T P_506 ; real_T P_507 ; real_T P_508 ; real_T P_509 ; real_T
P_510 ; real_T P_511 ; real_T P_512 ; real_T P_513 ; real_T P_514 ; real_T
P_515 ; real_T P_516 ; real_T P_517 ; real_T P_518 ; real_T P_519 ; real_T
P_520 ; real_T P_521 ; real_T P_522 ; real_T P_523 ; real_T P_524 ; real_T
P_525 ; real_T P_526 ; real_T P_527 ; real_T P_528 ; real_T P_529 ; real_T
P_530 ; real_T P_531 ; real_T P_532 ; real_T P_533 ; real_T P_534 ; real_T
P_535 ; real_T P_536 ; real_T P_537 ; real_T P_538 ; real_T P_539 ; real_T
P_540 ; real_T P_541 ; real_T P_542 ; real_T P_543 ; real_T P_544 ; real_T
P_545 ; real_T P_546 ; real_T P_547 ; real_T P_548 ; real_T P_549 ; real_T
P_550 ; real_T P_551 ; real_T P_552 ; real_T P_553 [ 9 ] ; real_T P_554 ;
real_T P_555 [ 3 ] ; real_T P_556 ; real_T P_557 ; real_T P_558 ; real_T
P_559 ; real_T P_560 ; real_T P_561 ; real_T P_562 ; real_T P_563 ; real_T
P_564 ; real_T P_565 ; real_T P_566 ; real_T P_567 ; real_T P_568 ; real_T
P_569 ; real_T P_570 ; real_T P_571 ; real_T P_572 ; real_T P_573 ; real_T
P_574 ; real_T P_575 ; real_T P_576 ; real_T P_577 ; real_T P_578 ; real_T
P_579 ; real_T P_580 ; real_T P_581 ; real_T P_582 ; real_T P_583 ; real_T
P_584 ; real_T P_585 ; real_T P_586 ; real_T P_587 ; real_T P_588 ; real_T
P_589 ; real_T P_590 ; real_T P_591 ; real_T P_592 ; real_T P_593 ; real_T
P_594 ; real_T P_595 ; real_T P_596 ; real_T P_597 ; real_T P_598 ; real_T
P_599 ; real_T P_600 ; real_T P_601 ; real_T P_602 ; real_T P_603 ; real_T
P_604 ; real_T P_605 ; real_T P_606 ; real_T P_607 ; real_T P_608 ; real_T
P_609 ; real_T P_610 ; real_T P_611 ; real_T P_612 ; real_T P_613 ; real_T
P_614 ; real_T P_615 ; real_T P_616 ; real_T P_617 ; real_T P_618 ; real_T
P_619 ; real_T P_620 [ 3 ] ; real_T P_621 ; real_T P_622 ; real_T P_623 ;
real_T P_624 ; real_T P_625 ; real_T P_626 ; real_T P_627 ; real_T P_628 ;
real_T P_629 ; real_T P_630 ; real_T P_631 ; real_T P_632 ; real_T P_633 ;
real_T P_634 ; real_T P_635 ; real_T P_636 ; real_T P_637 ; real_T P_638 ;
real_T P_639 ; real_T P_640 ; real_T P_641 ; real_T P_642 ; real_T P_643 ;
real_T P_644 ; real_T P_645 ; real_T P_646 ; real_T P_647 ; real_T P_648 ;
real_T P_649 ; real_T P_650 ; real_T P_651 ; real_T P_652 ; real_T P_653 ;
real_T P_654 ; real_T P_655 ; real_T P_656 ; real_T P_657 ; real_T P_658 ;
real_T P_659 ; real_T P_660 [ 2 ] ; real_T P_661 ; real_T P_662 ; real_T
P_663 ; real_T P_664 ; real_T P_665 ; real_T P_666 ; real_T P_667 ; real_T
P_668 ; real_T P_669 ; real_T P_670 ; real_T P_671 ; real_T P_672 ; real_T
P_673 ; real_T P_674 ; real_T P_675 ; real_T P_676 ; real_T P_677 ; real_T
P_678 ; real_T P_679 ; real_T P_680 ; real_T P_681 ; real_T P_682 ; real_T
P_683 ; uint32_T P_684 ; uint32_T P_685 [ 2 ] ; uint32_T P_686 ; uint32_T
P_687 ; uint32_T P_688 ; uint32_T P_689 ; uint32_T P_690 ; uint32_T P_691 ;
uint8_T P_692 ; uint8_T P_693 ; uint8_T P_694 ; uint8_T P_695 ; uint8_T P_696
; uint8_T P_697 ; uint8_T P_698 ; uint8_T P_699 ; uint8_T P_700 ; uint8_T
P_701 ; uint8_T P_702 ; uint8_T P_703 ; uint8_T P_704 ; uint8_T P_705 ;
uint8_T P_706 ; char_T pad_P_706 [ 5 ] ; } ; extern P_testAWE_Testbed_opt4b_T
testAWE_Testbed_opt4b_rtDefaultP ;
#endif
