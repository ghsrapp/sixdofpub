#include "__cf_testAWE_Testbed_opt4b.h"
#ifndef RTW_HEADER_testAWE_Testbed_opt4b_acc_types_h_
#define RTW_HEADER_testAWE_Testbed_opt4b_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_Airframe_StateEstimation_Bus_
#define DEFINED_TYPEDEF_FOR_Airframe_StateEstimation_Bus_
typedef struct { real_T omega_OB_B_radDs [ 3 ] ; real_T h_barom ; real_T
airdata [ 3 ] ; real_T pos_G_O_m [ 3 ] ; real_T vel_K_B_mDs [ 3 ] ; real_T
eta_OB_rad [ 3 ] ; real_T pathAngles [ 2 ] ; real_T quaternions [ 4 ] ;
real_T acc_B_mDs2 [ 3 ] ; real_T pathAngles_a [ 2 ] ; real_T v_w_hat_O [ 3 ]
; real_T T_t_tot ; real_T DCM [ 9 ] ; real_T longlat [ 2 ] ; real_T
eta_tau_rad [ 3 ] ; real_T F_a_B_est [ 3 ] ; real_T ddt_v_w_x_O ; }
Airframe_StateEstimation_Bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_Airframe_Output_Bus_
#define DEFINED_TYPEDEF_FOR_Airframe_Output_Bus_
typedef struct { real_T pos_G_O_m [ 3 ] ; real_T vel_K_B_mDs [ 3 ] ; real_T
eta_OB_rad [ 3 ] ; real_T omega_OB_B_radDs [ 3 ] ; real_T airdata [ 3 ] ;
real_T DCM [ 9 ] ; real_T pathAngles [ 2 ] ; real_T quaternions [ 4 ] ;
real_T acc_B_mDs2 [ 3 ] ; } Airframe_Output_Bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_Airframe_Measurements_Bus_
#define DEFINED_TYPEDEF_FOR_Airframe_Measurements_Bus_
typedef struct { real_T omega_OB_B_meas_radDs [ 3 ] ; real_T acc_B_meas_mDs2
[ 3 ] ; real_T diffPressure_meas_NDm2 ; real_T staticPressure_meas_NDm2 ;
real_T Psi_OB_meas_rad ; real_T pos_G_O_GPS_meas_m [ 3 ] ; real_T
vel_O_GPS_meas_mDs ; real_T Course_OK_GPS_meas_rad ; real_T alpha_a_meas_rad
; real_T beta_a_meas_rad ; real_T eta_OB_meas_rad [ 3 ] ; real_T F_t_W_N [ 3
] ; real_T DCM [ 9 ] ; } Airframe_Measurements_Bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_DataLinkGround2Kite_Bus_
#define DEFINED_TYPEDEF_FOR_DataLinkGround2Kite_Bus_
typedef struct { real_T flight_state ; real_T v_r ; real_T path_update [ 3 ]
; } DataLinkGround2Kite_Bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_DataLinkKite2Ground_Bus_
#define DEFINED_TYPEDEF_FOR_DataLinkKite2Ground_Bus_
typedef struct { real_T airdata [ 3 ] ; real_T pos_O [ 3 ] ; real_T longlat [
2 ] ; real_T eta_tau_rad [ 3 ] ; real_T vel_K_B [ 3 ] ; real_T F_a_B_est [ 3
] ; } DataLinkKite2Ground_Bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_l2bbyVwOb8asqLFc6mGQ4B_
#define DEFINED_TYPEDEF_FOR_struct_l2bbyVwOb8asqLFc6mGQ4B_
typedef struct { real_T S_ref ; real_T S_wing ; real_T b ; real_T c ; real_T
mass ; real_T J [ 9 ] ; real_T Jx ; real_T Jy ; real_T Jz ; real_T Jxz ;
real_T Jinv [ 9 ] ; real_T d_tether ; real_T rho_tether ; real_T Cd_tether ;
real_T rho_air ; real_T Cx_0_0 ; real_T Cx_0_alpha ; real_T Cx_0_alpha2 ;
real_T Cx_q_0 ; real_T Cx_q_alpha ; real_T Cx_q_alpha2 ; real_T Cx_deltaE_0 ;
real_T Cx_deltaE_alpha ; real_T Cx_deltaE_alpha2 ; real_T Cy_beta_0 ; real_T
Cy_beta_alpha ; real_T Cy_beta_alpha2 ; real_T Cy_p_0 ; real_T Cy_p_alpha ;
real_T Cy_p_alpha2 ; real_T Cy_r_0 ; real_T Cy_r_alpha ; real_T Cy_r_alpha2 ;
real_T Cy_deltaA_0 ; real_T Cy_deltaA_alpha ; real_T Cy_deltaA_alpha2 ;
real_T Cy_deltaR_0 ; real_T Cy_deltaR_alpha ; real_T Cy_deltaR_alpha2 ;
real_T Cz_0_0 ; real_T Cz_0_alpha ; real_T Cz_0_alpha2 ; real_T Cz_q_0 ;
real_T Cz_q_alpha ; real_T Cz_q_alpha2 ; real_T Cz_deltaE_0 ; real_T
Cz_deltaE_alpha ; real_T Cz_deltaE_alpha2 ; real_T Cm_0_0 ; real_T Cm_0_alpha
; real_T Cm_0_alpha2 ; real_T Cm_q_0 ; real_T Cm_q_alpha ; real_T Cm_q_alpha2
; real_T Cm_deltaE_0 ; real_T Cm_deltaE_alpha ; real_T Cm_deltaE_alpha2 ;
real_T Cl_beta_0 ; real_T Cl_beta_alpha ; real_T Cl_beta_alpha2 ; real_T
Cl_p_0 ; real_T Cl_p_alpha ; real_T Cl_p_alpha2 ; real_T Cl_r_0 ; real_T
Cl_r_alpha ; real_T Cl_r_alpha2 ; real_T Cl_deltaA_0 ; real_T Cl_deltaA_alpha
; real_T Cl_deltaA_alpha2 ; real_T Cl_deltaR_0 ; real_T Cl_deltaR_alpha ;
real_T Cl_deltaR_alpha2 ; real_T Cn_beta_0 ; real_T Cn_beta_alpha ; real_T
Cn_beta_alpha2 ; real_T Cn_p_0 ; real_T Cn_p_alpha ; real_T Cn_p_alpha2 ;
real_T Cn_r_0 ; real_T Cn_r_alpha ; real_T Cn_r_alpha2 ; real_T Cn_deltaA_0 ;
real_T Cn_deltaA_alpha ; real_T Cn_deltaA_alpha2 ; real_T Cn_deltaR_0 ;
real_T Cn_deltaR_alpha ; real_T Cn_deltaR_alpha2 ; real_T CL0 ; real_T
CL_alpha ; real_T g ; real_T sampling_rate_fcs ; }
struct_l2bbyVwOb8asqLFc6mGQ4B ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_WA4b5EzbzxH6pRtlcnkbbD_
#define DEFINED_TYPEDEF_FOR_struct_WA4b5EzbzxH6pRtlcnkbbD_
typedef struct { real_T a ; real_T b ; real_T phi0 ; real_T s_trans_retract ;
real_T init_sol ; } struct_WA4b5EzbzxH6pRtlcnkbbD ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_tsATL4x2pPPJwZkYY6vf3F_
#define DEFINED_TYPEDEF_FOR_struct_tsATL4x2pPPJwZkYY6vf3F_
typedef struct { real_T l_tether_min ; real_T l_tether_max ; real_T
dlat_retraction ; real_T lat_max ; real_T dlat_transition ; real_T va_min ;
real_T dlong_transition ; real_T lat_trans_traction ; }
struct_tsATL4x2pPPJwZkYY6vf3F ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_nMRMB5qj13SdWFHXuruB9F_
#define DEFINED_TYPEDEF_FOR_struct_nMRMB5qj13SdWFHXuruB9F_
typedef struct { real_T Klqr_s [ 18 ] ; } struct_nMRMB5qj13SdWFHXuruB9F ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_r31hl1KcaKVWraMCRB46AE_
#define DEFINED_TYPEDEF_FOR_struct_r31hl1KcaKVWraMCRB46AE_
typedef struct { real_T gs ; real_T R ; real_T n ; real_T Ts ; real_T rhos ;
real_T ps ; real_T wv_ref_6m ; } struct_r31hl1KcaKVWraMCRB46AE ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_Unit6gTlhQcDbqhGR3ex7C_
#define DEFINED_TYPEDEF_FOR_struct_Unit6gTlhQcDbqhGR3ex7C_
typedef struct { real_T AP_Ts ; real_T T_sensor ; }
struct_Unit6gTlhQcDbqhGR3ex7C ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_vYwCFuiAwYvnYUbjQrt9LE_
#define DEFINED_TYPEDEF_FOR_struct_vYwCFuiAwYvnYUbjQrt9LE_
typedef struct { real_T c0 ; real_T d0 ; real_T rho_t ; real_T d_tether ;
real_T CD_tether ; real_T np ; real_T l0 ; } struct_vYwCFuiAwYvnYUbjQrt9LE ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_pRZrTErR4CmX8saGIFHKh_
#define DEFINED_TYPEDEF_FOR_struct_pRZrTErR4CmX8saGIFHKh_
typedef struct { real_T omega0 ; real_T zeta ; real_T range ; real_T sigma ;
real_T Ts ; } struct_pRZrTErR4CmX8saGIFHKh ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_27iGKDG9Xh65BSFAxogJC_
#define DEFINED_TYPEDEF_FOR_struct_27iGKDG9Xh65BSFAxogJC_
typedef struct { real_T bias ; real_T sigma ; real_T Ts ; }
struct_27iGKDG9Xh65BSFAxogJC ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_VMAeqpybirA53tIiPzycnC_
#define DEFINED_TYPEDEF_FOR_struct_VMAeqpybirA53tIiPzycnC_
typedef struct { real_T omega0 ; real_T zeta ; }
struct_VMAeqpybirA53tIiPzycnC ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_Lqw8OGqztRGakolwZlYmSC_
#define DEFINED_TYPEDEF_FOR_struct_Lqw8OGqztRGakolwZlYmSC_
typedef struct { real_T omega0 ; real_T zeta ; real_T sigma ; real_T bias ; }
struct_Lqw8OGqztRGakolwZlYmSC ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_pDRHgk717bh8GlULF8nHuE_
#define DEFINED_TYPEDEF_FOR_struct_pDRHgk717bh8GlULF8nHuE_
typedef struct { real_T Ts ; real_T bias ; real_T sigma ; }
struct_pDRHgk717bh8GlULF8nHuE ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_09XiEeIuIVUKmzIc8N9FqD_
#define DEFINED_TYPEDEF_FOR_struct_09XiEeIuIVUKmzIc8N9FqD_
typedef struct { real_T Ts ; real_T sigmaNorth ; real_T sigmaEast ; real_T
sigmaAltitude ; real_T TMarkov ; } struct_09XiEeIuIVUKmzIc8N9FqD ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_yefgVgsJTPAOP4GlyWY39D_
#define DEFINED_TYPEDEF_FOR_struct_yefgVgsJTPAOP4GlyWY39D_
typedef struct { real_T sigma ; real_T bias ; } struct_yefgVgsJTPAOP4GlyWY39D
;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_e24UZuYdRCmWqnwLx4iKq_
#define DEFINED_TYPEDEF_FOR_struct_e24UZuYdRCmWqnwLx4iKq_
typedef struct { struct_pRZrTErR4CmX8saGIFHKh RateGyros ;
struct_pRZrTErR4CmX8saGIFHKh Acc ; struct_27iGKDG9Xh65BSFAxogJC AbsPressure ;
struct_27iGKDG9Xh65BSFAxogJC DiffPressure ; struct_VMAeqpybirA53tIiPzycnC AoA
; struct_Lqw8OGqztRGakolwZlYmSC beta ; struct_pDRHgk717bh8GlULF8nHuE Compass
; struct_09XiEeIuIVUKmzIc8N9FqD GPS ; struct_yefgVgsJTPAOP4GlyWY39D alpha ; }
struct_e24UZuYdRCmWqnwLx4iKq ;
#endif
typedef struct P_testAWE_Testbed_opt4b_T_ P_testAWE_Testbed_opt4b_T ;
#endif
