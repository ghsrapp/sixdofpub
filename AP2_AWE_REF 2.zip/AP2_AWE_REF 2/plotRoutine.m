
%% Plot routine
close all; 
%%
plot3( pos_W.Data(:,1), pos_W.Data(:,2), pos_W.Data(:,3), '-b' );
%plot3( pos_W.Data(:,1), pos_W.Data(:,2), zeros( length(pos_W.Data),1), '--k' );
%plot3( pos_W.Data(:,1), 100*ones( length(pos_W.Data),1), pos_W.Data(:,3), '--k' );
%plot3( zeros( length(pos_W.Data),1), pos_W.Data(:,2), pos_W.Data(:,3), '--k' ); hold on;
view( 70, 20);

%% ==== Plotting
l_tether = norm(waypoint_mat(end,:));
l_tether = 160; 
r_SE = r_d / l_tether; % This is the radius on the small earth
lat = latChoose;
if 1
    % l_tether = 200;
    t = linspace( 0,2*pi , 100);
    phi = linspace(0,2*pi, 100);
    grid on
    t1 = linspace( 2*pi, pi , 1000);
    t2 = linspace( pi, 0 , 1000);
    close all;
    FigHandle = figure(1);
    if 1
        [X,Y,Z] = sphere(50);
        s = surf(X*l_tether, Y*l_tether, Z*l_tether);
        set(s, 'FaceAlpha', 0.1);
        cmap = [180,180,180]./256;
        cmap = [0.8,0.8,0.8];
        colormap(cmap);
    end
    grid on; hold on;
    axis equal; hold on;
    xlabel('x'); hold on;
    ylabel('y'); hold on;
    zlabel('z'); hold on;
    view(90,latChoose*180/pi); hold on;
    set(FigHandle, 'Position', [100, 100, 649, 500]);
    axis([-10 200 -150 150 0 150])
    longLeft = -asin(maxWidth/2 / (cos(latChoose)*l_tether) );
    
    x_circle1 = r_SE * cos(t1);
    y_circle1 = r_SE* sin(t1);
    
    % Circle two
    x_circle2 = r_SE * cos(t2);
    y_circle2 = r_SE* sin(t2);
    z_circle = zeros(1, length(x_circle1));
    v_circ1 = [ x_circle1; y_circle1; z_circle] * l_tether;
    v_circ2 = [ x_circle2; y_circle2; z_circle] * l_tether;
    
    % First circle
    M_NE_left = [-sin(latChoose)*cos(longLeft), -sin(latChoose)*sin(longLeft), cos(latChoose);
        -sin(longLeft), cos(longLeft), 0;
        -cos(latChoose)*cos(longLeft), -cos(latChoose)*sin(longLeft), -sin(latChoose)];
    M_EN_left = M_NE_left';
    v_circ_E1 = M_EN_left * v_circ1;
    
    % This is important: Definitions of the center of the circle
    deltaAngle = asin( r_SE );
    s = cos(deltaAngle);
    p_circO1_E =  s*[cos(longLeft)*cos(latChoose);...
        sin(longLeft)*cos(latChoose);...
        sin(latChoose)];
    
    % sommit
    p01_E = M_EN_left * [0;0;-1];
    
    % Second circle
    longRight = -longLeft;
    M_NE_right = [-sin(latChoose)*cos(longRight), -sin(latChoose)*sin(longRight), cos(latChoose);
        -sin(longRight), cos(longRight), 0;
        -cos(latChoose)*cos(longRight), -cos(latChoose)*sin(longRight), -sin(latChoose)];
    
    % unit vectors
    %e_N_x = [-sin(latChoose)*cos(longRight), -sin(latChoose)*sin(longRight), cos(latChoose)]';
    %e_N_y = [-sin(longRight), cos(longRight), 0];
    %e_N_z = [ -cos(latChoose)*cos(longRight), -cos(latChoose)*sin(longRight), -sin(latChoose)];
    
    M_EN_right = M_NE_right';
    v_circ_E2 = M_EN_right * v_circ2;
    
    % This is important: Definitions of the center of the circle
    p_circO2_E = s*[cos(longRight)*cos(latChoose);...
        sin(longRight)*cos(latChoose);...
        sin(latChoose)];
    
    % Sommit
    p02_E = M_EN_right * [0;0;-1];
    col = [0.4 0.4 0.4];
    
    if 1
        plot3(v_circ_E1(1,:)+p_circO1_E(1)* l_tether, v_circ_E1(2,:)+p_circO1_E(2)* l_tether, v_circ_E1(3,:)+p_circO1_E(3)* l_tether,'color',col, 'Linewidth', 1.4); hold on
        plot3(v_circ_E2(1,:)+p_circO2_E(1)* l_tether, v_circ_E2(2,:)+p_circO2_E(2)* l_tether, v_circ_E2(3,:)+p_circO2_E(3)* l_tether,'color',col', 'Linewidth', 1.4);
    end
    % Definition of the waypoints
    left_top = [r_SE; 0; 0];
    left_bottom = [-r_SE; 0; 0];
    left_top_E = M_EN_left * left_top;
    left_bottom_E = M_EN_left * left_bottom;
    left_top_abs_E = p_circO1_E + left_top_E;
    left_bottom_abs_E = p_circO1_E + left_bottom_E;
    
    right_bottom = [-r_SE; 0; 0];
    right_top = [r_SE; 0; 0];
    right_bottom_E = M_EN_right * right_bottom;
    right_bottom_abs_E = p_circO2_E + right_bottom_E;
    right_top_E = M_EN_right * right_top;
    right_top_abs_E = p_circO2_E + right_top_E;
    
    
    
    % middle point
    lat_bottom = asin( right_bottom_abs_E(3)/norm(right_bottom_abs_E) );
    mid_bottom_abs_E = [right_bottom_abs_E(1);0;right_bottom_abs_E(3)];%l_tether*[cos(lat_bottom);0;sin(lat_bottom)]; %
    if 1
        plot3(left_top_abs_E(1)/norm(left_top_abs_E)*l_tether, left_top_abs_E(2)/norm(left_top_abs_E)*l_tether, left_top_abs_E(3)/norm(left_top_abs_E)*l_tether, 'color',col, 'Marker', '+');
        plot3(left_bottom_abs_E(1)/norm(left_bottom_abs_E)*l_tether, left_bottom_abs_E(2)/norm(left_bottom_abs_E)*l_tether, left_bottom_abs_E(3)/norm(left_bottom_abs_E)*l_tether, 'color',col, 'Marker', '+');
        plot3(right_bottom_abs_E(1)/norm(right_bottom_abs_E)*l_tether, right_bottom_abs_E(2)/norm(right_bottom_abs_E)*l_tether, right_bottom_abs_E(3)/norm(right_bottom_abs_E)*l_tether,  'color',col, 'Marker', '+');
        plot3(right_top_abs_E(1)/norm(right_top_abs_E)*l_tether, right_top_abs_E(2)/norm(right_top_abs_E)*l_tether, right_top_abs_E(3)/norm(right_top_abs_E)*l_tether, 'color',col, 'Marker', '+');
    end
    
    % calculate normal vector
    rot_vec_1 = cross( right_top_abs_E/norm(right_top_abs_E), left_bottom_abs_E/norm(left_bottom_abs_E));
    %rot_vec_2 = cross( left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_2 = cross( mid_bottom_abs_E/norm(mid_bottom_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_3 = cross( left_top_abs_E/norm(left_top_abs_E), mid_bottom_abs_E/norm(mid_bottom_abs_E));
    rot_vec_4 = cross( left_bottom_abs_E/norm(left_bottom_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_5 = cross( mid_bottom_abs_E/norm(mid_bottom_abs_E), right_top_abs_E/norm(right_top_abs_E));
    rot_vec_6 = cross( left_top_abs_E/norm(left_top_abs_E), right_top_abs_E/norm(right_top_abs_E));
    rot_vec_7 = cross( left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    
    
    
    rot_vec_8 = cross( zenith_pos/norm(zenith_pos), reference_pos/norm(reference_pos));
    %rot_vec_trans = cross( zenith_E/norm(zenith_E), left_top_abs_E/norm(left_top_abs_E));
    
    % Calculate orthonormal basis that lies in the great circle plane:
    e_x_1 = right_top_abs_E/norm(right_top_abs_E); e_z_1 = rot_vec_1/norm(rot_vec_1);e_y_1 = cross(e_z_1,e_x_1);
    %e_x_2 = left_top_abs_E/norm(left_top_abs_E); e_z_2 = rot_vec_2/norm(rot_vec_2);e_y_2 = cross(e_z_2,e_x_2);
    e_x_2 = mid_bottom_abs_E/norm(mid_bottom_abs_E); e_z_2 = rot_vec_2/norm(rot_vec_2);e_y_2 = cross(e_z_2,e_x_2);
    e_x_3 = left_top_abs_E/norm(left_top_abs_E); e_z_3 = rot_vec_3/norm(rot_vec_3);e_y_3 = cross(e_z_3,e_x_3);
    e_x_4 = left_bottom_abs_E/norm(left_bottom_abs_E); e_z_4 = rot_vec_4/norm(rot_vec_4);e_y_4 = cross(e_z_4,e_x_4);
    e_x_5 = mid_bottom_abs_E/norm(mid_bottom_abs_E); e_z_5 = rot_vec_5/norm(rot_vec_5);e_y_5 = cross(e_z_5,e_x_5);
    e_x_6 = left_top_abs_E/norm(left_top_abs_E); e_z_6 = rot_vec_6/norm(rot_vec_6);e_y_6 = cross(e_z_6,e_x_6);
    e_x_7 = left_top_abs_E/norm(left_top_abs_E); e_z_7 = rot_vec_7/norm(rot_vec_7);e_y_7 = cross(e_z_7,e_x_7);
    % zenith
    e_x_8 = zenith_pos/norm(zenith_pos); e_z_8 = rot_vec_8/norm(rot_vec_8);e_y_8 = cross(e_z_8,e_x_8);
    %e_x_trans = zenith_E/norm(zenith_E); e_z_trans = rot_vec_trans/norm(rot_vec_trans);e_y_trans = cross(e_z_trans,e_x_trans);
    
    % Plotting the great circles
    M_GE_1 = [e_x_1'; e_y_1'; e_z_1'];
    M_GE_2 = [e_x_2'; e_y_2'; e_z_2'];
    M_GE_3 = [e_x_3'; e_y_3'; e_z_3'];
    M_GE_4 = [e_x_4'; e_y_4'; e_z_4'];
    M_GE_5 = [e_x_5'; e_y_5'; e_z_5'];
    M_GE_6 = [e_x_6'; e_y_6'; e_z_6'];
    M_GE_7 = [e_x_7'; e_y_7'; e_z_7'];
    M_GE_8 = [e_x_8'; e_y_8'; e_z_8'];
    %   M_GE_trans = [e_x_trans'; e_y_trans'; e_z_trans'];
    
    great_circle_1_G =   [cos(t); sin(t); zeros(1,length(t))] * l_tether;
    great_circle_1_E = M_GE_1' * great_circle_1_G;
    great_circle_2_E = M_GE_2' * great_circle_1_G;
    great_circle_3_E = M_GE_3' * great_circle_1_G;
    great_circle_4_E = M_GE_4' * great_circle_1_G;
    great_circle_5_E = M_GE_5' * great_circle_1_G;
    great_circle_6_E = M_GE_6' * great_circle_1_G;
    great_circle_7_E = M_GE_7' * great_circle_1_G;
    great_circle_8_E = M_GE_8' * great_circle_1_G;
    % great_circle_trans_E = M_GE_trans' * great_circle_1_G;
    if 1
        zenith_E = [0;0;1];
        %if figIndx == 4 || figIndx ==3
            plot3( great_circle_8_E(1,:), great_circle_8_E(2,:), great_circle_8_E(3,:),'color',col, 'Linewidth', 1.4); hold on
            plot3( great_circle_1_E(1,:), great_circle_1_E(2,:), great_circle_1_E(3,:),'color',col, 'Linewidth', 1.4); hold on
            plot3( great_circle_7_E(1,:), great_circle_7_E(2,:), great_circle_7_E(3,:),'color',col, 'Linewidth', 1.4); hold on
%         elseif figIndx == 2
%             plot3(mid_bottom_abs_E(1)/norm(mid_bottom_abs_E)*l_tether, mid_bottom_abs_E(2)/norm(mid_bottom_abs_E)*l_tether, mid_bottom_abs_E(3)/norm(mid_bottom_abs_E)*l_tether, '*r');
%             plot3( great_circle_3_E(1,:), great_circle_3_E(2,:), great_circle_3_E(3,:),'color',col, 'Linewidth', 1.4); hold on
%             plot3( great_circle_5_E(1,:), great_circle_5_E(2,:), great_circle_5_E(3,:),'color',col, 'Linewidth', 1.4); hold on
%         end
    end
    
    % if 1
    %     plot3( waypoint_mat(:,1), waypoint_mat(:,2), waypoint_mat(:,3), '--*k');
    %  end
    
    %plot3( great_circle_4_E(1,:), great_circle_4_E(2,:), great_circle_4_E(3,:),'--g', 'Linewidth', 2); hold on
   
    %normalVectors; % visualize half space
else
    plot3( -waypoint_mat(:,1), waypoint_mat(:,2),-waypoint_mat(:,3), '--ok'); hold on 
%    axis([-1 30 -10 10 -1 100]); hold on 
        axis([-10 300 -150 150 0 300])
    grid on; hold on
  view([-1, -1]); hold on; 
    axis equal; 
end
% animate;
vehicle_handle = []; 
if 1 
[transition_idx,a] = find(kiteModeTransitionFlag==1); 
if 0
    plot3(pos_W.Data(transition_idx,1), pos_W.Data(transition_idx,2), pos_W.Data(transition_idx,3),'.r')  ; hold on 
    plot3(pos_W.Data(:,1), pos_W.Data(:,2), pos_W.Data(:,3),'-b')  ;
    plot3(p_VT_E.Data(:,1), p_VT_E.Data(:,2), p_VT_E.Data(:,3),'-g');
else
    
    h_tot = [];
    cnt = 1;
    h_pos = [];
    %
    %plot3( pos_W.Data(:,1), pos_W.Data(:,2), pos_W.Data(:,3), 'color','[0.4 0.4 0.4]', 'Linewidth', 0.5, 'Linestyle', '--'); hold on
    h_cnt = 0;
    dTcnt = 100; 
    for tcnt = 1 : dTcnt : length ( pos_W.Data(:,1) )
      %pause(0.001); 
        title(['Sim time: ', num2str( sim_time(tcnt) ), ' (s)'] );
       % pause;
        % Calculate body fixed frame in W coordinates
        phi = phi_save(tcnt)*pi/180;
        theta = theta_save(tcnt)*pi/180;
        psi = psi_save(tcnt)*pi/180;
        
        pos_O = M_OW * pos_W.Data(tcnt,:)';
        pn = pos_O(1); pe = pos_O(2); pd = pos_O(3);
        if 1
            if tcnt==1
                [Vertices, Faces, facecolors] = defineVehicleBody;
                vehicle_handle = drawVehicleBody(Vertices, Faces, facecolors, ...
                    pn, pe, pd, phi, theta, psi, ...
                    [], 'normal');
            else
                handleSave(tcnt) = drawVehicleBody(Vertices, Faces, facecolors,...
                    pn, pe, pd, phi, theta, psi, ...
                    vehicle_handle);
            end
            end
        %delete(vehicle_handle); 
        if 1 
            %pause;
            if kiteModeTransitionFlag(tcnt)  
               modD = 500;
               view(0,0);
               axis([-10 200 -150 150 0 150])
               %pause(0.001);
               %plot3( [0 pos_W.Data(tcnt,1)], [0 pos_W.Data(tcnt,2)], [0 pos_W.Data(tcnt,3)], '*r');
            elseif kiteModeFlag(tcnt)
                  modD = 50;
                  view(0,0);
                  axis([-10 200 -150 150 0 150])
                  view(90,15);
                  %pause(0.1);
            elseif landingApproachFlag(tcnt)
                modD = 50;
            elseif vtolLandingFlag
               view(0,0);
                axis([-1 200 -100 100 0 150]); 
                modD = 1000;
            else
               view(0,0);
                axis([-1 200 -100 100 0 150]); 
                modD = 10000;
            end
            if 0
                if mod(tcnt-1, modD) == 0
                    [Vertices, Faces, facecolors] = defineVehicleBody;
                    vehicle_handle = drawVehicleBody(Vertices, Faces, facecolors, ...
                        pn, pe, pd, phi, theta, psi, ...
                        [], 'normal');
                  %  plot3( [0 pos_W.Data(tcnt,1)], [0 pos_W.Data(tcnt,2)], [0 pos_W.Data(tcnt,3)], '-k');
                    %pause;
                end
            end
        end
        %title(['Time = ', num2str(sim_time(tcnt)), ' \Phi = ', num2str( phi_save(tcnt)), ' \Theta = ', num2str( theta_save(tcnt)), ' \Psi = ', num2str( psi_save(tcnt))]);
        
        
        e_xB_O = [cos(psi)*cos(theta); sin(psi)*cos(theta); -sin(theta)];
        e_yB_O = [cos(psi)*sin(theta)*sin(phi)-sin(psi)*cos(phi); sin(psi)*sin(theta)*sin(phi)+cos(psi)*cos(phi); cos(theta)*sin(phi)];
        e_zB_O = [cos(psi)*sin(theta)*cos(phi)+sin(psi)*sin(phi); sin(psi)*sin(theta)*cos(phi)-cos(psi)*sin(phi); cos(theta)*cos(phi)];
        
        scale = 10;
        
        e_x_W = scale*M_WO*e_xB_O;
        e_y_W = scale*M_WO*e_yB_O;
        e_z_W = scale*M_WO*e_zB_O;
        
        
        delete(h_tot);
        %h_pos = zeros(100,1);
        if h_cnt >= 100*300
            delete( h_pos(1) );
            h_pos(1) = [];
            h_pos_new = plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), '.b', 'Linewidth', 2, 'Markersize', 5 ); hold on
            h_pos = [h_pos;h_pos_new];
        else
            h_cnt = h_cnt + 1;
            if kiteModeTransitionFlag(tcnt)
                h_pos_new = plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), '.r', 'Linewidth', 2, 'Markersize', 5 ); hold on
            elseif landingApproachFlag(tcnt)
                h_pos_new = plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), '.m', 'Linewidth', 2, 'Markersize', 5 ); hold on
            else
                h_pos_new = plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), '.b', 'Linewidth', 2, 'Markersize', 5 ); hold on
            end
                h_pos = [h_pos;h_pos_new];
        end
        
        %h_pos = [h_pos, h_pos1];
        
        %plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), 0, '.k' );
        %plot3( 0, pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), '.k' );
        %plot3( pos_W.Data(tcnt,1), 200, pos_W.Data(tcnt,3), '.k' );
       
        if kiteMode
            h_VT = [];%plot3( p_VT_E.Data(tcnt,1)/norm(p_VT_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                %p_VT_E.Data(tcnt,2)/norm(p_VT_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                %p_VT_E.Data(tcnt,3)/norm(p_VT_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)), 'color', 'green', 'Marker', '+' );
        else
            if kiteModeTransitionFlag(tcnt) || kiteModeFlag(tcnt)
                h_VT = [];%plot3( p_VT_E.Data(cnt_kiteMode,1)/norm(p_VT_E.Data(cnt_kiteMode,:))*norm(pos_W.Data(tcnt,:)),...
                          %    p_VT_E.Data(cnt_kiteMode,2)/norm(p_VT_E.Data(cnt_kiteMode,:))*norm(pos_W.Data(tcnt,:)),...
                           %   p_VT_E.Data(cnt_kiteMode,3)/norm(p_VT_E.Data(cnt_kiteMode,:))*norm(pos_W.Data(tcnt,:)), 'color', 'magenta', 'Marker', '+', 'Markersize', 15 );
                cnt_kiteMode = cnt_kiteMode + 100; 
            else
                cnt_kiteMode = 1; 
                h_VT = [];%plot3( p_VT_VTOL_E.Data(tcnt,1)/norm(p_VT_VTOL_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                %p_VT_VTOL_E.Data(tcnt,2)/norm(p_VT_VTOL_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                %p_VT_VTOL_E.Data(tcnt,3)/norm(p_VT_VTOL_E.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)), 'color', 'green', 'Marker', '+' );
            end
        end
        
         h_projPos = [];%plot3( p_test_proj.Data(tcnt,1)/norm(p_test_proj.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                       %p_test_proj.Data(tcnt,2)/norm(p_test_proj.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)),...
                       %p_test_proj.Data(tcnt,3)/norm(p_test_proj.Data(tcnt,:))*norm(pos_W.Data(tcnt,:)), 'color', 'green', 'Marker', '+' );
       
        
        h_tether = plot3( [0 pos_W.Data(tcnt,1)], [0 pos_W.Data(tcnt,2)], [0 pos_W.Data(tcnt,3)], '-k');
        h_p = plot3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), 'xb' );
        
        h_bearing = [];%quiver3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), scale*bearing_vec_proj_W.Data(tcnt,1), scale*bearing_vec_proj_W.Data(tcnt,2), scale*bearing_vec_proj_W.Data(tcnt,3));
       
        h_Refbearing = [];%quiver3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), scale*refBearing.Data(tcnt,1), scale*refBearing.Data(tcnt,2), scale*refBearing.Data(tcnt,3));
        
        set(h_bearing, 'Linewidth', 1.2, 'color', '[0.0 0.5  0.0]','Linestyle','-','MaxHeadSize', 0.6);
        set(h_Refbearing, 'Linewidth', 1.2, 'color',  'red','Linestyle','-','MaxHeadSize', 0.6);
        
        if 0
            h_ex =quiver3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), e_x_W(1), e_x_W(2), e_x_W(3) );
            h_ey = quiver3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), e_y_W(1), e_y_W(2), e_y_W(3) );
            h_ez = quiver3( pos_W.Data(tcnt,1), pos_W.Data(tcnt,2), pos_W.Data(tcnt,3), e_z_W(1), e_z_W(2), e_z_W(3) );
            
            set(h_ex, 'Linewidth', 1.2, 'color','magenta','Linestyle','-','MaxHeadSize', 0.6);
            set(h_ey, 'Linewidth', 1.2,  'color','black','Linestyle','-','MaxHeadSize', 0.6);
            set(h_ez, 'Linewidth', 1.2,  'color','black','Linestyle','-','MaxHeadSize', 0.6);
        end
        % h_tot = [h_VT, h_p,h_tether,h_bearing,h_Refbearing, h_ex, h_ey, h_ez];
        h_tot = [h_VT, h_p,h_tether,h_bearing,h_Refbearing, h_projPos];
        drawnow;
        T_save = 2;
        savePics = 0;
        if savePics
            if mod(cnt-1, T_save) == 0
                if cnt == 1
                   print([eval('pwd'),'/video/','vidPic_',num2str(cnt)], '-dpng', '-r300');
                else
                    print([eval('pwd'),'/video/','vidPic_',num2str((cnt-1)/T_save)], '-dpng', '-r300');
                end
            end
        end
        cnt = cnt + 1;
    end
end
%%
videoRecOn =0;
if videoRecOn
    addpath('video');
    writerObj = VideoWriter('powerGen.avi');
    open(writerObj);
    for K = 1 : 239
        filename = sprintf(['vidPic_','%d.png'], K);
        thisimage = imread(filename);
        writeVideo(writerObj, thisimage);
    end
    close(writerObj);
end
%plot3( pos_W.Data(:,1), pos_W.Data(:,2), pos_W.Data(:,3), '-b', 'Linewidth', 2 )

end