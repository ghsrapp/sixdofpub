function [x0_trim,u0_trim,K_long,K_lat, HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br, A_long_aug, B_long_aug, A_lat_aug, B_lat_aug] =  generateRetractionPhaseController( sim_with_indx, path_with_gains )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;
save_flag = 0;

%path_with_gains = 'Trim_results/trim_case_1';
%path_with_gains = 'Trim_results/retr_trim_case_1_20mDs_m3And0deg_gamma_m10';

%addpath(path_with_gains); 

load([path_with_gains,'/G_save.mat']);
load([path_with_gains,'/rps_st.mat']);
load([path_with_gains,'/x0_save.mat']);
load([path_with_gains,'/u0_save.mat']);
load([path_with_gains,'/M_OB_init.mat']);


% Q_lat = eye( 4 );
% Q_lat(1,1) = 0.1; 
% Qi_lat = 1*diag([2000,10000]);
% Qs_lat = mdiag(Q_lat,Qi_lat); 
% R_lat = 1000*diag([1,0.1]);
%%
% Q     = 0*eye(4);
% Q(1,1) = 0; 
% Q(2,2) = 0; 
% Q(3,3) = 0; 
% Q(4,4) = 0.2; 
% Q(5,5) = 3;
% R_long = 1;
% Qs_long = Q;
Q     = 0*eye(4);
Q(1,1) = 0; 
Q(2,2) = 0; 
Q(3,3) = 0; 
Q(4,4) = 0.2; 
Q(5,5) = 3;
R_long = 1;
Qs_long = Q;
% 
Q_lat = eye( 4 );
Q_lat(1,1) = 1; 
Qi_lat = 1*diag([50,50]);
Qs_lat = mdiag(Q_lat,Qi_lat); 
R_lat = diag([1,1]);


[K_lat, K_long, A_long_aug, A_lat, B_long_aug, B_lat, B_long_wFt, Mx, Mu, A_lat_aug, B_lat_aug] = lqr_w_psi_wVa_test_decoupled_retraction(G_save{sim_with_indx}, Qs_lat,R_lat,Qs_long, R_long);

% Some step responses of the lateral controller
A_lat_cl = A_lat_aug - B_lat_aug * K_lat;
B_lat_cl = B_lat_aug.*0;
B_lat_cl(end-1, 1) = 1;
B_lat_cl(end,2) = 1;
sys_beta = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0], [] );
sys_phi = ss( A_lat_cl, B_lat_cl, [0,1,0,0,0,0], [] );
tvec = 0 : 0.1 : 12;

opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
% BETA
[y,t] = step(sys_beta,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,1)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t(:,:,1)./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\beta_a$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_beta');
    cd ..
end
% PHI
[y,t] = step(sys_phi,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,2)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\Phi_tau$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_phi');
    cd ..
end

Q = 0*eye(5); 
Q(1,1) = 0; 
Q(2,2) = 5;%5; 
Q(3,3) = 0; 
Q(4,4) = 0; 
Q(5,5) = 50;  % 100
R = 1; 

[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = test_simple_piecewise_L1_aug(A_long_aug,B_long_aug, Q, R);
K_long = Kbl;
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\alpha_a$ $(deg)$');
axis([0 12 0 12]);
%%
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI');
    cd ..
end

% Trim states and inputs
x0_trim = x0_save(:,sim_with_indx);
u0_trim = u0_save(:,sim_with_indx);

