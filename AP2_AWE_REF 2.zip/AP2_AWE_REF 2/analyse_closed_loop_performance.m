function analyse_closed_loop_performance( A_p, B_p, C_p, C_s, Klqr )


col = [0,206,209]/255; 
n = size(A_p,1); 
m = size( B_p, 2 ); 
ne = size( C_s,1 ); 

%% Controller model 
Ac = zeros(2); 
Bc1 = -C_s; 
Bc2 = C_s; 
Cc = -Klqr(1:m, end-ne+1:end); 
Dc1 = -Klqr(1:m, 1:end-ne); 


%% Closed loop system 
A_cl = [A_p + B_p*Dc1, B_p*Cc; 
    -C_s,  zeros(ne, m )]; 
B_cl = [zeros(n,m); eye(ne,m)];

% Loop gain at plant input
Ali = [A_p, zeros(n,m); 
    -C_s, zeros(m)]; 
Bli = [B_p; zeros(m)]; 
Cli = [Dc1, Cc]; 
Dli = zeros(ne,m); 

sys_li = ss( Ali, Bli, Cli, [] ); 

% Loop gain at plant output
Alo = [A_p, B_p*Cc; 
    zeros(ne,n), zeros(ne,m)]; 
Blo = [B_p*Dc1; Bc1]; 
Clo = [C_p zeros(n,m)];

sys_lo = ss( Ali, Blo, Clo, [] ); 
%% Performance weights
Wp = tf( makeweight(100, 5, 0.1) );

%% Now we have all the state space models: Lets check performance metrics
omegas = logspace( -4, 2, 1000 ); 
for k = 1 : length( omegas )
     [U,S,V] = svd(  freqresp( sys_lo, omegas(k) ) ); 
     max_sv_lo(k) = max( diag(S) ); 
     min_sv_lo(k) = min( diag(S) ); 
     
     wp_frsp(k) = abs(  freqresp( 1/Wp, omegas(k) ) ) ;
     
     %[U,S,V] = svd( eye(2) +  freqresp( sys_li, omegas(k) ) ); 
     
     %[U,S,V] = svd( eye(2) +  inv( freqresp( sys_li, omegas(k) ) ) ); 
     
     [U,S,V] = svd(  inv(  eye(2) + freqresp( sys_li, omegas(k) ) ) ); % Sensitivity
 
     %[U,S,V] = svd(  eye(2) - inv(  eye(2) + freqresp( sys_li, omegas(k) )
     %) ); % Complementary Sensitivity
     
     max_sv(k) = max( diag(S) ); 
     min_sv(k) = min( diag(S) ); 
end
%%
figure;
plot( omegas, (max_sv) ,'-b', 'Linewidth', 2); hold on 
plot( omegas, (min_sv),'color',col,'Linewidth', 2 )
%plot( omegas,(min_sv_lo),'color','red','Linewidth', 2 )
plot( omegas, 1./wp_frsp,'color','red','Linewidth', 2 )
xlabel('\omega (rad/s)');
ylabel('\sigma_{min,max}(G)')
set(gca, 'XScale', 'log');
set(gca, 'YScale', 'log');
