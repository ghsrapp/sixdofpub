close all
mks = 10;

LQR_flag = 0; 

% Controller: 
if LQR_flag
    load('UsedGains/K_lat_1'); 
else
    load('UsedGains/K_lat_MMLQR'); 
end

h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);

h7 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);


folder = 'Trim_results/case_1_16kN20kN_alpha4and7and10';
addpath( folder );
load('G_save.mat');
load('x0_save.mat');

% Extract matrices

indx = [1,3,5,7,9];
k_max = length( indx ); 
mks_low = 5;
mks_high = 10;
lw_high = 1.2;
lw_low = 1.2;
alpha_high = 1;
alpha_low = 0.3;

airspeed_order = [2, 5, 3, 1, 4]; 
for k = 1 : k_max
    
    k_real = airspeed_order(k);
    
    Va_trim = x0_save(1,indx(k))
    a_mks = (k_real-1)/(k_max-1);
    mks = (1-a_mks)*mks_high + a_mks*mks_low;
    lw = (1-a_mks)*lw_high + a_mks*lw_low;
    alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
    
    
    
    
    idx = indx(k);
    A = G_save{idx}.A(1:9, 1:9);
    B = G_save{idx}.B(1:9, 1:4);
    
    A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
        A(3,1), A(3,3), A(3, 5), A(3,8);
        A(5,1), A(5,3), A(5, 5), A(5,8);
        A(8,1), A(8,3), A(8, 5), A(8,8)];
    B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
    C = [0,1,0,0];
    
    C_control = zeros(1, size( A_long,2) );
    C_control(1,2) = 1;
    A_long_aug = [A_long, zeros(size( A_long,2) ,2);
        -C_control, zeros(1,1)];
    B_long_aug = [B_long; zeros(2)];
    
    damp( A_long_aug-B_long_aug*K_long ) 
    
    C_lat = [1,0,0,0,0,0;
        0,1,0,0,0,0];
    lw = 1.2;
    [vec,val ] = eig( A_lat_aug-B_lat_aug*K_lat );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    norms = abs( vec );
    
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    figure(7); 
    [vec,val ] = eig( A_lat_aug-B_lat_aug*K_lat );
    val = diag(val);


    if k == 3
        plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
        plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    else
        plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
        plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(3) ), imag( val(3) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(5) ), imag( val(5) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(6) ), imag( val(6) ), 'x', 'color', col2, 'Markersize', mks);
        %
%         plot( real( val(1) ), imag( val(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
%         plot( real( val(2) ), imag( val(2) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(3) ), imag( val(3) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(4) ), imag( val(4) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(5) ), imag( val(5) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(6) ), imag( val(6) ), 'x', 'color', col1, 'Markersize', mks);
    end
    if k == 0
        figure(1); % Rollmotion
        [val, idx] = max( abs( vec(:,1)  ) );
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        % title('Rollmotion');
        
        
        figure(2);
        [val, idx] = max( abs( vec(:,2)  ) );
        R = exp(sqrt(-1)*(-phase(idx,2))); %rotation by phase p
        vec_rot = R * vec(:,2);
        phase(:,2) = angle( vec_rot );
        polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
        %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  title('DR');
        
        figure(3);
        [val, idx] = max( abs( vec(:,4)  ) );
        R = exp(sqrt(-1)*(-phase(idx,4))); %rotation by phase phi
        vec_rot = R * vec(:,4);
        phase(:,4) = angle( vec_rot );
        polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
        
        %% open loop
        [vec,val ] = eig( A_lat );
        vec_abs = abs(vec);
        val = diag(val);
        phase = atan2( imag(vec), real(vec) );
        norms = abs( vec );
        
        vec_abs = abs(vec);
        val = diag(val);
        phase = atan2( imag(vec), real(vec) );
        %%
        figure(4); % Rollmotion
        [val, idx] = max( abs( vec(:,1)  ) );
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        % title('Rollmotion');
        
        
        figure(5);
        [val, idx] = max( abs( vec(:,2)  ) );
        R = exp(sqrt(-1)*(-phase(idx,2))); %rotation by phase p
        vec_rot = R * vec(:,2);
        phase(:,2) = angle( vec_rot );
        polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  title('DR');
        
        figure(6);
        [val, idx] = max( abs( vec(:,4)  ) );
        R = exp(sqrt(-1)*(-phase(idx,4))); %rotation by phase phi
        vec_rot = R * vec(:,4);
        phase(:,4) = angle( vec_rot );
        polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        
        folder_name = 'ESA_lat';
%         Plot2LaTeX3(h1,['EV_star_roll_cl_',folder_name]);
%         Plot2LaTeX3(h2,['EV_star_DR_cl_',folder_name]);
%         Plot2LaTeX3(h3,['EV_star_Spiral_cl_',folder_name]);
%         Plot2LaTeX3(h4,['EV_star_roll_op_',folder_name]);
%         Plot2LaTeX3(h5,['EV_star_DR_op_',folder_name]);
%         Plot2LaTeX3(h6,['EV_star_Spiral_op_',folder_name]);
    end
    
    
    
end

figure(7);
axis( [-30 0 -8 8]);
xlabel('$\mathrm{Real}(\lambda_\mathrm{i})$');
ylabel('$\mathrm{Imag}(\lambda_\mathrm{i})$');
sgrid
folder_name = 'UsedGains';
if ESA_flag
    Plot2LaTeX2(h7,['eigenvalues_ESA_lateral'])
    movefile('eigenvalues_ESA_lateral*', 'UsedGains');
else
    Plot2LaTeX2(h7,['eigenvalues_MLQR_lateral'])
    movefile('eigenvalues_MLQR_lateral*', 'UsedGains');
end