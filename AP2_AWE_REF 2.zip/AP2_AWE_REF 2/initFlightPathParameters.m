% Define flight path

%% ====== Specifications of the path - Design parameters ==================
% In this script the flight path is specified.
% So far the path is specified as a figure of 8 flight path.
% The figure 8 is defined by the latitude (latChoose) of the origins of the circle
% segments, the radius of the circle segments (r_d) and the distance (maxWidth) between the
% the orgins of the two circle segments. In addition to that the maximum
% tether lenght can be specified (if reached this triggers the return
% phase), a minimum elevation angle, as well as the tuning parameters of
% the carrot following algorithm.

figIndx = 4;

% For each figure example paths are provided. The parameters can of course
% be adjusted if desired.

switch figIndx
    case 1 % circle
        latMin = 0; % Minimum latitude
        latChoose = 20*pi/180; % Choose latitude of the circle origins
        maxWidth = 0; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % This is the desired radius that the kite will fly
    case 2 % fake fig8
        latMin = 0; % Minimum latitude
        latChoose = 20*pi/180; % Choose latitude of the circle origins
        maxWidth = 50; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 15; % This is the desired radius that the kite will fly
    case 3 % ellipse
        latMin = 0; % Minimum latitude
        latChoose = 20*pi/180; % Choose latitude of the circle origins
        maxWidth = 40; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 20; % This is the desired radius that the kite will fly
    case 4 % fig 8
        latMin = 0; % Minimum latitude
        latChoose = 45*pi/180; % Choose latitude of the circle origins
        maxWidth = 80; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 20; % This is the desired radius that the kite will fly
end

l_tetherMax = 300; % maximum tether length

% Tuning Parameters for the pathfollowing algorithm
% Carrots
deltaAlphaLeft = -10*pi/180; % move virtual target forward on circle segments (absolute value)
deltaAlphaRight = -deltaAlphaLeft;
deltaGC = 0.01; % move virtual target forward on great circle (fraction)
% Switch regions
wpSwitchBound = 10; % scaled by 1/l_tether

zenith_pos = [-sin(1*pi/180);0;cos(1*pi/180)]; % shouldn't be reached
reference_pos = [cos(40*pi/180);0;sin(40*pi/180)];

lat = min(latChoose, 90*pi/180-2*latMin);
alpha = lat - latMin;
radMax = sin(alpha);

l_tether = norm( waypoint_mat(end,:) ); 
r_SE = r_d / l_tether; % This is the radius on the small earth

p_zenith = [0;0;-1];
p_zenith_proj = p_zenith; 

% State machine 
SM.dMaxLand = 0.3; 
SM.minParkAltitude = 100; 
SM.max_l_t_traction = l_tetherMax; 
SM.min_l_t_traction = 200; 