function [v_w_O,interval_indices_t, spat_mat_u1, spat_mat_u2,...
    spat_mat_v1, spat_mat_v2, spat_mat_w1, spat_mat_w2] = doLinInterpolation(pos_W,tvec,xvec,yvec,zvec,t_sim,interval_indices_t_u,...
    spat_mat_u1,spat_mat_u2, spat_mat_v1,spat_mat_v2, spat_mat_w1,spat_mat_w2,windDirection_rad,u_tau)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


pos_W(1) = min( max( pos_W(1), xvec(1)), xvec(end));
pos_W(2) = min( max( pos_W(2), yvec(1)), yvec(end));
pos_W(3) = min( max( pos_W(3), zvec(1)), zvec(end));

x_vec = [pos_W; t_sim]';

% Determine boundaries
[ interval_bounds_x, interval_indices_x ] = searchIntervalBounds( xvec, x_vec(1) ); % x
[ interval_bounds_y, interval_indices_y ] = searchIntervalBounds( yvec, x_vec(2) ); % y
[ interval_bounds_z, interval_indices_z ] = searchIntervalBounds( zvec, x_vec(3) ); % z
[ interval_bounds_t, interval_indices_t ] = searchIntervalBounds( tvec, x_vec(4) ); % t

t_min = interval_bounds_t(1);
t_max = interval_bounds_t(2);

if interval_indices_t(1) == interval_indices_t_u(1) && interval_indices_t(2) == interval_indices_t_u(2) 
    flag_keep_spat_mats = 1; 
else 
   flag_keep_spat_mats = 0; 
end

x_min = interval_bounds_x(1);
x_max = interval_bounds_x(2);
y_min = interval_bounds_y(1);
y_max = interval_bounds_y(2);
z_min = interval_bounds_z(1);
z_max = interval_bounds_z(2);

p_vec_max = [x_max, y_max, z_max, t_max];
p_vec_min = [x_min, y_min, z_min, t_min];

% interpolation ratios
Theta = (x_vec - p_vec_min)./(p_vec_max - p_vec_min);
Theta = Theta';

theta1 = Theta(1);
theta2 = Theta(2);
theta3 = Theta(3);
theta4 = Theta(4);

xi =[ (theta1 - 1)*(theta2 - 1)*(theta3 - 1)*(theta4 - 1),...
    -theta1*(theta2 - 1)*(theta3 - 1)*(theta4 - 1),...
    -theta2*(theta1 - 1)*(theta3 - 1)*(theta4 - 1),...
    theta1*theta2*(theta3 - 1)*(theta4 - 1),...
    -theta3*(theta1 - 1)*(theta2 - 1)*(theta4 - 1),...
    theta1*theta3*(theta2 - 1)*(theta4 - 1),...
    theta2*theta3*(theta1 - 1)*(theta4 - 1),...
    -theta1*theta2*theta3*(theta4 - 1),...
    -theta4*(theta1 - 1)*(theta2 - 1)*(theta3 - 1),...
    theta1*theta4*(theta2 - 1)*(theta3 - 1),...
    theta2*theta4*(theta1 - 1)*(theta3 - 1),...
    -theta1*theta2*theta4*(theta3 - 1),...
    theta3*theta4*(theta1 - 1)*(theta2 - 1),...
    -theta1*theta3*theta4*(theta2 - 1),...
    -theta2*theta3*theta4*(theta1 - 1),...
    theta1*theta2*theta3*theta4];

%% Calculation of the vertex weights
% => normally we would get also an index with that i.e.
% x_max_idx = ... , z_min_idx = ... . We will choose arbitray values here:
t_min_idx = interval_indices_t(1); t_max_idx = t_min_idx+1;
x_min_idx = interval_indices_x(1); x_max_idx = x_min_idx+1;
y_min_idx = interval_indices_y(1); y_max_idx = y_min_idx+1;
z_min_idx = interval_indices_z(1); z_max_idx = z_min_idx+1;

idx_vec_max = [x_max_idx,y_max_idx,z_max_idx,t_max_idx];
idx_vec_min = [x_min_idx,y_min_idx,z_min_idx,t_min_idx];

% we now create a matrix that associates the indices to max/min values
% Create vertices
numb_param = 4; % spatial coordinates with time

Vbin_max = [zeros(1,numb_param);
    de2bi(1:2^numb_param-1)];
Vbin_min = Vbin_max == 0;

max_v_mat = repmat( idx_vec_max, 2^numb_param,1,1);
min_v_mat = repmat( idx_vec_min, 2^numb_param,1,1);

V_indices = max_v_mat .* Vbin_max + min_v_mat .* Vbin_min;

% Ok know we know where we have to look up the vertices. We can simply look
% them up in the dataset. For each row in V_indices we get a vector,
% corresponding to the "weight" at this point
  
[vel_inter_x, spat_mat_u1, spat_mat_u2 ] = interpolateVelocityVector(flag_keep_spat_mats,spat_mat_u1,spat_mat_u2,xi,V_indices,'u', xvec, yvec, zvec);
[vel_inter_y, spat_mat_v1, spat_mat_v2 ] = interpolateVelocityVector(flag_keep_spat_mats,spat_mat_v1,spat_mat_v2,xi,V_indices,'v', xvec, yvec, zvec);  
[vel_inter_z, spat_mat_w1, spat_mat_w2 ] = interpolateVelocityVector(flag_keep_spat_mats,spat_mat_w1,spat_mat_w2,xi,V_indices,'w',xvec, yvec, zvec);

v_w_W = [vel_inter_x; vel_inter_y; vel_inter_z];

v_w_O = u_tau*transformFromWtoO(windDirection_rad, v_w_W );


end

