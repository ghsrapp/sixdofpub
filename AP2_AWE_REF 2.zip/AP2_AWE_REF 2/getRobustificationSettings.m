function [time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings()

%% Controller Design
% Longitudinal motion 
time_domain_ref_long.RiseTime = 1.7; %% 2.5 works: 2.5;
time_domain_ref_long.SettlingTime =  2.8;
time_domain_ref_long.Overshoot = 0.01*100;

%% Uncertainty range (percentage/100)
frequ_domain_ref_long.unc_factor = .3;
frequ_domain_ref_long.CriticalFrequ = 1;


%% Same for lateral controller
time_domain_ref_lat.RiseTime = 1.5;
time_domain_ref_lat.SettlingTime = 1.5;
time_domain_ref_lat.Overshoot = 0.02*100;
frequ_domain_ref_lat.CriticalFrequ = 1; 
frequ_domain_ref_lat.unc_factor = .3;
