close all
mks = 10;

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255]; 

ESA_flag = 1; 

% Controller: 
if ESA_flag
    load('UsedGains/K_lat_1'); 
else
    load('UsedGains/K_lat_MMLQR'); 
end

h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);

h7 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);


folder = 'Trim_results/case_1_16kN20kN_alpha4and7and10';
addpath( folder );
load('G_save.mat');
load('x0_save.mat');

% Extract matrices

indx = [1,3,5,7,9];
k_max = length( indx ); 
mks_low = 5;
mks_high = 10;
lw_high = 1.2;
lw_low = 1.2;
alpha_high = 1;
alpha_low = 0.3;

airspeed_order = [2, 5, 3, 1, 4]; 
for k = 1 : k_max
    
    k_real = airspeed_order(k);
    
    Va_trim = x0_save(1,indx(k))
    a_mks = (k_real-1)/(k_max-1);
    mks = (1-a_mks)*mks_high + a_mks*mks_low;
    lw = (1-a_mks)*lw_high + a_mks*lw_low;
    alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
    
    
    
    
    idx = indx(k);
    A = G_save{idx}.A(1:9, 1:9);
    B = G_save{idx}.B(1:9, 1:4);
    
    A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9); % beta
        A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9); % phi_tau
        A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9); % psi_tau
        A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9); % p
        A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];% r
    
    B_lat = [B(2,1),B(2,3);...
        B(4,1),B(4,3);...
        B(6,1),B(6,3);...
        B(7,1),B(7,3);...
        B(9,1),B(9,3)];
    A_lat(3,:) = [];
    A_lat(:,3) = [];
    B_lat(3,:) = [];
    C_control = zeros(2, size( A_lat,2) );
    C_control(1,1) = 1;
    C_control(2,2) = 1;
    A_lat_aug = [A_lat, zeros(size( A_lat,2) ,2);
        -C_control, zeros(2,2)];
    B_lat_aug = [B_lat; zeros(2)];
    
    damp( A_lat_aug-B_lat_aug*K_lat ) 
    
    C_lat = [1,0,0,0,0,0;
        0,1,0,0,0,0];
    lw = 1.2;
    [vec,val ] = eig( A_lat_aug-B_lat_aug*K_lat );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    norms = abs( vec );
    
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    figure(7); 
    [vec,val ] = eig( A_lat_aug-B_lat_aug*K_lat );
    val = diag(val);


    if k == 3
        plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
        plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
        plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    else
        plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
        plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(3) ), imag( val(3) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(5) ), imag( val(5) ), 'x', 'color', col2, 'Markersize', mks);
        plot( real( val(6) ), imag( val(6) ), 'x', 'color', col2, 'Markersize', mks);
        %
%         plot( real( val(1) ), imag( val(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
%         plot( real( val(2) ), imag( val(2) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(3) ), imag( val(3) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(4) ), imag( val(4) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(5) ), imag( val(5) ), 'x', 'color', col1, 'Markersize', mks);
%         plot( real( val(6) ), imag( val(6) ), 'x', 'color', col1, 'Markersize', mks);
    end
    if k == 3
        figure(1); % Rollmotion
        [val, idx] = max( abs( vec(:,1)  ) );
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        % title('Rollmotion');
        
        
        figure(2);
        [val, idx] = max( abs( vec(:,2)  ) );
        R = exp(sqrt(-1)*(-phase(idx,2))); %rotation by phase p
        vec_rot = R * vec(:,2);
        phase(:,2) = angle( vec_rot );
        polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
        %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  title('DR');
        
        figure(3);
        [val, idx] = max( abs( vec(:,4)  ) );
        R = exp(sqrt(-1)*(-phase(idx,4))); %rotation by phase phi
        vec_rot = R * vec(:,4);
        phase(:,4) = angle( vec_rot );
        polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
        
        %% open loop
        [vec,val ] = eig( A_lat );
        vec_abs = abs(vec);
        val = diag(val);
        phase = atan2( imag(vec), real(vec) );
        norms = abs( vec );
        
        vec_abs = abs(vec);
        val = diag(val);
        phase = atan2( imag(vec), real(vec) );
        %%
        figure(4); % Rollmotion
        [val, idx] = max( abs( vec(:,1)  ) );
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        % title('Rollmotion');
        
        
        figure(5);
        [val, idx] = max( abs( vec(:,2)  ) );
        R = exp(sqrt(-1)*(-phase(idx,2))); %rotation by phase p
        vec_rot = R * vec(:,2);
        phase(:,2) = angle( vec_rot );
        polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        %  title('DR');
        
        figure(6);
        [val, idx] = max( abs( vec(:,4)  ) );
        R = exp(sqrt(-1)*(-phase(idx,4))); %rotation by phase phi
        vec_rot = R * vec(:,4);
        phase(:,4) = angle( vec_rot );
        polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p
        polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south');
        
        if ESA_flag
            folder_name = 'ESA';
            Plot2LaTeX3(h1,['EV_star_roll_cl_',folder_name]);
            Plot2LaTeX3(h2,['EV_star_DR_cl_',folder_name]);
            Plot2LaTeX3(h3,['EV_star_Spiral_cl_',folder_name]);
            Plot2LaTeX3(h4,['EV_star_roll_op_',folder_name]);
            Plot2LaTeX3(h5,['EV_star_DR_op_',folder_name]);
            Plot2LaTeX3(h6,['EV_star_Spiral_op_',folder_name]);
        else
            folder_name = 'LMI';
            Plot2LaTeX3(h1,['EV_star_roll_cl_',folder_name]);
            Plot2LaTeX3(h2,['EV_star_DR_cl_',folder_name]);
            Plot2LaTeX3(h3,['EV_star_Spiral_cl_',folder_name]);
            Plot2LaTeX3(h4,['EV_star_roll_op_',folder_name]);
            Plot2LaTeX3(h5,['EV_star_DR_op_',folder_name]);
            Plot2LaTeX3(h6,['EV_star_Spiral_op_',folder_name]);
        end
    end
    
    
    
end

figure(7);
axis( [-30 0 -8 8]);
xlabel('$\mathrm{Real}(\lambda_\mathrm{i})$');
ylabel('$\mathrm{Imag}(\lambda_\mathrm{i})$');
sgrid
folder_name = 'UsedGains';
if ESA_flag
    Plot2LaTeX2(h7,['eigenvalues_ESA_lateral'])
    movefile('eigenvalues_ESA_lateral*', 'UsedGains');
else
    Plot2LaTeX2(h7,['eigenvalues_MLQR_lateral'])
    movefile('eigenvalues_MLQR_lateral*', 'UsedGains');
end