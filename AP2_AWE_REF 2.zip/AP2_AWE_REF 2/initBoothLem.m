%load('x_best_trac_tmp1');
Lbooth.a = 0; % height
Lbooth.b = 0; % length
Lbooth.phi0 = 0;
Lbooth.s_trans_retract = 2; 
Lbooth.init_sol =  3.9270; 