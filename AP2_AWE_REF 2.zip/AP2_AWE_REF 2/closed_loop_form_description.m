A_cl = [A_p, B_p*K1.C; 
    K1.B(:,3:end)- K1.B(:,1:2)*C_prime, K1.A];



B_cl = [zeros(size(A_p,1),2);  K1.B(:, 1:2)];
C = [eye(2),  zeros(2, size( A_cl,1)-2 ) ];
G_cl = ss( A_cl, B_cl, C, [] );
