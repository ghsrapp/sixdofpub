function cost = costFunctionRetract(x, max_bandwidth,TSIM )%COSTFUNCTION Summary of this function goes here
%   Detailed explanation goes her
 % to get the right accuracy
%% ====== Controller Gains ======
% load opt traction phase controller
x_opt_traction = load('x_best_trac_tmp1.mat');
x_tract = x_opt_traction.x;
%x_tract(1:20) = x_tract(1:20)/10;
assignin('base','Kp_mu_traction',x_tract(1));
assignin('base','Kp_alpha_traction',x_tract(2));
assignin('base','Kp_beta_traction',x_tract(3));

assignin('base','Ki_mu_traction',x_tract(4));
assignin('base','Ki_alpha_traction',x_tract(5));
assignin('base','Ki_beta_traction',x_tract(6));

assignin('base','Kp_p',x_tract(7));
assignin('base','Kp_q',x_tract(8));
assignin('base','Kp_r',x_tract(9));

assignin('base','Ki_p',x_tract(10));
assignin('base','Ki_q',x_tract(11));
assignin('base','Ki_r',x_tract(12));

assignin('base','Kp_chi_tau',x_tract(13));

%% ====== Filter Definition ======
assignin('base','w0_mu_traction',x_tract(14)*x_tract(17)*max_bandwidth);
assignin('base','w0_alpha_traction',x_tract(15)*x_tract(18)*max_bandwidth);
assignin('base','w0_beta_traction',x_tract(16)*x_tract(19)*max_bandwidth);

assignin('base','w0_p',x_tract(17)*max_bandwidth);
assignin('base','w0_q',x_tract(18)*max_bandwidth);
assignin('base','w0_r',x_tract(19)*max_bandwidth);

%% ==== Path definitions ====
assignin('base','a_booth',x_tract(20));
assignin('base','b_booth',x_tract(21));
assignin('base','phi0_booth',x_tract(22));

assignin('base','Ki_chi_tau',x_tract(23)/10);

assignin('base','F_T_traction_set',5*100+1000);

assignin('base','Kp_chi_tau_trans',x_tract(25)/100);

assignin('base','Kp_gamma_tau_trans',x_tract(26)/100);
assignin('base','Kp_gamma_tau',x_tract(27)/10);
assignin('base','Ki_gamma_tau',x_tract(28)/10);

% retraction
assignin('base','Kp_chi_retract',x(1)/10);
assignin('base','Ki_chi_retract',x(2)/10);

assignin('base','Kp_gamma_retract',x(3)/10);
assignin('base','Ki_gamma_retract',x(4)/10);

assignin('base','v_retraction_opt',x(5));
assignin('base','gamma_retract_opt',x(6));

simOut = sim('AWE_Testbed_opt4', 'CaptureErrors','on');
if simOut.sim_time(end) < TSIM
    cost = 1e15/(simOut.sim_time(end)+1) ;
else
    % cost function as a function of the output of the simulink simulation
    cost = 2*pi/180*norm( simOut.alpha_a_save.Data(:,2) - simOut.alpha_a_save.Data(:,3) )+...
        1*pi/180*norm( simOut.beta_a_save.Data(:,2) - simOut.beta_a_save.Data(:,3) ) +...
        0*pi/180*norm( simOut.eta_tether.Data(:,1) ) +...
        pi/180*norm( simOut.gamma_a_retraction.Data(:,3)-simOut.gamma_a_retraction.Data(:,2)) + ...
         pi/180*norm( simOut.chi_a_retraction.Data(:,3)-simOut.chi_a_retraction.Data(:,2)) + ...
        0.2*norm( simOut.course_tau_traction.Data(:,2) - simOut.course_tau_traction.Data(:,1) ) +...
        norm(simOut.delta_a_meas.Data) + ...
        norm(simOut.delta_e_meas.Data) + ...
        norm(simOut.delta_r_meas.Data) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,1)/max(simOut.omega_OB_rad.Data(:,1))) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,2)/max(simOut.omega_OB_rad.Data(:,2))) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,3)/max(simOut.omega_OB_rad.Data(:,3))); %/length(simOut.sim_time);
    disp(['Current x: ', num2str(x)]);
    disp(['Current cost: ', num2str(cost)]);
    % Sim current controller

   figure(9);
   clf; drawnow;
   visualization_stuff = simOut.visualization_stuff;
   assignin('base','visualization_stuff',visualization_stuff);
   addpath('Visualization_Offline/')
   sim('visualize_offline_v2');
   title(num2str(cost));
    
end


end

