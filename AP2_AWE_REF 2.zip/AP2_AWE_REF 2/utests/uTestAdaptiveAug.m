clear all
close all

Kp = 2*eye(3);
Ki = 1*eye(3);
Kd = 1;

k1 = 1;
k2 = 1;

n = 1;

%% Test system
A = rand(3,3);
B = rand(3,3);
Binv = inv(B);
biasA = A;
biasB = B;
Areal = A+biasA;
Breal = B+biasB;
Brealinv = inv(Breal);
1

%% Controller 
[adaptiveAug] = initAdaptiveAugmentation( Kp, Ki, Kd,  1 );
Ar = 2*diag([-2;-2;-2]);
Br =  2*diag([2;2;2]);

adaptiveAug.Gamma = diag([0.1, 0.1, 0.1, 10, 10,10, 2, 2, 2,2, 2, 2]);
