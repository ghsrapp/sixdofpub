%% Init all the retraction phase parameters 

gamma_retraction_final = 10; 