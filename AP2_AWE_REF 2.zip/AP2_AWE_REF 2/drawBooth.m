2l_tether = 300;
Lbooth.b = params.b_booth;
Lbooth.a = params.b_booth*params.a_booth;
Lbooth.phi0 = params.phi0_booth;
[Lem] = updateBoothLemniscate(l_tether,Lbooth);
s = 0 : 0.005 : 2*pi;
%a = a/l_tether; 


%s =  Lbooth.s_trans_retract
%s = Lbooth.init_sol
long_ = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
lat_ =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;

%long = Lem.a * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
%lat =   Lem.a^2/Lem.b * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;



% transform into cartesian coordinates 
p = [ cos(long_).*cos(lat_);sin(long_).*cos(lat_);sin(lat_)]*l_tether;
% figure(1); 
%plot3(p(1,:), p(2,:), p(3,:),'color',  col2 ,'MarkerIndices',1:20:length(p)); hold on 
plot3(p(1,:), p(2,:), p(3,:),'--','color', 'b','Linewidth',2); hold on 
%plot3(p(1,:), p(2,:), p(3,:),'*r','Markersize',20); hold on 
% 
% xlabel('$x_W$ $(m)$','interpreter', 'latex')
% ylabel('$y_W$ $(m)$','interpreter', 'latex')
% zlabel('$z_W$ $(m)$','interpreter', 'latex')
% axis equal
% axis([ 0 1550 -300 300 50 600])

% s = Lbooth.init_sol;
% long = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
% lat =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
% Lbooth.p_init_VT_path = [ cos(long).*cos(lat);
%       sin(long).*cos(lat);
%       sin(lat)]*l_tether;
% X = [-300;1000;1000;-300];
% Y = [-600;-600;600;600];
% v = [X,Y];
% c = [0 1 0; % red
%     0 1 0; % green
%     0 1 0;
%     0 1 0];
% fill(X,Y, c(:,2),'EdgeColor','none','FaceColor',c(1,:),'FaceAlpha',0.1);
% axis equal;
% 
%view(90,25);
