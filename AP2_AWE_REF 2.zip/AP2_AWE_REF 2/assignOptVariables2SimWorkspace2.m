function assignOptVariables2SimWorkspace2(max_bandwidth,x)
%% ---------------------------- TRACTION ----------------------------

assignin('base','w0_p_traction',x(1)*max_bandwidth);
assignin('base','w0_q_traction',x(2)*max_bandwidth);
assignin('base','w0_r_traction',x(3)*max_bandwidth);

assignin('base','w0_mu_traction',x(4)*x(1)*max_bandwidth);
assignin('base','w0_alpha_traction',x(5)*x(2)*max_bandwidth);
assignin('base','w0_beta_traction',x(6)*x(3)*max_bandwidth);
 
assignin('base','Kp_chi_tau_traction',  x(7) );
assignin('base','Kp_gamma_tau_traction', x(8) );
assignin('base','Kp_chi_tau_trans',     x(9) );
assignin('base','Kp_gamma_tau_trans',   x(10) );
assignin('base','Ki_chi_tau_traction',  x(11) );
assignin('base','Ki_gamma_tau_traction',  x(12));

assignin('base','Kp_mu_traction', x(13));
assignin('base','Kp_alpha_traction',x(14));
assignin('base','Kp_beta_traction',x(15));
assignin('base','Ki_mu_traction',x(16));
assignin('base','Ki_alpha_traction',x(17));
assignin('base','Ki_beta_traction',x(18));

assignin('base','a_booth',x(19)); 
assignin('base','b_booth',x(20));
assignin('base','phi0_booth',x(21));
assignin('base','F_T_traction_set',x(22));

assignin('base','Kp_p_traction',x(23));
assignin('base','Kp_q_traction',x(24));
assignin('base','Kp_r_traction',x(25));
assignin('base','Ki_p_traction',x(26));
assignin('base','Ki_q_traction',x(27));
assignin('base','Ki_r_traction',x(28));

% winch controller
assignin('base','kp_winch',x(29));
assignin('base','ki_winch',x(30));

%% ---------------------------- RE-TRACTION ----------------------------
% Bandwidths
assignin('base','w0_p_retraction',x(31)*max_bandwidth);
assignin('base','w0_q_retraction',x(32)*max_bandwidth);
assignin('base','w0_r_retraction',x(33)*max_bandwidth);

assignin('base','w0_mu_retraction',x(34)*evalin('base','  w0_p_retraction'));
assignin('base','w0_alpha_retraction',x(35)*evalin('base','  w0_q_retraction'));
assignin('base','w0_beta_retraction',x(36)*evalin('base','  w0_r_retraction'));

assignin('base','w0_chi_retraction',x(37)*evalin('base','  w0_mu_retraction'));
assignin('base','w0_gamma_retraction',x(38)*evalin('base','  w0_alpha_retraction'));

assignin('base','Kp_chi_retraction',x(39));
assignin('base','Kp_gamma_retraction',x(40));
assignin('base','Ki_chi_retraction',x(41));
assignin('base','Ki_gamma_retraction',x(42));

assignin('base','Kp_mu_retraction',x(43));
assignin('base','Kp_alpha_retraction',x(44));
assignin('base','Kp_beta_retraction',x(45));
assignin('base','Ki_mu_retraction',x(46));
assignin('base','Ki_alpha_retraction',x(47));
assignin('base','Ki_beta_retraction',x(48));

assignin('base','Kp_p_retraction',x(49));
assignin('base','Kp_q_retraction',x(50));
assignin('base','Kp_r_retraction',x(51));
assignin('base','Ki_p_retraction',x(52));
assignin('base','Ki_q_retraction',x(53));
assignin('base','Ki_r_retraction',x(54));


% retraction path/speed
assignin('base','gamma_retract_opt',x(55));
assignin('base','F_set_retraction',x(56));

% general cycle parameters 
assignin('base','l_tether_max',x(57));
assignin('base','l_tether_min',x(58));
assignin('base','alpha_star_flag',x(59));
assignin('base','alpha_star',x(60));

% more winch related parameter
assignin('base','w0_ftset_filters',x(61));
assignin('base','kp_winch_retraction',x(62));
assignin('base','ki_winch_retraction',x(63));






