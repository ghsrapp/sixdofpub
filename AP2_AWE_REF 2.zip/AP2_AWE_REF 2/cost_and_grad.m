function [J, GJ] = cost_and_grad(K, a, b, R, p, models )
J = 0;
GJ = zeros( size(K,1), size(K,2) );

dF1d_delta = 1;
dF1d_w = @(d,w) a/b*w*1/sqrt(w^2+b^2);
dF2d_delta = @(d,w) d/sqrt(d^2+w^2);
dF2d_w = @(d,w) w/sqrt(d^2+w^2);

for j = 1 : size(models.C,1) % C_ % loop over all outputs
    for i = 1 : size(models.B,2) %size( B_, 2) % loop over all inputs
        for mu = 1 : size(models.A,3) % loop over all models
            
            A_cl= models.A(:,:,mu) - models.B(:,:,mu)*K*models.C(:,:,mu);
            [V,D,W] = eig(A_cl);
            lambdas = diag( D );
            
            
            for nu = 1 : size( A_cl, 1) % loop over all eigenvectors
                % Evaluate cost function
                % Evaluate the gradients
                if i == 1 && j == 1
                    J = J + exp( p(mu) * ( real( lambdas(nu) ) +  a/b * sqrt( imag(lambdas(nu) )^2 + b^2 ) ) ) + exp( p(mu)*( sqrt( real(lambdas(nu) )^2 + imag(lambdas(nu) )^2 ) - R ) );
                end
                d_lambda_nu_d_kij = -W(:,nu)'*models.B(:,i,mu)*models.C(j,:,mu)*V(:,nu)/(W(:,nu)'*V(:,nu));
                d_delta_mu_d_kij = real( d_lambda_nu_d_kij );
                d_omega_mu_d_kij = imag( d_lambda_nu_d_kij );
                
                GJ(i,j) =  GJ(i,j) + ...
                    p(mu)*( exp( p(mu) * ( real( lambdas(nu) ) +  a/b * sqrt( imag(lambdas(nu))^2 + b^2 ) ) ) ) *...
                    ( dF1d_delta *  d_delta_mu_d_kij + dF1d_w(real(lambdas(nu)), imag( lambdas(nu))) * d_omega_mu_d_kij) +  ...
                    p(mu)*( exp( p(mu)*( sqrt( real(lambdas(nu) )^2 + imag(lambdas(nu) )^2 ) - R ) ) ) *...
                    ( dF2d_delta(real(lambdas(nu)), imag( lambdas(nu))) *  d_delta_mu_d_kij + dF2d_w(real(lambdas(nu)), imag( lambdas(nu))) * d_omega_mu_d_kij );
            end
        end
    end
end
1;


