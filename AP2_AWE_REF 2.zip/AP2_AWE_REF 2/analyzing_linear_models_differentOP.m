clear
close all

save_plots = 0;

addpath('Trim_results');

folder_name = 'case_1_18kN_alpha0to10'; % for the traction phase
%folder_name = 'em_analysis_retr_trim_case_1'
%folder_name = 'em_analysis_retr_trim_case2_1'

cd(['Trim_results/',folder_name]);

load('G_save.mat');
load('x0_save.mat');
load('u0_save.mat');


%

l_tether = x0_save(end,1);

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
lw = 1.2;
h1 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);
h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h4 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);
h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h9 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);
h10 = figure('Renderer', 'painters', 'Position', [0 0 500 400]);
h11 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h12 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);

h13 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h14 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h15 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h16 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h17 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);


mks_low = 5;
mks_high = 10;

lw_high = 1.2;
lw_low = 1.2;

alpha_high = 1;
alpha_low = 0.3;

numb_cases = 3; 
k_max = 5; %size( x0_save(1,:),2 )/numb_cases;%6;

k_vec = 1:k_max; %[1:6,13:18]; %[13:18]; %%,  % these two intervals are for 1000 and 1800 (middle interval is 1400)
kk_vec = 1:k_max; %[1:6, 1:6];
cnt_max = length( k_vec ); 
for cnt =  1 : cnt_max
    k =k_vec(cnt);
    A = G_save{k}.A(1:9, 1:9);
    B = G_save{k}.B(1:9, 1:4);
    
    A_mod = A;
    B_mod = B;
    
    A_mod(6,:) = [];
    A_mod(:,6) = [];
    B_mod(6,:) = [];
    B_mod(:,4) = [];
    
    A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
        A(3,1), A(3,3), A(3, 5), A(3,8);
        A(5,1), A(5,3), A(5, 5), A(5,8);
        A(8,1), A(8,3), A(8, 5), A(8,8)];
    B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
    B_long = [B_long, [B(1,4);B(3,4);B(5,4);B(8,4)]*1800];

    
    C = [0,1,0,0];
    %
    A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9); % beta
        A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9); % phi_tau
        A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9); % psi_tau
        A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9); % p
        A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];% r
    
    B_lat = [B(2,1),B(2,3);...
        B(4,1),B(4,3);...
        B(6,1),B(6,3);...
        B(7,1),B(7,3);...
        B(9,1),B(9,3)];
    A_lat(3,:) = [];
    A_lat(:,3) = [];
    B_lat(3,:) = [];
    
    
    
    kk = kk_vec(cnt); 

    Va_trim = x0_save(1,kk);
    a_mks = (kk-1)/(k_max-1);
    mks = (1-a_mks)*mks_high + a_mks*mks_low;
    lw = (1-a_mks)*lw_high + a_mks*lw_low;
    alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
    
    
    C_long = [0,1,0,0];
    G_long = minreal( ss( A_long, B_long, C_long, [] ) );
    
  
    T = eye(size(A_mod,1));
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_mod*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    norms = abs( vec );
    idx_unstable = ( real(val)>0 );
    if sum( idx_unstable ) > 0
        idx_oscillatory_mode = ( imag( val( idx_unstable ) ) > 0 );
        if sum( idx_oscillatory_mode ) > 0
            s_unstable_phygoid = [s_unstable_phygoid, svec( k )];
        end
    end
     if k == 1
    %% Eigenvector star full model 
    idx_vec = [1,3,5,6,8]; % retraction
%    idx_vec = [1,2,4,6,8]; % traction

    for j = 1 : length( idx_vec )
        m = idx_vec(j); 
        figure(12+j);
        [val_, idx] = max( abs( vec(:,m)  ) );
        R = exp(sqrt(-1)*(-phase(idx,m))); %rotation by phase q
        vec_rot = R * vec(:,m);
        phase(:,m) = angle( vec_rot );
        polarplot([phase(1,m) phase(1,m)], [0, abs(vec(1,m))], '-o', 'color', col1, 'Linewidth', lw); hold on % va
        polarplot([phase(2,m) phase(2,m)], [0, abs(vec(2,m))], '-x', 'color', col2, 'Linewidth', lw); hold on % beta
        polarplot([phase(3,m) phase(3,m)], [0, abs(vec(3,m))], '-v', 'color', col3, 'Linewidth', lw); hold on % alpha
        polarplot([phase(4,m) phase(4,m)], [0, abs(vec(4,m))], '-s', 'color', col4, 'Linewidth', lw); hold on % phi
        polarplot([phase(5,m) phase(5,m)], [0, abs(vec(5,m))], '-+', 'color', 'k', 'Linewidth', lw); hold on % theta
        polarplot([phase(6,m) phase(6,m)], [0, abs(vec(6,m))], '-d', 'color', 'cyan', 'Linewidth', lw); hold on % p
        polarplot([phase(7,m) phase(7,m)], [0, abs(vec(7,m))], '->', 'color', 'magenta', 'Linewidth', lw); hold on % q
        polarplot([phase(8,m) phase(8,m)], [0, abs(vec(8,m))], '-^', 'color', 'g', 'Linewidth', lw); hold on % r
        %if j == 2
        %legend('$\mathrm{v}_\mathrm{a}$', '$\beta_\mathrm{a}$', '$\alpha_\mathrm{a}$', '$\Phi_{\tau}$', '$\Theta_{\tau}$', 'p', 'q', 'r');
           % 1;
       % end
        
  %    Plot2LaTeX3(eval(['h',num2str(12+j)]),['ev_stern_',num2str(j),folder_name]);
    end
    %%
    
    
    % legend('$v_a$', '$\alpha$', '$\Theta_{\tau}$', '$q$', 'Location', 'south')
     end
    
    % ========================= Eigenvalues Total, Longitudinal and Lateral ========================
    figure(1);
    plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(7) ), imag( val(7) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(8) ), imag( val(8) ), 'o', 'color', col1, 'Markersize', mks);
    
    [vec,val ] = eig( A_lat );
    val = diag(val);
    plot( real( val(1) ), imag( val(1) ), 's', 'color',col3, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 's', 'color', col3, 'Markersize', mks);
    
    % Long
    T = eye(size(A_long,1));
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'x', 'color',  col2, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
    
    
%     figure(4);
%     %[p,z] = pzmap(G_long); % transfer function from elevator to angle of attack
%     plot( real( p(1) ), imag( p(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
%     plot( real( p(2) ), imag( p(2) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( p(3) ), imag( p(3) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( p(4) ), imag( p(4) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( z(1) ), imag( z(1) ), 'o', 'color', col2, 'Markersize', mks);
%     plot( real( z(2) ), imag( z(2) ), 'o', 'color', col2, 'Markersize', mks);
%     plot( real( z(3) ), imag( z(3) ), 'o', 'color', col2, 'Markersize', mks);
    
%     figure(5)
%     omegas = logspace(-2, 2, 1000);
%     if cnt > 6
%         h_bode = semilogx(omegas, 20*log10( squeeze( abs(freqresp(G_long, omegas)) ) ), 'color', col2, 'Linewidth', lw); hold on
%     else
%         h_bode = semilogx(omegas, 20*log10( squeeze( abs(freqresp(G_long, omegas)) ) ), 'color', col1, 'Linewidth', lw); hold on
%     end
%     h_bode.Color(4) = alpha_lvl;
%     xlabel('Frequency (rad/s)');
%     ylabel('Magnitude (dB)');
%     
%     figure(12)
%     omegas = logspace(-2, 2, 1000);
%     freq_resp =  squeeze( freqresp(G_long, omegas) ) ;
%     if cnt > 6
%         h_bode = semilogx(omegas, atan2( imag(freq_resp), real(freq_resp) )*180/pi-180 , 'color', col2, 'Linewidth', lw); hold on
%     else
%         h_bode = semilogx(omegas, atan2( imag(freq_resp), real(freq_resp) )*180/pi-180 , 'color', col1, 'Linewidth', lw); hold on
%     end
%     h_bode.Color(4) = alpha_lvl;
%     xlabel('Frequency (rad/s)');
%     ylabel('Phase (deg)');
%     
    % ========================= Eigenvectors Longitudinal ========================
    if k == 1
        figure(2);
        [val, idx] = max( abs( vec(:,1)  ) ); 
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw); hold on % va 
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw); hold on % alpha
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw); hold on % theta
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw); hold on % q
   %  legend('$v_a$', '$\alpha$', '$\Theta_{\tau}$', '$q$', 'Location', 'south')
      %   title('AoA');         

        
        figure(3);
        [val, idx] = max( abs( vec(:,3)  ) ); 
        R = exp(sqrt(-1)*(-phase(idx,3))); %rotation by phase va
        vec_rot = R * vec(:,3);
        phase(:,3) = angle( vec_rot );
        polarplot([phase(1,3) phase(1,3)], [0, abs(vec_rot(1))], '-o', 'color', col1, 'Linewidth', lw); hold on
        polarplot([phase(2,3) phase(2,3)], [0, abs(vec_rot(2))], '-x', 'color', col2, 'Linewidth', lw); hold on
        polarplot([phase(3,3) phase(3,3)], [0, abs(vec_rot(3))], '-v', 'color', col3, 'Linewidth', lw); hold on
        polarplot([phase(4,3) phase(4,3)], [0, abs(vec_rot(4))], '-s', 'color', col4, 'Linewidth', lw); hold on
      %  legend('$v_a$', '$\alpha$', '$\Theta_{\tau}$', '$q$', 'Location', 'south')
        %xlabel('');
    %    title('Phygoid');         

        
        % ========================= Eigenvectors Lateral ========================
        
        C_lat = [1,0,0,0;
            0, 1, 0, 0];
        G_lat = minreal( ss( A_lat, B_lat, C_lat, [] ) );
        nom_input = [1;1];
        pertubation_perc = 0.05;
%        [y_perturbed,y_nom]  = demonstrateConditionNumberProblem( G_lat,nom_input, pertubation_perc );
        [vec,val ] = eig( A_lat );
        vec_abs = abs(vec);
        val = diag(val);
        phase = atan2( imag(vec), real(vec) );
        norms = abs( vec );
        
        figure(6); % Rollmotion
        [val, idx] = max( abs( vec(:,1)  ) ); 
        R = exp(sqrt(-1)*(-phase(idx,1))); %rotation by phase q
        vec_rot = R * vec(:,1);
        phase(:,1) = angle( vec_rot );
        polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on % beta
        polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on % phi
        polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on % p 
        polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on % r 
        %legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south'); 
        % title('Rollmotion');         

        
        figure(7);
        [val, idx] = max( abs( vec(:,2)  ) ); 
        R = exp(sqrt(-1)*(-phase(idx,2))); %rotation by phase p
        vec_rot = R * vec(:,2);
        phase(:,2) = angle( vec_rot );
        polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
      %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south'); 
      %  title('DR');         

        figure(8);
        [val, idx] = max( abs( vec(:,4)  ) ); 
        R = exp(sqrt(-1)*(-phase(idx,4))); %rotation by phase phi
        vec_rot = R * vec(:,4);
        phase(:,4) = angle( vec_rot );
        polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
        polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
      %  legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south'); 
     %   title('Spiralmode');         

    end
    %% zoomed plots

    T = eye(size(A_mod,1));
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_mod*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    figure(9);
    plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(7) ), imag( val(7) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(8) ), imag( val(8) ), 'o', 'color', col1, 'Markersize', mks);
    % Lateral
    [vec,val ] = eig( A_lat );
    val = diag(val);
    plot( real( val(1) ), imag( val(1) ), 's', 'color',col3, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 's', 'color', col3, 'Markersize', mks);
    
    % Longi
    T = eye(4);
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'x', 'color',  col2, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
    
%     figure(10);
%     [p,z] = pzmap(G_long); % transfer function from elevator to angle of attack
%     plot( real( p(1) ), imag( p(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
%     plot( real( p(2) ), imag( p(2) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( p(3) ), imag( p(3) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( p(4) ), imag( p(4) ), 'x', 'color', col1, 'Markersize', mks);
%     plot( real( z(1) ), imag( z(1) ), 'o', 'color', col2, 'Markersize', mks);
%     plot( real( z(2) ), imag( z(2) ), 'o', 'color', col2, 'Markersize', mks);
%     plot( real( z(3) ), imag( z(3) ), 'o', 'color', col2, 'Markersize', mks);
    
%     %% Singular value plot lateral 
%     C_lat = zeros(2,4); 
%     C_lat(1,1) = 1; 
%     C_lat(2,2) = 1; 
%     G_lat = minreal( ss( A_lat, B_lat, C_lat, [] ) ); 
%     [val] = sigma(G_lat, omegas);
%     figure(11);
%     hsv=semilogx( omegas, val(1,:) , 'color', col1, 'Linewidth', lw); hold on
%     hsv.Color(4) = alpha_lvl;
%     hsv=semilogx( omegas, val(2,:) , 'color', col2, 'Linewidth', lw); hold on
%     hsv=semilogx( omegas,  val(1,:)./val(2,:) , 'color', col3, 'Linewidth', lw); hold on
%     hsv.Color(4) = alpha_lvl;
% 
%     %% Relative gain array 
%    [RGAw, RGA, RGAno, RGAno2] = getRGA( G_lat, omegas );
%    semilogx( omegas, RGAno ); hold on 
%       semilogx( omegas, RGAno2 ); 

   
end
figure(1);
xlabel('$\mathrm{Real}(\lambda_\mathrm{i})$');
ylabel('$\mathrm{Imag}(\lambda_\mathrm{i})$');
sgrid
if save_plots
    Plot2LaTeX2(h1,['lambdas_',folder_name])
end
if save_plots
    figure(2);
    Plot2LaTeX3(h2,['EV_star_SP_',folder_name]);
    figure(3);
    Plot2LaTeX3(h3,['EV_star_phyg_',folder_name]);
end


figure(4);
xlabel('Real');
ylabel('Imag');
sgrid

if save_plots
    Plot2LaTeX2(h4,['pole_zero_plot_',folder_name])
    Plot2LaTeX3(h5,['bodemag_Glong_',folder_name]);
    Plot2LaTeX3(h6,['EV_star_roll_',folder_name]);
    Plot2LaTeX3(h7,['EV_star_DR_',folder_name]);
    Plot2LaTeX3(h8,['EV_star_Spiral_',folder_name]);
end

figure(9);
xlabel('$\mathrm{Real}(\lambda_\mathrm{i})$');
ylabel('$\mathrm{Imag}(\lambda_\mathrm{i})$');
axis([-0.5 0.5 -3 3]); hold on
sgrid
if save_plots
    Plot2LaTeX2(h9,['lambdas_zoom_',folder_name])
end
figure(10);
xlabel('Real');
ylabel('Imag');
axis([-0.5 0.1 -3 3]); hold on
sgrid
if save_plots
    Plot2LaTeX2(h10,['pole_zero_plot_zoom_',folder_name])
    fclose('all');
    delete('*_temp.svg')
end

figure(11);
xlabel('Frequency (rad/s)');
ylabel('Max./Min. singular value');
if save_plots
    Plot2LaTeX2(h11,['max_min_singular_value_lat_',folder_name])
    fclose('all');
    delete('*_temp.svg')
end

figure(12);
% semilogx(omegas, -180*ones(length( omegas )), '--', 'color', 'black', 'Linewidth', 1); hold on
if save_plots
    Plot2LaTeX2(h12,['phase_long_',folder_name])
    fclose('all');
    delete('*_temp.svg')
end

cd ..
cd ..