function  [p_VT_W,p_Proj_W] = getVTOnCircle(M_CW,p_circO1_W, p_kite_W, r_SE, deltaAlpha)
% Transform the current kite position into the circ frame
% and project it into the circle plane

%================== Function Description ================================
% Version: 1.0 
% Author: Sebastian Rapp 
% Last Update: 28.08.2017
% 1) Calculate relative position to circle center
% 2) Project the relative position into the circle plane
% 3) Rotate the projected kite position along the circle to get 
% the virtual target
% 4) Transform the virtual target back to the W frame.
% Inputs: Transformation matrix between the circle and the W frame M_CW, 
% the circle center p_circO1_W, the kite position p_kite_W, the radius of
% the circle on the unit sphere r_SE and a tuning paramter deltaAlpha.
%=========================================================================
p_kiteOP_C = M_CW * (p_kite_W - p_circO1_W); 
p_kiteOP_C(3) = 0; 

p_kiteP_C = p_kiteOP_C/norm(p_kiteOP_C)*r_SE; 

% For analysis purposes: Cross Track Error Calculation.
p_Proj_W = M_CW' * p_kiteP_C + p_circO1_W; 

% For improved performance close to the path, the lookahead point 
% can be placed closer with respect to the crosstrack error.
% e_cross = acos( min( max( p_kite_W' * p_Proj_W, -1),1 ) ); % Crosstrack error as arclength
% deltaAlpha_min = deltaAlpha * 0.1; 
% deltaAlpha_max = deltaAlpha; 
% if abs(e_cross) < 0.01
%     deltaAlpha_eff = deltaAlpha_max * e_cross/0.01 + deltaAlpha_min * (1-e_cross/0.01) ;
% else
    deltaAlpha_eff = deltaAlpha; 
%end
RotM = [cos(deltaAlpha_eff), -sin(deltaAlpha_eff), 0;
        sin(deltaAlpha_eff), cos(deltaAlpha_eff), 0;
        0, 0, 1];
p_VT_C =  RotM * p_kiteP_C;
p_VT_W = M_CW' * p_VT_C + p_circO1_W;



end