% A_long(1,1): 

v = [3.326*P_AP2.Cx_0_0 
- 0.001455*P_AP2.Cx_q_0 
- 0.06654*P_AP2.Cx_deltaE_0
- 0.2107*T.CD_tether];
sum(v)

idx_neglect = find( abs(v)<0.01*max(abs(v)) ); 

v(idx_neglect) = []; 
sum(v)
% neglected elements: Cx_q_0 Cx_deltaE_0