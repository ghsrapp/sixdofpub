addpath(genpath('YALMIP-master')); 
addpath(genpath('sdpt3-master')); 


%% Short Period Model F16
A(:,:,1) = [-1.8406, 0.9092; 
           -30.7874, -3.7534];
B(:,:,1) = [0; 
           -12.7528];
A(:,:,2) = 1.2*[-1.8406, 0.9092; 
           -30.7874, -3.7534];
B(:,:,2) = 1.2*[0; 
           -12.7528];  
       
C = [1, 0]; 
numb_sys = size( A, 3);
for ii = 1 : numb_sys
    A_s(:,:,ii) = [A(:,:,ii), zeros(2,1);
        -C, 0];
    B_s(:,:,ii) = [B(:,:,ii);0];
end

Q = eye(3); 
R = 1;
K_MM_LQR = calcMMLQR( A_s, B_s, Q, R )

%% Test: 
K_lqr = lqr( A_s(:,:,1), B_s(:,:,1), Q, R )