function [v_k_tangential, p_mech, v_reeling,s_dot] =   getKinematics(rps, windDirection_rad,vel_w_W)

phi_tau = rps.States(2).x(1);
    theta_tau = rps.States(2).x(2);
    psi_tau = rps.States(2).x(3);
    long = rps.States(4).x(1);
    lat = rps.States(4).x(2);
    r = rps.States(4).x(3);
    Ft = rps.Inputs(4).u(1);
    
    Va = rps.States(1).x(1);
    beta = rps.States(1).x(2);
    alpha = rps.States(1).x(3);
    
    M_tauB = [ cos(psi_tau)*cos(theta_tau), cos(psi_tau)*sin(phi_tau)*sin(theta_tau) - cos(phi_tau)*sin(psi_tau), sin(phi_tau)*sin(psi_tau) + cos(phi_tau)*cos(psi_tau)*sin(theta_tau);
        cos(theta_tau)*sin(psi_tau), cos(phi_tau)*cos(psi_tau) + sin(phi_tau)*sin(psi_tau)*sin(theta_tau), cos(phi_tau)*sin(psi_tau)*sin(theta_tau) - cos(psi_tau)*sin(phi_tau);
        -sin(theta_tau),                              cos(theta_tau)*sin(phi_tau),                              cos(phi_tau)*cos(theta_tau)];
    
    M_tauW = [-sin(lat)*cos(long), -sin(lat)*sin(long), cos(lat);
        -sin(long), cos(long), 0;
        -cos(lat)*cos(long), -cos(lat)*sin(long), -sin(lat)];
    
    M_Wtau = M_tauW';
    
    M_OW = [cos(windDirection_rad), sin(windDirection_rad), 0;
        sin(windDirection_rad), -cos(windDirection_rad), 0;
        0, 0, -1];
    
    M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
        -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
        -sin(alpha), 0, cos(alpha)];
    M_BA = M_AB';
    
    V_k_tau = M_tauB*M_BA*[Va;0;0]+M_tauW*vel_w_W;
    long_dot = V_k_tau(2)/( r*cos(lat) );
    lat_dot = V_k_tau(1)/r;
    
    v_k_tangential = sqrt( V_k_tau(1)^2 + V_k_tau(2)^2 );
    v_reeling = -V_k_tau(3);
    v_k_tot = norm( V_k_tau );
    p_mech = v_reeling * Ft;
    s_dot = v_k_tangential/r; 
end