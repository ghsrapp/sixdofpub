% Aileron
aileron.w0 = 35; %35 is more realistic
aileron.rl = 2;%300*pi/180; %

aileron.max_deflection = 20*pi/180;
aileron.min_deflection = -20*pi/180;
aileron.bias = 0; 


% Elevator
elevator.w0 = 35; %
elevator.rl = 2;%300*pi/180; %
elevator.max_deflection = 20*pi/180;
elevator.min_deflection = -20*pi/180;
elevator.bias = 0; 


% Rudder
rudder.w0 = 35; %
rudder.rl = 2;%300*pi/180; %
rudder.max_deflection = 30*pi/180;
rudder.min_deflection = -30*pi/180;
rudder.bias = 0; 
