clear
close all

save_plots = 0;

addpath('Trim_results');
folder_name = 'case_1_phi45_Ft1800';
cd(['Trim_results/',folder_name]);

load('A_lat_s.mat');
load('B_lat_s.mat');
load('A_long_s.mat');
load('B_long_s.mat');
load('initValues.mat');
load('params.mat');
load('A_tot_s.mat');
l_tether = initValues.l_tether;

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
lw = 1.2;
h1 = figure('Renderer', 'painters', 'Position', [0 0 400 300]);
h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h4 = figure('Renderer', 'painters', 'Position', [0 0 400 300]);
h5 = figure('Renderer', 'painters', 'Position', [0 0 400 300]);
h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h9 = figure('Renderer', 'painters', 'Position', [0 0 400 300]);
h10 = figure('Renderer', 'painters', 'Position', [0 0 400 300]);

svec = linspace( 0, 2*pi, numel(A_long_s) );
svec = flip(svec);
Va_trim =  initValues.Va;

s_unstable_phygoid = [];

mks_low = 5; 
mks_high = 10; 

lw_high = 1.2; 
lw_low = 1.2;

alpha_high = 1; 
alpha_low = 0.3; 

k_max = numel( A_long_s ); 
for k =  1 : k_max
    a_mks = (k-1)/(k_max-1); 
    mks = (1-a_mks)*mks_high + a_mks*mks_low; 
    lw = (1-a_mks)*lw_high + a_mks*lw_low; 
    alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low; 

    A_long = A_long_s{k};
    
    B_long = B_long_s{k};
    C_long = [0,1,0,0];
    G_long = minreal( ss( A_long, B_long, C_long, [] ) );
    
    A_long = A_tot_s{k};
    A_long(6,:) = [];
    A_long(:,6) = [];
    
    T = eye(8);
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    norms = abs( vec );
    idx_unstable = ( real(val)>0 );
    if sum( idx_unstable ) > 0
        idx_oscillatory_mode = ( imag( val( idx_unstable ) ) > 0 );
        if sum( idx_oscillatory_mode ) > 0
            s_unstable_phygoid = [s_unstable_phygoid, svec( k )];
        end
    end
    
    figure(1);
    plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(7) ), imag( val(7) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(8) ), imag( val(8) ), 'o', 'color', col1, 'Markersize', mks);
    
    % Lateral
    A_lat = A_lat_s{k};
    [vec,val ] = eig( A_lat );
    val = diag(val);
    plot( real( val(1) ), imag( val(1) ), 's', 'color',col3, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 's', 'color', col3, 'Markersize', mks);
    
    T = eye(4);
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long_s{k}*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'x', 'color',  col2, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
    
    figure(2);
    R = exp(sqrt(-1)*(-phase(4,1))); %rotation by phase q
    vec_rot = R * vec(:,1);
    phase(:,1) = angle( vec_rot );
    polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw); hold on
    polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw); hold on
    polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw); hold on
    polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw); hold on
    % legend('$v_a$', '$\alpha$', '$\Theta_{\tau}$', '$q$', 'Location', 'south')
    
    figure(3);
    R = exp(sqrt(-1)*(-phase(4,3))); %rotation by phase q
    vec_rot = R * vec(:,3);
    phase(:,3) = angle( vec_rot );
    polarplot([phase(1,3) phase(1,3)], [0, abs(vec_rot(1))], '-o', 'color', col1, 'Linewidth', lw); hold on
    polarplot([phase(2,3) phase(2,3)], [0, abs(vec_rot(2))], '-x', 'color', col2, 'Linewidth', lw); hold on
    polarplot([phase(3,3) phase(3,3)], [0, abs(vec_rot(3))], '-v', 'color', col3, 'Linewidth', lw); hold on
    polarplot([phase(4,3) phase(4,3)], [0, abs(vec_rot(4))], '-s', 'color', col4, 'Linewidth', lw); hold on
    %  legend('$v_a$', '$\alpha$', '$\Theta_{\tau}$', '$q$', 'Location', 'south')
    %xlabel('');
    
    
    figure(4);
    [p,z] = pzmap(G_long); % transfer function from elevator to angle of attack
    plot( real( p(1) ), imag( p(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
    plot( real( p(2) ), imag( p(2) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( p(3) ), imag( p(3) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( p(4) ), imag( p(4) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( z(1) ), imag( z(1) ), 'o', 'color', col2, 'Markersize', mks);
    plot( real( z(2) ), imag( z(2) ), 'o', 'color', col2, 'Markersize', mks);
    plot( real( z(3) ), imag( z(3) ), 'o', 'color', col2, 'Markersize', mks);
    
    figure(5)
    omegas = logspace(-1, 2, 1000);
    h_bode = semilogx(omegas, 20*log10( squeeze( abs(freqresp(G_long, omegas)) ) ), 'color', col1, 'Linewidth', lw); hold on
    h_bode.Color(4) = alpha_lvl; 
    xlabel('$Frequency$ $(rad/s)$');
    ylabel('$Magnitude$ $(dB)$');
    
    % ========================= Lateral ========================
    A_lat = A_lat_s{k};
    B_lat = B_lat_s{k};
    C_lat = [1,0,0,0;
        0, 1, 0, 0];
    G_lat = minreal( ss( A_lat, B_lat, C_lat, [] ) );
    
    [vec,val ] = eig( A_lat );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    norms = abs( vec );
    
    figure(6);
    R = exp(sqrt(-1)*(-phase(3,1))); %rotation by phase q
    vec_rot = R * vec(:,1);
    phase(:,1) = angle( vec_rot );
    polarplot([phase(1,1) phase(1,1)], [0, abs(vec(1,1))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(2,1) phase(2,1)], [0, abs(vec(2,1))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(3,1) phase(3,1)], [0, abs(vec(3,1))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(4,1) phase(4,1)], [0, abs(vec(4,1))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
    % legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south')
    
    figure(7);
    R = exp(sqrt(-1)*(-phase(4,2))); %rotation by phase r
    vec_rot = R * vec(:,2);
    phase(:,2) = angle( vec_rot );
    polarplot([phase(1,2) phase(1,2)], [0, abs(vec(1,2))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(2,2) phase(2,2)], [0, abs(vec(2,2))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(3,2) phase(3,2)], [0, abs(vec(3,2))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(4,2) phase(4,2)], [0, abs(vec(4,2))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
    %   legend('$\beta$', '$\Phi_{\tau}$', '$p$', '$r$', 'Location', 'south')
    
    figure(8);
    R = exp(sqrt(-1)*(-phase(2,4))); %rotation by phase phi
    vec_rot = R * vec(:,4);
    phase(:,4) = angle( vec_rot );
    polarplot([phase(1,4) phase(1,4)], [0, abs(vec(1,4))], '-o', 'color', col1, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(2,4) phase(2,4)], [0, abs(vec(2,4))], '-x', 'color', col2, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(3,4) phase(3,4)], [0, abs(vec(3,4))], '-v', 'color', col3, 'Linewidth', lw, 'Markersize', mks); hold on
    polarplot([phase(4,4) phase(4,4)], [0, abs(vec(4,4))], '-s', 'color', col4, 'Linewidth', lw, 'Markersize', mks); hold on
    
    %% zoomed plots
    A_long = A_tot_s{k};
    A_long(6,:) = [];
    A_long(:,6) = [];
    
    T = eye(8);
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    figure(9);
    plot( real( val(1) ), imag( val(1) ), 'o', 'color', col1, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(5) ), imag( val(5) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(6) ), imag( val(6) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(7) ), imag( val(7) ), 'o', 'color', col1, 'Markersize', mks);
    plot( real( val(8) ), imag( val(8) ), 'o', 'color', col1, 'Markersize', mks);
    % Lateral
    A_lat = A_lat_s{k};
    [vec,val ] = eig( A_lat );
    val = diag(val);
    plot( real( val(1) ), imag( val(1) ), 's', 'color',col3, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 's', 'color', col3, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 's', 'color', col3, 'Markersize', mks);
    
    T = eye(4);
    T(1,1) = 1/Va_trim;
    
    [vec,val ] = eig( T*A_long_s{k}*inv(T) );
    vec_abs = abs(vec);
    val = diag(val);
    phase = atan2( imag(vec), real(vec) );
    
    plot( real( val(1) ), imag( val(1) ), 'x', 'color', col2, 'Markersize', mks); hold on
    plot( real( val(2) ), imag( val(2) ), 'x', 'color', col2, 'Markersize', mks);
    plot( real( val(3) ), imag( val(3) ), 'x', 'color',  col2, 'Markersize', mks);
    plot( real( val(4) ), imag( val(4) ), 'x', 'color', col2, 'Markersize', mks);
    
    figure(10);
    [p,z] = pzmap(G_long); % transfer function from elevator to angle of attack
    plot( real( p(1) ), imag( p(1) ), 'x', 'color', col1, 'Markersize', mks); hold on
    plot( real( p(2) ), imag( p(2) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( p(3) ), imag( p(3) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( p(4) ), imag( p(4) ), 'x', 'color', col1, 'Markersize', mks);
    plot( real( z(1) ), imag( z(1) ), 'o', 'color', col2, 'Markersize', mks);
    plot( real( z(2) ), imag( z(2) ), 'o', 'color', col2, 'Markersize', mks);
    plot( real( z(3) ), imag( z(3) ), 'o', 'color', col2, 'Markersize', mks);
    
    
    drawnow;
end
figure(1);
xlabel('$Real(\lambda_i)$');
ylabel('$Imag(\lambda_i)$');
sgrid
if save_plots
    Plot2LaTeX(h1,['lambdas_',folder_name])
end

if save_plots
    figure(2);
    Plot2LaTeX(h2,['EV_star_SP_',folder_name]);
    figure(3);
    Plot2LaTeX(h3,['EV_star_phyg_',folder_name]);
end

figure(4);
xlabel('$Real$');
ylabel('$Imag$');
sgrid

if save_plots
    Plot2LaTeX(h4,['pole_zero_plot_',folder_name])
    Plot2LaTeX(h5,['bodemag_Glong_',folder_name]);
    Plot2LaTeX(h6,['EV_star_roll_',folder_name]);
    Plot2LaTeX(h7,['EV_star_DR_',folder_name]);
    Plot2LaTeX(h8,['EV_star_Spiral_',folder_name]);
end

figure(9);
xlabel('$Real(\lambda_i)$');
ylabel('$Imag(\lambda_i)$');
axis([-0.5 0.5 -3 3]); hold on
sgrid
if save_plots
    Plot2LaTeX(h9,['lambdas_zoom_',folder_name])
end
figure(10);
xlabel('$Real$');
ylabel('$Imag$');
axis([-0.5 0.1 -3 3]); hold on
sgrid
if save_plots
    Plot2LaTeX(h10,['pole_zero_plot_zoom_',folder_name])
    fclose('all');
    delete('*_temp.svg')
end
cd ..
cd ..