CircleParam.radius = 40; 
CircleParam.mean_elevevation = 30*pi/180; 
CircleParam.clockwise = 0; % Clockwise=1, Counterclockwise=0
CircleParam.d0 = 50;   % the real param eter is given by Vtot/d0