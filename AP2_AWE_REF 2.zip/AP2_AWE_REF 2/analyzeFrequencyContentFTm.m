%clear all
clc 
FTM = F_T_m.Data(230/dt:270/dt);
tvec = F_T_m.Time(230/dt:270/dt);
dt = F_T_m.Time(10) - F_T_m.Time(9);

%%

%%
L = length( FTM ) ;
Y = fft(FTM);
%%
f = 1/dt * (0:L/2)/L;
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
%%
figure(2);
plot(f(2:100),P1(2:100), '-o');
%%
[P1sort,idx] = sort(P1,'descend');
fsort = f(idx); 
xlabel('f (Hz)'); 
ylabel('Amplitude');
%%
N = 2;
fvec = fsort(1:N);
avec = P1sort(1:N);
figure(1); 
f_approx = []; 
figure(1);clf
plot( tvec,FTM ); hold on
h = []; 
for j = 1 : N
    delete(h); 
    if j == 1
        f_approx = avec(1)*ones(length(tvec),1);
    else
        f_approx = f_approx + avec(j) * sin(2*pi*fvec(j)*tvec ) ;
    end
    h = plot(tvec, f_approx, '-b'); hold on 
    pause(0.1);
    title(['#harmonics: ', num2str(j)]);
end


