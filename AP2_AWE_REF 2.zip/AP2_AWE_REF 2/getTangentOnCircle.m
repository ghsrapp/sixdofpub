function t_circ_W = getTangentOnCircle(sol, transCircle)

t_circ_C = -[-sin(sol);cos(sol); 0];

t_circ_W = transCircle.M_CW'*t_circ_C;