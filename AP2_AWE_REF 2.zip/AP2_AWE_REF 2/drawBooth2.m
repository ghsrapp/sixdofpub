

Lbooth.b = params.b_booth;
Lbooth.a = params.b_booth*params.a_booth;
%Lbooth.phi0 = params.phi0_booth;
[Lem] = updateBoothLemniscate(l_tether,Lbooth);
s = 0 : 0.005 : 2*pi;
%a = a/l_tether; 

%s =  Lbooth.s_trans_retract
%s = Lbooth.init_sol
long_P = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
lat_P =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 );

%long = Lem.a * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
%lat =   Lem.a^2/Lem.b * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;



% transform into cartesian coordinates 
p_P = [ cos(long_P).*cos(lat_P);sin(long_P).*cos(lat_P);sin(lat_P)]*l_tether;

%% 
phi_p_mean = params.phi0_booth;  
M_WP = [cos(phi_p_mean),0, -sin(phi_p_mean);0, 1, 0;  sin(phi_p_mean),0, cos(phi_p_mean)];  
 
p = M_WP * p_P; 
%figure(1); 
%plot3(p(1,:), p(2,:), p(3,:),'color',  col2 ,'MarkerIndices',1:20:length(p)); hold on 
try
plot3(p(1,:), p(2,:), p(3,:),'-','color', 'r','Linewidth',1.2); hold on 
catch
    plot3(p(1,:), p(2,:), p(3,:),'-','color', 'r','Linewidth',1.2); hold on 
end
try
    s = s_unstable_phygoid;
    long_P = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
    lat_P =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 );
    p_P = [ cos(long_P).*cos(lat_P);sin(long_P).*cos(lat_P);sin(lat_P)]*l_tether;
    phi_p_mean = params.phi0_booth;
    M_WP = [cos(phi_p_mean),0, -sin(phi_p_mean);0, 1, 0;  sin(phi_p_mean),0, cos(phi_p_mean)];
    
    p = M_WP * p_P;
    plot3(p(1,:), p(2,:), p(3,:),'x','color', col2, 'Markersize',10); hold on
end

% view(90,params.phi0_booth*180/pi); hold on 
% axis off
%ylabel('$y_W$');
%zlabel('$z_W$');
% xlabel('$x_W$ $(m)$','interpreter', 'latex')
% ylabel('$y_W$ $(m)$','interpreter', 'latex')
% zlabel('$z_W$ $(m)$','interpreter', 'latex')
% axis equal
% axis([ 0 1550 -300 300 50 600])

% s = Lbooth.init_sol;
% long = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
% lat =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
% Lbooth.p_init_VT_path = [ cos(long).*cos(lat);
%       sin(long).*cos(lat);
%       sin(lat)]*l_tether;
% X = [-300;1000;1000;-300];
% Y = [-600;-600;600;600];
% v = [X,Y];
% c = [0 1 0; % red
%     0 1 0; % green
%     0 1 0;
%     0 1 0];
% fill(X,Y, c(:,2),'EdgeColor','none','FaceColor',c(1,:),'FaceAlpha',0.1);
% axis equal;
% 
%view(90,25);



if 0 
%%
l_tether = 600;
[x,y,z] = sphere(100); 
r = l_tether;
figure
surf(x*r,y*r,z*r); hold on 
axis( [-l_tether l_tether -l_tether l_tether 0 l_tether]); 
axis equal

end
