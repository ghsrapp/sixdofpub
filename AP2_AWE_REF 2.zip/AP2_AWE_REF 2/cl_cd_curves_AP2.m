clear all
close all

initAP2_ModelParameters;

omega_OB_rad = zeros(3,1);
u_rb = zeros(3,1);
Va = 30;
beta = 0;
a_vec = [-10 : 0.01 : 15]*pi/180;
for n = 1 : length( a_vec )
    alpha = a_vec(n);
    airdata = [Va;alpha;beta];
    [F_a_B, M_a_B] = getAeroForcesAndMoments( omega_OB_rad, u_rb, airdata,  P_AP2);
    M_BA = [cos(alpha)*cos(beta), -cos(alpha)*sin(beta), -sin(alpha);
        sin(beta), cos(beta), 0;
        sin(alpha)*cos(beta), -sin(alpha)*sin(beta), cos(alpha)];
    M_AB = M_BA.';
    F_a_A = M_AB * F_a_B; 
    CD(n) = -F_a_A(1)/(0.5*1.225*P_AP2.S_ref*Va^2); 
    CL(n) = -F_a_A(3)/(0.5*1.225*P_AP2.S_ref*Va^2); 
end
%%
[l,m] = find( a_vec==10*pi/180 ); 
CL_10_deg = CL(m); 
[l,m] = find( a_vec==-5*pi/180 ); 
CL_m5_deg = CL(m); 
[l,m] = find( a_vec==0*pi/180 ); 
CL_0_deg = CL(m); 
% linear approximation
CL_alpha = (CL_10_deg-CL_m5_deg)/(15*pi/180); 
CL_0 = CL_10_deg - CL_alpha*10*pi/180; 


%% aerodynamically most efficient AoA
[l,m] = max( CL(1:m)./CD(1:m) ); 
alpha_CL_CD_opt = a_vec(m); 

%% AWE most efficient AoA
[l,m] = max( CL.^3./CD.^2 ); 
alpha_CL_CD_opt = a_vec(m); 
figure; 
plot( a_vec*180/pi, CL.^3./CD.^2 ) ; 

%% plot CL / CD curves 
figure; 
plot( a_vec*180/pi, CL ); hold on
xlabel('$\alpha$ (degrees)', 'interpreter', 'latex'); 
ylabel('$CL,CD$', 'interpreter', 'latex'); 
plot( a_vec*180/pi, CD ); 
% linear approximation
plot( a_vec*180/pi, CL_0 + CL_alpha * a_vec ); 

