function [ p_VT_W, wp_idx_] = getVTonGcCDiscPath( p_kite_W, l_tether, r_d,latChoose, maxWidth,fWp, wp_idx )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

waypointsPath_W = discPathUpdateGcC(l_tether, r_d,latChoose, maxWidth,fWp); 
waypointsPath_W = waypointsPath_W/l_tether; 

% Calculate normal vectors
waypointsPath_W_ = [waypointsPath_W(end,:); waypointsPath_W(1:end-1,:)];
delta_p = waypointsPath_W - waypointsPath_W_;
norm_ = sqrt( delta_p(:,1).*delta_p(:,1) + delta_p(:,2).*delta_p(:,2) + delta_p(:,3).*delta_p(:,3) );
q_vec = delta_p ./ repmat(norm_,1,3);

j = 1; 
flag = 1; 
while j <=1 %&& flag % might be important for a practical implementation
    % Normalvector
    if wp_idx == 1
        nvec_wp_idx = (q_vec(1,:) + q_vec(length( waypointsPath_W_),:)) / norm( q_vec(1,:) + q_vec(length( waypointsPath_W_),:) );
    else
        nvec_wp_idx = (q_vec(wp_idx,:) + q_vec(wp_idx-1,:)) / norm( q_vec(wp_idx,:) + q_vec(wp_idx-1,:) );
    end
    % Switching condition
    if ( (p_kite_W'/norm(p_kite_W) - waypointsPath_W_(wp_idx,:))*nvec_wp_idx' ) >= 0
        p = 3; % thats basically the carrot parameter.
        if wp_idx < length(waypointsPath_W)-p
            wp_idx = wp_idx + 1 + p;
        else
            wp_idx = 1;
        end
    else 
        flag = 0; 
    end
    j = j + 1; 
end

wp_idx_ = wp_idx;

% Calculate course
p_VT_W = waypointsPath_W_(wp_idx_,:)';
% e_1 = cross(  p_VT_E, p_kite_W);
% e_1 = e_1/norm(e_1);
% e_2 = cross( p_kite_W, e_1);
% e_2 = e_2/norm(e_2); % Bearing vector!
% 
% % Course angle is defined between the NED and the K system
% % the orthonormal basis of the NED system is defined by longitude and
% % latitude of the current position:
% e_z_O_E = -p_kite_W/norm(p_kite_W);
% 
% % Now using the definition of the transformation M_EO matirix:
% lat_p = -asin( e_z_O_E(3) );
% long_p = atan( e_z_O_E(2) / e_z_O_E(1) );
% e_x_O_E = [-sin(lat_p)*cos(long_p); -sin(lat_p)*sin(long_p); cos(lat_p)];
% 
% e_z_0K = cross( e_2, e_x_O_E);
% bearing_vec = e_2;
% 
% chi_K_des = acos(  max( min( e_x_O_E'*e_2, 1), -1 ) ) * sign(e_z_0K(3) );

end

