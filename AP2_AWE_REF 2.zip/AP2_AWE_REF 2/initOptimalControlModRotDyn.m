% Implemented according to Nguyen Nhan, An Optimal Control Modification to
% MRAC for Fast-Adaption

adapt.Kp = diag([FCS.Kp_p, FCS.Kp_q, FCS.Kp_r]);
adapt.Ki = diag([FCS.Ki_p,FCS.Ki_q,FCS.Ki_r]);
adapt.Ki_inv = inv(adapt.Ki); 
adapt.Ac = [zeros(3), eye(3);
    -adapt.Ki, -adapt.Kp];
adapt.b = [zeros(3);
    eye(3)];
adapt.P = lyap(adapt.Ac', 2*eye(6));

adapt.P = [inv(adapt.Ki)*adapt.Kp+inv(adapt.Kp)*(adapt.Ki+eye(3)), inv(adapt.Ki);
    inv(adapt.Ki), inv(adapt.Kp)*(eye(3)+inv(adapt.Ki))];

adapt.M = adapt.b' * adapt.P * inv(adapt.Ac) * adapt.b;

adapt.Gamma_opt_mod = 100*eye(9); 

adapt.nu_opt_mod = 0.001; 
adapt.sigma = 0.1; 


% adapt.Kp = diag([FCS.Kp_chi_predictive]);
% adapt.Ki = diag([FCS.Ki_chi_predictive]);
% adapt.Ki_inv = inv(adapt.Ki); 
% adapt.Ac = [zeros(1), eye(1);
%     -adapt.Ki, -adapt.Kp];
% adapt.b = [zeros(1);
%     eye(1)];
% adapt.P = lyap(adapt.Ac', 2*eye(9));
% 
% adapt.M = adapt.b' * adapt.P * inv(adapt.Ac) * adapt.b;
% 
% adapt.Gamma_opt_mod = 1e-3*eye(3); 
% 
% adapt.nu_opt_mod = 0.001; 
% adapt.sigma = 0.1; 
