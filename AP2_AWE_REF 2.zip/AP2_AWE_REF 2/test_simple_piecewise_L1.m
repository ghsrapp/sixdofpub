
function [HmInvHum, Ke_L1, C1, Ts, F, K, Am, Bp_um] = test_simple_piecewise_L1(Ap, Bp, K) 

% Working gains!
% Q = 0*eye(4); 
% Q(1,1) = 0; 
% Q(2,2) = 0; 
% Q(3,3) = 0.001; 
% Q(4,4) = 0.03; 
% R = 1; 

Q = 0*eye(4); 
Q(1,1) = 0; 
Q(2,2) = 0; 
Q(3,3) = 0; 
Q(4,4) = 0.1; 
R = 1; 
 K = lqr( Ap, Bp, Q, R ); 
Am = Ap - Bp*K; 

% 
 Cc = [0,1,0,0];
 MxMu =  ([Ap, Bp; Cc, 0 ] ) \ [zeros(4,1); 1] ; 
 Mx = MxMu(1:end-1);
 Mu = MxMu(end); 
F = K*Mx+Mu;

sys = ss( Am, Bp*F, [0,1,0,0], [] ); 
figure; 
step(sys); 

% nullspace of bp_plus:
s = 1; t = 0; %
x4 = (-Bp(1)*s-Bp(2)*t)/Bp(4);
v1 = [s;t;0;x4]; 

s = 0; t = 1; % x3 and x5 can be set to zero
x4 = (-Bp(1)*s-Bp(2)*t)/Bp(4);
v2 = [s;t;0;x4]; 

s = 1; t = 1; % x3 and x5 can be set to zero
x4 = (-Bp(1)*s-Bp(2)*t)/Bp(4);
v3 = [s;t;1;x4]; 

Bp_um = [v1, v2, v3];



%% L1 Piecewise constant update law
s = tf('s'); 
%Bm = Bp*F; 
Hm = Cc* ( (s*eye(4)-Am)\Bp ) ; 
Hum = Cc* ( (s*eye(4)-Am)\Bp_um ) ;


HmInvHum = 1/Hm*Hum; 

Ts = 0.01; 
B = [Bp, Bp_um]; 
% Ke_L1 =( B \  ( (Am\(expm(Am*Ts)-eye(size(Am,1)))) )) \expm(Am*Ts) ; 
C1 = tf( [0, 30], [1, 30] ); 
Ke_L1 =  -inv(B) * inv( expm(Am*Ts) - eye(size(Am,1) ) ) * Am * expm(Am*Ts) ; 

 
 