function state = myPlotFunc(options, state, flag)
disp(['Current generation: ',num2str(state.Generation), ' | ', 'Best Score: ',num2str( min(state.Score) ), ' | ', 'Mean Score: ',num2str( mean(state.Score) ) ]  );  
figure(2); 
pop_current = state.Population;
save('pop_current.mat', 'pop_current');
plot(state.Generation, min(state.Score), '*r'); hold on
plot(state.Generation*ones(1,length(state.Score)), state.Score, 'ob'); hold on
x = pop_current(1,:);
testOptimizedController_v2;

figure(1);
% Store the current best parameter combination in txt file
cd 'params'
exportTmpBestParams2( x,state.Generation,min(state.Score) );
cd .. 
end
