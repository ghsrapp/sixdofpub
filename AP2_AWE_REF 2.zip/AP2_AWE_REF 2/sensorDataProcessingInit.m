%% Lowpass filter init
% Bodyrates 
SensorData.Rates.omega = 100; 
SensorData.absP.omega = 50; 
SensorData.DiffPressure.omega = 50; 
SensorData.GPSPos.omega = 10; 
P.T_sensor = 0.02; 