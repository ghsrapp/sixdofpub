

addpath('Flightpaths');
addpath('Flightpaths/new_lissajous_fig_following/');
addpath('TetherModel');
addpath('windfield');
addpath('boothLem');
l_tether = 400; 

initBoothLem;
initRetractionParameters;
%drawBooth;
%% Select one of the following figures
%v_retraction = -15;
%h_dot_retraction = -1;

figIndxCircle = 1;
figIndxApprox8 = 2;
figIndxLem8 = 5;
figIndxLissajousVecF = 5;

delay_g2k = 0.1;
delay_k2g = delay_g2k;

windDirection_rad = pi;

figIndx = figIndxLissajousVecF;%figIndxLem8; % Circle: 1, Figure 8: 2;, Lemniscate: 5
scenarioFig8;
aircraftParametersKitemill5kw;
initAP2_ModelParameters;

sensorsInit;
controlParameters;

%% Following factors are for tuning purposes only.
%
factor_chi = 0.8;
factor_mu= 0.6;
factor_p= 0.8;
factor_gamma= 0.8;
factor_alpha= 0.6;
factor_q= 0.8;
factor_beta= 1;
factor_r= 1;
%
factor_w0_p = 25;
factor_w0_q = 25;
factor_w0_r = 25;
factor_w0_mu = 1/4;
factor_w0_alpha = 1/4;
factor_w0_beta = 1/4;
factor_w0_chi = 1/4;
factor_w0_gamma = 1/4;
%
constraints;%
VTOL_Parameters;
MRAC_settings;
tether_parameters;
nav_init;
initTwoWps;
initActuatorModels;

% Initialize th1e reference paths
initFourWps;
initLissajous;
%drawLissajous;
initCircle;
selected_path =2;%2; % 1: Four Waypoints,2: Lissajous 3: Circle
if selected_path == 1
    disp('### Four waypoint navigation is selected. ###');
    initControllerGains;%
elseif selected_path == 2
    disp('### Lissajous figure following is selected. ###');
    %initControllerGains;%
    initControllerGainsLisaNew3;
else
    disp('### Circle navigation is selected. ###');
    %initControllerGains;
    initControllerGains_circle;
end

adaptiveInit;
%aerodynamicsController; % remove?
Environment;
initBusObjects;
sensorDataProcessingInit;

% Choose simulation mode
kiteMode = 0;
transitionTest = 0;

if ~kiteMode
    flightModeInit = 1;
    % AIRCRAFT STATE INITIALIZATION
    %pos_O_init = [0,0,-90];
    pos_O_init = [waypoint_mat(end-1,1), 0,waypoint_mat(end-1,3) ];
    vel_B_init = [10;0;0];zeros(3,1);
    eta_init = [0;0;0];
    tether_inital_lenght = norm( pos_O_init);
    phi_t = 0; theta_t =0*pi/180; psi_t = eta_init(3);
    eta_t_init = [phi_t; theta_t; psi_t];
    M_OW = [-1, 0, 0; 0, 1, 0; 0, 0, -1]; M_WO = M_OW; % downwind is south
    
else
    % AIRCRAFT STATE INITIALIZATION
    flightModeInit = 5;
    M_OW = [-1, 0, 0; 0, 1, 0; 0, 0, -1]; M_WO = M_OW;
    l_tether = 200;
    
    % Position
    gamma_launch = 20 * pi/180;
    long_init = 0* 20*pi/180;
    pos_W_init = [cos(gamma_launch)*cos(long_init);
        sin(long_init)*cos(gamma_launch);
        sin(gamma_launch) ] * l_tether;
    pos_O_init = M_OW * pos_W_init;
    
    M_TW = [-sin(gamma_launch)*cos(long_init), -sin(gamma_launch)*sin(long_init), cos(gamma_launch);
        -sin(long_init), cos(long_init), 0;
        -cos(gamma_launch)*cos(long_init), -cos(gamma_launch)*sin(long_init), -sin(gamma_launch)];
    e_x_T = M_TW(1,:);
    
    % Attitude
    phi_t = 0; theta_t =-60*pi/180;%-(pi/2-gamma_launch);
    psi_t = 0;
    eta_t_init = [phi_t; theta_t; psi_t];
    M_TB = [cos(psi_t)*cos(theta_t), cos(psi_t)*sin(theta_t)*sin(phi_t)-sin(psi_t)*cos(phi_t), cos(psi_t)*sin(theta_t)*cos(phi_t)+sin(psi_t)*sin(phi_t);
        sin(psi_t)*cos(theta_t), sin(psi_t)*sin(theta_t)*sin(phi_t)+cos(psi_t)*cos(phi_t), sin(psi_t)*sin(theta_t)*cos(phi_t)-cos(psi_t)*sin(phi_t);
        -sin(theta_t), cos(theta_t)*sin(phi_t), cos(theta_t)*cos(phi_t) ];
    M_OB = M_OW * M_TW' * M_TB;
    theta_euler = asin( -M_OB(3,1) );
    psi_euler = atan2( M_OB(2,1) , M_OB(1,1) );
    phi_euler = atan2( M_OB(3,2) , M_OB(3,3) );
    eta_init = [phi_euler;theta_euler;psi_euler];
    
    % Velocity
    v_T_init = [15;0;0];
    vel_B_init = M_TB' * v_T_init;
    vel_B_init = [20;0;0];
    v_K_init = norm(vel_B_init);
    
    tether_inital_lenght = l_tether;
end

% initial long/lat
pos_W_init = transformFromOtoW(windDirection_rad, pos_O_init');
long_init = atan2( pos_W_init(2), pos_W_init(1) );
lat_init = asin( pos_W_init(3)/norm(pos_W_init) );

p_zenith = [0;0;-1];
p_zenith_proj = [0;0;-1];
lat = min(latChoose, 90*pi/180-2*latMin);

initWinch;


%% Tether parameters (analytical tether model from Van, Fagiano, Schnez)
E = 5.3e9;
epsilon = 0.02;
drag = 1;
diameter = 0.002;
c_tether = E * pi * diameter^2 / (4*epsilon);

%% State machine
SM.dMaxLand = 0.3;
SM.minParkAltitude = 100;
SM.max_l_t_traction = l_tetherMax;
SM.min_l_t_traction = 200;

% Waypoint based lemniscate
%initReferenceLemniscate;

%% Init visualization
if 0
    % Now calculate the figure at tether lenght
    lemniscate_W_real = lemniscate_W * tetherLtest;
    plot3( lemniscate_W_real(:,1),  lemniscate_W_real(:,2), lemniscate_W_real(:,3), '--o', 'color', [0.5, 0.5, 0.5], 'Linewidth',2); hold on
    plot3( [lemniscate_W_real(1,1) lemniscate_W_real(end,1)], [lemniscate_W_real(1,2) lemniscate_W_real(end,2)], [lemniscate_W_real(1,3) lemniscate_W_real(end,3)], '--o', 'color', [0.5, 0.5, 0.5],'Linewidth', 2); hold on
    axis equal;
    plot3( lemniscate_W_real(wp_idx_init,1),lemniscate_W_real(wp_idx_init,2),lemniscate_W_real(wp_idx_init,3), '*g');
else
    %initVisualization;
end


Tether_Particles_Init;
initRetraction2Traction;
%%
% plot3( wp_plot(1,1), wp_plot(1,2), wp_plot(1,3), 'xk', 'Markersize', 10, 'Linewidth', 2); hold on
% plot3( wp_plot(2,1), wp_plot(2,2), wp_plot(2,3), 'xk', 'Markersize', 10,'Linewidth', 2);hold on
% plot3( wp_plot(3,1), wp_plot(3,2), wp_plot(3,3), 'xk', 'Markersize', 10, 'Linewidth', 2);hold on
% plot3( wp_plot(4,1), wp_plot(4,2), wp_plot(4,3), 'xk', 'Markersize', 10', 'Linewidth', 2);hold on

%%
radius = norm(wp_plot(1,:));
n_circ = cross( wp_plot(2,:)', wp_plot(3,:)');
t = cross( wp_plot(3,:)', n_circ);
z = n_circ/norm(n_circ); %z/norm(z);
x = t/norm(t);
y = wp_plot(3,:)'/norm(wp_plot(3,:));%cross(z,x);
transCircle.M_CW = [x';y';z'];
theta_circ = 0 : 0.01 : 2*pi;
x_circ_C = cos( theta_circ )*radius;
y_circ_C = sin( theta_circ )*radius;
z_circ_C = 0 * x_circ_C;

p_circ_W = transCircle.M_CW.' * [x_circ_C;y_circ_C;z_circ_C];
%%


%% sphere
%[x,y,z]=sphere(100);
% use surf function to plot
%hSurface=surf(x*radius,y*radius,z*radius);
%hold on
%set(hSurface,'FaceColor',[0.5 0.5 0.5], ...
%   'FaceAlpha',0.2,'EdgeColor','black')
%plot3( p_circ_W(1,:), p_circ_W(2,:), p_circ_W(3,:), '--b');
milspec_windmodel_flag = 1;
stationaryWindfieldFlag = 0;
%generateLookupTableData; % for aerodynamic model

if ~milspec_windmodel_flag
    %%
    exportWindDataFlag = 0;
    cd 'windfield'
    initWindfieldThomas;
    cd ..
end
dt = 0.00025; % Step size Simulink

%% Some filter try out stuff
% create a bandpass filter centered around 1 rad/s (the frequency of the
% first harmonic of the tether force
bp_tf_filter = tf( makeweight(1e-4, 1, 10) ) * tf( makeweight(10,1,1e-4) );

% Tuning parameters
initTuningParameters;
% Sensor data processing
initSensorDataProcessing;



