function [p_VT_W, wp_idx_] = getVTonDiscLemniscate( p_kite_W, wp_idx,lat_op, l_tether, LEMNISCATE )
%LEMNISCATECOURSE Summary of this function goes here
%   Detailed explanation goes here
% 1: Bernoulli 0: Lemniscate
if 1
    t = LEMNISCATE.t;%linspace(0,2*pi, 30);
    a_star = LEMNISCATE.a_star;%80;
    a = a_star / l_tether;
    long_vec = ( a * sqrt(2) * cos(t) ) ./ (sin(t).^2 + 1) ;
    lat_vec = ( a * sqrt(2) * cos(t) .* sin(t) ) ./ (sin(t).^2 + 1) ;
else
    t = LEMNISCATE.t;%linspace(2*pi,0, 20);
    AStar = LEMNISCATE.AStar;%60;
    BStar = LEMNISCATE.BStar;
    A = AStar/l_tether;
    B = BStar/l_tether;
    long_vec = A * sin( 1 * t  ) ;
    lat_vec = B * sin( 2 * t );
end
lemniscate_W = [cos(long_vec).*cos(lat_vec);
    sin(long_vec).*cos(lat_vec);
    sin(lat_vec)];
M_rot = [cos(lat_op), 0, -sin(lat_op);
    0, 1, 0;
    sin(lat_op), 0, cos(lat_op)];

lemniscate_W_tmp = lemniscate_W' * M_rot';
lemniscate_W = lemniscate_W_tmp(1:end-1,:);

% Up or Down fig 8
midUpFlag = 0;
if midUpFlag
    lemniscate_W = flip(lemniscate_W);
end
% Calculate normal vectors
lemniscate_W_ = [lemniscate_W(end,:); lemniscate_W(1:end-1,:)];
delta_p = lemniscate_W - lemniscate_W_;
norm_ = sqrt( delta_p(:,1).*delta_p(:,1) + delta_p(:,2).*delta_p(:,2) + delta_p(:,3).*delta_p(:,3) );
q_vec = delta_p ./ repmat(norm_,1,3);

j = 1; 
flag = 1; 
while j <=1 && flag % might be important for a practical implementation
    % Normalvector
    if wp_idx == 1
        nvec_wp_idx = (q_vec(1,:) + q_vec(length( lemniscate_W_),:)) / norm( q_vec(1,:) + q_vec(length( lemniscate_W_),:) );
    else
        nvec_wp_idx = (q_vec(wp_idx,:) + q_vec(wp_idx-1,:)) / norm( q_vec(wp_idx,:) + q_vec(wp_idx-1,:) );
    end
    % Switching condition
    if ( (p_kite_W'/norm(p_kite_W) - lemniscate_W_(wp_idx,:))*nvec_wp_idx' ) >= 0
        p = 0; 
        if wp_idx < length(lemniscate_W) - p 
            wp_idx = wp_idx + 1 + p;
        else
            wp_idx = 1;
        end
    else 
        flag = 0; 
    end
    j = j + 1; 
end

wp_idx_ = wp_idx;

% Calculate course
p_VT_W = lemniscate_W_(wp_idx_,:)';
% e_1 = cross(  p_VT_E, p_kite_W);
% e_1 = e_1/norm(e_1);
% e_2 = cross( p_kite_W, e_1);
% e_2 = e_2/norm(e_2); % Bearing vector!
% 
% % Course angle is defined between the NED and the K system
% % the orthonormal basis of the NED system is defined by longitude and
% % latitude of the current position:
% e_z_O_E = -p_kite_W/norm(p_kite_W);
% 
% % Now using the definition of the transformation M_EO matirix:
% lat_p = -asin( e_z_O_E(3) );
% long_p = atan( e_z_O_E(2) / e_z_O_E(1) );
% e_x_O_E = [-sin(lat_p)*cos(long_p); -sin(lat_p)*sin(long_p); cos(lat_p)];
% 
% e_z_0K = cross( e_2, e_x_O_E);
% bearing_vec = e_2;
% 
% chi_K_des = acos(  max( min( e_x_O_E'*e_2, 1), -1 ) ) * sign(e_z_0K(3) );

end

