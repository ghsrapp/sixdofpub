l_tether = 400;
l = l_tether; 
theta_vec= 0 : 0.001 : 2*pi;theta_vec = theta_vec';
axis equal; grid on;hold on; view(90,0);
box on; 

%for l = 200 : 10 : 600
%l_tether = l; 
%theta_vec = theta_v(l); 

[ LemPs ] = updateLissajous( l_tether, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = 20*pi/180;% LemPs.phi0;


L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];

L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];

L_W_k = L_W * l_tether;
Delta0 = 0.5 * max( L_W_k(2,: ) );
col3 =  [237/255, 85/255, 59/255 ];
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), '-', 'color',col3); hold on; 
drawnow; 

%
theta_point = LemPsRef.s_trans;%   pi/2+0.5;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * l;

%end


%%

%%
u = visualization_stuff.Data(:,650); 
u(7) = 0; 
drawVehicle_v2(u);

[x,y,z] = sphere(50);
%h = surf( x*l_tether, y*l_tether, z*l_tether);hold on
h = surf( x*400, y*400, z*400);hold on
set(h,'FaceColor',[0.5,0.5,0.5], 'FaceAlpha', 0.5, 'EdgeColor', 'none'); 
%shading interp
axis([0 400 -400 400 0 400]);
