function [ sol,p_C_W] = getTargetOnLissajousNewton(LemPs, p_kite_W, c0, l_tether, direction)
%GETVTONLEMNISCATE Summary of this function goes here
%   Detailed explanation goes here
p_kite_W = p_kite_W/norm(p_kite_W);

%% Two approaches for the calculation of the closest point on the path: bisec and newton
% use a bisection method to compute closest point on path relative to kite
% position.
% newton
[sol, exceedMaxIter] = doNewtonIteration(c0,LemPs, p_kite_W, direction);

% if sol <= intervalInit(1) || sol >= intervalInit(2) || exceedMaxIter == 1
%     
%     f = func([0:0.01:2*pi],p_kite_W, LemPs);
%     figure(2);
%     plot( [0:0.01:2*pi], f, 'r' ); hold on
%     
%     [ sol, res, f ] = bisec( intervalInit, p_kite_W, LemPs, c0 );
%     ph = [];
%     disp('Bisection');
% end

sol = mod(sol, 2*pi);
interval = [sol-0.2, sol+0.2];

L = [LemPs.Alambda * sin(LemPs.blambda*sol');
    LemPs.Aphi    * sin(LemPs.bphi*sol') + LemPs.phi0];

p_C_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
end