% Giani model 
alpha_vec = -8 : 0.1 : 16;
alpha_vec = alpha_vec * pi/180;
Cx0 = 0.46;
Cx_alpha = 8.32;

figure; 
plot( alpha_vec * 180/pi, Cx0 + (Cx_alpha*alpha_vec).*alpha_vec ); hold on 

% Elena model 
plot( alpha_vec *180/pi, P_AP2.Cx_0_0 + P_AP2.Cx_0_alpha * alpha_vec + P_AP2.Cx_0_alpha2 * alpha_vec.^2 ); 
legend('Gianni', 'Elena');
xlabel('\alpha (deg)'); 
ylabel('Cx(\alpha)');


%%
%Gianni
Cz0 = -5.4; 
Czalpha = 1.23; 
Czalpha2 = 10.2; 
figure; 
plot( alpha_vec*180/pi, Cz0 + (Czalpha*alpha_vec + Czalpha2*alpha_vec.^2).*alpha_vec); hold on 
% Elena
plot( alpha_vec*180/pi,  P_AP2.Cz_0_0  + P_AP2.Cz_0_alpha  * alpha_vec + P_AP2.Cz_0_alpha2 * alpha_vec.^2 ); 
legend('Gianni', 'Elena');
xlabel('\alpha (deg)'); 
ylabel('Cz(\alpha)');


%% Lift/Drag curve 
for j = 1 : length(alpha_vec)
    alpha = alpha_vec(j);
    M_AB = [cos(alpha), 0, sin(alpha);
        0, 1, 0;
        -sin(alpha), 0, cos(alpha) ];
    CX1 = P_AP2.Cx_0_0 + P_AP2.Cx_0_alpha * alpha + P_AP2.Cx_0_alpha2 * alpha.^2;
    CZ1 = P_AP2.Cz_0_0  + P_AP2.Cz_0_alpha  * alpha + P_AP2.Cz_0_alpha2 * alpha.^2;
    
    %CX2 = Cx0 + (Cx_alpha*alpha)*alpha;
    %CZ2 = Cz0 + (Czalpha*alpha + Czalpha2*alpha.^2)*alpha;
    
    C_a_A1 = M_AB * [CX1; 0; CZ1];
    C_a_A2 = M_AB * [CX2; 0; CZ2];
    
    CD1(j) = -C_a_A1(1); 
    CL1(j) = -C_a_A1(3); 

    CD2(j) = -C_a_A2(1); 
    CL2(j) = -C_a_A2(3); 
    
end

%%
[a,b] = max(CL1./CD1);
figure; 
title('lift over drag'); 
plot( alpha_vec*180/pi, CL1./CD1 ); hold on 
CL1best = CL1(b); 
CD1best = CD1(b); 
e = CL1best^2 / (CD1best * 10 * pi);
%plot( alpha_vec*180/pi, CL2./CD2 ); 
%%
figure; 
title('Lift and Drag coeff'); hold on 
%plot( alpha_vec*180/pi, CL2, '-r'); hold on 
%plot( alpha_vec*180/pi, CD2, '-b'); 
plot( alpha_vec*180/pi, CL1, '--r'); hold on 
plot( alpha_vec*180/pi, CD1, '--b'); 
%%

% Cma 
% Gianni
Cma = 0.21*alpha_vec; 
Cm0 = -0.32;
figure; 


plot( alpha_vec*180/pi,  Cm0 + Cma.*alpha_vec ); hold on 
plot( alpha_vec*180/pi, P_AP2.Cm_0_0 + P_AP2.Cm_0_alpha * alpha_vec ); 
