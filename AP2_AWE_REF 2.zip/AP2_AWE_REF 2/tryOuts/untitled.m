G=nd2sys( [200],conv([10 1],conv([0.05 1],[0.05 1])) ); 
s = tf('s'); 
K=nd2sys( [0.1 1], conv([0.65 1],[0.03 1]),0.2 );
systemnames='G';
inputvar='[w1;w2;d;n;r;u]'; outputvar='[u;r-n-d-w1-G;G+w1+d-r;r+w2-n-d-w1-G]';
input_to_G='[u]';
sysoutname='P';
cleanupsysic='yes';
sysic
N=starp(P,K);
M11=sel(N,1,1);
M22=sel(N,2,2);
M=sel(N,[1 2],[1 2]);
om=logspace(0,1);
clf; vplot('liv,m',frsp(M11,om),':',frsp(M22,om),':',vnorm(frsp(M,om)),'--'); hold on;grid on

Mmu=mu(frsp(M,om),[1 1;1 1]);
vplot('liv,m',Mmu,'-');