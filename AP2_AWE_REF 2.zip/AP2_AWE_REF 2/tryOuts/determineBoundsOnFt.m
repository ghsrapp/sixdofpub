Va_max = 50;
Va_min = 20;

theta_tau_min = -20*pi/180;
theta_tau_max = 20*pi/180;

alpha_max = 20*pi/180;
alpha_min = -5*pi/180;

alpha_vec = linspace( alpha_min, alpha_max, 50);
theta_tau_vec = linspace( theta_tau_min, theta_tau_max, 60);
figure;
f = [];
Va = 30;
if 1
    for n = 1 : length( alpha_vec)
        alpha = alpha_vec(n);
        for j = 1 : length( theta_tau_vec )
            theta_t = theta_tau_vec(j);
            
            
            % Aerodynamic Force
            if alpha*180/pi <= 10
                CLalpha=P.CL_Theta1_0 + P.CL_Theta1_1 * alpha +...
                    P.CL_Theta1_2 * alpha.^2 + P.CL_Theta1_3 * alpha.^3 +...
                    P.CL_Theta1_4 * alpha.^4;
            else
                CLalpha=P.CL_Theta2_0 + P.CL_Theta2_1 * alpha +...
                    P.CL_Theta2_2 * alpha.^2;
            end
            CDalpha = P.CD_Theta1_0 + P.CD_Theta1_1 * alpha +...
                P.CD_Theta1_2 * alpha.^2 + P.CD_Theta1_3 * alpha.^3 +...
                P.CD_Theta1_4 * alpha.^4;
            
            L = 0.5 * 1.225*  P.S_wing * CLalpha * Va^2;
            D = 0.5 * 1.225*  P.S_wing * CDalpha * Va^2;
            
            f(n,j) = sin(theta_t)*cos(alpha)*D-...
                sin(theta_t)*sin(alpha)*L-...
                cos(theta_t)*sin(alpha)*D-...
                cos(theta_t)*cos(alpha)*L;
            %plot3(alpha*180/pi, theta_t*180/pi, f(n,j), '+r'); hold on
        end
    end
    [X,Y] = meshgrid( 180/pi*alpha_vec, 180/pi*theta_tau_vec );
    mesh(X,Y,f'); hold on

end

%% Numerical determination of the solution
alpha_num = 0;
theta_num = 0;
res = 1;
iter = 0;
maxIter = 10000;
lambda = 1e-6;
maxif = 1; % set to minus one if you want to maximize
while res > 1e-6 && iter < maxIter %&& alpha_num<alpha_max
    if alpha_num > 10 * pi/180;
        dCLdalpha= P.CL_Theta2_1+...
            2*P.CL_Theta2_2 * alpha_num;
    else
        dCLdalpha = P.CL_Theta1_1 +...
            2*P.CL_Theta1_2 * alpha_num + 3*P.CL_Theta1_3 * alpha_num.^2 +...
            4*P.CL_Theta1_4 * alpha_num.^3;
    end
    dCDalpha =   P.CD_Theta1_1 +...
        2*P.CD_Theta1_2 * alpha_num + 3*P.CD_Theta1_3 * alpha_num.^2 +...
        4*P.CD_Theta1_4 * alpha_num.^3;
    %
    if alpha_num*180/pi <= 10
        CLalpha=P.CL_Theta1_0 + P.CL_Theta1_1 * alpha_num +...
            P.CL_Theta1_2 * alpha_num.^2 + P.CL_Theta1_3 * alpha_num.^3 +...
            P.CL_Theta1_4 * alpha_num.^4;
    else
        CLalpha=P.CL_Theta2_0 + P.CL_Theta2_1 * alpha_num +...
            P.CL_Theta2_2 * alpha_num.^2;
    end
    CDalpha = P.CD_Theta1_0 + P.CD_Theta1_1 * alpha_num +...
        P.CD_Theta1_2 * alpha_num.^2 + P.CD_Theta1_3 * alpha_num.^3 +...
        P.CD_Theta1_4 * alpha_num.^4;
    
    L = 0.5 * 1.225*  P.S_wing * CLalpha * Va^2;
    D = 0.5 * 1.225*  P.S_wing * CDalpha * Va^2;
    
    dLdalpha = 0.5 * 1.225*  P.S_wing * dCLdalpha * Va^2;
    dDalpha = 0.5 * 1.225*  P.S_wing * dCDalpha * Va^2;
    
    dtheta = cos(theta_num)*cos(alpha_num)*D-cos(theta_num)*sin(alpha_num)*L+sin(theta_num)*D*sin(alpha_num)+L*sin(theta_num)*cos(alpha_num);
    dalpha = -sin(theta_num)*sin(alpha_num)*D+sin(theta_num)*cos(alpha_num)*dDalpha-...
        sin(theta_num)*cos(alpha_num)*L-sin(theta_num)*sin(alpha_num)*dLdalpha-...
        cos(theta_num)*cos(alpha_num)*D - cos(theta_num)*sin(alpha_num)*dDalpha-...
        cos(theta_num)*cos(alpha_num)*dLdalpha+L*cos(theta_num)*sin(alpha_num);
    
    df = [dtheta;dalpha];
    
    x = [theta_num;alpha_num]-maxif*lambda*df;
    
    
    res = norm( [theta_num;alpha_num]-x);
    theta_num = min( max( x(1), theta_tau_min), theta_tau_max);
    alpha_num = max( min( x(2), alpha_max ), alpha_min );
    iter = iter + 1;
    res
end
%%
alpha = alpha_num; 
theta_t = theta_num;
% Aerodynamic Force
if alpha*180/pi <= 10
    CLalpha=P.CL_Theta1_0 + P.CL_Theta1_1 * alpha +...
        P.CL_Theta1_2 * alpha.^2 + P.CL_Theta1_3 * alpha.^3 +...
        P.CL_Theta1_4 * alpha.^4;
else
    CLalpha=P.CL_Theta2_0 + P.CL_Theta2_1 * alpha +...
        P.CL_Theta2_2 * alpha.^2;
end
CDalpha = P.CD_Theta1_0 + P.CD_Theta1_1 * alpha +...
    P.CD_Theta1_2 * alpha.^2 + P.CD_Theta1_3 * alpha.^3 +...
    P.CD_Theta1_4 * alpha.^4;

L = 0.5 * 1.225*  P.S_wing * CLalpha * Va^2;
D = 0.5 * 1.225*  P.S_wing * CDalpha * Va^2;

f_min = sin(theta_t)*cos(alpha)*D-...
    sin(theta_t)*sin(alpha)*L-...
    cos(theta_t)*sin(alpha)*D-...
    cos(theta_t)*cos(alpha)*L;
plot3( alpha*180/pi, theta_t*180/pi, f_min, '*k', 'Markersize', 20);
xlabel('AoA'); 
ylabel('Theta_{\tau}')
