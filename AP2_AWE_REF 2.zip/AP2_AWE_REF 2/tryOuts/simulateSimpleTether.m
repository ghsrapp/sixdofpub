clear all
close all
clc

p_init = [200;0;200];

T.E = 5.3*1e9; 
T.d = 0.002; 
T.epsi = 0.02;
T.Ct = 1.2;
P.mass = 40; 

sim('simple_tether');