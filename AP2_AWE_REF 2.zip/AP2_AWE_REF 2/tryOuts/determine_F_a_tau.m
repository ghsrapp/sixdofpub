syms PHI theta psi

M_BO = [cos(psi)*cos(theta), sin(psi)*cos(theta), -sin(theta); 
        cos(psi)*sin(theta)*sin(PHI)-sin(psi)*cos(PHI), sin(psi)*sin(theta)*sin(PHI)+cos(psi)*cos(PHI), cos(theta)*sin(PHI); 
        cos(psi)*sin(theta)*cos(PHI)+sin(psi)*sin(PHI), sin(psi)*sin(theta)*cos(PHI)-cos(psi)*sin(PHI), cos(theta)*cos(PHI)];
M_OB = M_BO.';

%syms windDirection_rad 
windDirection_rad = pi; 
M_WO = [-1, 0, 0;
       0, 1, 0;
        0, 0, -1];
 
syms phi lamb
M_tauW = [-sin(phi)*cos(lamb), -sin(phi)*sin(lamb), cos(phi);
    -sin(lamb), cos(lamb), 0;
    -cos(phi)*cos(lamb), -cos(phi)*sin(lamb), -sin(phi)];


syms F_a_b_x F_a_b_y F_a_b_z
F_a_B = [F_a_b_x; F_a_b_y; F_a_b_z];

F_a_tau = M_tauW * M_WO * M_OB * F_a_B;


