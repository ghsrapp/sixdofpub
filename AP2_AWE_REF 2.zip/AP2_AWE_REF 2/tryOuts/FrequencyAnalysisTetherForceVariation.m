close all
tstart0 = 20; 
tend0 = 100;

%% Sampling frequency 
%power_vr_tether.Time(tstart0/dt:tend0/dt),power_vr_tether.Data(tstart0/dt:tend0/dt,3)/1000
Fs = 1/dt; 
T = 1/Fs;
L = length( power_vr_tether.Time(tstart0/dt:tend0/dt) ); 
t = power_vr_tether.Time(tstart0/dt:tend0/dt); 
X = power_vr_tether.Data(tstart0/dt:tend0/dt,3); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;
%
figure(1); 
stem(f(2:end),P1(2:end)/max(P1(2:end))); hold on 
title('Tetherforce')
xlabel('f (Hz)')
ylabel('|P1(f)|')
axis([0 1 0 1] ); 

%% Tangential plane roll angle 
Fs = 1/dt; 
T = 1/Fs;
L = length( eta_tether.Time(tstart0/dt:tend0/dt) ); 
t = eta_tether.Time(tstart0/dt:tend0/dt); 
X = eta_tether.Data(tstart0/dt:tend0/dt,3); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;

phi_tau_f = P1(2:end)/max(P1(2:end));

figure; 
stem(f(2:end),P1(2:end)/max(P1(2:end))) 
title('Phi')
xlabel('f (Hz)')
ylabel('|P1(f)|')
axis([0 1 0 1] ); 

%% Airspeed
Fs = 1/dt; 
T = 1/Fs;
L = length( airdata.Time(tstart0/dt:tend0/dt) ); 
t = airdata.Time(tstart0/dt:tend0/dt); 
X = airdata.Data(tstart0/dt:tend0/dt,1); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;

figure(1); 
stem(f(2:end),P1(2:end)/max(P1(2:end))) 
title('Airspeed')
xlabel('f (Hz)')
ylabel('|P1(f)|')
axis([0 1 0 1] );

%%
% difference between lift and tether force tracking
F_T_ac = sqrt( F_T_B_N.Data(tstart0/dt:tend0/dt).^2+ F_T_B_N.Data(tstart0/dt:tend0/dt).^2+ F_T_B_N.Data(tstart0/dt:tend0/dt).^2) ;
lift = -0.5*1.225*P.S_wing*CL_A_save.Data(tstart0/dt:tend0/dt)'.*airdata.Data(tstart0/dt:tend0/dt).^2; 
e_tracking = F_T_ac - lift; 
Fs = 1/dt; 
T = 1/Fs;
L = length( e_tracking ); 
t = F_T_B_N.Time(tstart0/dt:tend0/dt); 
X = e_tracking; 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;

%%
figure(2); 
stem(f(2:end),P1(2:end)/max(P1(2:end))); hold on;
stem(f(2:end), phi_tau_f ); hold on;
title('Compare phiTau and e')
xlabel('f (Hz)')
ylabel('|P1(f)|')
axis([0 1 0 1] );

%%
figure; 
plot(t,abs(e_tracking)/80) ; hold on 
plot(eta_tether.Time(tstart0/dt:tend0/dt),abs(eta_tether.Data(tstart0/dt:tend0/dt,1))); 
