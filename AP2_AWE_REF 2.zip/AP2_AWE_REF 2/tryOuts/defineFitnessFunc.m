% Defined cost function: As a combination of rates, angle of attack and
% sideslip angle. 
c1 = 1; 
c2 = 1; 
c3 = 1; 
c4 = 0; 
c5 = 0; 

F =  c1 * sum( abs(airdata.Data(:,3)-0*pi/180)/max(abs(airdata.Data(:,3)-0*pi/180)) )+...
    c2 * sum( abs(airdata.Data(:,2)-10*pi/180)/max(abs(airdata.Data(:,2)-10*pi/180)) )+...
    c3 * sum( abs(omega_OB_rad.Data(:,1))/max(abs(omega_OB_rad.Data(:,1))) )+...
    c4 * sum( abs(omega_OB_rad.Data(:,2))/max(abs(omega_OB_rad.Data(:,2))) )+...
    c5 * sum( abs(omega_OB_rad.Data(:,3))/max(abs(omega_OB_rad.Data(:,3))) )+...
    c6 * sum( abs(course_tau_traction.Data(:,1)-course_tau_traction.Data(:,2))/max(course_tau_traction.Data(:,1)-course_tau_traction.Data(:,2)) );

%% plot each contribution
figure; 
plot( abs(airdata.Data(:,3)-0*pi/180)/max(abs(airdata.Data(:,3)-0*pi/180)) ); hold on 
plot( abs(airdata.Data(:,2)-10*pi/180)/max(abs(airdata.Data(:,2)-10*pi/180)) )  ; 
plot( abs(omega_OB_rad.Data(:,1))/max(abs(omega_OB_rad.Data(:,1))) ) ;
plot( abs(omega_OB_rad.Data(:,2))/max(abs(omega_OB_rad.Data(:,2))) );
plot( abs(omega_OB_rad.Data(:,3))/max(abs(omega_OB_rad.Data(:,3)))  ) ;
plot( abs(course_tau_traction.Data(:,1)-course_tau_traction.Data(:,2))/max(course_tau_traction.Data(:,1)-course_tau_traction.Data(:,2))  ) 
