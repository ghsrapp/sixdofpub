
name = 'AWE_Testbed_07';
load_system(name);
set_param(name, 'SimulationCommand','Start');
block = [name,'/clockSampled'];
rto = get_param(block, 'RuntimeObject');
time = rto.OutputPort(1).Data
sim('AWE_Testbed_07');

