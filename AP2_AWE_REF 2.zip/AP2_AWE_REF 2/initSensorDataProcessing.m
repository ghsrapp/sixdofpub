%% Airdata 
% angle of attack and sideslip angle measurements are low-pass filtered 
se_aoa_w0 = 100; 
se_sidesl_w0 = 100; 
