omegas = -60 : 0.1 : 60; 
delta_plot_1 = -a/b*sqrt( omegas.^2 + b^2 ); 
delta_plot_2 = -sqrt( R^2 - omegas.^2 ); 
figure(1); clf
plot(  delta_plot_1, omegas, 'k'); hold on 
plot( delta_plot_2, omegas, 'k'); hold on 
axis equal
drawnow
figure(2); clf; 
for mu = 1 : 2
A_cl= models.A(:,:,mu) - models.B(:,:,mu)*K*models.C(:,:,mu);            
lambdas_cl = eig( A_cl );
figure(1); 
if mu == 2
    plot( real( lambdas_cl ), imag( lambdas_cl ), 'xr')
else
   plot( real( lambdas_cl ), imag( lambdas_cl ), 'xb')
end
axis([-R 0 -R R])
figure(2); 
sys_cl = ss( A_cl, [zeros(4,1);1], [0,1,0,0,0], [] ); hold on 
step( sys_cl ); 
stepinfo( sys_cl )

end
