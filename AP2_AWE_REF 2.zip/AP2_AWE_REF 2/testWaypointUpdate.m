%% Test different tether lengts and get the corresponding waypoints 

l_tethers = linspace(150, 800, 5 ); 
close all;
FigHandle = figure(1);
grid on; hold on;
xlabel('x'); hold on;
ylabel('y'); hold on;
zlabel('z'); hold on;
view(90,latChoose*180/pi); hold on;
set(FigHandle, 'Position', [100, 100, 649, 500]);
axis([-10 800 -150 150 0 600])

fWp = 2; 
pathDiscFlag = 1; 

for l = 1 : length(l_tethers)
    switch pathDiscFlag
        case 1
            % Update the waypoints
            waypointsPath = discPathUpdateGcC( l_tethers(l), r_d, latChoose, maxWidth,fWp);
        case 2 % TO-DO: There is still a big difference between the original path and the resulting path.
            % Calculate a reference path 
            waypointsPathRef = discPathUpdateGcC( 200, r_d, latChoose, maxWidth,fWp); % just an example
            lats = asin( pathReference(:,3) / l_tethers(1) );
            lats_ = lats - mean(lats); 
            longs = atan2(  pathReference(:,2),  pathReference(:,1) );
            % Update the waypoints
            waypointsPath = discPathUpdatePointCloud( l_tethers(l), [longs, lats_,l_tethers(1)*ones(length(pathReference),1)], latChoose );
    end
    plot3(waypointsPath(:,1), waypointsPath(:,2), waypointsPath(:,3), '-+b', 'Linewidth', 0.5); hold on
    plot3([waypointsPath(end,1), waypointsPath(1,1)],[waypointsPath(end,2), waypointsPath(1,2)],[waypointsPath(end,3), waypointsPath(1,3)], '-+b', 'Linewidth', 0.5); hold on
    axis equal; hold on;
end

 latMin = 0; % Minimum latitude
        latChoose = 30*pi/180; % Choose latitude of the circle origins
        maxWidth = 90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % 15 This is the desired radius that the kite will fly