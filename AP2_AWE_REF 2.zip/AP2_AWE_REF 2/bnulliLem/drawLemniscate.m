l_tether = 300; 
s = 0 : 0.01 : 2*pi;
%a = a/l_tether; 
long = Lem.a*sqrt(2) * cos(s) ./ (sin(s).^2+1);
lat = Lem.a*sqrt(2) * cos(s) .* sin(s) ./  (sin(s).^2+1)  + Lem.phi0;


%% transform into cartesian coordinates 
p = [ cos(long).*cos(lat);
      sin(long).*cos(lat);
      sin(lat)];


plot3(p(1,:), p(2,:), p(3,:) ); hold on 
axis equal
