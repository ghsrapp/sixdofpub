function [t,DtDs,L, dLds,q] = getLemniscateInfos(s_old,Lem, direction)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes her
% calculate the tangent at the solution and its derivative
% -1: down in the middle
a = Lem.a; 

L = [ a*sqrt(2) * cos(s_old) ./ (sin(s_old).^2+1);
    a*sqrt(2) * cos(s_old) .* sin(s_old) ./  (sin(s_old).^2+1) + Lem.phi0];  
%dLds = [ -a*sqrt(2)*sin(s_old)/(sin(s_old)^2+1)^2 * (2+cos(s_old)^2);...
       % a*sqrt(2)/(sin(s_old)^2+1)^2 * (-3*sin(s_old)^2 + 1)];
dLds = [sqrt(2)*a*sin(s_old) * (sin(s_old)^2 - 3) / (sin(s_old)^2+1)^2; ...
       sqrt(2)*a*(3*cos(s_old)^2 - 2) / (cos(s_old)^2-2)^2];
    
d2Lds2 =  [ sqrt(2)*a*cos(s_old)*(10*cos(s_old)^2+cos(s_old)^4-8)/(cos(s_old)^2-2)^3;...
            sqrt(2)*a*(sin(2*s_old)*14+cos(2*s_old)*sin(2*s_old)*6)*2/(cos(2*s_old)-3)^3];
 %-(sqrt(2)*a*(sin(2*s_old)*14 + sin(4*s_old)*3))/(4*(sin(s_old)^2 + 1)^3)];
%     
s_lambda = sin( L(1,:)  ); 
s_phi = sin( L(2,:) );
c_lambda = cos( L(1,:) ); 
c_phi = cos( L(2,:) ); 

q = [c_lambda*c_phi; s_lambda*c_phi; s_phi];

dqdlambda = [-s_lambda*c_phi; c_lambda*c_phi; 0];
dqdphi = [-c_lambda*s_phi; -s_lambda*s_phi; c_phi];

t = direction*( dqdlambda * dLds(1) + dqdphi *dLds(2) ); 

dtdlambda = [-c_lambda*c_phi*dLds(1)+s_lambda*s_phi*dLds(2); 
             -s_lambda*c_phi*dLds(1)-s_phi*c_lambda*dLds(2);
            0];
        
dtdphi = [s_lambda*s_phi*dLds(1)-c_phi*c_lambda*dLds(2); 
         -c_lambda*s_phi*dLds(1)-c_phi*s_lambda*dLds(2); 
         -s_phi*dLds(2)];
     
dtds = dqdlambda * d2Lds2(1)  + dqdphi * d2Lds2(2); 
     
% The negative sign cancels out 
DtDs =  ( dtdlambda * dLds(1) + dtdphi * dLds(2) + dtds ); 



end

