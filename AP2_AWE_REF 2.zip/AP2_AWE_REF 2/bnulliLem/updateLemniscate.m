function [Lem] = updateLemniscate(l_tether,LemRef)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
Lem.a = LemRef.a/l_tether;
Lem.phi0 = LemRef.phi0;
end

