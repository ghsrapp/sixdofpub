LemRef.a = 70; 
LemRef.phi0 = 30*pi/180;