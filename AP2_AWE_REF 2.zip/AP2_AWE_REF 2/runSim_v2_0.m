init_new;
TSIM = 160; 

%% load (optimized) parameters
load('paramStruct.mat');

%% make changes to parameters
allocateStruct2SimVariables;

assignin('base','w0_mu_traction',0.3*w0_p_traction);
assignin('base','w0_alpha_traction',0.3*w0_q_traction);
assignin('base','w0_beta_traction',0.1*w0_r_traction);

assignin('base','Kp_mu_traction', 10);
assignin('base','Kp_alpha_traction', 15);
assignin('base','Kp_beta_traction',2);
assignin('base','Ki_mu_traction',0.1);
assignin('base','Ki_alpha_traction',0.5);
assignin('base','Ki_beta_traction',0.1);
assignin('base','a_booth',0.7); %0.7;
assignin('base','b_booth',250);% 90/100;
assignin('base','phi0_booth',paramStruct.phi0_booth);
assignin('base','F_T_traction_set',1700);

assignin('base','Kp_p_traction',10);
assignin('base','Kp_q_traction',10);
assignin('base','Kp_r_traction',10);
assignin('base','Ki_p_traction',1);
assignin('base','Ki_q_traction',1);
assignin('base','Ki_r_traction',1);

assignin('base','Kp_chi_tau_traction', 0.5);
assignin('base','Ki_chi_tau_traction', 0.01 );

assignin('base','Kp_gamma_tau_traction',  0.01 );
assignin('base','Ki_gamma_tau_traction',   0.01 );

assignin('base','Kp_chi_tau_trans',  0.1  );
assignin('base','Kp_gamma_tau_trans',  0.1  );


createParamStruct;

Lbooth.a = a_booth*b_booth;
Lbooth.b = b_booth;
Lbooth.phi0 = phi0_booth;

% Simulate
sim('testAWE_Testbed_opt4b');

%% Visualize
assignin('base', 'visualization_stuff', visualization_stuff );
addpath('Visualization_Offline');
sim('visualize_offline_v2');
rmpath('Visualization_Offline\');

%% print some results + high level set points
clc
disp(['Mean power output: ', num2str(mean( power_vr_tether.Data(:,1))/1000), ' kW' ]);
disp(['Tether force set point: ', num2str( F_T_traction_set), ' N' ]);
disp(['Mean elevation angle: ', num2str(phi0_booth*180/pi), ' degrees' ]);
disp(['path height: ', num2str(a_booth*b_booth), ' m' ]);
disp(['path width: ', num2str(b_booth), '  m' ]);