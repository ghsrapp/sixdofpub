

addpath('Flightpaths');
addpath('Flightpaths/new_lissajous_fig_following/');
addpath('TetherModel');
addpath('windfield');
addpath('boothLem');

P.AP_Ts = 0.01; 

l_tether = 400; 

initBoothLem;
initRetractionParameters;
delay_g2k = 0.1;
delay_k2g = delay_g2k;
windDirection_rad = pi;
initAP2_ModelParameters;
sensorsInit;
constraints;%
tether_parameters;
nav_init;
initActuatorModels;
Environment;
initBusObjects;
sensorDataProcessingInit;

% AIRCRAFT STATE INITIALIZATION
pos_O_init = [-200,0,-250];
vel_B_init = [20;0;0];zeros(3,1);
eta_init = [0;0;0];
tether_inital_lenght = norm( pos_O_init)+1;
M_OW = [-1, 0, 0; 0, 1, 0; 0, 0, -1]; M_WO = M_OW; % downwind is south
pos_W_init = transformFromOtoW(windDirection_rad, pos_O_init');
long_init = atan2( pos_W_init(2), pos_W_init(1) );
lat_init = asin( pos_W_init(3)/norm(pos_W_init) );

initWinch;
Tether_Particles_Init;
milspec_windmodel_flag = 1;
stationaryWindfieldFlag = 0;

if ~milspec_windmodel_flag
    exportWindDataFlag = 0;
    cd 'windfield'
    initWindfieldThomas;
    cd ..
end
dt = 0.00025; % Step size Simulink
initTuningParameters;
maxBandwidth = aileron.w0;
numbPumpCycles = 1;
pumpCycSucc = 0; % will be set to one if kite was flying numbPumpCycles

