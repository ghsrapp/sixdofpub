close all

figure(1);


lat_op = lat;

M_rot = [cos(lat), 0, -sin(lat);
    0, 1, 0;
    sin(lat), 0, cos(lat)];

% 1: Bernoulli 2: Lemniscate
if 1
    % Choose same a_star as in the simulation
    LEMNISCATE.a_star = 60; % distance between the foci of the figure the kite is following independent on the tether length
    LEMNISCATE.t = linspace(0, 2*pi, 100);

    tetherLtest = 2000;160;
    % Adapt the path on the unit sphere
    a  = LEMNISCATE.a_star/tetherLtest;
    long_vec = ( a * sqrt(2) * cos(LEMNISCATE.t) ) ./ (sin(LEMNISCATE.t).^2 + 1) ;
    lat_vec = ( a * sqrt(2) * cos(LEMNISCATE.t) .* sin(LEMNISCATE.t) ) ./ (sin(LEMNISCATE.t).^2 + 1) ;
    [val, wp_idx_init] = min( long_vec(  long_vec > 0 ) );
    %wp_idx_init = wp_idx_init + 1;
    lemniscate_W = [cos(long_vec).*cos(lat_vec);
        sin(long_vec).*cos(lat_vec);
        sin(lat_vec)];
    lemniscate_W = lemniscate_W' * M_rot';
    lemniscate_W(end,:) = [];
    
    % Now calculate the figure at tether lenght
    lemniscate_W_real = lemniscate_W * tetherLtest;
    plot3( lemniscate_W_real(:,1),  lemniscate_W_real(:,2), lemniscate_W_real(:,3), '--o', 'color', [0.5, 0.5, 0.5], 'Linewidth',2); hold on
    plot3( [lemniscate_W_real(1,1) lemniscate_W_real(end,1)], [lemniscate_W_real(1,2) lemniscate_W_real(end,2)], [lemniscate_W_real(1,3) lemniscate_W_real(end,3)], '--o', 'color', [0.5, 0.5, 0.5],'Linewidth', 2); hold on
    plot3( lemniscate_W_real(wp_idx_init,1),lemniscate_W_real(wp_idx_init,2),lemniscate_W_real(wp_idx_init,3), '*g');
    axis equal; 
else
    %% Alternatives: E.g. Lemniscate parameterization -> in this form the width and the height can be set
    close all;
    alem = 1;
    blem = alem*2;
    LEMNISCATE.AStar = 60;  LEMNISCATE.BStar = 20;  % A is the desired width, B is the desired height
    
    close all
    LEMNISCATE.t = linspace(2*pi, 0, 100);
    
    wp_idx_init = 1;
    
    figure(1);
    tetherLtest = 10000;
    A = LEMNISCATE.AStar/tetherLtest;
    B = LEMNISCATE.BStar/tetherLtest;
    long_vec = A * sin( alem * LEMNISCATE.t ) ;
    lat_vec = B * sin( blem * LEMNISCATE.t );
    
    lemniscate_W = [cos(long_vec).*cos(lat_vec);
        sin(long_vec).*cos(lat_vec);
        sin(lat_vec)];
    lemniscate_W_tmp = lemniscate_W' * M_rot';
    lemniscate_W = lemniscate_W_tmp(1:end-1,:);
    %figure(9)
    %plot3( lemniscate_W(:,1),  lemniscate_W(:,2), lemniscate_W(:,3), '--o', 'color', [0.5, 0.5, 0.5], 'Linewidth',2); hold on
    
    
    % Up or Down fig 8
    midUpFlag = 0;
    if midUpFlag
        lemniscate_W = flip(lemniscate_W);
    end
    
    % Now calculate the figure at tether lenght
    lemniscate_W_real = lemniscate_W * tetherLtest;
    plot3( lemniscate_W_real(:,1),  lemniscate_W_real(:,2), lemniscate_W_real(:,3), '-', 'color', [0.5, 0.5, 0.5], 'Linewidth',2); hold on
    plot3( [lemniscate_W_real(1,1) lemniscate_W_real(end,1)], [lemniscate_W_real(1,2) lemniscate_W_real(end,2)], [lemniscate_W_real(1,3) lemniscate_W_real(end,3)], '-', 'color', [0.5, 0.5, 0.5],'Linewidth', 2); hold on
    axis equal;
   % plot3( lemniscate_W_real(wp_idx_init,1),lemniscate_W_real(wp_idx_init,2),lemniscate_W_real(wp_idx_init,3), '*g');
    
end

