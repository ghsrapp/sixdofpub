function simIn =  initAllStructs2(x0_trim, u0_trim, x0_trim_retract, u0_trim_retract, x0_sim,u0_sim, act, aeroModel, base_windspeed, constr,...
    ENVMT, P_AP2, simInit, T, winchParameter,params,Airframe_Output_Bus_Elements, K_long, K_lat, K_long_retract, K_lat_retract, random_seed, name_simulink_model)

simIn = Simulink.SimulationInput(name_simulink_model);

simIn = simIn.setVariable('params',params,'Workspace',name_simulink_model);
simIn = simIn.setVariable('act',act,'Workspace',name_simulink_model);
simIn = simIn.setVariable('constr',constr,'Workspace',name_simulink_model);
simIn = simIn.setVariable('ENVMT',ENVMT,'Workspace',name_simulink_model);
simIn = simIn.setVariable('P_AP2',P_AP2,'Workspace',name_simulink_model);
simIn = simIn.setVariable('simInit',simInit,'Workspace',name_simulink_model);
simIn = simIn.setVariable('T',T,'Workspace',name_simulink_model);
simIn = simIn.setVariable('winchParameter',winchParameter,'Workspace',name_simulink_model);
simIn = simIn.setVariable('base_windspeed',base_windspeed,'Workspace',name_simulink_model);
simIn = simIn.setVariable('Airframe_Output_Bus_Elements',Airframe_Output_Bus_Elements,'Workspace',name_simulink_model);
simIn = simIn.setVariable('aeroModel',aeroModel,'Workspace',name_simulink_model);
simIn = simIn.setVariable('x0_trim',x0_trim,'Workspace',name_simulink_model);
simIn = simIn.setVariable('u0_trim',u0_trim,'Workspace',name_simulink_model);
simIn = simIn.setVariable('x0_trim_retract',x0_trim_retract,'Workspace',name_simulink_model);
simIn = simIn.setVariable('u0_trim_retract',u0_trim_retract,'Workspace',name_simulink_model);
simIn = simIn.setVariable('x0_sim',x0_sim,'Workspace',name_simulink_model);
simIn = simIn.setVariable('u0_sim',u0_sim,'Workspace',name_simulink_model);

simIn = simIn.setVariable('K_long',K_long,'Workspace',name_simulink_model);
simIn = simIn.setVariable('K_lat',K_lat,'Workspace',name_simulink_model);
simIn = simIn.setVariable('K_long_retract',K_long_retract,'Workspace',name_simulink_model);
simIn = simIn.setVariable('K_lat_retract',K_lat_retract,'Workspace',name_simulink_model);

simIn = simIn.setVariable('random_seed',random_seed,'Workspace',name_simulink_model);

end