function [G_dFt_to_alphac, G_dFt_to_alphac_unc, So, To, gm, ph ] = getTransferfunctionFromFt_to_alphac( path2models, sim_with_indx_vec, K_long )


load([path2models,'/G_save.mat']);

for k = 1 : length( sim_with_indx_vec )
    ii = sim_with_indx_vec(k);
    
    A = G_save{ii}.A(1:9, 1:9);
    B = G_save{ii}.B(1:9, 1:4);
    A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
        A(3,1), A(3,3), A(3, 5), A(3,8);
        A(5,1), A(5,3), A(5, 5), A(5,8);
        A(8,1), A(8,3), A(8, 5), A(8,8)];
    B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
    C = [0,1,0,0];
    A_long_aug(:,:,k) = [A_long, zeros(4,1);
        -C, 0];
    B_long_aug(:,:,k) = [B_long; 0];
    C_long_aug(:,:,k) = eye( size( A_long_aug, 1) ); 

    G_aug = ss( A_long_aug, B_long_aug, C_long_aug, [] ); 
    Li = K_long*G_aug; 
    [gm,ph] = margin( Li ); 
   % gm_save(k) = gm;
   % ph_save(k) = ph;
    
    dFt_max = 1; % for scaling
    E_long = [B(1,4);B(3,4);B(5,4);B(8,4)]*dFt_max;
   % E_prime = ( ( B_long'*B_long )\B_long' )*E_long; 

    Kp = K_long(1:end-1); 
    s = tf('s');
    Ki = -K_long(end)/s; 
    C_cl = [0,1,0,0]; 
    A_cl = A_long - B_long*Kp; 
    B_cl = B_long; 
    G_prime = ss( A_cl, B_cl, C_cl, [] ); 
   
    Gd =  C_cl * 1/(s*eye( size(A_cl,1) ) - A_cl )*E_long; 
    
    Lo = G_prime * Ki; 
    So{k} = 1/(1+G_prime*Ki); 
    To{k} = 1 - So{k}; 
    
    G_dFt_to_alphac{k} =  So{k}*Gd; 
    C_cl = [0,1,0,0]; 
    G_dFt_to_alphac_unc{k} = ss( A_long, E_long, C_cl, [] ); 
end


