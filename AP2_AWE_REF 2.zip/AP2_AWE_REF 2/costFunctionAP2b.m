function cost = costFunctionAP2b(x, max_bandwidth,pumpCycSucc, gs, alpha_a_max,TSIM )%COSTFUNCTION Summary of this function goes here
%   Detailed explanation goes her
assignOptVariables2SimWorkspace2(max_bandwidth,x);

% simulate
% disp(['Height path: ', num2str(x(19)*x(20)),...
%     ' | Width path: ', num2str(x(20)), ' | Mean elevation path: ', num2str(x(21)),...
%     ' | Tether force: ', num2str(x(22))]);
assignin('base', 'TSIM', TSIM );
simOut = sim('optAWE_Testbed_light', 'CaptureErrors','on');
cost = 0; 
if ~simOut.pumpCycSucc % high penalty if specified number of PC couldnt be reached (e.g. due to crash)
    cost = 1e15/simOut.sim_time(end) ;
    disp(['Current cost: ', num2str(cost)]);
else
    % Control performance related cost 
    cost = 20*pi/180*norm( simOut.alpha_a_save.Data(:,1) - simOut.alpha_a_save.Data(:,3) )+...
        10*pi/180*norm( simOut.beta_a_save.Data(:,1) - simOut.beta_a_save.Data(:,3) ) +...
        norm( simOut.course_tau_traction.Data(:,2) - simOut.course_tau_traction.Data(:,1) ) +...
        5*norm(simOut.delta_a_meas.Data) + ...
        5*norm(simOut.delta_e_meas.Data) + ...
        5*norm(simOut.delta_r_meas.Data) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,1)/max(simOut.omega_OB_rad.Data(:,1)) ) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,2)/max(simOut.omega_OB_rad.Data(:,2)) ) + ...
        0.5*norm(simOut.omega_OB_rad.Data(:,3)/max(simOut.omega_OB_rad.Data(:,3)) ) + ...
        norm( x(22)  - simOut.power_vr_tether.Data(:,3) )/1000;
    
    % Penalize additionally if sim violates certain constraints
    if max( simOut.power_vr_tether.Data(:,3) ) > gs.F_T_max
        cost = cost + abs(max( simOut.power_vr_tether.Data(:,3) ) - gs.F_T_max); 
    end
    
    if max( simOut.alpha_a_save.Data(:,3) ) > alpha_a_max*180/pi
        cost = cost + 0.1*cost*abs( max( simOut.alpha_a_save.Data(:,3) ) - alpha_a_max*180/pi);
    end
    
    % improve cost by generated power but only if the specified number of PC was achieved. 
    mean_power = mean( simOut.power_vr_tether.Data(:,1) );
    cost = cost - mean_power;
    disp(['Current cost: ', num2str(cost)]);
end

end

