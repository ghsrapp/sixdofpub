mu_a_max = 80*pi/180; 
mu_a_min = -80*pi/180; 
alpha_a_max = 9*pi/180; 
alpha_a_min = -6*pi/180; 

mu_a_max_retraction = 20*pi/180; 
mu_a_min_retraction = -20*pi/180; 


mu_k_max = mu_a_max; 
alpha_k_max = alpha_a_max; 

alpha_a_star = 5 * pi/180;

phi_tau_max = 80*pi/180; 
theta_tau_max = 80*pi/180;

max_rates_B = 50*pi/180;

% max winch acceleratin in m/s^2
winchParameter.a_max = 3;
winchParameter.a_min = -3;
% max winch velocity in m/s
winchParameter.v_max = 20;
winchParameter.v_min = -15;

% tether
gs.F_T_max = 1800; % 2000 with the opt. parameters

