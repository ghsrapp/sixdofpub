init_new;
sim('AWE_Testbed_07');

sim('visualize_offline_v2');

plotFlag = 1;
time_vec = wind_save.Time;
if plotFlag
    figure;
    plot( time_vec, wind_save.Data );
    
    legend('v_{w,x,W}', 'v_{w,y,W}', 'v_{w,z,W}');
    set(gca,'TickLabelInterpreter','latex')
end