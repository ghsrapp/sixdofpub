% In this script all tuning parameters that are required for the control of
% ground station as well as the flight controller are defined in this
% script.           

%%====================== State Machine / High level control ======================
% minimum tether length
sm.l_tether_min = 250; 
% maximum tether length
sm.l_tether_max = 700 ; 
% Elevation angle increment added to mean elevation angle of the "ref.
% path" that if passed triggers retraction 
sm.dlat_retraction= -0.5; 
%sm.dlat_kite_trigger = -0.5; 
% maximum elevation angle 
sm.lat_max = 70; 
% Elevation angle increment added added to the WP4 waypoint of the reference path that
% triggers the transition into traction mode
%sm.dlat_transition = 1;
sm.dlat_transition = 10;15; 
% Airspeed that triggers the transition from VTOL to KITE mode 
sm.va_min = 10; 
% Longitude increment added to the WP4 waypoint of the reference path that
% triggers the transition into traction mode. 
sm.dlong_transition = 1; % 1 was working!
% Latitude angle that triggers traction phase controller.
sm.lat_trans_traction  = 40;

%%====================== Ground Station ======================

% Retraction velocity 
gs.va_retract_1 = -5; % -10 was for the "old" lissajous following 
gs.va_retract = -25;%-15;
% Reelin-velocity from VTOL to Kite mode
gs.vr_vtol2kite = -5; 
% max. tether force
% hystersis
gs.hysteresis = 500; 
% Tether force setpoint 
gs.F_T_set_traction = 1200; % 1200
gs.F_T_set_retraction = 100; 
% min. tether force
gs.F_T_min_traction = 100; % delta term
gs.F_T_min_retraction = 0; 
% Incremental change of v_r
gs.v_r_increment = 0.5; 
% numbers of figure 8 until v_r is adatped
gs.numbFig8Ad = 0.5; 
% Fixed reel out speed if tether force exceeds maximum value 
gs.v_ro_fix = 10; 
% Fixed reel in speed if tether force drops below a certain value 
gs.v_ri_fix = -6; 
% Deadzone smoothing factor (deadzone = no change of reeling speed, improve robustness by sacrificing steady state performance)
gs.dz_smoothing = 0.5; 
% Deadzone start value 
gs.dz_start = 50;
% Number of figures 8 until average tether force is adapted 
gs.numbFig8UpdateRate = 0.5; 

% force set point adaption 
gs.maxCounterTime = 10; % in seconds

%%%%====================== Flight Control %%=======================================
% Angle of attack during traction phase 
FCS.AoA_Traction = 6; % deg

%w0_ftset_filters = 0.25; 
