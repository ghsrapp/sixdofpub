function margins = getRobStabMargin_2( A_save, B_save, K, C )

% This is overly conservative! For the robustness check across the envelope
% one cannot vary the element independently. They are dependent. 
lower_bound_A = min( A_save, [], 3 ); 
upper_bound_A = max( A_save, [], 3 ); 

lower_bound_B = min( B_save, [], 3 ); 
upper_bound_B = max( B_save, [], 3 ); 

mean_A = mean( A_save, 3);
mean_B = mean( B_save, 3);

for r = 1 : size( lower_bound_A, 1 )
    for c = 1 : size( lower_bound_A, 2)
        if abs( lower_bound_A(r,c) - upper_bound_A(r,c) ) < 1e-6
            A_unc(r,c) = mean_A(r,c);
        else
            A_unc(r,c) = ureal(['A_',num2str(r),num2str(c)], mean_A(r,c) ,'Range',[lower_bound_A(r,c), upper_bound_A(r,c)]);
        end
    end
end

for r = 1 : size( lower_bound_B, 1 )
    for c = 1 : size( lower_bound_B, 2)
        if abs( lower_bound_B(r,c) - upper_bound_B(r,c) ) < 1e-6
            B_unc(r,c) = mean_B(r,c);
        else
            B_unc(r,c) = ureal(['B_',num2str(r),num2str(c)], mean_B(r,c) ,'Range',[lower_bound_B(r,c), upper_bound_B(r,c)]);
        end
    end
end


G_unc = ss( A_unc, B_unc,C, zeros( size( C, 1), size( B_unc, 2)) ); 
L = G_unc*K; 
CL = feedback(G_unc*K, eye(5) );

[stabmarg,wcu] = robstab(CL);
