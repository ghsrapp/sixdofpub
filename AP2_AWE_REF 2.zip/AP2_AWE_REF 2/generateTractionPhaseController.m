function [x0_trim,u0_trim,K_long,K_lat, A_long_aug, B_long_aug, A_lat_aug, B_lat_aug] =  generateTractionPhaseController( sim_with_indx, EA_Flag, act, path_with_gains, Qs_long, Rs_long )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;
save_flag = 0;

% path_with_gains = 'Trim_results/case_1_test03';
%addpath(path_with_gains);

load([path_with_gains,'/G_save.mat']);
load([path_with_gains,'/rps_st.mat']);
load([path_with_gains,'/x0_save.mat']);
load([path_with_gains,'/u0_save.mat']);
load([path_with_gains,'/M_OB_init.mat']);

%[K_lat, K_long, A_tot, B_tot, Ks, A_long_aug, A_lat, B_long_aug, B_lat, B_long_wFt, Mx, Mu, A_lat_aug, B_lat_aug] = lqr_w_psi_wVa_test_decoupled(G_save{sim_with_indx}, act);
% Longitudinal controller
A = G_save{sim_with_indx}.A(1:9, 1:9);
B = G_save{sim_with_indx}.B(1:9, 1:4);
A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
          A(3,1), A(3,3), A(3, 5), A(3,8);
          A(5,1), A(5,3), A(5, 5), A(5,8);
          A(8,1), A(8,3), A(8, 5), A(8,8)];
B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
C = [0,1,0,0];
A_long_aug = [A_long, zeros(4,1);
            -C, 0];
B_long_aug = [B_long; 0];

%% Standard LQR
K_long = lqr( A_long_aug, B_long_aug, Qs_long, Rs_long );
%% 


%[K_lat] = EA_lateralDynamics(G_save{sim_with_indx});
if EA_Flag
    [K_lat, A_lat_aug, B_lat_aug] = EA_lateralDynamics( G_save{sim_with_indx},act );
    %if x0_save(1,sim_with_indx)<26
    if 0 % longitudinale dynamics are controlled with LQR-PI 
        [K_long, A_long_aug, B_long_aug] = EA_longDynamics( G_save{sim_with_indx},act );
    end
%else
     %   [K_long, A_long_aug, B_long_aug]  = EA_longDynamics_HighVa( G_save{sim_with_indx},act );
   % end
    A_lat_cl = A_lat_aug - B_lat_aug * K_lat;
    B_lat_cl = B_lat_aug.*0;
    B_lat_cl(end-1, 1) = 1;
    B_lat_cl(end,2) = 1;
    sys_beta = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0;0,1,0,0,0,0], [] );
    sys_phi = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0;0,1,0,0,0,0], [] );
    tvec = 0 : 0.1 : 12;
   
    opt = stepDataOptions;
    opt.StepAmplitude = 10*pi/180;
    %% BETA
    [y,t] = step(sys_beta,tvec,opt);
   % h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( t, y(:,1,1)*180/pi, 'Linewidth', lw, 'color', col1); hold on
    plot( t, y(:,2,1)*180/pi, 'Linewidth', lw, 'color', col3); hold on
    plot( t(:,:,1), t(:,:,1)./t(:,:,1)*10, '--', 'Linewidth', lw, 'color', col2); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$\beta_a$ $(deg)$');
    axis([0 6 -1 11]);
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h1,'step_response_EA_beta');
        cd ..
    end
    %% PHI
    [y,t] = step(sys_phi,tvec,opt);
    %h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    plot( t, y(:,2,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on
    plot( t, y(:,1,2)*180/pi, 'Linewidth', lw, 'color', col1); hold on
    plot( t, t./t*10, '--', 'Linewidth', lw, 'color', col2); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$\Phi_{\tau}$ $(deg)$');
    axis([0 6 -1 11]);
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h2,'step_response_EA_phi');
        cd ..
    end
   
   
else
    %% Some step responses of the lateral controller
    A_lat_cl = A_lat_aug - B_lat_aug * K_lat;
    B_lat_cl = B_lat_aug.*0;
    B_lat_cl(end-1, 1) = 1;
    B_lat_cl(end,2) = 1;
    sys_beta = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0], [] );
    sys_phi = ss( A_lat_cl, B_lat_cl, [0,1,0,0,0,0], [] );
    tvec = 0 : 0.1 : 12;
    G_lat_cl = ss( A_lat_cl, B_lat_cl, eye( size(A_lat_cl, 1) ), zeros(size(A_lat_cl, 1), 2) ); 
    fprintf('Lateral closed loop system: \n'); 
    damp(G_lat_cl)
    opt = stepDataOptions;
    opt.StepAmplitude = 10*pi/180;
    %% BETA
    [y,t] = step(sys_beta,tvec,opt);
   % h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    figure(1);
    plot( t, y(:,:,1)*180/pi, 'Linewidth', lw, 'color', col2); hold on
    plot( t, t(:,:,1)./t*10, 'Linewidth', lw, 'color', col1, '--'); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$\beta_a$ $(deg)$');
    axis([0 6 0 12]);
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h1,'step_response_EA_beta');
        cd ..
    end
    %% PHI
    [y,t] = step(sys_phi,tvec,opt);
    %h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    figure(2);
    plot( t, y(:,:,2)*180/pi, 'Linewidth', lw, 'color', col2); hold on
    plot( t, t./t*10, 'Linewidth', lw, 'color', col1, '--'); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$\Phi_tau$ $(deg)$');
    axis([0 6 0 12]);
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h1,'step_response_EA_phi');
        cd ..
    end
end
% Q = 0*eye(5);
% Q(1,1) = 0;
% Q(2,2) = 11;%11; %11;
% Q(3,3) = 0;
% Q(4,4) = 0.2;%0.2;%0.2;
% Q(5,5) = 10; 10;
% 
% 
% Q = 0*eye(5);
% Q(1,1) = 0;
% Q(2,2) = 30;%5;
% Q(3,3) = 0;
% Q(4,4) = 0;
% Q(5,5) = 50;  % 100
% 
% R = 1;
%if ~EA_Flag
   % [HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = test_simple_piecewise_L1_aug(A_long_aug,B_long_aug, Q, R);
   % K_long = Kbl;

   A_long_cl = A_long_aug - B_long_aug*K_long;
   B_long_cl = zeros(5,1);
   B_long_cl(5) = 1;
   
   sys = ss( A_long_cl, B_long_cl, [0,1,0,0,0], [] );
   tvec = 0 : 0.1 : 12;
   opt = stepDataOptions;
   opt.StepAmplitude = 10*pi/180;
   [y,t] = step(sys, tvec, opt);

%     figure(3);
%     %h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%     plot( t, y*180/pi, 'Linewidth', lw, 'color', col2); hold on
%     plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
%     xlabel('$Time$ $(s)$');
%     ylabel('$\alpha_a$ $(deg)$');
%     axis([0 12 0 12]);
%     %damp(Am);
%else
 %   [HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = piecewise_L1_aug_with_EA(A_long_aug, B_long_aug, K_long) ;
%end
%%
% if save_flag
%     cd('Trim_results/');
%     Plot2LaTeX(h1,'step_response_LQRI');
%     cd ..
% end

% Trim states and inputs
x0_trim = x0_save(:,sim_with_indx);
u0_trim = u0_save(:,sim_with_indx);

