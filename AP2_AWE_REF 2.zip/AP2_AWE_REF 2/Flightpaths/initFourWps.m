

% nominalF
FourWpConfig.d_nom_wps = 120;
FourWpConfig.h_nom_wps = 40;
FourWpConfig.h_nom_wps = 30;

l_init = 650;


wp_lat_mean = 30*pi/180;

FourWpConfig.dlong = 1*pi/180;
FourWpConfig.dlat = 1*pi/180;
FourWpConfig.wp_lat_mean= 30*pi/180;
FourWpConfig.exp_avg_const = 0.99;

cnt = 2;

l=l_init;
[wp_W_list] = update4WpList(l, FourWpConfig);
wp_plot = wp_W_list * l;

%%
% max latitude 
FourWpConfig.max_lat = asin( wp_W_list(3,3)/ norm(wp_W_list(3,:) ) );
% min latitude
FourWpConfig.min_lat = asin( wp_W_list(1,3)/ norm(wp_W_list(1,:) ) );
% max longitude
FourWpConfig.max_long = atan2( wp_W_list(1,2),norm(wp_W_list(1,1) ) )*180/pi;

