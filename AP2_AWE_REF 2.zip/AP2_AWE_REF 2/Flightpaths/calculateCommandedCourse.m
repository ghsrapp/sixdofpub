function [Chi_cmd,Delta_chi] = calculateCommandedCourse(t,delta_vec, delta, delta0, chi_K_des, L_sol, pos_W)
%CALCULATEDESIREDCOURSE Summary of this function goes here
%   Detailed explanation goes here

% check sign with curve frame - y component is negative in this frame -
% delta Chi is positive and vice versa.
% add a predictive part to smooth highly curved paths. 
% basis:
e1 = t/norm(t);
e3 = -L_sol/norm(L_sol);
e2 = cross(e3, e1);
M_CW = [e1';e2';e3'];
pos_C = M_CW * (pos_W-L_sol);

% Step 2: Calculate distance to closest point
%delta = acos( min( max( x_K'/norm(x_K) * p_C_W/norm(p_C_W), -1),1 ) ) * norm(x_K);
%delta = abs(pos_C(2));

%Delta_chi = atan2( -sign(L_sol' * cross( t, delta_vec  )) * delta , delta0 );
Delta_chi = atan2( -sign(pos_C(2)) * delta , delta0 );
%end

Chi_cmd = chi_K_des + Delta_chi;

if Chi_cmd > pi
    Chi_cmd = -pi + mod( Chi_cmd, pi );
elseif Chi_cmd < -pi
    Chi_cmd = pi + mod(Chi_cmd, -pi);
end




end

