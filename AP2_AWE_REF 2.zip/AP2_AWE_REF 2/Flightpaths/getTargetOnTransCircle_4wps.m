function [pos_target_W, sol] = getTargetOnTransCircle_4wps( pos_W, transCircle,radius )

pos_C = transCircle.M_CW * pos_W;
pos_C_proj = pos_C; 
pos_C_proj(3) = 0;
pos_C_proj_2 = pos_C_proj/norm(pos_C_proj)*radius;
da = 1*pi/180;
M_rot = [cos(da), sin(da), 0; 
    -sin(da), cos(da), 0; 
    0, 0, 1];

pos_C_proj_2_rot = M_rot * pos_C_proj_2; 

sol = atan2(pos_C_proj_2_rot(2),pos_C_proj_2_rot(1));

angle_max = pi/2;

if sol > angle_max
    target_C = [cos(angle_max); sin(angle_max); 0 ]*radius;
    pos_target_W = transCircle.M_CW'*target_C;
else
    pos_target_W = transCircle.M_CW'*pos_C_proj_2_rot;
end

