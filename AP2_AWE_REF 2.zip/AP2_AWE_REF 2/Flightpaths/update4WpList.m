function [wp_W_list] = update4WpList(l, FourWpConfig)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here



wp_low_lat = FourWpConfig.wp_lat_mean - asin( FourWpConfig.h_nom_wps / 2 / l ); 
wp_high_lat = FourWpConfig.wp_lat_mean + asin( FourWpConfig.h_nom_wps / 2 / l ); 

wp1_long = asin(FourWpConfig.d_nom_wps/(2*l*cos(wp_low_lat))); 
wp3_long = asin(FourWpConfig.d_nom_wps/(2*l*cos(wp_high_lat))); 

wp1_W = [cos(wp_low_lat)*cos(wp1_long);
         cos(wp_low_lat)*sin(wp1_long); 
         sin(wp_low_lat)];
     
wp2_W = [cos(wp_low_lat)*cos(-wp1_long);
         cos(wp_low_lat)*sin(-wp1_long); 
         sin(wp_low_lat)];
  
wp3_W = [cos(wp_high_lat)*cos(wp3_long);
         cos(wp_high_lat)*sin(wp3_long); 
         sin(wp_high_lat)];
     
wp4_W = [cos(wp_high_lat)*cos(-wp3_long);
         cos(wp_high_lat)*sin(-wp3_long); 
         sin(wp_high_lat)];     
     
    
wp_W_list = [wp1_W'; wp2_W'; wp3_W'; wp4_W'];

end

