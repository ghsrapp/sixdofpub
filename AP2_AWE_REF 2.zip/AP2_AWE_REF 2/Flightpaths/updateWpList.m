function [wp_W_list] = updateWpList(l, wp1_lat, d)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

wp1_long = asin(d/(2*l*cos(wp1_lat))); 

wp1_W = [cos(wp1_lat)*cos(wp1_long);
         cos(wp1_lat)*sin(wp1_long); 
         sin(wp1_lat)];
     
wp2_W = [cos(wp1_lat)*cos(-wp1_long);
         cos(wp1_lat)*sin(-wp1_long); 
         sin(wp1_lat)];
     
    
wp_W_list = [wp1_W'; wp2_W'];

end

