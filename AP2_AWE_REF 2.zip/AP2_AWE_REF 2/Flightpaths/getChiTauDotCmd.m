function [chi_tau_dot, c0]  = getChiTauDotCmd(pos_O, LemPsRef,  windDirection_rad, v_w_vec, c0)

pos_W = transformFromOtoW(windDirection_rad, pos_O); 

distanceOrigin = norm(pos_W);
% Step 0: Update Lemniscate
[ LemPs ] = updateLissajous( distanceOrigin, LemPsRef );
% Step 1: Determine closest point
[  sol,p_C_W ] = getTargetOnLissajous(LemPs, pos_W, c0, distanceOrigin);
c0 = sol; 
pos_target_W = p_C_W/norm(p_C_W) * distanceOrigin;

pos_W = transformFromOtoW(windDirection_rad, pos_O );

long = atan2( pos_W(2), pos_W(1) ); 
lat = asin( pos_W(3)/norm(pos_W) ); 


plot3( pos_target_W(1), pos_target_W(2), pos_target_W(3), '+c'); 


v_tau_vec = transformFromWtoTau(long,lat, v_w_vec ); 
chi_tau = atan2( v_tau_vec(2) , v_tau_vec(1) ); 

% Calculate normal acceleration 
%L1vec = pos_proj_W - pos_W;
%L1 = norm(L1vec);
[~,~, L1vec_W] = calcBearingToWp(pos_target_W, pos_W);
L1 = acos( pos_target_W'*pos_W / norm(pos_target_W) / norm(pos_target_W) )*norm(pos_W); 
%quiver3( pos_W(1), pos_W(2), pos_W(3), L1vec_W(1)*10,L1vec_W(2)*10,L1vec_W(3)*10, '-b');

M_tauW = [-sin(lat)*cos(long), -sin(lat)*sin(long), cos(lat);
    -sin(long), cos(long), 0;
    -cos(lat)*cos(long), -cos(lat)*sin(long), -sin(lat)];
M_Ktau = [cos(chi_tau), sin(chi_tau), 0; 
    -sin(chi_tau), cos(chi_tau), 0; 
    0, 0, 1];

M_KW = M_Ktau * M_tauW;

L1_vec_K = M_KW * L1vec_W;

eta = sign(L1_vec_K(2))*acos( L1vec_W'*v_w_vec / norm(L1vec_W) /norm(v_w_vec) );

a_s_cmd = 2 * norm(v_w_vec)^2/L1 * sin(eta);
a_s_cmd_vec = M_KW(2,:)' * a_s_cmd;
quiver3( pos_W(1),pos_W(2),pos_W(3), a_s_cmd_vec(1)*10, a_s_cmd_vec(2)*10, a_s_cmd_vec(3)*10, '-r')
drawnow;
chi_tau_dot = a_s_cmd / norm(v_w_vec);
    

