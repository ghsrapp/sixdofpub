

% nominal
TwoWpConfig.d_nom_wps = 160;
l_init = 200;

wp1_lat = 25*pi/180;
wp2_lat = 25*pi/180;

wp1_long = asin( TwoWpConfig.d_nom_wps/2/l_init/cos(wp1_lat));
wp2_long = -wp1_long;

wp1_W = [cos(wp1_lat)*cos(wp1_long); cos(wp1_lat)*sin(wp1_long); sin(wp1_lat)];
wp2_W = [cos(wp2_lat)*cos(wp2_long); cos(wp2_lat)*sin(wp2_long); sin(wp2_lat)];

TwoWpConfig.wp_W_list_nom = [wp1_long, wp1_lat; wp2_long, wp2_lat];

TwoWpConfig.dlong = 1*pi/180;
TwoWpConfig.dlat = 1*pi/180;
TwoWpConfig.exp_avg_const = 0.98;

cnt = 2;

% optional: plot waypoints
[wp_W_list] = updateWpList(l_init, wp1_lat, TwoWpConfig.d_nom_wps);

wp_plot = wp_W_list * 200;


