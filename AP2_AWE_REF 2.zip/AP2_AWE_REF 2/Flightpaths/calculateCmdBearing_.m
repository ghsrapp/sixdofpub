function [bearing] = calculateCmdBearing(Chi_c, p_kite_W)
p_kite_W = p_kite_W / norm(p_kite_W); 

% Extract latitude/longitude with respect to the ground station
lat_kite = asin( p_kite_W(3) / norm(p_kite_W) );
long_kite = atan2( p_kite_W(2), p_kite_W(1) );
% Calculate final flight direction
% Orthonormal basis of the tether frame
e_xT_W = [-sin(lat_kite)*cos(long_kite),-sin(lat_kite)*sin(long_kite), cos(lat_kite)];
e_zT_W = -p_kite_W/norm(p_kite_W);
e_yT_W = [e_zT_W(2)*e_xT_W(3)-e_zT_W(3)*e_xT_W(2),...
    e_zT_W(3)*e_xT_W(1)-e_zT_W(1)*e_xT_W(3),...
    e_zT_W(1)*e_xT_W(2)-e_zT_W(2)*e_xT_W(1)];
e_yT_W = e_yT_W/norm(e_yT_W);
M_TW = [e_xT_W;
    e_yT_W;
    e_zT_W'];
M_KT = [cos(Chi_c), sin(Chi_c), 0;
       -sin(Chi_c), cos(Chi_c), 0;
                 0,          0, 1];
M_KW = M_KT * M_TW;

bearing = M_KW(1,:);
% Test 


end

