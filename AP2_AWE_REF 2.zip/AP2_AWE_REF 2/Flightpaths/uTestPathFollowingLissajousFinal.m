clear all
close all
clc
l_tether = 500;


initLissajous;
windDirection_rad = pi;
nav.gamma_t_cmd = 0;

lam_vec = [0, -10, -20, -30];
phi_vec = [35, 50, 60, 80];
h = [];
chi_tau = -pi;
chi_f = 0;
Vtot = 30;
v_tau_vec = [cos(chi_tau); sin(chi_tau); 0]*Vtot;
dt = 0.02;
w_f = 10;
t_old = zeros(3,1);

q0 = zeros(3,1);
ex_old = zeros(3,1);
ey_old = zeros(3,1);
delta_old = 1;
Delta_chi_0 = 0;
e_chi = 0;
for m = 1 : length( lam_vec )
    for z = 1 : length( phi_vec )
        lam =lam_vec(m)*pi/180;
        phi = phi_vec(z)*pi/180;
        longlat = [lam,phi];
        v_w_vec = transformFromTautoW(lam, phi, v_tau_vec );
        
        pos_W = [cos(lam)*cos(phi); sin(lam)*cos(phi); sin(phi)]*l_tether;
        l = norm(pos_W);
        pos_O = transformFromWtoO(windDirection_rad, pos_W);
        
        longlat = [atan2(pos_W(2), pos_W(1)), asin(pos_W(3)/norm(pos_W))];
        long = longlat(1);
        lat = longlat(2);
        %% draw the circle
        if m == 1 && z == 1
            figure;
            drawLissajous;
            view(90,30); hold on
            plot3( pos_W(1), pos_W(2), pos_W(3), '*b');
            axis equal;
            plot3(0,0,0,'oK');
            [x,y,z] = sphere(50);
            %h = surf( x*l_tether, y*l_tether, z*l_tether);hold on
            h = surf( x*1, y*1, z*1);hold on
            set(h, 'FaceAlpha', 0.5)
            shading interp
            % axis([-0 300 -200 200 -0 300]);
            % axis([-0 l_tether+10 -l_tether l_tether -100 400]);
            axis([-0 1 -1 1 0 1]);
            plot3( pos_W(1)/norm(pos_W), pos_W(2)/norm(pos_W), pos_W(3)/norm(pos_W), '*b');
            
            drawnow;
        end
        %pos_W = pos_W*l_tether;
        c0 = 0;
        h = [];
        
        % Curvature curve (planar)
        kappa_fun = @(Al,Ap,bl,bp,cc) (Al*Ap*bl*bp^2*cos(bl*cc).*sin(bp*cc) - ...
            Al*Ap*bl^2*bp*cos(bp*cc).*sin(bl*cc))./...
            (Al^2*bl^2*cos(bl*cc).^2 + Ap^2*bp^2*cos(bp*cc).^2).^(3/2);
        
        htnb = [];
        chi_tau_old = chi_tau;
%        bearing_vec_W = v_tau_vec/norm(v_tau_vec); % initial flight direction
        Delta_chi = 0;
        htot = [];
        Tmax = 2000; 
         chi_k_num = zeros(Tmax,1); 
         gamma_k_num = chi_k_num; 
         chi_num = chi_k_num; 
        for n = 1 : Tmax
            delete(h);
            delete(htot);
            
            % == This function makes all the calculations for the APC
            % control ==
            % Following steps: Either: directly used as a chi_dot_cmd
            % or: integrate -> calculate chi_k, gamma_k and then use the
            % same procedure as already implemented.
            % c0: this is the pos_W value for the solution.
            distanceOrigin = norm(pos_W);
            
            % Step 0: Update Lemniscate
            % Maybe we can here define the direction of flight
            [ LemPs ] = updateLissajous( distanceOrigin, LemPsRef );
            
            delete(h);
            
            if n == 1 % find initiale solution
                iv = 0 : 0.1 : 2*pi;
                intervalInit = [pi, 3/2*pi]; % Thats the initial "quadrant"
                c0 = mean(intervalInit);
                ph = [];
            end
            delete(ph);
            direction = -1;
            
            % Step 1: Determine closest point
            [  sol,p_C_W,interval] = getTargetOnLissajous(LemPs, pos_W, c0, distanceOrigin,intervalInit, direction);
            [t,DtDs,L,dLds,q] = getPathInfos(sol,LemPs, direction);
            c0 = sol;
            intervalInit = interval;
            
            % Step 2: Calculate distance to closest point
            delta = acos( min( max( pos_W'/norm(pos_W) * p_C_W/norm(p_C_W), -1),1 ) );% * norm(pos_W);
            
            % Step 3.5: Calculate the perpendicular course
            [ perpCourse, delta_vec ] = calcCourse2ClosestPoint( p_C_W, pos_W );
            delta_vec_2 = (q - cos(delta) * pos_W/norm(pos_W) ) / sin(delta);
            
            %% ##### Rodrigues Formula ############### -> the correct vector
            % Active rotation / subtle difference
            %if norm( pos_W - p_C_W) > 1e-5
            t_rot = doRodriguesRotation(pos_W, p_C_W, t);
            t_rot_T = transformFromWtoTau(long, lat, t_rot);
            chi_parallel = atan2( t_rot_T(2), t_rot_T(1) );
            
            % Step 4: Calculate commanded course in tangential plane
            tau = 1;
            delta0 = norm(v_w_vec/norm(pos_W)) * tau;
            
            [chi_tau, Delta_chi,theta, Delta_chi_dot, deltaDot1] = calculateCommandedCourse(t_rot,delta_vec, delta, delta0, chi_parallel, p_C_W, pos_W,v_w_vec, e_chi);
            
            v_tau = [cos(chi_tau); sin(chi_tau); 0]*Vtot;
            v_w_vec_ideal = transformFromTautoW(long,lat, v_tau);
            bearing_W_ideal = v_w_vec_ideal/norm(v_w_vec_ideal);
            
            bearing_O_ideal = transformFromWtoO(windDirection_rad, bearing_W_ideal);
            %chi_k_d = atan2( bearing_O_ideal(2), bearing_O_ideal(1) );
            
            [chi_tau_dot_predict] = predictChiDotRequ(long,lat,v_w_vec, pos_W,p_C_W, t, DtDs,chi_parallel );

            if n < 2
                chi_num(n) = chi_tau;
                
                %bearing_O = transformFromWtoO(windDirection_rad, bearing_W_ideal);
                
                %bearing_O = bearing_O/norm(bearing_O);
                vel_O =  bearing_O_ideal * Vtot;
                
                chi_k_num(n) = atan2(vel_O(2), vel_O(1));
                gamma_k_num(n) = -asin( vel_O(3)/Vtot );
                
                
                chi_k = atan2(vel_O(2), vel_O(1));%chi_k_num(n) ;
                gamma_k =  -asin( vel_O(3)/Vtot ); %gamma_k_num(n);
                
                vel_W = bearing_W_ideal/norm(bearing_W_ideal) * Vtot;
                vel_tau = transformFromWtoTau(long,lat, vel_W);
                
                chi_tau_2 = atan2( vel_tau(2), vel_tau(1) );
                gamma_tau_2 = -asin( vel_tau(3)/norm(vel_tau) );
                
                chi2_dot = 0;
                gamma2_dot = 0;
                e_chi = 0;
                e_chi = wrapCourseError( chi_tau,chi_num(1));
                
                chi_dot_cmd = (chi_tau_dot_predict + Delta_chi_dot) + 0.1*e_chi;
                v_w_vec = vel_W;
                [chi_dot, gamma_dot] = getChiDotGammaDotOK(windDirection_rad,lat,long, v_w_vec,...
                    chi_dot_cmd, norm(pos_W),chi_k_num(1), gamma_k_num(1), v_w_vec_ideal, pos_W);
            else
                e_chi = wrapCourseError( chi_tau,chi_num(n-1));
                
                chi_dot_cmd = (chi_tau_dot_predict + Delta_chi_dot) + 0.1*e_chi;
                
                [chi_dot, gamma_dot] = getChiDotGammaDotOK(windDirection_rad,lat,long, v_w_vec,...
                    chi_dot_cmd, norm(pos_W),chi_k_num(n-1), gamma_k_num(n-1), v_w_vec_ideal, pos_W);
                
                chi_k_num(n) =   chi_k_num(n-1) + chi_dot * dt;
                gamma_k_num(n) =  gamma_k_num(n-1) + gamma_dot * dt;
                
                
                if chi_k_num(n) > pi
                    dchi = mod(chi_k_num(n),pi);
                    chi_k_num(n) = -pi+dchi;
                elseif chi_k_num(n) < -pi
                    chi_k_num(n) = mod(chi_k_num(n) , pi);
                end
                
                if gamma_k_num(n) > pi
                    dchi = mod(gamma_k_num(n),pi);
                    gamma_k_num(n) = -pi+dchi;
                elseif gamma_k_num(n) < -pi
                    gamma_k_num(n) = mod(gamma_k_num(n) , pi);
                end
                
                vel_O = [cos(chi_k_num(n))*cos(gamma_k_num(n));
                    sin(chi_k_num(n)) *cos(gamma_k_num(n));
                    -sin(gamma_k_num(n))]*Vtot;
                
                vel_W = transformFromOtoW(windDirection_rad, vel_O);
                
                vel_tau = transformFromWtoTau(long,lat, vel_W);
                
                chi_tau_2 = atan2( vel_tau(2), vel_tau(1) );
                gamma_tau_2 = -asin( vel_tau(3)/norm(vel_tau) );
                chi_num(n) = chi_tau_2;
            end
            
            
            v_w_vec = vel_W; 
            
            % enforce flight on tangential plane ("Tether" constraints)
            v_tau = transformFromWtoTau(long,lat, v_w_vec );
            v_tau(3) = 0;
            v_w_vec = transformFromTautoW(long,lat, v_tau );
            v_w_vec = v_w_vec/norm(v_w_vec)*Vtot;
            % I have obviously also then to correct chi and gamma!!
            v_O = transformFromWtoO(windDirection_rad, v_w_vec);
     
            chi_tau_2 = atan2( v_tau(2), v_tau(1) );
            gamma_tau_2 = -asin( v_tau(3)/norm(v_tau) );
            chi_num(n) = chi_tau_2;
            
            pos_W = pos_W + v_w_vec * dt;
            
            longlat = [atan2(pos_W(2), pos_W(1)), asin(pos_W(3)/norm(pos_W))];
            long = longlat(1);
            lat = longlat(2);
            
            delta_old = delta;
            
            plot3( pos_W(1)/norm(pos_W), pos_W(2)/norm(pos_W), pos_W(3)/norm(pos_W), '.b');
            
            drawnow;
        end
    end
end
%%
figure; hold on
plot( chi_dot_new );
%plot( chi_dot_save ) ;
%plot( chi_dot_test_num ) ; hold on
%plot( chi_dot_test ) ;
%plot( chi_dot_est, '-o' ) ;
% determination of chi_dot_ref (feedforward), based on the path curvature.
% if we look at the planar curve we can calculate the curvature, if we look
% at the tangential plane is chi_tau_dot <=> kappa*V. Let's check this
%
