%% Defines the geometrical properties of the figure of 8
%l_tether = 100; 
LemPsRef.AlambdaRef = 150   ;
LemPsRef.factor = 5; 
LemPsRef.AphiRef = LemPsRef.AlambdaRef/LemPsRef.factor;
LemPsRef.blambdaRef = 1;
LemPsRef.bphiRef = 2;
LemPsRef.phi0 = 30*pi/180;
LemPsRef.c0 = pi/4;
LemPsRef.deltaSol = 0.1;

LemPsRef.s_trans = 3.7;%pi/2; 
LemPsRef.s_trans_retract = pi/2+0.5; 

% Define the attractor point on the lissajous figure for the transition 
% theta_point = LemPsRef.s_trans ;%1.2*pi;%sol_init;
% L = [Alambda * sin(blambda*theta_point');
%     Aphi    * sin(bphi*theta_point') + phi0];
% L_W = [cos(L(1,:)).*cos(L(2,:));
%         sin(L(1,:)).*cos(L(2,:));
%         sin(L(2,:))];
% LemPsRef.transition_target_W = L_W; % "Upper-Left"

% Define point that triggers retraction phase
% theta_point = pi/2+pi;%1.2*pi;%sol_init;
% L = [Alambda * sin(blambda*theta_point');
%     Aphi    * sin(bphi*theta_point') + phi0];
% L_W = [cos(L(1,:)).*cos(L(2,:));
%         sin(L(1,:)).*cos(L(2,:));
%         sin(L(2,:))];
% LemPsRef.retraction_trans_W = L_W; % "Upper-Left"



