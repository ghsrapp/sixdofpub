function [] = drawPointLissajous(l_tether,LemPsRef, s)
%DRAWPOINTLISSAJOUS Summary of this function goes here
%   Detailed explanation goes here
[ LemPs ] = updateLissajous( l_tether, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
L = [Alambda * sin(blambda*s');
    Aphi    * sin(bphi*s') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
plot3( L_W(1), L_W(2), L_W(3), 'ob'); 

end

