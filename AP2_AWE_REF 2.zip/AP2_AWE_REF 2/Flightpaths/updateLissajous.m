function [ LemPs ] = updateLissajous( l_t, LemPsRef )
%UPDATELEMNISCATE Summary of this function goes here
%   Detailed explanation goes here
% Adjusts the size of the figure of eight with the euclidean distance
% to the groundstation.
    LemPs.blambda = LemPsRef.blambdaRef;
    LemPs.bphi = LemPsRef.bphiRef;
    LemPs.phi0 = LemPsRef.phi0;
    LemPs.deltaSol = LemPsRef.deltaSol;
    %LemPs.Alambda = LemPsRef.AlambdaRef/(l_t*cos(LemPsRef.phi0));
    LemPs.Alambda = LemPsRef.AlambdaRef/(l_t);
    LemPs.Aphi = LemPsRef.AphiRef/l_t;
    %LemPs.Aphi = LemPsRef.AlambdaRef/(l_t*cos(LemPsRef.phi0))/LemPsRef.factor;
    %LemPs.Aphi = LemPs.Alambda/LemPsRef.factor;
end