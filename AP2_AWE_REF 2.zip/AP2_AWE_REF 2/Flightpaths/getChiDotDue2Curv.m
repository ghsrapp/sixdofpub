function chi_dot = getChiDotDue2Curv(t, DtDs, pos_W, v_parallel, chi_tau)

lamb = atan2( pos_W(2), pos_W(1) ); 
phi = asin( pos_W(3)/norm(pos_W) ); 
ez = [-cos(phi)*cos(lamb); -cos(phi)*sin(lamb); -sin(phi)];


chi_dot = v_parallel * ( DtDs' * cross( ez, t ) / norm(t)^3 - tan(phi) * sin( chi_tau ) );  



end