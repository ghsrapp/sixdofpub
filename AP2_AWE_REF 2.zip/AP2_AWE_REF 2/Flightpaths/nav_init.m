% Tuning navigation loop 
nav.ds = 0.3;
nav.t0trac = 1.2; % velocity dependent
nav.t0transCirc = 30; % absolute distance
nav.gamma_t_cmd = 0;