function [chi_dot_cmd, gamma_dot_cmd] = getChiDotGammaDotOK_b(windDirection_rad,lat,long, chi_tau_dot, r, chi_k, gamma_k,...
    v_ideal,v_w_vec_is,gamma_tau_is,gamma_tau_dot_cmd)
%UNTITLED Summary of this function goes here

c_chi_k = cos(chi_k); 
c_gamma_k = cos(gamma_k); 
s_chi_k = sin(chi_k); 
s_gamma_k = sin(gamma_k); 



e_y_K_O = [-s_chi_k, c_chi_k, 0 ]';
e_y_K_W = transformFromOtoW(windDirection_rad,e_y_K_O);
e_y_tau_W = [-sin(long), cos(lat), 0]';
% angle between the K frame and the tau frame
mu = -acos( e_y_K_W'*e_y_tau_W/norm(e_y_K_W)/norm(e_y_tau_W) );

M_KbarO = [1,0,0;
    0, cos(mu), sin(mu);
    0,-sin(mu), cos(mu)]*[ c_chi_k*c_gamma_k, s_chi_k*c_gamma_k, -s_gamma_k; 
    -s_chi_k, c_chi_k, 0; 
    c_chi_k*s_gamma_k, s_chi_k*s_gamma_k, c_gamma_k];
M_OKbar = M_KbarO';
omega_OKbar_Kbar = [0;
             0;
              chi_tau_dot];
          
          
omega_TK_T = [0;
               0;
               chi_tau_dot];
           
           
v_k_tau_ideal = transformFromWtoTau( long, lat, v_ideal); 
omega_TK_W = transformFromTautoW( long, lat, omega_TK_T); 
omega_TK_O = transformFromWtoO(windDirection_rad, omega_TK_W);

long_dot = v_k_tau_ideal(2) /(r*cos(lat)); 
lat_dot = v_k_tau_ideal(1) / r; 
  
omega_WT_W = [lat_dot*sin(long); 
             -lat_dot*cos(long); 
              long_dot];

omega_WT_O = transformFromWtoO(windDirection_rad, omega_WT_W ); 
omega_WT_K = M_KbarO*omega_WT_O;

omega_OK_O = omega_WT_O + omega_TK_O;
%omega_OK_K = omega_WT_K + omega_TK_K;

gamma_dot_cmd = omega_OK_O(1)*(-s_chi_k) +  omega_OK_O(2) *c_chi_k;
%chi_dot_cmd  =  omega_OK_O(3);
%chi_dot_cmd = omega_OK_K(2)*(-s_gamma_k) +  omega_OK_O(3) *c_gamma_k;

omega_OKbar_Kbar = M_KbarO * omega_WT_O + omega_OKbar_Kbar;
chi_dot_cmd = (omega_OKbar_Kbar(2) * sin(mu) + omega_OKbar_Kbar(3) * cos(mu) ) / cos(gamma_k); 


omega_OKbar_O = omega_WT_O + M_OKbar * omega_OKbar_Kbar; 

gamma_dot_cmd = omega_OKbar_O(1) * (-sin(chi_k)) + omega_OKbar_O(2) * cos(chi_k); 

end



