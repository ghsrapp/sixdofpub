function [ sol, res, f ] = bisec( interval, p_kite_W, LemPs, c0 )
%NEWTONMETHOD Summary of this function goes here
%   Detailed explanation goes here
res = 1;
f=1;
kk = 1;
iv = 0 : 0.1 : 2*pi;
%figure;
%plot( iv, func( iv, p_kite_W, LemPs) )
% Check interval bounds and adapt if necessary
%while sign( fun(interval(1))) == sign( fun(interval(2))) && kk < 100
% delta = acos( min( max( p_kite_W' * p_C_W/norm(p_kite_W)/norm(p_C_W), -1),1 ) ) * norm(x_K);

lat = asin( p_kite_W(3) / norm(p_kite_W) );
long = atan2( p_kite_W(2), p_kite_W(1) );
% if lat >= LemPs.phi0 && long >= 0
%     interval = [0, pi/2];
% end
% 
% if lat >= LemPs.phi0 && long < 0
%     interval = [pi, 3*pi/2];
% end
% 
% if lat <= LemPs.phi0 && long >= 0
%     interval = [pi/2, pi];
% end
% 
% if lat < LemPs.phi0 && long < 0
%     interval = [3/2*pi, 2*pi];
% end


while sign( func(interval(1),p_kite_W, LemPs )) == sign( func(interval(2),p_kite_W, LemPs ) ) && kk < 100
    %if sign( func(interval(1),p_kite_W, LemPs )) == sign( func(interval(2),p_kite_W, LemPs ) ) %&& kk < 100
    interval(1) =  mod( interval(1)+0.1,2*pi);
    kk = kk + 1;
end

%m_prev = interval(1);
m_prev = interval(2);

m = m_prev;
k = 1;
while res > 1e-6 && k < 100
    m = ( interval(1) + interval(2) )/2;
    fm = func(m,p_kite_W, LemPs );
    fa = func(interval(1),p_kite_W, LemPs );
    if sign( fm ) ~= sign( fa )
        interval(2) = m;
    else
        interval(1) = m;
    end
    f = func(m,p_kite_W, LemPs );
    res = abs( m - m_prev );
    m_prev = m;
    k = k + 1;
end
if k >= 100
    disp('Max Iter.');
end
sol = m;
end
