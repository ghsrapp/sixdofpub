function [chi_tau_dot, pos_target_W]  = getChiTauDot_CircleAPC(l_tether,pos_O, CircleParam,  windDirection_rad, v_w_vec, longlat)


pos_W = transformFromOtoW(windDirection_rad, pos_O );

long = longlat(1); 
lat = longlat(2); 

% Update
r = CircleParam.radius;
alpha = asin( r/norm(pos_W) ) ;
d = cos(alpha)*norm(pos_W) ;

e_c_x = [-sin(CircleParam.mean_elevevation); 0; cos(CircleParam.mean_elevevation)];
e_c_y = [0; 1; 0];
e_c_z = -[cos(CircleParam.mean_elevevation); 0; sin(CircleParam.mean_elevevation)];

M_CW = [e_c_x'; e_c_y'; e_c_z'];
M_WC = M_CW';
p_co_W = d*[cos(CircleParam.mean_elevevation);0; sin(CircleParam.mean_elevevation)];

%% Determine point on circle and calculate the course and the path angle to fly towards it

pos_C = M_CW * ( pos_W - p_co_W );
pos_proj_C = [pos_C(1);pos_C(2);0];% - e_c_z*(e_c_z'*pos_C);
pos_target_C = pos_proj_C/norm(pos_proj_C) * r;

al = 1*pi/180;
M_rot = [cos(al), sin(al), 0;
    -sin(al), cos(al), 0;
    0, 0, 1];
pos_target_C = M_rot * pos_target_C;

pos_target_W = M_CW'*pos_target_C + p_co_W;

%plot3( pos_target_W(1), pos_target_W(2), pos_target_W(3), '+c'); 


v_tau_vec = transformFromWtoTau(long,lat, v_w_vec ); 
chi_tau = atan2( v_tau_vec(2) , v_tau_vec(1) ); 

% Calculate normal acceleration 
%L1vec = pos_proj_W - pos_W;
%L1 = norm(L1vec);
[~,~, L1vec_W] = calcBearingToWp(pos_target_W, pos_W);
L1 = acos( pos_target_W'*pos_W / norm(pos_target_W) / norm(pos_target_W) )*norm(pos_W); 


M_tauW = [-sin(lat)*cos(long), -sin(lat)*sin(long), cos(lat);
    -sin(long), cos(long), 0;
    -cos(lat)*cos(long), -cos(lat)*sin(long), -sin(lat)];
M_Ktau = [cos(chi_tau), sin(chi_tau), 0; 
    -sin(chi_tau), cos(chi_tau), 0; 
    0, 0, 1];

M_KW = M_Ktau * M_tauW;

L1_vec_K = M_KW * L1vec_W;

eta = sign(L1_vec_K(2))*acos( L1vec_W'*v_w_vec / norm(L1vec_W) /norm(v_w_vec) );

a_s_cmd = 2 * norm(v_w_vec)^2/L1 * sin(eta);
a_s_cmd_vec = M_KW(2,:)' * a_s_cmd;

chi_tau_dot = a_s_cmd / norm(v_w_vec);
    

