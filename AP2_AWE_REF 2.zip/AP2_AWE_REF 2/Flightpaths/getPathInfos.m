function [t,DtDs,L, dLds,q] = getPathInfos(s_old,LemPs, direction)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes her
% calculate the tangent at the solution and its derivative
% -1: down in the middle

L = [LemPs.Alambda * sin(LemPs.blambda*s_old);
     LemPs.Aphi * sin(LemPs.bphi*s_old)+LemPs.phi0];
 
dLds = [ LemPs.blambda*LemPs.Alambda*cos(LemPs.blambda*s_old);...
         LemPs.bphi*LemPs.Aphi*cos(LemPs.bphi*s_old)];

d2Lds2 =  [ -LemPs.blambda^2*LemPs.Alambda*sin(LemPs.blambda*s_old);...
         -LemPs.bphi^2*LemPs.Aphi*sin(LemPs.bphi*s_old)];    
          
s_lambda = sin( L(1,:)  ); 
s_phi = sin( L(2,:) );
c_lambda = cos( L(1,:) ); 
c_phi = cos( L(2,:) ); 

q = [c_lambda*c_phi; s_lambda*c_phi; s_phi];

dqdlambda = [-s_lambda*c_phi; c_lambda*c_phi; 0];
dqdphi = [-c_lambda*s_phi; -s_lambda*s_phi; c_phi];

t = direction*( dqdlambda * dLds(1) + dqdphi *dLds(2) ); 

%t = -[(-s_lambda.*dLds(1,:).*c_phi-s_phi.*dLds(2,:).*c_lambda);
 %   ( c_lambda.*dLds(1,:).*c_phi-s_phi.*dLds(2,:).*s_lambda);
  %  c_phi.*dLds(2,:)];
% 
% Dlambda = dLds(1); 
% Dphi = dLds(2); 
% D2GammaD2lambda = [-c_lambda*c_phi; -s_lambda*c_phi; 0]; 
% D2GammaD2phi = [-c_lambda*c_phi; -s_lambda*c_phi; -s_phi]; 
% D2GammaDlambdaDphi = [s_lambda*s_phi; -c_lambda*s_phi; 0];
% 
% DtDs = D2GammaD2lambda * Dlambda^2 + 2 * D2GammaDlambdaDphi * Dlambda * Dphi + D2GammaD2phi * Dphi^2; 
% DtDs = -DtDs;

dtdlambda = [-c_lambda*c_phi*dLds(1)+s_lambda*s_phi*dLds(2); 
             -s_lambda*c_phi*dLds(1)-s_phi*c_lambda*dLds(2);
            0];
        
dtdphi = [s_lambda*s_phi*dLds(1)-c_phi*c_lambda*dLds(2); 
         -c_lambda*s_phi*dLds(1)-c_phi*s_lambda*dLds(2); 
         -s_phi*dLds(2)];
     
dtds = dqdlambda * d2Lds2(1)  + dqdphi * d2Lds2(2); 
     
% The negative sign cancels out 
DtDs =  ( dtdlambda * dLds(1) + dtdphi * dLds(2) + dtds ); 



end

