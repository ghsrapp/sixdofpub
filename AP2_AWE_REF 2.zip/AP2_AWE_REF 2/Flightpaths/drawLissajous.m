[ LemPs ] = updateLissajous( l_tether, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;

theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';

L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];

L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];

L_W_k = L_W * l_tether;
Delta0 = 0.5 * max( L_W_k(2,: ) );
col3 =  [237/255, 85/255, 59/255 ];
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), '-', 'color',col3); hold on;
axis equal; grid on;hold on; view(90,0);
%
theta_point = LemPsRef.s_trans;%   pi/2+0.5;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * 200;

%plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), '*g'); hold on;

%% Waypoints
theta_point = LemPsRef.s_trans_retract ;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
wp_1 = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
%plot3(wp_1(1,:),wp_1(2,:),wp_1(3,:), 'color', 'k', 'Marker', 'o'); hold on;

theta_point = LemPsRef.s_trans ;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
wp_4 = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
%plot3(wp_4(1,:),wp_4(2,:),wp_4(3,:), 'color', 'k', 'Marker', 'o'); hold on;
view(90, LemPsRef.phi0*180/pi);
