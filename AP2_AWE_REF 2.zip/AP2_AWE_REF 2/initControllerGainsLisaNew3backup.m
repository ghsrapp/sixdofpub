%% ======= Actuators ====
% The bandwidth of the system is restricted by the actuator bandwidth.
% The actuators are modeled as second order spring-damper elements.
zeta_actutaor = 1;%1.2;
omega_actuator = 50;%35;

omega_rates = omega_actuator;
omega_attitude = 10;%1/3*omega_rates ;
omega_course = 2;%1/6 * omega_attitude;
omega_gamma = 2; %1/6 * omega_attitude;

%% Chosen reference frequencies and damping
% Traction phase
FCS.w0_p = 30;%35;%factor_w0_p;
FCS.w0_mu_traction = 1/3*FCS.w0_p;
FCS.w0_mu_retraction = 1/4*FCS.w0_p;
FCS.w0_chi = factor_w0_chi*FCS.w0_mu_retraction;
factor_w0_chi = 1/FCS.w0_mu_retraction;
FCS.w0_q = 25;%factor_w0_q;
FCS.w0_alpha_traction = 1/6*FCS.w0_q ;
FCS.w0_gamma = factor_w0_gamma*FCS.w0_alpha_traction;
FCS.w0_r = 20;%factor_w0_r;
factor_w0_beta = 0.5;
FCS.w0_beta = factor_w0_beta*FCS.w0_r;

FCS.zeta_mu = 1;
FCS.zeta_alpha = 1;
FCS.zeta_beta = 1;
FCS.zeta0_p = 1;
FCS.zeta0_q = 1;
FCS.zeta0_r = 1;
FCS.zeta_chi = 1;
FCS.zeta_gamma =1;

% Retraction phase
%FCS.w0_mu_retraction = 1/4*FCS.w0_p;
FCS.w0_mu_retraction = 1/6*FCS.w0_p;%lisa2
FCS.w0_chi_retract = 0.4*FCS.w0_mu_retraction;

FCS.w0_alpha_retraction = factor_w0_alpha*FCS.w0_q ;
FCS.w0_alpha_retraction = 1/3*FCS.w0_q ;

FCS.w0_gamma_retract =1/3*FCS.w0_alpha_retraction;
FCS.w0_gamma_retract =1/2.5*FCS.w0_alpha_retraction;

FCS.zeta_chi_retract  = 1;
FCS.zeta_gamma_retract  = 1;


%% =====================================================
% P and I feedback gains
%
% Traction phase
FCS.Kp_chi_predictive = 0.5;%0.5;%0.5; 
FCS.Ki_chi_predictive = 1e-3;

FCS.Kp_chi = factor_chi*FCS.w0_chi^2;
FCS.Ki_chi = factor_chi*2*FCS.w0_chi*FCS.zeta_chi;

FCS.Kp_mu_traction = FCS.w0_mu_traction;
FCS.Ki_mu_traction = FCS.w0_mu_traction ;

factor_chi = 0.6;

factor_p = 0.1;
FCS.Kp_p = 2*FCS.w0_p; % 1
FCS.Ki_p = 1.2*FCS.w0_p; % 1.2
%
FCS.Kp_gamma = factor_gamma*FCS.w0_gamma^2;
FCS.Ki_gamma = factor_gamma*2*FCS.w0_gamma*FCS.zeta_gamma;

FCS.Kp_q =  2.5*FCS.w0_q; % was 2
factor_q = 0.1; 
FCS.Ki_q = 2.5*FCS.w0_q; % was 2
%
FCS.Kp_beta =  1*FCS.w0_beta;
FCS.Ki_beta =  0.1*FCS.w0_beta; % War 1
FCS.Kd_beta = 0.1*FCS.w0_beta;

factor_r = 0.5;
FCS.Kp_r = 2*FCS.w0_r; % war 0.8
FCS.Kp_r_retraction = FCS.w0_r;
factor_r = 0.1; 
FCS.Ki_r = 0.1*FCS.w0_r; % war 0.9

% Retraction phase
factor_chi_p = 0.3; % 2 for the not-zenith case
FCS.Kp_chi_retract = factor_chi_p*FCS.w0_chi_retract^2;
factor_chi_i = 0.1; % 0.05 for the not-zenith case
%FCS.Ki_chi_retract = factor_chi*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;
FCS.Ki_chi_retract = factor_chi_i*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;

%FCS.Kp_mu_retraction = FCS.w0_mu_retraction;
FCS.Kp_mu_retraction = 0.1*FCS.w0_mu_retraction ^2;
%FCS.Ki_mu_retraction = FCS.w0_mu_retraction ;
FCS.Ki_mu_retraction = 0.2 * 2 * FCS.zeta_mu * FCS.w0_mu_retraction ;

%FCS.Kp_p = factor_p*FCS.w0_p^2;
%FCS.Ki_p = factor_p*2*FCS.w0_p*FCS.zeta0_p;
%FCS.Kp_gamma_retract = 0.3*FCS.w0_gamma_retract;
%FCS.Ki_gamma_retract = 0.3*FCS.w0_gamma_retract;
factor_gamma = 0.6;
FCS.Kp_gamma_retract = 1.8*FCS.w0_gamma_retract^2;
FCS.Ki_gamma_retract = 0*0.001*2*FCS.w0_gamma_retract*FCS.zeta_gamma_retract;


FCS.Kp_alpha_traction = 10;FCS.w0_alpha_traction;
FCS.Ki_alpha_traction = 10;FCS.w0_alpha_traction;
FCS.Kd_alpha_traction = 0;
% 
% FCS.Kp_alpha_retraction =  2*FCS.w0_alpha_retraction^2;
% FCS.Ki_alpha_retraction =  0.1*FCS.w0_alpha_retraction;
factor_alpha = 0.6; 
FCS.Kp_alpha_retraction =  0.3*FCS.w0_alpha_retraction^2;
FCS.Ki_alpha_retraction =  1*2 * FCS.zeta_alpha * FCS.w0_alpha_retraction;

%FCS.Kp_beta_retraction =  0.1*FCS.w0_beta;
FCS.Kp_beta_retraction =  0.05*factor_beta*FCS.w0_beta^2;
FCS.Ki_beta_retraction =  0.6*FCS.w0_beta;
FCS.Kd_beta_retraction = 0.1*FCS.w0_beta;


FCS.Kp_p_retraction =1*FCS.w0_p;
FCS.Ki_p_retraction = 1.2*FCS.w0_p;

FCS.Kp_q_retraction =  5*FCS.w0_q;
FCS.Ki_q_retraction = 5*FCS.w0_q; 

FCS.Kp_r_retraction = 7*FCS.w0_r; % + 20%
FCS.Ki_r_retraction = 3*FCS.w0_r; 

%% =====================================================

% FCS.omegaGammaDot = 25;
% FCS.zetaGammaDot = 0.8;

%% ======= Rate Controller Gains =======
% %FCS.Kp_rate = diag( [10,30,25] );
% FCS.Kp_rate = diag( [10,20,25] );
%
% FCS.Ki_rate = 0.5*diag( [10,10,10] );
% FCS.ARefRate = -omega_rates* eye(3);%5*FCS.ARefAttitude;
% FCS.BRefRate = omega_rates* eye(3);%5*FCS.BRefAttitude;
%

%% Control Allocation
FCS.C_A = [P.C_ell_delta_a, 0,P.C_ell_delta_r;
    0,P.C_m_delta_e ,0;
    P.C_n_delta_a, 0,P.C_n_delta_r];
FCS.C_A_inv = FCS.C_A \ eye(3);


%% Model parameters
FCS.J = P.J;
FCS.Jinv = P.Jinv;

%% Winch controller
omega_winch = 10;


P_gain_winch = 0.5;
Va_max = 80;
Va_min = 20;
hysteris_e = 5;