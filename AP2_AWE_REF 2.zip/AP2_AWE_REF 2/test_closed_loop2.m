clear all
close all
clc

save_flag = 0;

addpath(genpath('MiscFiles'))
path_with_gains = 'Trim_results/case_1_test03';
addpath(path_with_gains);
addpath(genpath('AWESTRIM'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))

load('G_save.mat');
load('rps_st.mat');
load('x0_save.mat');
load('u0_save.mat');
load('M_OB_init.mat');
s = [pi/2, 2*pi]; 

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;

%for k = 1 : numel( rps_st )
sim_with_indx = 2 ;
[K_lat, K_long, A_tot, B_tot, Ks, A_long, A_lat, B_long, B_lat, B_long_wFt, Mx, Mu, A_lat_plus, B_lat_plus] = lqr_w_psi_wVa_test_decoupled(G_save{sim_with_indx});

% K_delta_e(1,:) = K_long(1,:);
% K_delta_a(1,:) = K_lat(1,:);
% K_delta_r(1,:) = K_lat(2,:);
% A_long_s{k} = A_long;
% A_lat_s{k} = A_lat;
% B_long_s{k} = B_long;
% B_lat_s{k} = B_lat;
% Ks_save{k} = Ks;
% K_delta_tot_a(k,:) = Ks(1,:);
% K_delta_tot_e(k,:) = Ks(2,:);
% K_delta_tot_r(k,:) = Ks(3,:);
% A_tot_s{k} =  G_save{k}.A(1:9,1:9);
% B_tot_s{k} =  G_save{k}.B(1:9,1:3);
% Mx_s{k} = Mx;
% Mu_s{k} = Mu;
%end

%K_long = K_delta_e(1,:);
%K_lat = [K_delta_a(1,:);...
 %   K_delta_r(1,:)];
%A_long_test = A_long_s{1};
%B_long_test = B_long_s{1};
%Mx_test = Mx_s{1};
%Mu_test = Mu_s{1};
%K_long_p = K_long(1:end-1);
%K_long_i = K_long(end);
%F_long = K_long_p*Mx_test+Mu_test;

%% Some step responses of the lateral controller
A_lat_cl = A_lat_plus - B_lat_plus * K_lat;
B_lat_cl = B_lat_plus.*0;
B_lat_cl(end-1, 1) = 1;
B_lat_cl(end,2) = 1;
sys_beta = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0], [] );
sys_phi = ss( A_lat_cl, B_lat_cl, [0,1,0,0,0,0], [] );
tvec = 0 : 0.1 : 12;

opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
%% BETA
[y,t] = step(sys_beta,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,1)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t(:,:,1)./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\beta_a$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_beta');
    cd ..
end
%% PHI
[y,t] = step(sys_phi,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,2)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\Phi_tau$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_phi');
    cd ..
end

%Ap = A_long_test(1:4, 1:4);
%Bp = B_long_test(1:4);
%[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um] = test_simple_piecewise_L1(A_long,B_long, K_long_p);
%%
close all
[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = test_simple_piecewise_L1_aug(A_long,B_long);
K_long = Kbl;
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\alpha_a$ $(deg)$');
axis([0 12 0 12]);
%%
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI');
    cd ..
end
x0_trim = x0_save(:,sim_with_indx);
u0_trim = u0_save(:,sim_with_indx);

%% Initialize the simulation
sim_with_indx = 2;%length(s);
x0_sim = x0_save(:,sim_with_indx);
u0_sim = u0_save(:,sim_with_indx);

%lat_in = x0_sim(11); %80*pi/180;
lat_in = 80*pi/180; %

% Initialze position at higher elevation angles.


x0_sim(11) = lat_in;
x0_sim(12) = 300;

pos_init_W = [cos( x0_sim(10) ) * cos( lat_in );
    sin( x0_sim(10) ) * cos( lat_in );
    sin( lat_in )]*x0_sim(12);

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams_variable_p_init_W(pos_init_W);
l_tether = x0_sim(12);
Lbooth.init_sol = s(sim_with_indx);
M_OB = M_OB_init{sim_with_indx};
M_BO = M_OB';
params.a_booth = 0.5;
params.b_booth = 160;
params.phi0_booth =  30*pi/180;
windDirection_rad = ENVMT.windDirection_rad;
gamma_tau = 0;
vel_w_W = [9;0;0];
M_OW = [cos(windDirection_rad), sin(windDirection_rad), 0;
    sin(windDirection_rad), -cos(windDirection_rad), 0;
    0, 0, -1];
vel_w_B = M_BO*M_OW*vel_w_W;
alpha = x0_sim(3);
beta = x0_sim(2);
Va = x0_sim(1);
M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
    -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
    -sin(alpha), 0, cos(alpha)];
M_BA = M_AB';
v_k_B_init = vel_w_B + M_BA*[Va;0;0];
v_k_O_init = M_OB*v_k_B_init; 
v_k_W_init = M_OW'*v_k_O_init; 
pathangles_k_init(1) = atan2( v_k_O_init(2), v_k_O_init(1) ); 
pathangles_k_init(2) = -asin( v_k_O_init(3)/norm(v_k_O_init) ); 

%
Phi_traction_vec = 30*pi/180;%[30, 40]*pi/180;
Ft_set_vec = [1800];%[800,1300,1800];
base_windspeed_vec = 10; %[4,10];
adaptive_controller_flag_vec = [0, 1];
cnt = 1;
cnta = 1;
params_mat = [];
for n = 1 : length( adaptive_controller_flag_vec )
    ad_flag = adaptive_controller_flag_vec(n);
    for k = 1 : length( Phi_traction_vec )
        phi_trac = Phi_traction_vec(k);
        
        for l = 1 : length( Ft_set_vec )
            Ft_set = Ft_set_vec(l);
            for z = 1 : length( base_windspeed_vec )
                base_windspeed = base_windspeed_vec(z);
                fprintf('Simulation running...');
                yout = sim('AWES3_CL_wTether','ReturnWorkspaceOutputs','on');
                if ad_flag == 0
                    yout_baseline{cnt} = yout;
                    fprintf('Done %.1f \n', cnt );
                    cnt = cnt + 1;
                else
                    yout_adaptive{cnta} = yout;
                    fprintf('Adaptive sim done %.1f \n', cnta );
                    cnta = cnta + 1;
                end
                params_mat = [params_mat; [ad_flag, phi_trac*180/pi, Ft_set/1000, base_windspeed]];
            end
        end
    end
end

%%
%close all

cnt_idx = [1,2, 11, 12];
cd Trim_results
if 1
    load('yout_baseline.mat');
    load('yout_adaptive.mat');
end

for k = 1 : length( cnt_idx )
    close all;
    cnt = cnt_idx(k);
    h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$\alpha_a$ $(deg)$');
    axis tight
    % figure;
    % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    % h_bl_ref.Color(4) = alpha_lvl;
    % h_bl.Color(4) = alpha_lvl;
    % xlabel('$Time$ $(s)$');
    % ylabel('$F_t$ $(kN)$');
    
    h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on;
    h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2); hold on;
    xlabel('$Time$ $(s)$');
    ylabel('$\alpha_a$ $(deg)$');
    axis tight
    
    h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl_ref.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$F_t$ $(kN)$');
    axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
    
    h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl_ref.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$F_t$ $(kN)$');
    axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
    
    h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    plot( yout_baseline{cnt}.target_pos.Data(:,1),...
        yout_baseline{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
    plot( yout_baseline{cnt}.pos_W.Data(:,1),...
        yout_baseline{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
    %axis([0 600 -300 300 ])
    axis equal;
    xlabel('$x_W$ $(m)$');
    ylabel('$y_W$ $(m)$');
    
    h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
        yout_adaptive{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
    plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
        yout_adaptive{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
    %axis([ 0 600 -300 300])
    axis equal;
    xlabel('$x_W$ $(m)$');
    ylabel('$y_W$ $(m)$');
    
    h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    plot( yout_baseline{cnt}.target_pos.Data(:,1),...
        yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    plot( yout_baseline{cnt}.pos_W.Data(:,1),...
        yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
    %axis([0 600 100 500])
    axis equal;
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
    
    h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
        yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
        yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
    %axis([0 600 100 500])
    axis equal;
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
    
    
    Plot2LaTeX(h1,['only_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h2,['only_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h3,['Ftonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h4,['Ftonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    
    Plot2LaTeX(h5,['xyonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h6,['xyonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h7,['xzonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    Plot2LaTeX(h8,['xzonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
    
    
    
    
end
cd ..
% figure;
% h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
% h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
% h_bl_ref.Color(4) = alpha_lvl;
% h_bl.Color(4) = alpha_lvl;
% xlabel('$Time$ $(s)$');
% ylabel('$F_t$ $(kN)$');
% %
% figure;
% h_bl_ref = plot3( yout_baseline{cnt}.target_pos.Data(:,1),...
%     yout_baseline{cnt}.target_pos.Data(:,2),...
%     yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
% h_bl_ref = plot3( yout_baseline{cnt}.pos_W.Data(:,1),...
%     yout_baseline{cnt}.pos_W.Data(:,2),...
%     yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
% axis equal

% figure;
% h_bl_ref = plot3( yout_adaptive{cnt}.target_pos.Data(:,1),...
%     yout_adaptive{cnt}.target_pos.Data(:,2),...
%     yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
% h_bl_ref = plot3( yout_adaptive{cnt}.pos_W.Data(:,1),...
%     yout_adaptive{cnt}.pos_W.Data(:,2),...
%     yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
