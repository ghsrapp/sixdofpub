%% controller gains are optimized using a Genetic Algorithm
init_new;
% run time of the sim
TSIM = 20;
% population size

%% I Setup the GA
npar= 25; % number of optimization variables
varhi=50; varlo=0.1; % variable limits
%% II Stopping criteria
maxit=200; % max number of iterations
mincost=-9999999; % minimum cost
%% III GA parameters
popsize=50; % set population size
mutrate=.2; % set mutation rate
selection=0.5; % fraction of population kept
Nt=npar; % continuous parameter GA Nt=#variables
keep=floor(selection*popsize); % #population members that survive
nmut=ceil((popsize-1)*Nt*mutrate); % total number of mutations
M=ceil((popsize-keep)/2); % number of matings

%% Create the initial population
iga=0; % generation counter initialized
par=(varhi-varlo)*rand(popsize,npar)+varlo; % random
% if different parameters need different intervals:
hi1 = 5;
lo1 = 0.01;
par(:,1) = (hi1-lo1)*rand(popsize,1)+lo1; % for instance the course p-controller

feasible_set_coursePred = [0.1:0.1:1];

feasible_set_attitude = [1/2,1/3,1/4,1/5,1/6];
feasible_set_rates = [35,30,25,20,15,10];

feasible_set_gains = varlo : 0.5 : varhi; 
%
indx = randi([1 length( feasible_set_coursePred)],popsize,1);
par(:,1) = feasible_set_coursePred(indx);
%
indx = randi([1 length( feasible_set_rates)],popsize,1);
par(:,14) = feasible_set_rates(indx);
%
indx = randi([1 length( feasible_set_rates)],popsize,1);
par(:,15) = feasible_set_rates(indx);
%
indx = randi([1 length( feasible_set_rates)],popsize,1);
par(:,16) = feasible_set_rates(indx);
%
indx = randi([1 length( feasible_set_attitude)],popsize,1);
par(:,17) = feasible_set_attitude(indx);
%
indx = randi([1 length( feasible_set_attitude)],popsize,1);
par(:,18) = feasible_set_attitude(indx);
%
indx = randi([1 length( feasible_set_attitude)],popsize,1);
par(:,19) = feasible_set_attitude(indx);
%
indx = randi([1 length( feasible_set_attitude)],popsize,1);
par(:,20) = feasible_set_attitude(indx);
%
indx = randi([1 length( feasible_set_attitude)],popsize,1);
par(:,21) = feasible_set_attitude(indx);
%
indx = randi([1 length( feasible_set_gains)],popsize,1);
par(:,22) = feasible_set_gains(indx);
%
indx = randi([1 length( feasible_set_gains)],popsize,1);
par(:,23) = feasible_set_gains(indx);
%
indx = randi([1 length( feasible_set_gains)],popsize,1);
par(:,24) = feasible_set_gains(indx);
%
indx = randi([1 length( feasible_set_gains)],popsize,1);
par(:,25) = feasible_set_gains(indx);


Coords{1}=par;

for cnt = 1 : popsize
   
    genesForGA_Lissajous;
    
    simOut = sim('AWE_Testbed_07', 'CaptureErrors', 'on');
    
    if strcmp(simOut.ErrorMessage,'Simulation stopped because of a runtime error.')
        cost_vec(cnt) = NaN;
    else
        evaluateFitnessFunc;
        cost_vec(cnt)=F;
    end
    
end

[cost_vec,ind]=sort(cost_vec); % min cost in element 1
par=par(ind,:); % sort continuous

%% ************** START GENETIC ALGORITHM **************
runGeneticAlgorithm;
