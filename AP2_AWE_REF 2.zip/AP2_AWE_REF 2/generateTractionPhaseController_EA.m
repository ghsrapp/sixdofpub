function [x0_trim,u0_trim,K_long,K_lat, HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br] =  generateTractionPhaseController_EA( sim_with_indx )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;
save_flag = 0;

path_with_gains = 'Trim_results/case_1_test03';
addpath(path_with_gains);

load('G_save.mat');
load('rps_st.mat');
load('x0_save.mat');
load('u0_save.mat');
load('M_OB_init.mat');

[K_lat, K_long, A_tot, B_tot, Ks, A_long, A_lat, B_long, B_lat, B_long_wFt, Mx, Mu, A_lat_plus, B_lat_plus] = lqr_w_psi_wVa_test_decoupled(G_save{sim_with_indx});

%% Some step responses of the lateral controller
A_lat_cl = A_lat_plus - B_lat_plus * K_lat;
B_lat_cl = B_lat_plus.*0;
B_lat_cl(end-1, 1) = 1;
B_lat_cl(end,2) = 1;
sys_beta = ss( A_lat_cl, B_lat_cl, [1,0,0,0,0,0], [] );
sys_phi = ss( A_lat_cl, B_lat_cl, [0,1,0,0,0,0], [] );
tvec = 0 : 0.1 : 12;

opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
%% BETA
[y,t] = step(sys_beta,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,1)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t(:,:,1)./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\beta_a$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_beta');
    cd ..
end
%% PHI
[y,t] = step(sys_phi,tvec,opt);
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y(:,:,2)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\Phi_tau$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_phi');
    cd ..
end

Q = 0*eye(5); 
Q(1,1) = 0; 
Q(2,2) = 11;%11; %11; 
Q(3,3) = 0; 
Q(4,4) = 0.2;%0.2;%0.2; 
Q(5,5) = 10; 10;


Q = 0*eye(5); 
Q(1,1) = 0; 
Q(2,2) = 30;%5; 
Q(3,3) = 0; 
Q(4,4) = 0; 
Q(5,5) = 50;  % 100

R = 1; 
[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = test_simple_piecewise_L1_aug(A_long,B_long, Q, R);
K_long = Kbl;
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\alpha_a$ $(deg)$');
axis([0 12 0 12]);
damp(Am)
%%
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI');
    cd ..
end

% Trim states and inputs
x0_trim = x0_save(:,sim_with_indx);
u0_trim = u0_save(:,sim_with_indx);

