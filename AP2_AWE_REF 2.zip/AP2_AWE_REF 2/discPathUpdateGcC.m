function waypointsPath = discPathUpdateGcC(l_tether, r_d,latChoose, maxWidth,fWp)
r_SE = r_d / l_tether; % This is the radius on the small earth
t1 = linspace( 2*pi, pi , 10);
t2 = linspace( pi, 0 , 10);

longLeft = -asin(maxWidth/2 / (cos(latChoose)*l_tether) );
x_circle1 = r_SE * cos(t1);
y_circle1 = r_SE* sin(t1);

% Circle two
x_circle2 = r_SE * cos(t2);
y_circle2 = r_SE* sin(t2);
z_circle = zeros(1, length(x_circle1));
v_circ1 = [ x_circle1; y_circle1; z_circle] * l_tether;
v_circ2 = [ x_circle2; y_circle2; z_circle] * l_tether;

% First circle
M_NE_left = [-sin(latChoose)*cos(longLeft), -sin(latChoose)*sin(longLeft), cos(latChoose);
    -sin(longLeft), cos(longLeft), 0;
    -cos(latChoose)*cos(longLeft), -cos(latChoose)*sin(longLeft), -sin(latChoose)];
M_EN_left = M_NE_left';
v_circ_E1 = M_EN_left * v_circ1;

% This is important: Definitions of the center of the circle
deltaAngle = asin( r_SE );
s = cos(deltaAngle);
p_circO1_E =  s*[cos(longLeft)*cos(latChoose);...
    sin(longLeft)*cos(latChoose);...
    sin(latChoose)];

% Second circle
longRight = -longLeft;
M_NE_right = [-sin(latChoose)*cos(longRight), -sin(latChoose)*sin(longRight), cos(latChoose);
    -sin(longRight), cos(longRight), 0;
    -cos(latChoose)*cos(longRight), -cos(latChoose)*sin(longRight), -sin(latChoose)];

M_EN_right = M_NE_right';
v_circ_E2 = M_EN_right * v_circ2;

% This is important: Definitions of the center of the circle
p_circO2_E = s*[cos(longRight)*cos(latChoose);...
    sin(longRight)*cos(latChoose);...
    sin(latChoose)];

% Definition of the waypoints
left_top = [r_SE; 0; 0];
left_bottom = [-r_SE; 0; 0];
left_top_E = M_EN_left * left_top;
left_bottom_E = M_EN_left * left_bottom;
left_top_abs_E = p_circO1_E + left_top_E;
left_bottom_abs_E = p_circO1_E + left_bottom_E;

right_bottom = [-r_SE; 0; 0];
right_top = [r_SE; 0; 0];
right_bottom_E = M_EN_right * right_bottom;
right_bottom_abs_E = p_circO2_E + right_bottom_E;
right_top_E = M_EN_right * right_top;
right_top_abs_E = p_circO2_E + right_top_E;

% calculate normal vector
rot_vec_1 = cross( right_top_abs_E/norm(right_top_abs_E), left_bottom_abs_E/norm(left_bottom_abs_E));
rot_vec_7 = cross( left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));

%rot_vec_trans = cross( zenith_E/norm(zenith_E), left_top_abs_E/norm(left_top_abs_E));

% Calculate orthonormal basis that lies in the great circle plane:
e_x_1 = right_top_abs_E/norm(right_top_abs_E); e_z_1 = rot_vec_1/norm(rot_vec_1);e_y_1 = cross(e_z_1,e_x_1);
e_x_7 = left_top_abs_E/norm(left_top_abs_E); e_z_7 = rot_vec_7/norm(rot_vec_7);e_y_7 = cross(e_z_7,e_x_7);

% angle between the two waypoints
ang1 = acos( right_top_abs_E' * left_bottom_abs_E); % great circle is from 0 to ang1
t1 = linspace( 0, ang1, 10);
% angle between the two waypoints
ang2 = acos( left_top_abs_E' * right_bottom_abs_E); % great circle is from 0 to ang1
t2 = linspace( 0, ang2, 10);

% Plotting the great circles
M_GE_1 = [e_x_1'; e_y_1'; e_z_1'];
M_GE_7 = [e_x_7'; e_y_7'; e_z_7'];

great_circle_1_G_mod =   [cos(t1); sin(t1); zeros(1,length(t1))] * l_tether;
great_circle_7_G_mod =   [cos(t2); sin(t2); zeros(1,length(t1))] * l_tether;

great_circle_1_E = M_GE_1' * great_circle_1_G_mod;
great_circle_7_E = M_GE_7' * great_circle_7_G_mod;

% Save waypoints:
waypointsPath = [great_circle_7_E(:,2:end-1)';
    v_circ_E2'+repmat(p_circO2_E,1, length(v_circ_E2))'* l_tether;
    great_circle_1_E(:,2:end-1)';
    flip(v_circ_E1'+repmat(p_circO1_E,1, length(v_circ_E2))'* l_tether)];
waypointsPath = waypointsPath(1:fWp:end, :);

end