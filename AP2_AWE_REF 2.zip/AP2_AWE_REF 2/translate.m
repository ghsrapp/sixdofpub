function pts = translate(pts, pn, pe, pd)
pts = pts + repmat([pn;pe;pd], 1, size(pts,2));
end