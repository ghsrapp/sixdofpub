%% ====== Specifications of the path - Design parameters ==================
% In this script the flight path is specified.
% So far the path is specified as a figure of 8 flight path.
% The figure 8 is defined by the latitude (latChoose) of the origins of the circle
% segments, the radius of the circle segments (r_d) and the distance (maxWidth) between the
% the orgins of the two circle segments. In addition to that the maximum
% tether lenght can be specified (if reached this triggers the return
% phase), a minimum elevation angle, as well as the tuning parameters of
% the carrot following algorithm.


% For each figure example paths are provided. The parameters can of course
% be adjusted if desired.

l_tetherMax = 600; % maximum tether length

% Tuning Parameters for the pathfollowing algorithm
% Carrots
deltaVTCircle = -70*pi/180; %60*pi/180;%-20*pi/180; % move virtual target forward on circle segments (absolute value)
deltaVTGreatCircle = -5*pi/180;

wpSwitchBound =	10; % distance to waypoint (remains constant for all tether lengths!)
wpSwitchDistance = wpSwitchBound;

% Relative switch bound
switchWpRelBoundLatTop = 0.95;  % 10% of the latitude as switch area
switchWpRelBoundLongTop = 0.9;

switchWpRelBoundLongBottom = 0.7; % 10% of the longitude as switch area
switchWpRelBoundLatBottom = 0.7;

zenith_pos = [-sin(1*pi/180);0;cos(1*pi/180)]; % shouldn't be reached
reference_pos = [cos(40*pi/180);0;sin(40*pi/180)];

% Parking circle
latMinPark = 0; % Minimum latitude
latChoosePark = 55*pi/180; % Choose latitude of the circle origins
maxWidthPark = 0; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
r_dPark = 30;

switch figIndx
    case 1 % circle
        latMin = 0; % Minimum latitude
        latChoose = 30*pi/180; % Choose latitude of the circle origins
        maxWidth = 0; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 35; % This is the desired radius that the kite will fly
        deltaAlphaLeft = -20*pi/180; %60*pi/180;%-20*pi/180; % move virtual target forward on circle segments (absolute value)
        deltaAlphaRight = -deltaAlphaLeft;
        deltaGC = 0.2; % move virtual target forward on great circle (fraction)
        wpSwitchBound =	10; % distance to waypoint (remains constant for all tether lengths!)
        deltaVTCircle = deltaAlphaLeft;
        deltaVTGreatCircle = deltaGC;
        wpSwitchDistance = wpSwitchBound;
    case 2% fig 8 down in the middle
        latMin = 0; % Minimum latitude
        latChoose = 20*pi/180; % Choose latitude of the circle origins
        maxWidth =70;90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 20;     25; % 15 This is the desired radius that the kite will fly
        wpSwitchBound =	10; % distance to waypoint (remains constant for all tether lengths!)
        deltaVTCircle = -30*pi/180; -60*pi/180;
        deltaVTGreatCircle = -5*pi/180;
        wpSwitchDistance = wpSwitchBound;
    case 3 % TODO: not needed for 5
        latMin = 0; % Minimum latitude
        latChoose = 25*pi/180; % Choose latitude of the circle origins
        maxWidth = 90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % 15 This is the desired
    case 4 % TODO: not needed for 5
        latMin = 0; % Minimum latitude
        latChoose = 25*pi/180; % Choose latitude of the circle origins
        maxWidth = 90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % 15 This is the desired
    case 5 % Lemniscate
        latMin = 0; % Minimum latitude
        latChoose = 25*pi/180; % Choose latitude of the circle origins
        maxWidth = 90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % 15 This is the desired
    case 6 % Lemniscate
        latMin = 0; % Minimum latitude
        latChoose = 25*pi/180; % Choose latitude of the circle origins
        maxWidth = 90; % Total width of the figure of eight. Remember: that the kite only flies an 8 with this width if the tether lenght is higher or equal this value.
        r_d = 30; % 15 This is the desired
end


