% initializes the states of the simulator. 

l_tether = x0_sim(12);
Lbooth.init_sol = 2*pi;
windDirection_rad = ENVMT.windDirection_rad;
gamma_tau = 0;
vel_w_W = [12;0;0];
M_OW = [cos(windDirection_rad), sin(windDirection_rad), 0;
    sin(windDirection_rad), -cos(windDirection_rad), 0;
    0, 0, -1];
M_tauW = [-sin(lat_in)*cos(x0_sim(10)), -sin(lat_in)*sin(x0_sim(10)), cos(lat_in);
    -sin(x0_sim(10)), cos(x0_sim(10)), 0;
    -cos(lat_in)*cos(x0_sim(10)), -cos(lat_in)*sin(x0_sim(10)), -sin(lat_in)];
phi_t = x0_sim(4); theta_t = x0_sim(5); psi_t = x0_sim(6);
M_tauB = [ cos(psi_t)*cos(theta_t), cos(psi_t)*sin(phi_t)*sin(theta_t) - cos(phi_t)*sin(psi_t), sin(phi_t)*sin(psi_t) + cos(phi_t)*cos(psi_t)*sin(theta_t);
    cos(theta_t)*sin(psi_t), cos(phi_t)*cos(psi_t) + sin(phi_t)*sin(psi_t)*sin(theta_t), cos(phi_t)*sin(psi_t)*sin(theta_t) - cos(psi_t)*sin(phi_t);
    -sin(theta_t),                              cos(theta_t)*sin(phi_t),                              cos(phi_t)*cos(theta_t)];
M_OB = M_OW * M_tauW' * M_tauB;
M_BO = M_OB';
phi = atan2( M_OB(3,2) , M_OB(3,3) );
theta = -asin( M_OB(3,1) );
psi = atan2( M_OB(2,1) , M_OB(1,1) );
EULER_init = [phi;theta;psi];

params.a_booth = 0.5;
params.b_booth = 160;
params.phi0_booth =  30*pi/180;

vel_w_B = M_BO*M_OW*vel_w_W;
alpha = x0_sim(3);
beta = x0_sim(2);
Va = x0_sim(1);
M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
    -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
    -sin(alpha), 0, cos(alpha)];
M_BA = M_AB';
v_k_B_init = vel_w_B + M_BA*[Va;0;0];
v_k_O_init = M_OB*v_k_B_init;
v_a_O = v_k_O_init - transformFromWtoO( windDirection_rad, vel_w_W );
v_k_W_init = M_OW'*v_k_O_init;
pathangles_k_init(1) = atan2( v_k_O_init(2), v_k_O_init(1) );
pathangles_k_init(2) = -asin( v_k_O_init(3)/norm(v_k_O_init) );
chi_a = atan2( v_a_O(2), v_a_O(1) );
gamma_a = -asin( v_a_O(3)/norm(v_a_O) );
pathangles_a = [chi_a; gamma_a];
mu_a_init = asin( max( min( (cos(EULER_init(2))*sin(EULER_init(1)))/(cos(gamma_a)*cos(0)) + tan(gamma_a) * tan(0), 1),-1) );
