%% MRAC 
% Learning rate: 
gamma_x_course = 40; 
gamma_r_course = 10; 
gamma_eff = 50;
gamma_d = 50; 
A_ref_MRAC_course = 40; 
K_luenberger = 20*A_ref_MRAC_course ; 
