clear all
%close all
clc
LMI_LQR_flag = 0; % for the lateral controller
sim_with_indx = 1;
min_trim_indx = 1;
max_trim_indx = 11;

Simulink.sdi.clear;
trim_test_flag = 0;

trim_test_retraction = 0;

robustness_analysis_flag = 0;
step_response_flag = 0 ;

EA_Flag = 1;
get_controller_set_flag = 0;
opt_flag = 1;
converged_flag = 0;
addpath(genpath('MiscFiles'))
addpath(genpath('sdpt3-master'));
addpath(genpath('YALMIP-master'));

addpath(genpath('AWESTRIM'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))
s = [pi/2, 2*pi];

opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');

% ============== Initialize the simulation ==================================================================================================
path_with_gains = 'Trim_results/case_1_test03'; % works with these models
%path_with_gains = 'Trim_results/case_1_ft_18kN_alpha4deg'; % works with these models
%path_with_gains = 'Trim_results/case_1_phi35_mix_ft_and_alpha';
% path_with_gains = 'Trim_results/case_1_ft16kN_dense_alpha';
%path_with_gains = 'Trim_results/case_1_ft14kN_dense_alpha';

addpath(path_with_gains);

load('G_save.mat');
load('rps_st.mat');
load('x0_save.mat');
load('u0_save.mat');
load('M_OB_init.mat');

sim_with_indx = 2; %min_trim_indx;   % 2;
x0_sim = x0_save(:,sim_with_indx);
u0_sim = u0_save(:,sim_with_indx);

if trim_test_flag % for trim test
    lat_in = x0_sim(11); %80*pi/180;
else
    lat_in = 80*pi/180; %
end
% Initialze position at higher elevation angles.

x0_sim(11) = lat_in;
x0_sim(12) = 300;

pos_init_W = [cos( x0_sim(10) ) * cos( lat_in );
    sin( x0_sim(10) ) * cos( lat_in );
    sin( lat_in )]*x0_sim(12);


[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams_variable_p_init_W(pos_init_W);

opt_cnt = 1;

% bounds for longi PI-LQR
qs = [0, 30, 0, 0, 50];
qs = [30,0,0,50];
qs_lbounds = 0*ones( length( qs ),1);
qs_lbounds(end) = 1;
qs_ubounds = 100*ones( length( qs ),1);
Q_long = diag( [0, qs] );
R_long = 1;

% bounds
% T_R_Des = opt_params(1); % Rolltime constant
% T_S_Des = opt_params(2); %1/5; %1/w0s(end); % spiral mode
% zeta_DR_des = opt_params(3); %1/sqrt(2);
% w0_DR_des = opt_params(4); %w0s(2);

lat_low_bounds = [1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3];
lat_up_bounds = [10; 10; 1; 10; 10; 10];
lat_p_init = [0.04; 1/5; 1/sqrt(2); 3.86;4;4];
cnt = 1;
[time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();


% load([path_with_gains,'/list_old_individuals.mpat']);
% [val,idx] = min( list_old_individuals(end,:) );
% qs = list_old_individuals( 1 : 4 , idx );
qs = [30,0,0,50]';
Q_long = diag( [0; qs] );
R_long = 1;
% sim_with_indx = 2;

if 1 % another trim state at higher angles of attack
    sim_with_indx = 5;
    path_with_gains = 'Trim_results/case_1_16kN20kN_alpha4and7and10';
end


if LMI_LQR_flag
    %% Multimodell Lat Traction (Lets better call it LMI based solution), I think that is clearer
    [A_s, B_s] = setUpLTIs_Lat( path_with_gains, [1,3,5,7,9] );
    qs = [0,0,0,0,60,60]; 80; % works together with 1.6/2.0 for all windspeeds
    Q_lat = diag( qs );
    R_lat = eye(2);
    K_lat = calcMMLQR( A_s, B_s, Q_lat, R_lat );
else % ESA lat controller
    [x0_trim,u0_trim,K_long,K_lat, A_long, B_long, A_lat, B_lat] =  generateTractionPhaseController( sim_with_indx, EA_Flag, act, path_with_gains,  Q_long, R_long );
end

%  [stabmarg, CL] = getRobStabMargin_long( A_long, B_long,K_long, [0,1,0,0,0], opts, frequ_domain_ref_long);
%  s = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);

%     [stabmarg, CL,info] = getRobStabMargin_lat( A_lat, B_lat,K_lat, [1,0,0,0,0,0;0,1,0,0,0,0 ], opts, frequ_domain_ref_lat);
%     s = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
%   figure;
%  step( CL.NominalValue );

%% With additional plant models lateral
n_MC = 1000;
%indx_vec = 1:4; % working solution: lower angles of attack
indx_vec = [1,3,5,7,9]; % high angle of attack solution
%path_name = 'Trim_results/case_1_ft16kN20kN_alpha2and8/'; % working solution: lower angles of attack
path_name = 'Trim_results/case_1_16kN20kN_alpha4and7and10/';
%%
if robustness_analysis_flag
    for ii = 1 : length(indx_vec)
        k = indx_vec(ii);
        close all
        alpha_lvl = 0.2;
        lw = 1;
        
        %x0_tmp_trim = load( [ 'Trim_results/case_1_ft16kN20kN_alpha2and8/x0_save' ] );
        %u0_tmp_trim = load( [ 'Trim_results/case_1_ft16kN20kN_alpha2and8/u0_save' ] );
        
        x0_tmp_trim = load( [ path_name,'x0_save' ] );
        u0_tmp_trim = load( [ path_name, 'u0_save' ] );
        

        %[A_s, B_s] = setUpLTIs_Lat( 'Trim_results/case_1_ft16kN20kN_alpha2and8', indx_vec );
        [A_s, B_s] = setUpLTIs_Lat( path_name, indx_vec );
        
        [stabmarg, CL] = getRobStabMargin_lat( A_s(:,:,ii),  B_s(:,:,ii),K_lat, [1,0,0,0,0,0;0,1,0,0,0,0 ], opts, frequ_domain_ref_lat);
        fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,k), x0_tmp_trim.x0_save(3,k)*180/pi, x0_tmp_trim.x0_save(1,k), stabmarg.LowerBound, stabmarg.UpperBound);
        [rt_beta_95(ii,:), os_beta_95(ii,:), st_beta_95(ii,:), rt_phi_95(ii,:), os_phi_95(ii,:), st_phi_95(ii,:), beta_induced_95(ii),...
            rt_beta_nom(ii), rt_phi_nom(ii), os_beta_nom(ii), os_phi_nom(ii), st_beta_nom(ii), st_phi_nom(ii), beta_induced_nom(ii)] = ...
            drawStepResponseLateral(CL, 0, ['beta_EA_lat_trac_',num2str(ii)], ['phi_EA_lat_trac_',num2str(ii)], alpha_lvl, lw, n_MC);
    end
    
    indx_ = [2, 5, 3, 1, 4];
    round(rt_beta_95(indx_,:)',2)
    round(os_beta_95(indx_,:)',2)
    round(st_beta_95(indx_,:)',2)
    round(rt_phi_95(indx_,:)',2)
    round(os_phi_95(indx_,:)',2)
    round(st_phi_95(indx_,:)',2)
    round(beta_induced_95(indx_),2)
    disp('Nominal:')
    round(rt_beta_nom(indx_),2)
    round(os_beta_nom(indx_),2)
    round(st_beta_nom(indx_),2)
    round(rt_phi_nom(indx_),2)
    round(os_phi_nom(indx_),2)
    round(st_phi_nom(indx_),2)
    round(beta_induced_nom(indx_),2)
end
%%
if 1 % For frequency domain analysis
    [G_dFt_to_beta, G_dFt_to_beta_unc, So_lat, To_lat ] = getTransferfunctionFromFt_to_beta( path_name, indx_vec, K_lat );
end
%[G_dFt_to_beta, G_dFt_to_beta_unc, So_lat, To_lat ] = getTransferfunctionFromFt_to_beta(  'Trim_results/case_1_ft16kN20kN_alpha2and8', 1:4, K_lat );
if 0
    
    close all
    j = 5;
    [stabmarg, CL] = getRobStabMargin_lat( A_lat, B_lat,K_lat, [1,0,0,0,0,0;0,1,0,0,0,0 ], opts, frequ_domain_ref_lat);
    fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_trim(4), x0_trim(3)*180/pi, x0_trim(1), stabmarg.LowerBound, stabmarg.UpperBound);
    [rt_beta_95(5,:), os_beta_95(5,:), st_beta_95(5,:), rt_phi_95(5,:), os_phi_95(5,:), st_phi_95(5,:), beta_induced_95(5),...
        rt_beta_nom(5), rt_phi_nom(5), os_beta_nom(5), os_phi_nom(5), st_beta_nom(5), st_phi_nom(5), beta_induced_nom(5)] = ...
        drawStepResponseLateral(CL, 0, 'beta_EA_lat_trac_designPoint', 'phi_EA_lat_trac_designPoint', alpha_lvl, lw, n_MC);
    
    [G_dFt_to_beta_, G_dFt_to_beta_unc_, So_, To_ ] = getTransferfunctionFromFt_to_beta(  'Trim_results/case_1_phi35_mix_ft_and_denser_alpha', 83, K_lat );
    G_dFt_to_beta{j} = G_dFt_to_beta_{1};
    G_dFt_to_beta_unc{j} = G_dFt_to_beta_unc_{1};
    So_lat{j} = So_{1};
    To_lat{j} = To_{1};
    
    % order from lowest to highest airspeed
    indx = [2, 4, 5, 1, 3]; % working example
    
end

if 0 % this is the correct one
    close all; 
    indx = [2, 5, 3, 1, 4];
    drawFrequencyDomainStuff_Lat(indx,  G_dFt_to_beta, G_dFt_to_beta_unc,So_lat,To_lat, 0, 'beta_LMI_lat_trac_designPoint');
end

if robustness_analysis_flag
    rt_beta_95 = rt_beta_95( indx );
    os_beta_95 = os_beta_95( indx );
    st_beta_95 = st_beta_95( indx );
    
    rt_phi_95 = rt_phi_95( indx );
    os_phi_95 = os_phi_95( indx );
    st_phi_95 = st_phi_95( indx );
    
    beta_induced_95 = beta_induced_95( indx );
    
    rt_beta_nom = rt_beta_nom( indx );
    rt_phi_nom = rt_phi_nom( indx );
    
    os_beta_nom = os_beta_nom( indx );
    os_phi_nom = os_phi_nom( indx );
    
    st_beta_nom = st_beta_nom( indx );
    st_phi_nom = st_phi_nom( indx );
    
    beta_induced_nom = beta_induced_nom( indx );
end

%% Multimodel LQR
%sim_with_indx_vec = 1:4;%[8,11,14,17]; [2,14];%[7,12]; % working example
%path2models = 'Trim_results/case_1_ft16kN20kN_alpha2and8'; % working example

%path2models = 'Trim_results/case_1_phi35_mix_ft_and_alpha';
% path2models = 'Trim_results/case_1_16kN18kN_alpha2and8';
%path2models = 'Trim_results/case_1_14kN20kN_alpha2and8';


%% ===================== Longitudional controller LQR and LMI LQR =====================

path2models = 'Trim_results/case_1_16kN20kN_alpha4and7and10/';
path2models = 'Trim_results/case_1_dense_grid/';
sim_with_indx_vec = 1 : 54; 
%sim_with_indx_vec  = [1,3,5,7,9];


[A_s, B_s, C_s] = setUpLTIs_Long( path2models, sim_with_indx_vec );

save_flag = 0;
close all;
%%
for k = 2
    if k  == 1
        qs = [30,0,0.6,45]; % single model LQR
    else
        qs = [30,0,0.6,60]; % multi model LQR revised ( not tested in nonlinear sim): 2 and 8 angle of attack
        %qs = [30,0,0.5,60]; % working example
    end
    Q_long = diag( [0, qs] );
    R_long = 3; % single model LQR
    
    % around
    % working example
    %path_with_gains =   path2model; %'Trim_results/case_1_ft16kN20kN_alpha2and8';
    %sim_with_indx = 1:4;
    % higher angle of attack
    path_with_gains = path2models;
    sim_with_indx  = sim_with_indx_vec;%1,3,5,7,9]; % design point is 3:
    
    
    [A_s, B_s, C_s] = setUpLTIs_Long( path_with_gains, sim_with_indx );
    
    % middle
    if 0
        path_with_gains = 'Trim_results/case_1_phi35_mix_ft_and_denser_alpha';
        sim_with_indx = 83;
    end
    if k>1% add to multiple model plant description
        % [A_s(:,:,5), B_s(:,:,5), C_s(:,:,5)] = setUpLTIs_Long( path_with_gains, sim_with_indx );
    else
        sim_with_indx = 5; % thats the middle of the interval
        [A_s, B_s, C_s] = setUpLTIs_Long( path_with_gains, sim_with_indx );
    end
    K_MM_LQR = calcMMLQR( A_s, B_s, Q_long, R_long );
    K_long = K_MM_LQR;
    
    
    K_long_save{k} = K_MM_LQR;
    % Design point
    if k > 1
        designPoint = 3;
    else
        designPoint = 1;
    end
    if robustness_analysis_flag
        % Check performance at the design point
        [stabmarg_MM, CL] = getRobStabMargin_long( A_s(:,:,designPoint), B_s(:,:,designPoint),K_MM_LQR, [0,1,0,0,0], opts, frequ_domain_ref_long);
        stabmarg_MM_save{k} = stabmarg_MM;
        si{k} = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
        % close all;
        %step( CL.NominalValue );
    end
    if step_response_flag
        name_alpha = 'nominal_step_MvsSLQR';
        opt = stepDataOptions;
        opt.StepAmplitude = 10*pi/180;
        tvec = 0 : 0.1 : 12;
        [y,t] = step(CL.NominalValue,tvec,opt);
        col1 =  [ 57/255, 106/255, 177/255  ];
        col2 =  [218/255, 124/255, 48/255 ];
        col3 =  [62/255, 150/255, 81/255 ];
        col4 =  [255/255, 102/255, 102/255];
        if k == 1
            h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
            ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', lw, 'color', col1); hold on
        else
            ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', lw, 'color', col3); hold on
        end
        plot( t, t./t*10, '--', 'Linewidth', 1.2, 'color', col2); hold on
        axis([0 6 0 12]); hold on
        yticks([0 2 4 6 8 10 12])
        box on ;
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
    end
end
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,name_alpha);
    cd ..
end
%%
% Stability / Robustness analysis LQR and LMI LQR
n_MC = 100;
%
% Choose controller:
idx_chosen = 2; % 1 is LQR 2 is LMI based LQR
fprintf('Chosen longitudional controller: %.02f\n', idx_chosen);
%K_MM_LQR =  K_long_save{1}; % 2 is the MLQR, 1 is the SLQR
K_long = K_long_save{idx_chosen};

%path_with_gains = path2models;

%% Select the operating points / SS models that you would like to use to test the controller
sim_with_indx  = [1,3,5,7,9];
path_with_gains = 'Trim_results/case_1_16kN20kN_alpha4and7and10/';
% you can specify here a different path then the one you used to design the controller
indx_vec = sim_with_indx;
if robustness_analysis_flag
    for j = 1 : 1 : length(sim_with_indx)
        close all
        alpha_lvl = 0.2;
        lw = 1;
        k = indx_vec(j);
        
        %        [G_dFt_to_alphac, G_dFt_to_alphac_unc, So, To, gm,pm ]  = getTransferfunctionFromFt_to_alphac( 'Trim_results/case_1_ft16kN20kN_alpha2and8', 1:4, K_long );
       % [G_dFt_to_alphac, G_dFt_to_alphac_unc, So, To, gm,pm ]  = getTransferfunctionFromFt_to_alphac(path_with_gains, sim_with_indx, K_long );
        
        
        %x0_tmp_trim = load( [ 'Trim_results/case_1_ft16kN20kN_alpha2and8/x0_save' ] ); % working example
        %u0_tmp_trim = load( [ 'Trim_results/case_1_ft16kN20kN_alpha2and8/u0_save' ] ); % working example
        
        x0_tmp_trim = load( [ path_with_gains,'/x0_save' ] );
        u0_tmp_trim = load( [ path_with_gains,'/u0_save' ] );
        
        %        [A_s, B_s] = setUpLTIs_Long( 'Trim_results/case_1_ft16kN20kN_alpha2and8', 1:4 );
        [A_s, B_s] = setUpLTIs_Long( path_with_gains, sim_with_indx );
        
        [stabmarg_MM, CL] = getRobStabMargin_long( A_s(:,:,j), B_s(:,:,j),K_long, [0,1,0,0,0], opts, frequ_domain_ref_long);
        %        fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,j), x0_tmp_trim.x0_save(3,j)*180/pi, x0_tmp_trim.x0_save(1,j), stabmarg_MM.LowerBound, stabmarg_MM.UpperBound);
        fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,k), x0_tmp_trim.x0_save(3,k)*180/pi, x0_tmp_trim.x0_save(1,k), stabmarg_MM.LowerBound, stabmarg_MM.UpperBound);
        stabmarg_MM_save(j,:) = [stabmarg_MM.LowerBound, stabmarg_MM.UpperBound, stabmarg_MM.CriticalFrequency];
        if idx_chosen == 1
            name_file = 'alpha_sm_Slqr_long_trac_';
        else
            name_file = 'alpha_sm_Mlqr_long_trac_';
            name_file = 'LMI_long_trac_54pts_analysed_at_thesisPts';
        end
        % second input is plot yes/no
        [rt_alpha_95(j,:), os_alpha_95(j,:), st_alpha_95(j,:),...
            rt_alpha_nom(j),os_alpha_nom(j), st_alpha_nom(j)] = ...
            drawStepResponseLong(CL, 1, [name_file,num2str(j)], alpha_lvl, lw, n_MC);
    end
end
if 0
    visualizeStabMargins( stabmarg_MM_save,u0_tmp_trim,x0_tmp_trim, 'va_alpha_lbSSV' );
end

indx = [2, 5, 3, 1, 4]; % working example

close all;
if 0 % only for the low angle of attack range
    j = 5;
    [G_dFt_to_alphac_ , G_dFt_to_alphac_unc_, So_, To_, gm_,pm_ ]  = getTransferfunctionFromFt_to_alphac( 'Trim_results/case_1_phi35_mix_ft_and_denser_alpha', 83, K_long );
    G_dFt_to_alphac{j} = G_dFt_to_alphac_{1};
    G_dFt_to_alphac_unc{j} = G_dFt_to_alphac_unc_{1};
    So{j} = So_{1};
    To{j} = To_{1};
    gm(j) = gm_;
    pm(j) = pm_;
    
    % Design point:
    x0_tmp_trim = load( [ 'Trim_results/case_1_phi35_mix_ft_and_denser_alpha/x0_save' ] );
    u0_tmp_trim = load( [ 'Trim_results/case_1_phi35_mix_ft_and_denser_alpha/u0_save' ] );
    sim_with_indx = 83;
    [A_s, B_s] = setUpLTIs_Long(path_with_gains, sim_with_indx );
    [stabmarg_MM, CL] = getRobStabMargin_long( A_s(:,:,1), B_s(:,:,1),K_MM_LQR, [0,1,0,0,0], opts, frequ_domain_ref_long);
    fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,sim_with_indx), x0_tmp_trim.x0_save(3,sim_with_indx)*180/pi, x0_tmp_trim.x0_save(1,sim_with_indx), stabmarg_MM.LowerBound, stabmarg_MM.UpperBound);
    if idx_chosen == 1
        name_file = 'alpha_sm_Slqr_long_trac_design';
    else
        name_file = 'alpha_sm_Mlqr_long_trac_design';
    end
    [rt_alpha_95(j,:), os_alpha_95(j,:), st_alpha_95(j,:),...
        rt_alpha_nom(j),os_alpha_nom(j), st_alpha_nom(j)] = ...
        drawStepResponseLong(CL, 0,name_file, alpha_lvl, lw, n_MC);
end
indx = [2, 4, 5, 1, 3];  % working

if 0
    drawFrequencyDomainStuff(indx,  G_dFt_to_alphac, G_dFt_to_alphac_unc,So,To, 0, name_file);
end
indx = [2, 5, 3, 1, 4]; % high angle of attack
if robustness_analysis_flag
    rt_alpha_95 = rt_alpha_95( indx );
    os_alpha_95 = os_alpha_95( indx );
    st_alpha_95 = st_alpha_95( indx );
    
    rt_alpha_nom = rt_alpha_nom( indx );
    os_alpha_nom = os_alpha_nom( indx );
    st_alpha_nom = st_alpha_nom( indx );
end

%% ================ Let's do the retraction controller synthesis dance. ================================================================
sim_with_indx = 1;
sim_with_indx_vec = 1:3;

% Lateral
%path_with_gains = 'Trim_results/retr_trim_case_1_20mDs_m3Andm1deg_gamma_m10';
%path_with_gains = 'Trim_results/retr_trim_case_1_125mDs_m4Andm3deg_gamma_m75';
path_with_gains = 'Trim_results/retr_trim_case_1_125mDs_m4m35m3deg_gamma_m75';
[A_s, B_s, x0_retract_s, u0_retract_s] = setUpLTIs_Lat( path_with_gains, sim_with_indx_vec );

if ~LMI_LQR_flag
    [K_lat_retract,x0_retract, u0_retract] =  generateRetractionLateralController( 2, path_with_gains );
    x0_trim_retract = x0_retract(:, 2);
    u0_trim_retract = u0_retract(:, 2);
else
    % Lateral (MM LQR)
    x0_trim_retract = x0_retract_s(:, sim_with_indx_vec(1));
    u0_trim_retract = u0_retract_s(:, sim_with_indx_vec(1));
    Q_lat = eye( 4 );
    Q_lat(1,1) = 1;
    Qi_lat = 1*diag([50,50]);
    Qs_lat = mdiag(Q_lat,Qi_lat);
    R_lat = 2*2*diag([3,1]);%2
    K_MM_LQR = calcMMLQR( A_s, B_s, Qs_lat, R_lat );
    K_lat_retract = K_MM_LQR;
    
    %    [stabmarg_MM_lat, CL_lat_r] = getRobStabMargin_lat( A_s(:,:,1), B_s(:,:,1),K_MM_LQR, [1,0,0,0,0,0; 0, 1, 0, 0, 0,0], opts, frequ_domain_ref_lat);
    %   s = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
    
    %  figure;
    %  step( CL_lat_r );
    %% Hinf based design
    if 0
        [K1_red, K1] = hinf_design_lateral_V2( A_s(1:4,1:4,1),  B_s(1:4,:,1), K_lat_retract );
    end
end
n_vertices = 3;
if robustness_analysis_flag
    %     [A_s, B_s] = setUpLTIs_Lat( path_with_gains, sim_with_indx_vec );
    %     [stabmarg, CL_lat_r] = getRobStabMargin_lat( A_s(:,:,2), B_s(:,:,2),K_lat_retract, [1,0,0,0,0,0; 0, 1, 0, 0, 0,0], opts, frequ_domain_ref_long);
    %     s_lat_r = stepinfo(CL_lat_r.NominalValue,'RiseTimeLimits',[0,0.95]);
    %%
    n_MC = 1000;
    for ii = 1 : n_vertices
        close all;
        [stabmarg, CL] = getRobStabMargin_lat( A_s(:,:,ii),  B_s(:,:,ii),K_lat_retract, [1,0,0,0,0,0; 0, 1, 0, 0, 0,0], opts, frequ_domain_ref_lat);
        x0_tmp_trim = load( [ path_with_gains,'/x0_save' ] );
        u0_tmp_trim = load( [ path_with_gains,'/u0_save' ] );
        fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,ii), x0_tmp_trim.x0_save(3,ii)*180/pi, x0_tmp_trim.x0_save(1,ii), stabmarg.LowerBound, stabmarg.UpperBound);
        [rt_beta_95(ii,:), os_beta_95(ii,:), st_beta_95(ii,:), rt_phi_95(ii,:), os_phi_95(ii,:), st_phi_95(ii,:), beta_induced_95(ii),...
            rt_beta_nom(ii), rt_phi_nom(ii), os_beta_nom(ii), os_phi_nom(ii), st_beta_nom(ii), st_phi_nom(ii), beta_induced_nom(ii)] = ...
            drawStepResponseLateral(CL, 0,['beta_EA_lat_retrac_',num2str(ii)], ['phi_EA_lat_retrac_',num2str(ii)], alpha_lvl, lw, n_MC);
    end
    %
    indx_ = n_vertices : -1 : 1;
    round(rt_beta_95(indx_,:)',2)
    round(os_beta_95(indx_,:)',2)
    round(st_beta_95(indx_,:)',2)
    round(rt_phi_95(indx_,:)',2)
    round(os_phi_95(indx_,:)',2)
    round(st_phi_95(indx_,:)',2)
    round(beta_induced_95(indx_),2)
    
    round(rt_beta_nom(indx_),2)
    round(os_beta_nom(indx_),2)
    round(st_beta_nom(indx_),2)
    round(rt_phi_nom(indx_),2)
    round(os_phi_nom(indx_),2)
    round(st_phi_nom(indx_),2)
    round(beta_induced_nom(indx_),2)
    
    %
    close all;
    [G_dFt_to_beta, G_dFt_to_beta_unc, So_lat, To_lat ] = getTransferfunctionFromFt_to_beta( path_with_gains, indx_, K_lat_retract );
    drawFrequencyDomainStuff_Lat(indx_,  G_dFt_to_beta, G_dFt_to_beta_unc,So_lat,To_lat, 0, 'beta_LMI_lat_retrac_designPoint');
    
end

%% Longitudinal (MM LQR) Retraction
%sim_with_indx_vec = 1:2;
[A_s, B_s, C_s] = setUpLTIs_Long( path_with_gains, sim_with_indx_vec );

% This set works
Q_long(1,1) = 0;
Q_long(2,2) = 90;
Q_long(3,3) = 0;
Q_long(4,4) = 0.2;
Q_long(5,5) = 50;
R_long = 3;
%% retune
close all;
Q_long(1,1) = 0;
Q_long(2,2) = 15;
Q_long(3,3) = 0;
Q_long(4,4) = 0;
Q_long(5,5) = 40;
R_long = 1.1; % 1
K_MM_LQR = calcMMLQR( A_s, B_s, Q_long, R_long );

if robustness_analysis_flag
    %%
    save_flag = 0;
    n_vertices = 3;
    n_MC = 100;
    alpha_lvl = 0.2;
    lw = 1;
    name_file = 'alpha_sm_Mlqr_long_retrac_';
    for ii = 1 : n_vertices
        close all;
        [stabmarg, CL] = getRobStabMargin_long( A_s(:,:,ii),  B_s(:,:,ii),K_MM_LQR, [0,1,0,0,0], opts, frequ_domain_ref_long);
        x0_tmp_trim = load( [ path_with_gains,'/x0_save' ] );
        u0_tmp_trim = load( [ path_with_gains,'/u0_save' ] );
        fprintf('Trim-point: ft=%.2f alpha=%.2f va=%.2f Stab margin: lb=%.2f ub=%.2f\n', u0_tmp_trim.u0_save(4,ii), x0_tmp_trim.x0_save(3,ii)*180/pi, x0_tmp_trim.x0_save(1,ii), stabmarg.LowerBound, stabmarg.UpperBound);
        [rt_alpha_95(ii,:), os_alpha_95(ii,:), st_alpha_95(ii,:),...
            rt_alpha_nom(ii),os_alpha_nom(ii), st_alpha_nom(ii)] = ...
            drawStepResponseLong(CL, save_flag,[name_file,num2str(ii)], alpha_lvl, lw, n_MC);
    end
    close all
    indices = n_vertices : -1 : 1;
    [G_dFt_to_alphac, G_dFt_to_alphac_unc, So, To, gm,pm ]  = getTransferfunctionFromFt_to_alphac(path_with_gains, indices, K_MM_LQR );
    drawFrequencyDomainStuff(indices,  G_dFt_to_alphac, G_dFt_to_alphac_unc,So,To, save_flag, name_file);
end
%%

%%
K_long_retract = K_MM_LQR;
%% Hinf based design
if 0
    [K1_red_long, K1] = hinf_design_long_V2(  A_s(1:4,1:4,1), B_s(1:4,:,1), K_long_retract );
end


%%
% if trim_test_retraction
%     vel_w_W = [12.5;0;0];
%     lat_init = x0_trim_retract(end-1);
%     long_init = x0_trim_retract(end-2);
%     pos_init_W = [cos(long_init)*cos(lat_init); sin(long_init)*cos(lat_init); sin(lat_init)]*x0_trim_retract(end);
%     pos_init_O = M_OW*pos_init_W;
%     ad_flag = 0;
%     close all;
%     yout = sim('AWES3_Retraction_Test_CL','ReturnWorkspaceOutputs','on');
% else
%     %    x0_sim = x0_trim;
%
%     l_tether = x0_sim(12);
%     Lbooth.init_sol = s(sim_with_indx);
%     windDirection_rad = ENVMT.windDirection_rad;
%     gamma_tau = 0;
%     vel_w_W = [9;0;0];
%     M_OW = [cos(windDirection_rad), sin(windDirection_rad), 0;
%         sin(windDirection_rad), -cos(windDirection_rad), 0;
%         0, 0, -1];
%     M_tauW = [-sin(lat_in)*cos(x0_sim(10)), -sin(lat_in)*sin(x0_sim(10)), cos(lat_in);
%         -sin(x0_sim(10)), cos(x0_sim(10)), 0;
%         -cos(lat_in)*cos(x0_sim(10)), -cos(lat_in)*sin(x0_sim(10)), -sin(lat_in)];
%     phi_t = x0_sim(4); theta_t = x0_sim(5); psi_t = x0_sim(6);
%     M_tauB = [ cos(psi_t)*cos(theta_t), cos(psi_t)*sin(phi_t)*sin(theta_t) - cos(phi_t)*sin(psi_t), sin(phi_t)*sin(psi_t) + cos(phi_t)*cos(psi_t)*sin(theta_t);
%         cos(theta_t)*sin(psi_t), cos(phi_t)*cos(psi_t) + sin(phi_t)*sin(psi_t)*sin(theta_t), cos(phi_t)*sin(psi_t)*sin(theta_t) - cos(psi_t)*sin(phi_t);
%         -sin(theta_t),                              cos(theta_t)*sin(phi_t),                              cos(phi_t)*cos(theta_t)];
%     M_OB = M_OW * M_tauW' * M_tauB;
%     M_BO = M_OB';
%     phi = atan2( M_OB(3,2) , M_OB(3,3) );
%     theta = -asin( M_OB(3,1) );
%     psi = atan2( M_OB(2,1) , M_OB(1,1) );
%     EULER_init = [phi;theta;psi];
%
%     params.a_booth = 0.5; % 0.6
%     params.b_booth = 160; % 200 also fine
%     params.phi0_booth =  30*pi/180;
%
%     vel_w_B = M_BO*M_OW*vel_w_W;
%     alpha = x0_sim(3);
%     beta = x0_sim(2);
%     Va = x0_sim(1);
%     M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
%         -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
%         -sin(alpha), 0, cos(alpha)];
%     M_BA = M_AB';
%     v_k_B_init = vel_w_B + M_BA*[Va;0;0];
%     v_k_O_init = M_OB*v_k_B_init;
%     v_a_O = v_k_O_init - transformFromWtoO( windDirection_rad, vel_w_W );
%     v_k_W_init = M_OW'*v_k_O_init;
%     pathangles_k_init(1) = atan2( v_k_O_init(2), v_k_O_init(1) );
%     pathangles_k_init(2) = -asin( v_k_O_init(3)/norm(v_k_O_init) );
%     chi_a = atan2( v_a_O(2), v_a_O(1) );
%     gamma_a = -asin( v_a_O(3)/norm(v_a_O) );
%     pathangles_a = [chi_a; gamma_a];
%     mu_a_init = asin( max( min( (cos(EULER_init(2))*sin(EULER_init(1)))/(cos(gamma_a)*cos(0)) + tan(gamma_a) * tan(0), 1),-1) );
%
%     %
%     Phi_traction_vec = 30*pi/180;%[30, 40]*pi/180;
%     Ft_set_vec = 1800;%[800,1300,1800];
%     base_windspeed_vec = 8;%[4, 7, 10]; %[4,10];
%     adaptive_controller_flag_vec = 0;
%     cnt = 1;
%     cnta = 1;
%     params_mat = [];
%
%     if trim_test_flag
%         phi_trac = x0_trim(11);
%         ad_flag = 0;
%         Ft_set = u0_trim(4);
%         base_windspeed = 10;
%         close all;
%         Ft_vec = 1800;%1600 : 400 : 2000;
%         %Ft_test_set = 1800;
%         yout_mat = [];
%          mean_elevation = 35*pi/180;
%         for j = 1 : length( Ft_vec )
%             Ft_test_set = Ft_vec(j);
%             params.a_booth = 0.5; % 0.5 and 2
%             params.b_booth = 120; % 80 and 200  or 120 for high wind
%             yout = sim('AWES3_CL_BL_designModelTraction','ReturnWorkspaceOutputs','on');
%             yout_mat = [yout_mat,yout];
%         end
%         % analysis
%         save_flag = 1;
%        % plotResultsTractionPhaseDesignModel( yout_mat, save_flag, 'high_wind_', mean_elevation );
%       %  plotResultsParameterAnalysis( yout_mat, save_flag, 'low_wind_high_elevation_', mean_elevation);
%         plotResultsParameterAnalysis( yout_mat, save_flag, 'high_wind_lowAlowB_', mean_elevation);
%
%     else
%         for n = 1 : length( adaptive_controller_flag_vec )
%             ad_flag = adaptive_controller_flag_vec(n);
%             for k = 1 : length( Phi_traction_vec )
%                 phi_trac = Phi_traction_vec(k);
%                 for l = 1 : length( Ft_set_vec )
%                     Ft_set = Ft_set_vec(l);
%                     for z = 1 : length( base_windspeed_vec )
%                         base_windspeed = base_windspeed_vec(z);
%                         %break;
%                         ad_flag = 0;
%                         close all;
%                         base_windspeed  = 4;
%                         fprintf('Simulation running...');
%                         pause;
%
%                         if 0 % full sim
%                             yout = sim('AWES3_CL_wTether_v3','ReturnWorkspaceOutputs','on');
%                         else % only points mass
%                             yout_mat = [];
%                             base_wind_vec = [4,9]
%                             complex_tether_flag_vec = [1];
%                             for mm = 1 : length(complex_tether_flag_vec)
%                                 for kk = 1 : length(base_wind_vec)
%                                     complex_tether_flag = complex_tether_flag_vec(mm);
%                                     base_windspeed = base_wind_vec(kk);
%                                     yout = sim('AWES3_CL_wTether_v3_PM','ReturnWorkspaceOutputs','on');
%                                     yout_mat = [yout_mat,yout];
%                                     kk
%                                 end
%                             end
%                             save_flag = 1;
%                             plotResultsPM( yout_mat, save_flag, 'pointmass_', 30*pi/180);
%                         end
%
%                         if ad_flag == 0
%                             yout_baseline{cnt} = yout;
%                             fprintf('Done %.1f \n', cnt );
%                             cnt = cnt + 1;
%                         else
%                             yout_adaptive{cnta} = yout;
%                             fprintf('Adaptive sim done %.1f \n', cnta );
%                             cnta = cnta + 1;
%                         end
%                         params_mat = [params_mat; [ad_flag, phi_trac*180/pi, Ft_set/1000, base_windspeed]];
%                     end
%                 end
%             end
%         end
%         %%
%         close all;
%         folder_name_results = 'case_SLQR_diffWS';
%         lw = 1.2;
%         col1 =  [ 57/255, 106/255, 177/255  ];
%         col2 =  [218/255, 124/255, 48/255 ];
%         col3 =  [62/255, 150/255, 81/255 ];
%         col4 =  [255/255, 102/255, 102/255];
%         alpha_lvl = 1;
%         for cnt = 1 : length( base_windspeed_vec )
%             N = length( yout_baseline{cnt}.TetherForce.Data(:,1) );
%             samplesPerCycle = floor( N/yout_baseline{cnt}.cycleCounter.Data(end) );
%             numbConsideredCycles = 1;
%             from_sample = max( N - samplesPerCycle*numbConsideredCycles, 1);
%             cd Trim_results
%             if ~exist( folder_name_results )
%                 mkdir( folder_name_results );
%             end
%             cd(folder_name_results);
%             sim_out = yout_baseline{cnt};
%             save(['sim_out_',num2str(base_windspeed_vec(cnt)),'.mat'], 'sim_out');
%
%             h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,2)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             axis([ yout_baseline{cnt}.alpha_save.Time(from_sample), yout_baseline{cnt}.alpha_save.Time(end), -10 15]);
%             xlabel('$Time$ $(s)$');
%             ylabel('$\alpha_a$ $(deg)$');
%
%             h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.sideslip.Time(from_sample:end), yout_baseline{cnt}.sideslip.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             xlabel('$Time$ $(s)$');
%             ylabel('$\beta_a$ $(deg)$');
%             axis([ yout_baseline{cnt}.sideslip.Time(from_sample), yout_baseline{cnt}.sideslip.Time(end), -15 15]);
%
%             h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$Time$ $(s)$');
%             ylabel('$F_t$ $(N)$');
%             axis([yout_baseline{cnt}.TetherForce.Time(from_sample) yout_baseline{cnt}.TetherForce.Time(end) 0 2]);
%
%             h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1  ); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$x_W$ $(m)$');
%             ylabel('$z_W$ $(m)$');
%             axis tight
%
%
%             h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$x_W$ $(m)$');
%             ylabel('$y_W$ $(m)$');
%             axis tight
%
%             h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,1), 'Linewidth', lw, 'color', col1  ); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,1), 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$Time$ $(s)$');
%             ylabel('$x_W$ $(m)$');
%             axis tight
%
%             h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$Time$ $(s)$');
%             ylabel('$y_W$ $(m)$');
%             axis tight
%
%             h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%             h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1); hold on;
%             h_bl_ref.Color(4) = alpha_lvl;
%             h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
%             h_bl.Color(4) = alpha_lvl;
%             xlabel('$Time$ $(s)$');
%             ylabel('$z_W$ $(m)$');
%             axis tight
%
%             Plot2LaTeX(h1,['angleofattack_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%             Plot2LaTeX(h2,['sideslip_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%             Plot2LaTeX(h3,['Tetherforce_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%
%             Plot2LaTeX(h4,['path_xz',num2str(base_windspeed_vec(cnt) ) ]);
%             Plot2LaTeX(h5,['path_xy',num2str(base_windspeed_vec(cnt) ) ]);
%
%             Plot2LaTeX(h6,['path_x_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%             Plot2LaTeX(h7,['path_y_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%             Plot2LaTeX(h8,['path_z_vw_',num2str(base_windspeed_vec(cnt) ) ]);
%             cd ..
%             cd ..
%         end
%     end
% end
%
%
% %%
% %close all
% if 0
%     cnt_idx = [1,2, 11, 12];
%     cd Trim_results
%     if 1
%         load('yout_baseline.mat');
%         load('yout_adaptive.mat');
%     end
%
%     for k = 1 : length( cnt_idx )
%         close all;
%         cnt = cnt_idx(k);
%         h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
%         h_bl_ref.Color(4) = alpha_lvl;
%         h_bl = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
%         h_bl.Color(4) = alpha_lvl;
%         xlabel('$Time$ $(s)$');
%         ylabel('$\alpha_a$ $(deg)$');
%         axis tight
%         % figure;
%         % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
%         % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
%         % h_bl_ref.Color(4) = alpha_lvl;
%         % h_bl.Color(4) = alpha_lvl;
%         % xlabel('$Time$ $(s)$');
%         % ylabel('$F_t$ $(kN)$');
%
%         h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         h_bl_ref = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
%         h_bl_ref.Color(4) = alpha_lvl;
%         h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on;
%         h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2); hold on;
%         xlabel('$Time$ $(s)$');
%         ylabel('$\alpha_a$ $(deg)$');
%         axis tight
%
%         h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
%         h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
%         h_bl_ref.Color(4) = alpha_lvl;
%         h_bl_ref.Color(4) = alpha_lvl;
%         xlabel('$Time$ $(s)$');
%         ylabel('$F_t$ $(kN)$');
%         axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
%
%         h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
%         h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
%         h_bl_ref.Color(4) = alpha_lvl;
%         h_bl_ref.Color(4) = alpha_lvl;
%         xlabel('$Time$ $(s)$');
%         ylabel('$F_t$ $(kN)$');
%         axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
%
%         h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         plot( yout_baseline{cnt}.target_pos.Data(:,1),...
%             yout_baseline{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
%         plot( yout_baseline{cnt}.pos_W.Data(:,1),...
%             yout_baseline{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
%         %axis([0 600 -300 300 ])
%         axis equal;
%         xlabel('$x_W$ $(m)$');
%         ylabel('$y_W$ $(m)$');
%
%         h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
%             yout_adaptive{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
%         plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
%             yout_adaptive{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
%         %axis([ 0 600 -300 300])
%         axis equal;
%         xlabel('$x_W$ $(m)$');
%         ylabel('$y_W$ $(m)$');
%
%         h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         plot( yout_baseline{cnt}.target_pos.Data(:,1),...
%             yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
%         plot( yout_baseline{cnt}.pos_W.Data(:,1),...
%             yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
%         %axis([0 600 100 500])
%         axis equal;
%         xlabel('$x_W$ $(m)$');
%         ylabel('$z_W$ $(m)$');
%
%         h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
%         plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
%             yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
%         plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
%             yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
%         %axis([0 600 100 500])
%         axis equal;
%         xlabel('$x_W$ $(m)$');
%         ylabel('$z_W$ $(m)$');
%
%
%         Plot2LaTeX(h1,['only_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h2,['only_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h3,['Ftonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h4,['Ftonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%
%         Plot2LaTeX(h5,['xyonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h6,['xyonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h7,['xzonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%         Plot2LaTeX(h8,['xzonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
%
%     end
%     cd ..
%     % figure;
%     % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
%     % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
%     % h_bl_ref.Color(4) = alpha_lvl;
%     % h_bl.Color(4) = alpha_lvl;
%     % xlabel('$Time$ $(s)$');
%     % ylabel('$F_t$ $(kN)$');
%     % %
%     % figure;
%     % h_bl_ref = plot3( yout_baseline{cnt}.target_pos.Data(:,1),...
%     %     yout_baseline{cnt}.target_pos.Data(:,2),...
%     %     yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
%     % h_bl_ref = plot3( yout_baseline{cnt}.pos_W.Data(:,1),...
%     %     yout_baseline{cnt}.pos_W.Data(:,2),...
%     %     yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
%     % axis equal
%
%     % figure;
%     % h_bl_ref = plot3( yout_adaptive{cnt}.target_pos.Data(:,1),...
%     %     yout_adaptive{cnt}.target_pos.Data(:,2),...
%     %     yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
%     % h_bl_ref = plot3( yout_adaptive{cnt}.pos_W.Data(:,1),...
%     %     yout_adaptive{cnt}.pos_W.Data(:,2),...
%     %     yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
% end