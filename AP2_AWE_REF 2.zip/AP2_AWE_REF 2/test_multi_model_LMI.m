addpath(genpath('YALMIP-master')); 
addpath(genpath('sdpt3-master')); 


%% Short Period Model F16
A_sys_0 = [-1.8406, 0.9092; 
           -30.7874, -3.7534];
B_sys_0 = [0; 
           -12.7528];
       

%% LPV parameter settings
p_vec_min = 0.5* ones(5,1);
p_vec_min(3) = -1;0; 
p_vec_min(4) = -1;0;
p_vec_max = 2 * ones(5,1); 

% Save parameter ranges in vector format
pv = pvec('box', [p_vec_min, p_vec_max]);

% Calculate vertices of the hyperbox
[vertices] = polydec(pv);
vertices = vertices';

%% Prefilter
A_filter = -100 ;
B_filter = 100;

F = [];
gamma = sdpvar(1);

X_mat =sdpvar(4,4);
F = [F, X_mat >= 0 ];

W_mat =sdpvar(5,5);

% Loop over all vertices of P
for ii = 1 : size( vertices, 1)
  %  vertices = ones(1,5); 
    % LPV short period model
    A0 = [ A_sys_0(1,1)*vertices(ii,1) A_sys_0(1,2)*vertices(ii,2);         % paramter dependent Dynamic matrix
        A_sys_0(2,1)*vertices(ii,3) A_sys_0(2,2)*vertices(ii,4) ];
    
    B2 = [0;
        B_sys_0(2,1)*vertices(ii,5)];
    
    C = [1 0];               % Output matrix
    
    % Extend to servomechanism design model (constant disturbance, constant
    % tracking command)
    
    A_servo = [A0, zeros(2,1);
        -C, 0 ];
    B_servo = [B2;
        0];
    
    % Include Prefilter
    A_servo = [A_servo, B_servo;
        zeros(1,3), A_filter];
    B_servo = [zeros(3,1); B_filter];
    
    % H2 optimal control (full state feedback)
    % x_dot = Ax+B1w+B2u
    % Performance output: z = C1 x + D12 u
    
    % Noise input (alpha and q channel)
    n_e = size(A_servo,1);
    m_e = size(B_servo,2);
    B1 = [1;1;zeros(m_e+1,1)];
    
    % Weighting. Condition no-cross terms in the cost function:
    %D12'*C1 =0 and C1'*C1 = eye
    m = 1; 
    C1 = 0.001*eye(n_e); % Gewichtung x
    C1(2,2) = 0;
    C1(3,3) =1*eye(m_e);
    C1(n_e+1:n_e+m,:) = 0;
        D12 = [zeros(n_e,m_e); 0.0001*eye(m_e)]; % Gewichtung u

    eval(['Z_' num2str(ii) '=sdpvar(1,4)'])
    Z_mat{ ii } = [ eval(['Z_' num2str(ii) ]) ];
    
    % Specify LMI conditions
    F = [F, [A_servo*X_mat + B_servo*Z_mat{ii} + X_mat * A_servo' + Z_mat{ii}' * B_servo', B1; B1', -1] < 0 ];
    
    F = [F, [X_mat, (C1*X_mat + D12 * Z_mat{ii})'; C1*X_mat+D12*Z_mat{ii}, W_mat] > 0 ];
    
    % Feedforward test
    A_servo_save(:,:,ii) = A_servo;
    
    
end

gamma = trace( W_mat ) ;


% Solve LMI: minimize gamma (bound for H2 norm)
sol = solvesdp(F,gamma);

checkset( F );
double(gamma)

X_inv = (double(X_mat)\eye( size(double(X_mat)) ));
C_servo = [C, zeros(1,1) ];

for k = 1 : length( Z_mat )
    K_tot_save(k,:) = double( Z_mat{k} ) * X_inv; 
    K_tot = -double( Z_mat{k} ) * X_inv; 
    K_e_tot(k,:) = -K_tot(1,3);
    K_x_tot(k,:) = K_tot(1,1:2);
    K_filter(k,:) = K_tot(1,4);
end

% change parameter after Tp seconds
Tp = 20;
% Fixed poles LQR 
QQ = eye(4); 
QQ(1,1) = C1(1,1)^2; 
QQ(2,2) = C1(2,2)^2; 
QQ(3,3) = C1(3,3)^2;
QQ(4,4) = C1(4,4)^2;

RR = D12(end)^2; 

% Servosystem
 A_servo_0 = [A_sys_0, zeros(2,1);
        -C, 0 ];
    B_servo_0 = [B_sys_0;
        0];
% Include Prefilter
A_servo_0 = [A_servo_0, B_servo_0;
    zeros(1,3), A_filter];
B_servo_0 = [zeros(3,1); B_filter];
     
[K_lqr] = lqr( A_servo_0, B_servo_0, QQ, RR );
