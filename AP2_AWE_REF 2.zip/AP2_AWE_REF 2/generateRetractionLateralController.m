function [K_lat, x0_retract, u0_retract] =  generateRetractionLateralController( sim_with_indx, path_with_gains )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;
save_flag = 0;

load([path_with_gains,'/G_save.mat']);
load([path_with_gains,'/rps_st.mat']);
load([path_with_gains,'/x0_save.mat']);
load([path_with_gains,'/u0_save.mat']);
load([path_with_gains,'/M_OB_init.mat']);

x0_retract = x0_save; 
u0_retract = u0_save; 

% Extract matrices
A = G_save{sim_with_indx}.A(1:9, 1:9);
B = G_save{sim_with_indx}.B(1:9, 1:4);

A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9); % beta
         A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9); % phi_tau
         A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9); % psi_tau
         A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9); % p 
         A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];% r

B_lat = [B(2,1),B(2,3);...
         B(4,1),B(4,3);...
         B(6,1),B(6,3);...
         B(7,1),B(7,3);...
         B(9,1),B(9,3)];
A_lat(3,:) = [];
A_lat(:,3) = [];
B_lat(3,:) = [];

C_control = zeros(2, size( A_lat,2) ); 
C_control(1,1) = 1; 
C_control(2,2) = 1;  
A_lat_aug = [A_lat, zeros(size( A_lat,2) ,2); 
    -C_control, zeros(2,2)]; 
B_lat_aug = [B_lat; zeros(2)]; 

% System inherent dynamics
[w0s, zetas] = damp(A_lat); 

% Define desired eigenvalues 
T_R_Des = 1/w0s(1); % Rolltime constant
T_S_Des = 1/5; %1/w0s(end); % spiral mode
zeta_DR_des = 1/sqrt(2); 
w0_DR_des = w0s(2); 

% Corresponding desired eigenvalues + integrator states 
% Lambda_Des = [-1/T_R_Des; 
%    w0_DR_des*(-zeta_DR_des+1i*sqrt(1-zeta_DR_des^2)); 
%    w0_DR_des*(-zeta_DR_des-1i*sqrt(1-zeta_DR_des^2)); 
%    -10; 
%    -11; 
%    -12];

% Corresponding desired eigenvalues + integrator states 
Lambda_Des = [-1/T_R_Des; 
   w0_DR_des*(-zeta_DR_des+1i*sqrt(1-zeta_DR_des^2)); 
   w0_DR_des*(-zeta_DR_des-1i*sqrt(1-zeta_DR_des^2)); 
   -1/T_S_Des; 
   -4; 
   -4]; % was -4.1

if 1
 v1 = [0;NaN; NaN; 1e-4; NaN; NaN]; % Rollmode
 v2 = [NaN;0; 1e-4; NaN; NaN; NaN]; % DR
 v3 = [NaN;0; 1e-4; NaN; NaN; NaN]; % DR
v4 = [0;NaN; NaN; 1e-4; NaN; NaN]; % Spiral
v5 = [1;0; NaN; NaN; NaN; NaN]; % betaI
v6 = [0;1; NaN; NaN; NaN; NaN]; % phi_tauI
else
% ideal but not feasible because we invert by zeros 
 v1 = [0;NaN; NaN; 0; NaN; NaN]; % Rollmode
 v2 = [NaN;0; 0; NaN; NaN; NaN]; % DR
 v3 = [NaN;0; 0; NaN; NaN; NaN]; % DR
v4 = [0;NaN; NaN; 0; NaN; NaN]; % Spiral
v5 = [1;0; NaN; NaN; NaN; NaN]; % betaI
v6 = [0;1; NaN; NaN; NaN; NaN]; % phi_tauI
end

Vector_Des = [v1, v2, v3, v4, v5, v6]; 

% Eigenstructure Assignment procedure
[n,m] = size(B_lat_aug); 
C = [eye(n-2), zeros(n-2,2)];
C = eye(n); 
[r,n] = size(C); 


K = zeros(m,r); 
V = zeros(n,r); 
Z = zeros(m,r); 
%%
for Act_EV = 1 : r 
   ld = Lambda_Des(Act_EV); 
   vd = Vector_Des(:, Act_EV); 
   M = [ld*eye(n,n)-A_lat_aug, B_lat_aug]; 
   N_bar = null(M); % Nullspace 
   N = N_bar(1:n, :); %  corresponding to eigenvalues
   N_hat = N_bar(n+1:end,:); %  corresponding to input directions
   
   ps = find(~isnan(vd)); % selection 
   vd_s = vd(ps); % choose elements of desired eigenvector that are assinge d
   N_s = N(ps, :); % choose corresponding basis in nullspace 
   
   l = N_s\vd_s; % calculate parameter vector
   
   v = N*l; % calculate eigenvalue
   z = N_hat*l; % calculation of input direction 
   
   V(:, Act_EV) = v; 
   Z(:,Act_EV) = z; 
    
end
%%
K_imag = ((C*V)'\(Z'))';  
if (norm(imag(K)) > 100*eps)
    error('Bad gain design'); 
end

K_lat = real(K_imag); 

A_cl = A_lat_aug - B_lat_aug * K_lat * C;
fprintf('Closed loop lateral dynamics damping: \n'); 
damp(A_cl);
B_lat_cl = [B_lat*0;eye(2)];

C_beta = zeros(1, size(A_cl,2) ); C_beta(1) = 1; 
C_phi = zeros(1, size(A_cl,2) ); C_phi(2) = 1; 

sys_beta = ss( A_cl, B_lat_cl, C_beta, [] );
sys_phi = ss( A_cl, B_lat_cl, C_phi, [] );
tvec = 0 : 0.1 : 12;

opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
% BETA
[y,t] = step(sys_beta,tvec,opt);
%h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
figure(1); 
plot( t, y(:,:,1)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t(:,:,1)./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\beta_a$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_beta');
    cd ..
end
% PHI
[y,t] = step(sys_phi,tvec,opt);
%h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
figure(2);
plot( t, y(:,:,2)*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\Phi_tau$ $(deg)$');
axis([0 6 0 12]);
if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,'step_response_LQRI_phi');
    cd ..
end
