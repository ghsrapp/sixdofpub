function [p_VT_W,p_kite_proj_W] = getVTOnGreatCircleQuat(right_bottom_abs_W, left_top_abs_W, p_kite_W,deltaVTGreatCircle)
e1 = [left_top_abs_W(2)*right_bottom_abs_W(3)-left_top_abs_W(3)*right_bottom_abs_W(2); 
       left_top_abs_W(3)*right_bottom_abs_W(1)-left_top_abs_W(1)*right_bottom_abs_W(3); 
       left_top_abs_W(1)*right_bottom_abs_W(2)-left_top_abs_W(2)*right_bottom_abs_W(1)];
e1 = e1/norm(e1);
e2 = [e1(2)*left_top_abs_W(3)-e1(3)*left_top_abs_W(2); 
       e1(3)*left_top_abs_W(1)-e1(1)*left_top_abs_W(3); 
       e1(1)*left_top_abs_W(2)-e1(2)*left_top_abs_W(1)];
e3 = left_top_abs_W;
% Projection and rotation.
% This is acutally equivalent to the normal projection into the great
% circle plane:
V = [e2, e3]; 
p_kite_proj_W = V*V'*p_kite_W;
q_vec = [cos(-deltaVTGreatCircle/2);sin(-deltaVTGreatCircle/2)* e1/norm(e1)];
q0 = q_vec(1); q1 = q_vec(2); q2 = q_vec(3); q3 = q_vec(4); 
Drot = [q0^2+q1^2-q2^2-q3^2, -2*q0*q3+2*q1*q2, 2*q0*q2+2*q1*q3; 
        2*q0*q3+2*q1*q2, q0^2-q1^2+q2^2-q3^2, -2*q0*q1+2*q2*q3; 
       -2*q0*q2+2*q1*q3, 2*q0*q1+2*q2*q3, q0^2-q1^2-q2^2+q3^2];
p_VT_W = Drot * p_kite_proj_W;


