function [x0_trim,u0_trim,K_long,F_long, HmInvHum, Ke_L1, Ts, Am, Bp_um, B_aug, Bm] =  generateTractionPhaseController_FF( sim_with_indx )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
lw = 1.2;
cnt = 4;
save_flag = 0;

path_with_gains = 'Trim_results/case_1_test03';
addpath(path_with_gains);

load('G_save.mat');
load('rps_st.mat');
load('x0_save.mat');
load('u0_save.mat');
load('M_OB_init.mat');

[K_long, A_long, B_long, Mx, Mu, F_long] = lqr_w_psi_wVa_test_decoupled_wFF(G_save{sim_with_indx});

Am = A_long - B_long * K_long; 
Bm = B_long * F_long; 
B_aug = B_long; 
sys = ss( Am, Bm, [0,1,0,0,], [] ); 
tvec = 0 : 0.1 : 12; 
opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
[y,t] = step(sys, tvec, opt); 
%[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um, B_aug, Br,t,y] = test_simple_piecewise_L1_aug(A_long,B_long, Q, R);
%K_long = Kbl;
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot( t, y*180/pi, 'Linewidth', lw, 'color', col2); hold on
plot( t, t./t*10, 'Linewidth', lw, 'color', col1); hold on
xlabel('$Time$ $(s)$');
ylabel('$\alpha_a$ $(deg)$');
axis([0 12 0 12]);
damp(Am)
% Trim states and inputs
x0_trim = x0_save(:,sim_with_indx);
u0_trim = u0_save(:,sim_with_indx);

%% L1 adaptive augmentation for the Kp LQR only 
% nullspace of bp_plus:
s = 1; t = 0; %
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v1 = [s;t;0;x4]; 

s = 0; t = 1; % x3 and x5 can be set to zero
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v2 = [s;t;0;x4]; 

s = 1; t = 1; % x3 and x5 can be set to zero
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v3 = [s;t;1;x4]; 

Bp_um = [v1, v2, v3];



%% L1 Piecewise constant update law
s = tf('s'); 
%Bm = Bp*F; 
Cc = [0, 1, 0, 0]; 
Cc_aug = [Cc];
Hm = Cc_aug* ( (s*eye( size(Am,1) )-Am)\B_aug ) ; 
Hum = Cc_aug* ( (s*eye( size(Am,1) )-Am)\Bp_um ) ;


HmInvHum = 1/Hm*Hum; 

Ts = 0.001; 
B = [B_aug, Bp_um]; 
% Ke_L1 =( B \  ( (Am\(expm(Am*Ts)-eye(size(Am,1)))) )) \expm(Am*Ts) ; 
C1 = tf( [0, 30], [1, 30] ); 
Ke_L1 =  -inv(B) * inv( expm(Am*Ts) - eye(size(Am,1) ) ) * Am * expm(Am*Ts) 

