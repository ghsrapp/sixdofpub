
function [HmInvHum, Ke_L1, C1, Ts, F, K, Am, Bp_um, B_aug, Bm,tvec,y] = piecewise_L1_aug_with_EA(A_aug, B_aug, K) 

% Working gains!
% Q = 0*eye(4); 
% Q(1,1) = 0; 
% Q(2,2) = 0; 
% Q(3,3) = 0.001; 
% Q(4,4) = 0.03; 
% R = 1; 
Cc = [0,1,0,0];
% 
% A_aug = [Ap, zeros(4,1); 
%         -Cc, 0]; 
% B_aug = [Bp; 0]; 
         

Am = A_aug - B_aug*K; 
Bm = zeros(5,1);
Bm(5) = 1; 
F = 1;

sys = ss( Am, Bm, [0,1,0,0,0], [] ); 
tvec = 0 : 0.1 : 12; 
opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
[y,tvec] = step(sys, tvec, opt); 
%plot(t,y); 
%axis([0, 12, 0 1.2]); 

% nullspace of bp_plus:
s = 1; t = 0; %
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v1 = [s;t;0;x4;0]; 

s = 0; t = 1; % x3 and x5 can be set to zero
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v2 = [s;t;0;x4;0]; 

s = 1; t = 1; % x3 and x5 can be set to zero
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v3 = [s;t;1;x4;0]; 

s = 1; t = 1; % x3 and x5 can be set to zero
x4 = (-B_aug(1)*s-B_aug(2)*t)/B_aug(4);
v4 = [s;t;1;x4;1]; 

Bp_um = [v1, v2, v3, v4];



%% L1 Piecewise constant update law
s = tf('s'); 
%Bm = Bp*F; 
Cc_aug = [Cc,0];
Hm = Cc_aug* ( (s*eye( size(Am,1) )-Am)\B_aug ) ; 
Hum = Cc_aug* ( (s*eye( size(Am,1) )-Am)\Bp_um ) ;
F_long = []; 

HmInvHum = 1/Hm*Hum; 

Ts = 0.001; 
B = [B_aug, Bp_um]; 
% Ke_L1 =( B \  ( (Am\(expm(Am*Ts)-eye(size(Am,1)))) )) \expm(Am*Ts) ; 
C1 = tf( [0, 30], [1, 30] ); 
Ke_L1 =  -inv(B) * inv( expm(Am*Ts) - eye(size(Am,1) ) ) * Am * expm(Am*Ts) ; 

 
 