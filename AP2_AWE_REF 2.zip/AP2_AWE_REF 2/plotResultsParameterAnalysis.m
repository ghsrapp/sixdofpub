function plotResultsParameterAnalysis( yout_mat, save_flag, mother_file_name, mean_phi0 )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];

plot_indx_from = 100/0.01; % was 120
plot_indx_to = 160/0.01;

for j = 1 : length( yout_mat )
    close all;

    %% va
    h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).va_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).va_save.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
%   axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  26 34 ] );
     % axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  28 36 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$v_{a}$ $(m/s)$');
       
     %% Path tracking error
    l =   sqrt( sum(yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3)  ,2 ) ); 
    l_t = sqrt( sum(yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3) , 2 ) ); 
    h2 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    cte = acos( ( sum( yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3),2 ) )./l_t./l ) .* l; 
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), cte, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,2)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,2), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,3)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,3), 'color', col3, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
   % yticks([-12 -8 -4 0 4 8 12]); 
    %yticklabels({'-12', '-8','-4', '0', '4', '8','12'})    
    ylabel('$e_p$ $(m)$');
    xlabel('$Time$ $(s)$');
    
    %% path projection 
    M_WP = [cos(mean_phi0),0, -sin(mean_phi0);0, 1, 0;  sin(mean_phi0),0, cos(mean_phi0)];  
    p_P = M_WP'*[ yout_mat(j).pos_W.Data(:,1),  yout_mat(j).pos_W.Data(:,2),  yout_mat(j).pos_W.Data(:,3)]';
    pt_P = M_WP'*[ yout_mat(j).target_pos.Data(:,1),  yout_mat(j).target_pos.Data(:,2),  yout_mat(j).target_pos.Data(:,3)]';
    h3 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( p_P(2,:), p_P(3,:), 'color', col1, 'Linewidth', 1, 'Linestyle', '-' ); hold on
    plot( pt_P(2,:), pt_P(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on
    xlabel('$y_P$ $(m)$');
    ylabel('$z_P$ $(m)$');
    axis equal
    
    %% path in xz plane to show reeling speed change
    h4 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).pos_W.Data(:,1), yout_mat(j).pos_W.Data(:,3), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).pos_W.Data(:,1), yout_mat(j).pos_W.Data(:,3), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
    axis equal
    
     h5 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
     plot( yout_mat(j).phi_tau.Time(plot_indx_from:plot_indx_to), yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,2)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).phi_tau.Time(plot_indx_from:plot_indx_to), yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
  %  axis([ceil(yout_mat(j).phi_tau.Time(plot_indx_from)) ceil(yout_mat(j).phi_tau.Time(plot_indx_to))  -30 30 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$\Phi_{\tau}$ $(deg)$');
    
    
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h1,[mother_file_name,'_va_',num2str(j)]);
        Plot2LaTeX(h2,[mother_file_name,'_pE_',num2str(j)]);
        Plot2LaTeX(h3,[mother_file_name,'_path_proj_',num2str(j)]);
        Plot2LaTeX(h4,[mother_file_name,'_path_xz_',num2str(j)]);
        Plot2LaTeX(h5,[mother_file_name,'_phi_',num2str(j)]);
        cd ..
    end

end

end