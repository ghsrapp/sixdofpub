function [ left_top_abs_W, left_bottom_abs_W,...
            right_top_abs_W,right_bottom_abs_W,...
            M_CW_left,M_CW_right, p_circO1_W,p_circO2_W,r_SE ] = updateFlightPath( p_kite_W, r_d,maxWidth, lat, l_tether)
        
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% Normalize the kite position vector
%l_tether = norm( p_kite_W); 

r_SE = r_d / l_tether; % This is the radius on the small earth
longLeft = -asin(maxWidth/2 / (cos(lat)*l_tether) );

% First circle
M_CW_left = [-sin(lat)*cos(longLeft), -sin(lat)*sin(longLeft), cos(lat);
    -sin(longLeft), cos(longLeft), 0;
    -cos(lat)*cos(longLeft), -cos(lat)*sin(longLeft), -sin(lat)];
M_WC_left = M_CW_left';

% This is important: Definitions of the center of the circle
deltaAngle = asin( r_SE ); % Changes because r_SE changes
s = cos(deltaAngle); % Changes also -> radius -> smaller -> limit is s = 1
p_circO1_W = s*[cos(longLeft)*cos(lat);...
    sin(longLeft)*cos(lat);...
    sin(lat)];

% Second circle
M_CW_right = M_CW_left;
M_CW_right(1,2) = -1 * M_CW_right(1,2);
M_CW_right(2,1) = -1 * M_CW_right(2,1);
M_CW_right(3,2) = -1 * M_CW_right(3,2);
M_WC_right = M_CW_right';

% This is important: Definitions of the center of the circle
p_circO2_W = p_circO1_W;
p_circO2_W(2) = -1 * p_circO2_W(2);

% Definition of the waypoints
left_top = [r_SE; 0; 0];
left_bottom = [-r_SE; 0; 0];
left_top_W = M_WC_left * left_top;
left_bottom_W = M_WC_left * left_bottom;
left_top_abs_W = p_circO1_W + left_top_W;
left_bottom_abs_W = p_circO1_W + left_bottom_W;

right_bottom = [-r_SE; 0; 0];
right_top = [r_SE; 0; 0];
right_bottom_W = M_WC_right * right_bottom;
right_bottom_abs_W = p_circO2_W + right_bottom_W;
right_top_W = M_WC_right * right_top;
right_top_abs_W = p_circO2_W + right_top_W;


end

