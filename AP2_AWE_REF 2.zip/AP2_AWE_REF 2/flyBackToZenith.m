function [chi_K_des,bearing_vec] = flyBackToZenith( left_top_abs_E,right_bottom_abs_E, p_test, l_tether)

p_test = p_test / norm(p_test);

e1 = cross( left_top_abs_E, right_bottom_abs_E);
e1 = e1/norm(e1);
e2 = cross(e1, left_top_abs_E);
e3 = left_top_abs_E;

M_Gc1E = [e3'; e2'; e1'];

% Transform the position into the GC1 frame
p_test_Gc1 = M_Gc1E * p_test;
% Remove third component
p_test_Gc1(3) = 0;
p_test_Gc1 = p_test_Gc1/norm(p_test_Gc1);
% Transform back to E
p_test_proj = M_Gc1E' * p_test_Gc1;

% Second get the maximum angle on this great circle that is feasible
deltaLambda = acos( left_top_abs_E' * p_test_proj / norm(p_test_proj) );

% take a fraction of it
lambdaCarrot = -0.1 * deltaLambda; % towards the upper point is a negative rotation!

% Move the projection with this angle along the great circle (which is a
% simple rotation!)
M_gc_z = [cos(lambdaCarrot), -sin(lambdaCarrot),0;
    sin(lambdaCarrot), cos(lambdaCarrot),0;
    0, 0, 1];
carrot_Gc1 = M_gc_z * p_test_Gc1;
carrot_E =  M_Gc1E' * carrot_Gc1;

carrot_E = left_top_abs_E; 
%% Next: we have to calculate the desired course angle
% We use the following algorithm: 1) Calculate heading vector in NED 2)
% Calculate course vector in NED 3) Calculate the angle between these
% two vectors with the correct sign
% Calculate an orthonormal basis in the current position
e_1 = cross(  carrot_E, p_test);
e_1 = e_1/norm(e_1);
e_2 = cross( p_test, e_1); % Course direction
e_2 = e_2/norm(e_2);

% Course angle is defined between the NED and the K system
% the orthonormal basis of the NED system is defined by longitude and
% latitude of the current position:
e_z_O_E = -p_test/norm(p_test);
% Now using the definition of the transformation M_EO matirix:
lat_p = -asin( e_z_O_E(3) );
long_p = atan( e_z_O_E(2) / e_z_O_E(1) );
e_x_O_E = [-sin(lat_p)*cos(long_p); -sin(lat_p)*sin(long_p); cos(lat_p)]; % bearing

%h_course = quiver3(p_test_plot(1), p_test_plot(2), p_test_plot(3), e_2(1), e_2(2), e_2(3),0.25,'-r', 'Linewidth',1.2 ) ;

% Course angle calculation:
% to determine the sign of the course angle calculate the normal of the
% plane spanned by the x0 and the xK axis. If the sign is negative the course angle is negative:
e_z_0K = cross( e_2, e_x_O_E);
e_x_O_E = e_x_O_E / norm(e_x_O_E); 

%norm_ = norm( cross(e_x_O_E, e_2) ) < 1e-6
scalar = e_x_O_E'*e_2; 
%if sign(scalar) > 0 
    chi_K_des = acos( round(scalar) ) * sign(e_z_0K(3) );   % desired course angle
%else
 %   chi_K_des = acos( max(scalar,-1) ) * sign(e_z_0K(3) );   % desired course angle
%end
bearing_vec = e_2;
%norm( p_test - left_top_abs_E );

% if norm( p_test - left_top_abs_E ) < 1/l_tether ;
%     activeWp = 1;
% else
%     activeWp = 7;
% end
