d = 0 : 0.1 : 10;

m = 1;

f = 2/pi * atan( m * d ) ;

figure;
plot(d, f)