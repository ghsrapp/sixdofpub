v = 0;
for n = 1 : 1e6
    v = exp( -Sensors.GPS.TMarkov * Sensors.GPS.Ts ) * v + ...
        Sensors.GPS.sigmaNorth * randn(1); 
    v_save(n) = v; 
end
figure; 
plot(v_save)