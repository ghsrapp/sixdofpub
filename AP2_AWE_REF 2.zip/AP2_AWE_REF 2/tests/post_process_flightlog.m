
load('flight_log.mat');

%% Make the data a little bit less perfect 
% random dropouts (NaNs) 
% percentage/100 of NaN
lamb = 0.01;
% Rates
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.p_OB_meas_radDs(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.q_OB_meas_radDs(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.r_OB_meas_radDs(random_idx) = NaN;
% Acc
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.x_acc_B_meas_mDs2(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.y_acc_B_meas_mDs2(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.z_acc_B_meas_mDs2(random_idx) = NaN;
% Pos
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.pos_x_G_O_GPS_meas(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.pos_y_G_O_GPS_meas(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.pos_z_G_O_GPS_meas(random_idx) = NaN;
% Attitude
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.PHI_OB_meas_rad(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.THETA_OB_meas_rad(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.PSI_OB_meas_rad(random_idx) = NaN;
% Airdata 
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.alpha_a_meas_rad(random_idx) = NaN;
random_idx = floor( (length( flight_log.timestamps ) - 1 ) * rand( floor(lamb*length(flight_log.timestamps )) , 1) + 1 ); 
flight_log.beta_a_meas_rad(random_idx) = NaN;

save('flight_log_real.mat', 'flight_log'); 



