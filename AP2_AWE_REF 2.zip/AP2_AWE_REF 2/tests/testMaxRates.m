%% Max lift
Va = 45;
Vg = Va;
% Max CL
CLmax_vec = linspace(0.2, 1.2, 5); 
leg_h = [];
close all
figure;

for n = 1 : length(CLmax_vec)  
    Cl = CLmax_vec(n);
    Lmax = 1/2 * P.rho_air * P.S_wing * Cl * Va.^2;
    lat = 30*pi/180;
    
    r_min = 20;
    chi_dot = Vg/r_min;
    
    fun = @(mu_max) chi_dot - 1./(P.mass*Vg) * ( (Lmax*cos(mu_max) + sin(lat)*P.mass*P.g).* tan(mu_max) + cos(lat)*P.mass*P.g );
    
    mu_max = linspace( 0, 80*pi/180, 10 );
    fun_plot = chi_dot - 1./(P.mass*Vg) * ( (Lmax*cos(mu_max) + sin(lat)*P.mass*P.g).* tan(mu_max) + cos(lat)*P.mass*P.g );
    plot(mu_max*180/pi, fun_plot); hold on
    grid on; 
    
end
xlabel('Bankangle (deg)'); 
ylabel('courserate=0')
plot([0 80], [0 0], '-r'); 

