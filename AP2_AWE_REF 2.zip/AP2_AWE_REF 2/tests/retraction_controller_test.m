close all;
l_tether_max = 600;
[ LemPs ] = updateLissajous( l_tether_max, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];
%L_W = L_W/norm(L_W);    
    
L_W_k = L_W * l_tether_max;
Delta0 = 0.5 * max( L_W_k(2,: ) );
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;
axis equal; grid on;hold on; view(90,0);

l_tether_min = 300;
[ LemPs ] = updateLissajous( l_tether_min, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];
%L_W = L_W/norm(L_W);
L_W_k = L_W * l_tether_min;
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.5, 0.5 ,0.5]); hold on;
axis equal; grid on;hold on; view(90,0);

%%

% theta_point = pi/2;%1.2*pi;%sol_init;
% L = [Alambda * sin(blambda*theta_point');
%     Aphi    * sin(bphi*theta_point') + phi0];
% L_W = [cos(L(1,:)).*cos(L(2,:));
%         sin(L(1,:)).*cos(L(2,:));
%         sin(L(2,:))];
% L_W_k = L_W * 200;

% horizontal reference line
p_end = [0; L_W_k(2); L_W_k(3) ];
% plot3( [L_W_k(1) p_end(1)],[L_W_k(2) p_end(2)],[L_W_k(3) p_end(3)],'-k')
%% Test point
l_tether = 300;
[ LemPs ] = updateLissajous( l_tether, LemPsRef );
theta_point = pi/2;
Aphi = LemPs.Aphi;
Alambda = LemPs.Alambda;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];
%L_W = L_W/norm(L_W);
test = L_W * l_tether;
plot3(test(1,:), test(2,:),test(3,:), '+g'); hold on;

L = l_tether_max - l_tether_min;
sigma = 70;
x = norm(test) - l_tether_min - L/2;

gamma_cmd = -pi/2*exp( -x.^2./sigma^2)  + pi/2 - LemPsRef.phi0 ;

% desired course 
if test(2) > 0
chi_cmd = pi - atan2(abs(2*Delta0-test(2,:)), Delta0 );
else
chi_cmd = -pi + atan2( 2*Delta0-abs(test(2,:)), Delta0 );
end   
% bearing 
bearing_ = [cos(chi_cmd)*cos(gamma_cmd);sin(chi_cmd)*cos(gamma_cmd);sin(gamma_cmd)]*20;
plot3( [test(1) test(1)+bearing_(1)],[test(2) test(2)+bearing_(2)],[test(3) test(3)+bearing_(3)],'-b' );


