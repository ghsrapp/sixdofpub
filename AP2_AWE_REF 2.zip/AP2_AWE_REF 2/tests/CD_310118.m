Va = 30;
alpha_vec = [-8:2:44]'*pi/180;
CD_vec = [0.0585;
0.0453;
0.0408;
0.0437;
0.0524;
0.0677;
0.0883;
0.1131;
0.1421;
0.1740;
0.2076;
0.2482;
0.3060;
0.3715;
0.4437;
0.5209;
0.6018;
0.6828;
0.7663;
0.8439;
0.9184;
0.9885;
1.0544;
1.1166;
1.1767;
1.2340;
1.2893];

%
figure;
plot(alpha_vec, CD_vec, '+'); hold on

% Va = 50
CD_vec_50 = [0.0576;
0.0447;
0.0407;
0.0436;
0.0529;
0.0676;
0.0877;
0.1129;
0.1421;
0.1744;
0.2079;
0.2477];
alpha_vec_50 = [-8:2:14]'*pi/180;
plot(alpha_vec_50, CD_vec_50, '+'); hold on

%%
Phi_reg = [ones(length(alpha_vec),1), alpha_vec, alpha_vec.^2,  alpha_vec.^3,  alpha_vec.^4];
Theta_1 = Phi_reg'*Phi_reg\eye(5) * Phi_reg' * CD_vec;
CD_vec_hat = Theta_1(1) + Theta_1(2) * alpha_vec + Theta_1(3) * alpha_vec.^2 +...
    Theta_1(4) * alpha_vec.^3 + Theta_1(5) * alpha_vec.^4;
plot( alpha_vec, CD_vec_hat); 
