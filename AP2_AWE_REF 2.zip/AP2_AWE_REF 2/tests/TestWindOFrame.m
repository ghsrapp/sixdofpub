
close all;



% Specify O - frame: 
x_O = [1;0;0];
y_O = [0;1;0];
z_O = [0;0;1];

% draw O frame
figure(1);
quiver3( 0, 0, 0, x_O(1),x_O(2),x_O(3),'-b', 'Linewidth',2);hold on;
quiver3( 0, 0, 0, y_O(1),y_O(2),y_O(3),'-b', 'Linewidth',2);hold on;
quiver3( 0, 0, 0, z_O(1),z_O(2),z_O(3),'-b', 'Linewidth',2);hold on;
xlabel('North');
ylabel('East');
zlabel('Down');


% W frame
windDirection_rad = 60*pi/180; % with respect to North
windframe_x_axis_W = [1;0;0];
windframe_y_axis_W = [0;1;0];
windframe_z_axis_W = [0;0;1];

[windframe_x_axis_O] = transformFromWtoO(windDirection_rad,windframe_x_axis_W); 
[windframe_y_axis_O] = transformFromWtoO(windDirection_rad,windframe_y_axis_W); 
[windframe_z_axis_O] = transformFromWtoO(windDirection_rad,windframe_z_axis_W); 


quiver3( 0, 0, 0, windframe_x_axis_O(1),windframe_x_axis_O(2),windframe_x_axis_O(3),'-g', 'Linewidth',2);hold on;
quiver3( 0, 0, 0, windframe_y_axis_O(1),windframe_y_axis_O(2),windframe_y_axis_O(3),'-r', 'Linewidth',2);hold on;
quiver3( 0, 0, 0, windframe_z_axis_O(1),windframe_z_axis_O(2),windframe_z_axis_O(3),'-r', 'Linewidth',2);hold on;
