
t = linspace(2*pi,0, 30);
l_tether = 130;

%%

long_vec = ( a * sqrt(2) * cos(t) ) ./ (sin(t).^2 + 1) ;
lat_vec = ( a * sqrt(2) * cos(t) .* sin(t) ) ./ (sin(t).^2 + 1) ;
a  = a_star/l_tether;
a_star = 40; % distance between the foci of the figure the kite is following independent on the tether length


A = AStar/tetherLtest; 
B = BStar/tetherLtest; 
long_vec = A * sin( alem * t  ) ; 
lat_vec = B * sin( blem * t ); 


figure(1)
plot(long_vec*180/pi, lat_vec*180/pi, '-o'); hold on
plot(-a*180/pi, 0, '+r'); hold on
plot(a*180/pi,0, '+r'); hold on
axis equal

lemniscate_W = [cos(long_vec).*cos(lat_vec);
    sin(long_vec).*cos(lat_vec);
    sin(lat_vec)];
lat_op = 30 * pi/180;

M_rot = [cos(lat_op), 0, -sin(lat_op);
    0, 1, 0;
    sin(lat_op), 0, cos(lat_op)];

%lemniscate_W = lemniscate_W' * M_rot';
%lemniscate_W(end,:) = [];
lemniscate_W_tmp = lemniscate_W' * M_rot';
lemniscate_W = lemniscate_W_tmp(1:end-1,:);

% Up or Down fig 8
midUpFlag = 0;
if midUpFlag
    lemniscate_W = flip(lemniscate_W);
end

figure(2);
l_tether = 1; % unit sphere
hold on
plot3( l_tether*lemniscate_W(:,1),  l_tether*lemniscate_W(:,2), l_tether*lemniscate_W(:,3), 'o');
grid on
axis equal
[X,Y,Z] = sphere(50);
s = surf(X*l_tether, Y*l_tether, Z*l_tether);
set(s, 'FaceAlpha', 0);
cmap = [0.8,0.8,0.8];
colormap(cmap);
view(45, 45);
axis([0, l_tether + 1, -l_tether-1, l_tether+1, 0, l_tether+1]);

% Orthonormal basis
lemniscate_W_ = [lemniscate_W(end,:); lemniscate_W(1:end-1,:)];
delta_p = lemniscate_W - lemniscate_W_;
norm_ = sqrt( delta_p(:,1).*delta_p(:,1) + delta_p(:,2).*delta_p(:,2) + delta_p(:,3).*delta_p(:,3) );
q_vec = delta_p ./ repmat(norm_,1,3);



%% Test
h_tot = [];
wp_idx = 1;
n_save = 1;

wp_idx = 3;

% Calculate the normal vector
if wp_idx == 1
    nvec_wp_idx = (q_vec(1,:) + q_vec(length( lemniscate_W_),:)) / norm( q_vec(1,:) + q_vec(length( lemniscate_W_),:) );
else
    nvec_wp_idx = (q_vec(wp_idx,:) + q_vec(wp_idx-1,:)) / norm( q_vec(wp_idx,:) + q_vec(wp_idx-1,:) );
end

h_tmp = quiver3( lemniscate_W_(wp_idx,1), lemniscate_W_(wp_idx,2),lemniscate_W_(wp_idx,3),nvec_wp_idx(1), nvec_wp_idx(2),nvec_wp_idx(3));
set(h_tmp,'color', 'red', 'Linewidth', 2);

% Plot the plane
d = - lemniscate_W_(wp_idx,:) * nvec_wp_idx';
[xx,yy]=ndgrid(linspace(-10, 10, 100),linspace(-10, 10, 100));
% calculate corresponding z
z = (-nvec_wp_idx(1)*xx - nvec_wp_idx(2)*yy - d)/ nvec_wp_idx(3);
m = mesh(xx,yy,z, 'edgecolor', 'm');
set(m, 'Linewidth', 1.2);
set(m, 'FaceAlpha', 0);
h_tot = [m, h_tmp];

%% test condition
p_test = lemniscate_W_(4,:);
plot3( p_test(1), p_test(2), p_test(3),'*g');
% Half space condition
testPassed = (p_test - lemniscate_W_(wp_idx,:)) * nvec_wp_idx'

%% path at tether length: 
figure; 
%% Paramter that fully defines the Lemniscate
a_star = 50; % distance between the foci of the figure the kite is following independent on the tether length
tetherLtest = 130;
% Adapt the path on the unit sphere
t = linspace(0, 2*pi, 30);
a  = a_star/tetherLtest;
long_vec = ( a * sqrt(2) * cos(t) ) ./ (sin(t).^2 + 1) ;
lat_vec = ( a * sqrt(2) * cos(t) .* sin(t) ) ./ (sin(t).^2 + 1) ;
lemniscate_W = [cos(long_vec).*cos(lat_vec);
    sin(long_vec).*cos(lat_vec);
    sin(lat_vec)];
lemniscate_W = lemniscate_W' * M_rot';
lemniscate_W(end,:) = [];
% Now calculate the figure at tether lenght
lemniscate_W_real = lemniscate_W * tetherLtest; 
plot3( lemniscate_W_real(:,1),  lemniscate_W_real(:,2), lemniscate_W_real(:,3), '-or'); hold on 
axis equal; 