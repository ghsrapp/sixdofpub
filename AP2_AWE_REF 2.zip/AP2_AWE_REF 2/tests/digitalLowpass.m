w = 100; 
zeta = 0.8; 
Ts = 0.01; 
A = [0, 1; -w^2, -2*zeta*w]; 
b = [0; w^2];
alpha = exp(A*Ts); 