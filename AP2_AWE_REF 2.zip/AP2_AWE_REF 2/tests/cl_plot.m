alpha = - 10 : 0.1 : 10 ; 
alpha = alpha * pi/180;


sigma = ( 1+exp(-P.M*(alpha-P.alpha0))+exp(P.M*(alpha+P.alpha0)) )./...
    ( (1 + exp(-P.M*(alpha-P.alpha0))).*(1+exp(P.M*(alpha+P.alpha0))));
CLalpha = (1-sigma).*(P.C_L_0 + P.C_L_alpha.*alpha)+...
    sigma .* ( 2 * sign(alpha).*sin(alpha).^2.*cos(alpha));


plot(alpha*180/pi, CLalpha); hold on
plot(alpha*180/pi, P.C_L_0 + P.C_L_alpha.*alpha )