close all;
axis equal; hold on;
axis([0 600 -200 200 0 400]); hold on;

%% ================ Definition parameters ================
% the problem will be solved with decoupled, longitudinal and lateral dynamics
% essentially the plane will be retracted on a glideslopish path
l_tether_max = 600; % Distance of outmost path
l_tether_min = 300; % Distance of innermost path
% Glide slope -> retraction angle
lat_land = 30*pi/180; % as measured from the ground.
lat_transition = lat_land + 5*pi/180;
delta_x_flare = 50; % Start flare here
T = 30; % time constant flare
gamma_t_star = 10*pi/180;
delta_end_z = 50;
delta_start_z = 50;
ds = 50; %look ahead distance
dt = 1; % time increment transitioon back to traction
T_trans = 1; % time constant filter transition
time = 0; % initial time
%=========================================================

[ LemPs ] = updateLissajous( l_tether_max, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * l_tether_max;
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;

L_start = [Alambda * sin(blambda*pi/2');
    Aphi    * sin(bphi*pi/2') + phi0];
L_start = [cos(L_start(1,:)).*cos(L_start(2,:));
    sin(L_start(1,:)).*cos(L_start(2,:));
    sin(L_start(2,:))]* l_tether_max;

long_max = atan2( L_start(2), L_start(1) );

Delta0 = 0.5 * max( L_W_k(2,: ) );

% Path a min. tether length
[ LemPs ] = updateLissajous( l_tether_min, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * l_tether_min;
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.5, 0.5 ,0.5]); hold on;

% horizontal reference line
p_end = [0; L_W_k(2); L_W_k(3) ];

L_end = [Alambda * sin(blambda*pi/2');
    Aphi    * sin(bphi*pi/2') + phi0];
L_end = [cos(L_end(1,:)).*cos(L_end(2,:));
    sin(L_end(1,:)).*cos(L_end(2,:));
    sin(L_end(2,:))]* l_tether_min;

x_F = L_end(1); % flare parameter
x_0 = L_end(1)+delta_x_flare;

%===============================================================================
% Waypoints
Wp0 =  [L_start(1); L_start(2); L_start(3)+delta_start_z];L_start;
Wp1 = [L_end(1); L_end(2); L_end(3)+delta_end_z];
retraction_direction = (Wp1-Wp0)/norm(Wp1-Wp0);

plot3([Wp0(1) Wp1(1)],[Wp0(2) Wp1(2)],[Wp0(3) Wp1(3)],'--', 'color', [0.5 0.5 0.5]);
plot3(Wp0(1),Wp0(2),Wp0(3),'*r');
plot3(Wp1(1),Wp1(2),Wp1(3),'*r');

% Position
delta_tether = l_tether_max - l_tether_min;
%sigma = 100;
theta_point = 0.2+pi/2;
l_tether = 600;
[ LemPs ] = updateLissajous( l_tether, LemPsRef );
Aphi = LemPs.Aphi;
Alambda = LemPs.Alambda;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
x_K = L_W * l_tether;

x_K = [300;0;300];

plot3(x_K(1,:), x_K(2,:),x_K(3,:), '+g'); hold on;
view(0,0);

h = [];

glidslope = [cos(lat_land)*1000, 0, sin(lat_land)*1000];
%plot3([0 glidslope(1)],[0 glidslope(2)],[0 glidslope(3)],'--', 'color', [0.5 0.5 0.5]);
state = 2;

for n = 1 :10000
    %% Test point
    % Initd
    delete(h);
    lat = atan( x_K(3) / x_K(1) );
    
    if state == 1
        
        % Step 1: Project position on retraction path
        dP = x_K - Wp0;
        dp_proj_W = retraction_direction'*dP/norm(retraction_direction)*retraction_direction/norm(retraction_direction);
        p_proj_W = Wp0+dp_proj_W;
        t = p_proj_W - Wp0;
        if acos( retraction_direction'*t / norm(t) / norm(retraction_direction)) > pi/2
            p_proj_W = Wp0;
        end
        
        p_VT_W = p_proj_W + retraction_direction/norm(retraction_direction) * ds;
        
        if x_K(1) <= x_0
            x_ = x_0 - min(x_K(1),x_0);
            lat_land = atan( (Wp0(3)-Wp1(3))/ (Wp0(1)-Wp1(1)) );
            
            gamma_cmd = -LemPs.phi0  + pi/2 * ( 1 - exp( -x_/T ) );
            
            chi_cmd  = atan2( retraction_direction(2), retraction_direction(1) );
            
            bearing_W = [cos(chi_cmd)*cos(gamma_cmd);sin(chi_cmd)*cos(gamma_cmd);sin(gamma_cmd)];
            if x_K(1) < 1.01*x_F %lat > lat_transition && state ~= 2
                state = 2;
                time = 0;
            end
        else
            %chi_cmd  = atan2( retraction_direction(2), retraction_direction(1) );
            bearing_W = (p_VT_W - x_K)/norm(p_VT_W - x_K);
            
            chi_new_cmd = atan2( bearing_W(2), bearing_W(1) );
            gamma_new_cmd = asin( bearing_W(3)/norm(bearing_W) );
            alpha = 0.95;
            chi_cmd = chi_new_cmd;%chi_cmd * alpha + chi_new_cmd * (1-alpha) ;
            gamma_cmd = gamma_cmd * alpha + gamma_new_cmd * (1-alpha) ;
            bearing_W = [cos(chi_cmd)*cos(gamma_cmd);sin(chi_cmd)*cos(gamma_cmd);sin(gamma_cmd)];
        end
      

        
    elseif state == 2 % transition
        phi0_trans = LemPs.phi0;
        gamma_t = gamma_t_star;
        % Step 1: Define target point on figure 8;
        sol = 0; % attractor point
        %         L = [LemPs.Alambda * sin(LemPs.blambda*sol');
        %             LemPs.Aphi    * sin(LemPs.bphi*sol') + LemPs.phi0];
        L = [LemPs.Alambda * sin(LemPs.blambda*sol');
            LemPs.Aphi    * sin(LemPs.bphi*sol') + phi0_trans];
        p_C_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))];
        % Step 2: Calculate distance to closest point
        delta = acos( min( max( x_K'/norm(x_K) * p_C_W/norm(p_C_W), -1),1 ) ) * norm(x_K);
        % Step 3: Calculate desired course in the tangential plane
        [ chi_K_des, bearing_vec_W ] = calcCourse2Tangent( LemPs, sol, x_K );
        
        % test
        e1 = bearing_vec_W/norm(bearing_vec_W);
        e3 = -p_C_W/norm(p_C_W);
        e2 = cross(e3, e1);
        %
        
        % Step 4: Calculate commanded course in tangential plane
        [ perpCourse, delta_vec ] = calcCourse2ClosestPoint( p_C_W, x_K );
        delta0 = 30;
        [Chi_t_cmd,Delta_chi] = calculateCommandedCourse(bearing_vec_W,delta_vec, delta, delta0, chi_K_des, p_C_W, x_K);
        % Step 5: Calculate bearing vector (desired flight direction in W frame)
        [bearing_W] = calculateCmdBearing(Chi_t_cmd,gamma_t, x_K);
        
        chi_new_cmd = atan2( bearing_W(2), bearing_W(1) );
        gamma_new_cmd = asin( bearing_W(3)/norm(bearing_W) );
        alpha = 0.96;
        chi_cmd = chi_cmd * alpha + chi_new_cmd * (1-alpha) ;
        if n == 1
            gamma_cmd = 0;
        end
        gamma_cmd = gamma_cmd * alpha + gamma_new_cmd * (1-alpha) ;
        
        bearing_W = [cos(chi_cmd)*cos(gamma_cmd);sin(chi_cmd)*cos(gamma_cmd);sin(gamma_cmd)];
        
        
        if lat < 1.1*phi0_trans %&& atan(x_K(2)/ x_K(1)) < 1*pi/180
            state = 3;
            c0 = 0; % initial solution on the lemniscate
            t = 0;
        end
    elseif state == 3 % figure 8 following
        distanceOrigin = norm(x_K);
        gamma_t = gamma_t_star;
        % This corresponds basically to stop reeling out.
        % the kite will now continue flying on the sphere,
        % but on a constant tether length.
        if distanceOrigin >= l_tether_max
            gamma_t = 0;
            lat = asin( x_K(3)/ norm(x_K) );
            long = atan2( x_K(2), x_K(1) );
            %if lat < 0.9*LemPs.phi0 && long > long_max
            delta_ = acos( min( max( x_K'/norm(x_K) * L_start/norm(L_start), -1),1 ) ) * norm(x_K);
            if delta_ < 10
                state = 1; % if lattitude condition is fullfiled
            end
        else
            state = 3;
        end
        if state == 3
            % Step 0: Update Lemniscate
            [ LemPs ] = updateLissajous( distanceOrigin, LemPsRef );
            % Step 1: Determine closest point
            [ sol,p_C_W ] = getTargetOnLissajous(LemPs, x_K, c0, distanceOrigin);
            % Step 2: Calculate distance to closest point
            delta = acos( min( max( x_K'/norm(x_K) * p_C_W/norm(p_C_W), -1),1 ) ) * norm(x_K);
            % Step 3: Calculate desired course in the tangential plane
            [ chi_K_des, bearing_vec_W ] = calcCourse2Tangent( LemPs, sol, x_K );
            % Step 4: Calculate commanded course in tangential plane
            [ perpCourse, delta_vec ] = calcCourse2ClosestPoint( p_C_W, x_K );
            delta0 = 30;
            [Chi_t_cmd,Delta_chi] = calculateCommandedCourse(bearing_vec_W,delta_vec, delta, delta0, chi_K_des, p_C_W, x_K);
            % Step 5: Calculate bearing vector (desired flight direction in W frame)
            [bearing_W] = calculateCmdBearing(Chi_t_cmd,gamma_t, x_K);
            c0 = sol;
        end
        
        chi_cmd = atan2( bearing_W(2), bearing_W(1) );
        gamma_cmd = asin( bearing_W(3)/norm(bearing_W) );
    end
    
    p_new = x_K + bearing_W;
    %quiver3( p_new(1),p_new(2),p_new(3),bearing_W(1),bearing_W(2),bearing_W(3),10,'-b', 'linewidth', 1, 'MaxHeadSize', 0.5);
    
    plot3(p_new(1),p_new(2),p_new(3),'.b' );
    l_tether = norm(p_new);
    x_K = p_new;
    title(['Tether length: ', num2str(norm(p_new)), '(m)'])
    h = plot3([0 p_new(1)],[0 p_new(2)],[0 p_new(3)],'-k');
    drawnow
    
end

