L = 300;

x = linspace( -L/2, L/2, 1000 );

sigma = 70;

gamma_cmd = -pi/2*exp( -x.^2./sigma^2)  + pi/2 - LemPsRef.phi0 ;

figure;
plot(x,gamma_cmd); hold on
plot( [-L/2 L/2], [+ pi/2 - LemPsRef.phi0, + pi/2 - LemPsRef.phi0], '--b');


%% Flare controller

T = 10;
x_F = 100;
x_0 = 150;
x = 50 : 0.1 : 200;
x_ = x_0 - min(x,x_0);
gamma_c = -30*pi/180  + pi/2 * ( 1 - exp( -x_/T ) );
figure;
plot(x, gamma_c * 180/pi );
%%
figure;
gamma_c = pi/2-30*pi/180  -pi/2 * ( 1 - exp( -x_/T ) );
plot(x, 180/pi*gamma_c);