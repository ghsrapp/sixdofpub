close all
% estimate wind field in h using regression and chebyshew polynomials
% data points for batch: 
y = wind_save.Data(:,1)'; %vw_x_W_filtered.Data(1,:)'; 
x = pos_W.Data(:,3);

numb_m = length( x );
batch_fac = 1/3; 
x_batch = x(2:ceil(numb_m*batch_fac)); 
y_batch = y(2:ceil(numb_m*batch_fac)); 
% 
% x_batch = x(1:20/dt:end); 
% y_batch = y(1:20/dt:end);

T0 = ones( 1, length(x_batch))'; 
T1 = x_batch; 
T2 = 2 * x_batch.^2 - 1; 
T3 = 4*x_batch.^3 - 3*x_batch; 
T4 = 8*x_batch.^4 -  8*x_batch.^2 + 1; 
%T5 = 2*x_batch.*T4 - T3; 
phi_reg = [T0, T1, T2, T3];

figure; 
plot( x,y, '+r');  hold on
drawnow; 
h = [];
%Theta = inv( phi_reg*phi_reg' ) * phi_reg * y; 
Theta = ( phi_reg'*phi_reg )\(phi_reg' * y_batch); 
%Theta = inv( phi_reg'*phi_reg )*(phi_reg' * y_batch); 


test = min(x_batch) : 1 : max(x_batch); 
test = test'; 
T0 = ones( 1, length(test))'; 
T1 = test; 
T2 = 2 * test.^2 - 1; 
T3 = 4*test.^3 - 3*test; 
T4 = 8*test.^4 -  8*test.^2 + 1; 
%T5 = 2*x_batch.*T4 - T3; 
phi_reg = [T0, T1, T2, T3];
plot( x,phi_reg*Theta, '-b');  hold on

%y_hat = Theta'*phi_reg; 
%Theta = 1e-3*rand( size(phi_reg,2),1);
W1 = 0.1;10; 
P = (1/1e6^2 * eye( size(phi_reg,2) ) + phi_reg' *W1* phi_reg)\eye(size(phi_reg,2)); 
%Theta = P * (1/1e6 * randn(size(phi_reg,2),1)*1e-6 + phi_reg'*y_batch); 
% Recursive Least squares 
for k = ceil(numb_m*batch_fac)+1 : numb_m
    x_new = x(k); 
    y_new = y(k); 
    T0 = 1; 
    T1 = x_new; 
    T2 = 2 * x_new.^2 - 1; 
   T3 = 4*x_new.^3 - 3*x_new; 
%    T4 = 8*x_new.^4 -  8*x_new.^2 + 1;
%    T5 = 2*x_new.*T4 - T3; 
    phi_reg = [T0, T1, T2,T3];
    K = P * phi_reg' * 1/( phi_reg * P * phi_reg' + 1/W1); 
    Theta = Theta + K * (y_new - phi_reg * Theta ); 
    P = (eye(length(P)) - K * phi_reg ) * P; 
    disp(['Iteration: ', num2str(k), ' of ', num2str(numb_m)]); 
    
    if mod(k,4000) == 0
        delete(h);
        %% test
        T0 = ones( 1, length(x))';
        T1 = x;
        T2 = 2 * x.^2 - 1;
        T3 = 4*x.^3 - 3*x;
       % T4 = 8*x.^4 -  8*x.^2 + 1;
       % T5 = 2*x.*T4 - T3; 
        phi_reg = [T0, T1, T2, T3];
        y_hat = phi_reg * Theta;
        %plot( x, y, '.r');  hold on
        h=plot( x, y_hat, '-b'); hold on 
        drawnow; 
    end
    
end

%% test
T0 = ones( 1, length(x))'; 
T1 = x; 
T2 = 2 * x.^2 - 1; 
T3 = 4*x.^3 - 3*x; 
T4 = 8*x.^4 -  8*x.^2 + 1; 
%T5 = 2*x.*T4 - T3; 
phi_reg = [T0, T1, T2,T3];
y_hat = phi_reg * Theta; 

%%
y = wind_save.Data(:,1)'; 
x = pos_W.Data(:,3)';

%% quick sanity check 
v_w_x_W = log(x*3.28084/0.15)./ log(20/0.15)*ENVMT.wv_ref_6m;

%%
figure; 
plot( x, y, '.r');  hold on
plot( x, y_hat, '-b'); 
plot( x, v_w_x_W, '-g'); 

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%% Determine Wind Gradient 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

dT0 = 0*ones( 1, length(x)); 
dT1 = ones( 1, length(x));  
dT2 = 4 * x; 
dT3 = 12*x.^2 - 3; 
dT4 = 32*x.^3 -  16*x ; 
ddh_phi_reg = [dT0; dT1; dT2; dT3; dT4];
ddh_y_hat = Theta' * ddh_phi_reg; 
ddt_vw_x = ddh_y_hat' .* h_dot.Data; 
%%
figure; 
plot( ddt_v_w_x_filtered.Time, ddt_v_w_x_filtered.Data, '.r'); hold on 
plot( h_dot.Time, ddt_vw_x, '-b'); 

%% sanity check gradient
ddh_v_w_x_W = 1./(x*3.28084)./ log(20/0.15)*ENVMT.wv_ref_6m;
dddt_v_w_x_W = ddh_v_w_x_W'.* h_dot.Data*3.28084; % note, height is feet in the windfield
plot( h_dot.Time, dddt_v_w_x_W, '-g'); 
