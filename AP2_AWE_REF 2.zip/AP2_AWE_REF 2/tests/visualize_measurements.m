close all
figure;
stairs( flight_log.timestamps, flight_log.p_OB_meas_radDs); hold on
stairs( flight_log.timestamps, flight_log.q_OB_meas_radDs); hold on
stairs( flight_log.timestamps, flight_log.r_OB_meas_radDs); hold on
%
figure;
stairs( flight_log.timestamps, flight_log.PHI_OB_meas_rad*180/pi); hold on
stairs( flight_log.timestamps, flight_log.THETA_OB_meas_rad*180/pi); hold on
stairs( flight_log.timestamps, flight_log.PSI_OB_meas_rad*180/pi); hold on
%
figure; 
stairs( flight_log.timestamps, flight_log.alpha_a_meas_rad*180/pi); hold on
stairs( flight_log.timestamps, flight_log.beta_a_meas_rad*180/pi); hold on
%
figure; 
plot3( flight_log.pos_x_G_O_GPS_meas, flight_log.pos_y_G_O_GPS_meas, flight_log.pos_z_G_O_GPS_meas, '-+b')