% Extended flaps (10 deg), no sideslip, no control input
Va = 30;
alpha_vec = [-8:2:44]'*pi/180;
CL_vec_30 = [-0.053;0.151;0.354;0.554;0.754;0.929;1.098;
1.250;1.374;1.468;1.497;1.491;1.501;1.504;1.505;1.504;
1.500;1.492;1.482;1.466;1.447;1.429;1.409;1.387;1.362;
1.331;1.298];
figure; 
plot(alpha_vec, CL_vec_30, '+'); hold on 
% Va = 50
alpha_50 = [-8 : 2 : 14]'*pi/180;
CL_vec_50 = [-0.052;0.151;0.352;0.554;0.750;
0.935;1.103;1.254;1.385;1.484;1.520;1.507];
plot( alpha_50, CL_vec_50, 'o'); 

%%
alpha_vec_1 = [-8 : 2 : 10]'*pi/180; 
idx_1 = min(find( alpha_vec >= 10*pi/180 ));
Phi_reg = [ones(length(alpha_vec_1),1), alpha_vec_1, alpha_vec_1.^2,  alpha_vec_1.^4];
Theta_1 = Phi_reg'*Phi_reg\eye(4) * Phi_reg' * CL_vec_30(1:idx_1);
alpha_vec_1 = [-8 : 0.1 : 10]'*pi/180; 
CL_vec_hat = Theta_1(1) + Theta_1(2)*alpha_vec_1 + Theta_1(3)*alpha_vec_1.^2 + Theta_1(4)*alpha_vec_1.^4;
plot(alpha_vec_1, CL_vec_hat, '-o');
%%
alpha_vec_2 = [10 : 2 : 44]'*pi/180; 
idx_2 = min(find( alpha_vec >= 10*pi/180 ));
Phi_reg = [ones(length(alpha_vec_2),1), alpha_vec_2, alpha_vec_2.^2];
Theta_2 = Phi_reg'*Phi_reg\eye(3) * Phi_reg' * CL_vec_30(idx_2:end);
alpha_vec_2 = [10 : 0.1 : 44]'*pi/180; 
CL_vec_hat = Theta_2(1) + Theta_2(2)*alpha_vec_2 + Theta_2(3)*alpha_vec_2.^2;
plot(alpha_vec_2, CL_vec_hat, '-.'); hold on;

%% Plot only quadratic
alpha_vec_1 = [-8 : 2 : 10]'*pi/180; 
idx_1 = min(find( alpha_vec >= 10*pi/180 ));
Phi_reg = [ones(length(alpha_vec_1),1), alpha_vec_1, alpha_vec_1.^2];
Theta_1 = Phi_reg'*Phi_reg\eye(3) * Phi_reg' * CL_vec_30(1:idx_1);
alpha_vec_1 = [-8 : 0.1 : 10]'*pi/180; 
CL_vec_hat = Theta_1(1) + Theta_1(2)*alpha_vec_1 + Theta_1(3)*alpha_vec_1.^2;
plot(alpha_vec_1, CL_vec_hat); hold on 
%plot(alpha_vec_1, P.C_L_0 + P.C_L_alpha.*alpha_vec_1, '-or' )

%% Compare with current CL model

sigma = ( 1+exp(-P.M*(alpha_vec-P.alpha0))+exp(P.M*(alpha_vec+P.alpha0)) )./...
    ( (1 + exp(-P.M*(alpha_vec-P.alpha0))).*(1+exp(P.M*(alpha_vec+P.alpha0))));
CLalpha = (1-sigma).*(P.C_L_0 + P.C_L_alpha.*alpha_vec)+...
    sigma .* ( 2 * sign(alpha_vec).*sin(alpha_vec).^2.*cos(alpha_vec));

plot( alpha_vec, CLalpha, '-+')