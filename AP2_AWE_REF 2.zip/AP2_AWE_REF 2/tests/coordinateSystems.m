%pos_E.Data = 0 * pos_E.Data; 
figure; 
h_tot = [];
axis equal; hold on; grid on; hold on; 
axis([-30 30 -30 30 -30 30 ]); hold on 
h_ex_ref = quiver3( 0, 0, 0, -20, 0, 0); 
h_ey_ref = quiver3( 0, 0, 0, 0, 20, 0); 
set(h_ex_ref, 'Linewidth', 1.2, 'color','magenta','Linestyle','--','MaxHeadSize', 0.6);
set(h_ey_ref, 'Linewidth', 1.2, 'color','black','Linestyle','--','MaxHeadSize', 0.6);

for tcnt = 1 : 1 :  length ( pos_E.Data(:,1) )
    % Calculate body fixed frame in W coordinates 
    phi = phi_save(tcnt)*pi/180; 
    theta = theta_save(tcnt)*pi/180; 
    psi = psi_save(tcnt)*pi/180; 
    
    title(['\Phi = ', num2str( phi_save(tcnt)), ' \Theta = ', num2str( theta_save(tcnt)), ' \Psi = ', num2str( psi_save(tcnt))]); 

    
    e_xB_O = [cos(psi)*cos(theta); sin(psi)*cos(theta); -sin(theta)];
    e_yB_O = [cos(psi)*sin(theta)*sin(phi)-sin(psi)*cos(phi); sin(psi)*sin(theta)*sin(phi)+cos(psi)*cos(phi); cos(theta)*sin(phi)];
    e_zB_O = [cos(psi)*sin(theta)*cos(phi)+sin(psi)*sin(phi); sin(psi)*sin(theta)*cos(phi)-cos(psi)*sin(phi); cos(theta)*cos(phi)];
    
    scale = 20; 
    
    e_x_W = scale*M_WO*e_xB_O; 
    e_y_W = scale*M_WO*e_yB_O; 
    e_z_W = scale*M_WO*e_zB_O; 

    
    delete(h_tot);
   % plot3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), '.b', 'Linewidth', 2, 'Markersize', 5 ); hold on
  %  plot3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), 0, '.k' );
   % plot3( 0, pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), '.k' );
  %  plot3( pos_E.Data(tcnt,1), 200, pos_E.Data(tcnt,3), '.k' );
  %  h_VT = plot3( p_VT_E.Data(tcnt,1)/norm(p_VT_E.Data(tcnt,:))*norm(pos_E.Data(tcnt,:)),...
  %                p_VT_E.Data(tcnt,2)/norm(p_VT_E.Data(tcnt,:))*norm(pos_E.Data(tcnt,:)),...
  %                p_VT_E.Data(tcnt,3)/norm(p_VT_E.Data(tcnt,:))*norm(pos_E.Data(tcnt,:)), 'color', 'red', 'Marker', '*' );
  %  h_tether = plot3( [0 pos_E.Data(tcnt,1)], [0 pos_E.Data(tcnt,2)], [0 pos_E.Data(tcnt,3)], '-k'); 
  %  h_p = plot3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), 'xb' );
    
 %   h_bearing = quiver3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), scale*bearing_vec_proj_W.Data(tcnt,1), scale*bearing_vec_proj_W.Data(tcnt,2), scale*bearing_vec_proj_W.Data(tcnt,3)); 
    
 %   h_Refbearing = quiver3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), scale*refBearing.Data(tcnt,1), scale*refBearing.Data(tcnt,2), scale*refBearing.Data(tcnt,3)); 

 %   set(h_bearing, 'Linewidth', 1.2, 'color', '[0.0 0.5  0.0]','Linestyle','-','MaxHeadSize', 0.6);
 %   set(h_Refbearing, 'Linewidth', 1.2, 'color',  'red','Linestyle','-','MaxHeadSize', 0.6);

    h_ex = quiver3( 0 * pos_E.Data(tcnt,1), 0 * pos_E.Data(tcnt,2), 0 * pos_E.Data(tcnt,3), e_x_W(1), e_x_W(2), e_x_W(3) ); 
    h_ey = quiver3( 0 * pos_E.Data(tcnt,1), 0 * pos_E.Data(tcnt,2), 0 * pos_E.Data(tcnt,3), e_y_W(1), e_y_W(2), e_y_W(3) ); 
    h_ez = quiver3( 0 * pos_E.Data(tcnt,1),0 *  pos_E.Data(tcnt,2), 0 * pos_E.Data(tcnt,3), e_z_W(1), e_z_W(2), e_z_W(3) ); 
      
  %  hT_ref  = quiver3( pos_E.Data(tcnt,1), pos_E.Data(tcnt,2), pos_E.Data(tcnt,3), scale*e_xT_W(tcnt,1), scale*e_xT_W(tcnt,2), scale*e_xT_W(tcnt,3) ); 
  %  set(hT_ref, 'Linewidth', 1.2, 'color','cyan','Linestyle','-','MaxHeadSize', 0.6);
    
     set(h_ex, 'Linewidth', 1.2, 'color','magenta','Linestyle','-','MaxHeadSize', 0.6);
    set(h_ey, 'Linewidth', 1.2,  'color','black','Linestyle','-','MaxHeadSize', 0.6);
    set(h_ez, 'Linewidth', 1.2,  'color','black','Linestyle','-','MaxHeadSize', 0.6);

    h_tot = [h_VT, h_p,h_tether,h_bearing,h_Refbearing, h_ex, h_ey, h_ez,hT_ref];
    drawnow;
    cnt = cnt + 1; 
    pause;
end