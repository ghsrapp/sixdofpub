function [Gamma_cmd,Chi_cmd, sol] = getPathReference_(LemPsRef,x_K, c0, V_k, t0, windDirection_rad,gamma_t)
%GETPATHREFERENCE 
% =========================================================================
% Version: 1.0. 
% Author: Sebastian Rapp
% Mail: s.rapp@tudelft.nl
% Returns course and path angle as usually specified between K and O frame.
% Inputs are: Lissajous parameters LemPsRef, the kite position in W frame
% x_K, the previous solution c0, the current kite velocity V_k, and a
% tunring parameter t0. 
% Algorithm:
% 1) Determine the closest point on the flight path relative to the current
% kite position (computed on unit sphere)
% 2) Calculate the tangent on the path at the closest point and determine
% the final desired course in the tangential plane 
% 3) Add/Subtract an increment of the tangential course to obtain a course
% that guides the guide onto the path. Depending on the current velocity of
% the kite and the distance the increment will be decreased such that if
% the kite is on the path the commanded course is equal the course obtained
% in step 2).
% 4) Calculate the desired bearing vector and compute the course and path
% angle (angles between O and K frame and return these values.
% =========================================================================

distanceOrigin = norm(x_K); 

% Step 0: Update Lemniscate
[ LemPs ] = updateLissajous( distanceOrigin, LemPsRef );

% Step 1: Determine closest point
[  sol,p_C_W ] = getTargetOnLissajous(LemPs, x_K, c0, distanceOrigin);

% Step 2: Calculate distance to closest point
delta = acos( min( max( x_K'/norm(x_K) * p_C_W/norm(p_C_W), -1),1 ) ) * norm(x_K);

% Step 3: Calculate desired course in the tangential plane
[ chi_K_des, bearing_vec_W ] = calcCourse2Tangent( LemPs, sol, x_K );
[ perpCourse, delta_vec ] = calcCourse2ClosestPoint( p_C_W, x_K );

% Step 4: Calculate commanded course in tangential plane
delta0 = V_k*t0;
[Chi_t_cmd] = calculateCommandedCourse(bearing_vec_W,delta_vec, delta, delta0, chi_K_des, p_C_W);

% Step 5: Calculate bearing vector (desired flight direction in W frame)
[bearing_W] = calculateCmdBearing(Chi_t_cmd,gamma_t, x_K);
bearing_W = bearing_W'/norm(bearing_W);

% Step 6: Transform bearing vector into O frame (represents the desired
% velocity vector in the O frame.
[bearing_O] = transformFromWtoO(windDirection_rad,bearing_W');
bearing_O = bearing_O/norm(bearing_O); 

% Step 7: Calculate Course and Flightpath angle (common aerospace definition -
% between K and O frame)
Gamma_cmd = -asin( bearing_O(3) );
Chi_cmd = atan2( bearing_O(2), bearing_O(1) );
end

