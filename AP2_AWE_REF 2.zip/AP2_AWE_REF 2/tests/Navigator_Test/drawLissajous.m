
l_tether = 200; % distance to the ground station (where the path is drawn)

[ LemPs ] = updateLissajous( l_tether, LemPsRef );

theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';

L = [LemPs.Alambda * sin( LemPs.blambda*theta_vec');
    LemPs.Aphi    * sin(LemPs.bphi*theta_vec') + LemPs.phi0];

figure(1);
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];

L_W_k = L_W * l_tether;
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;
axis equal; grid on;hold on; view(90,0);