clear all
close all
clc

windDirection_rad = pi; % the wind direction is counted positive from north (right hand rotation fro
initLissajous;
drawLissajous;