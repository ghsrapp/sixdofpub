clear 
close all
clc



t = 0 : 0.1 : 10; 

x = sin(t); 
z_vec = 1 : 1 : 4;
y_tot = [];
for l = 1 : length( z_vec)
    y(:,l) = sin(z_vec(l).*x) + cos(2*x) + exp( -x.^2 ); 
    y_tot = [y_tot; y(:,l)];
end


%%
figure; 
for l = 1 : length( z_vec)
y1 = sin(z_vec(l).*x) + cos(2*x) + exp( -x.^2 ); 
plot( x, y(:,l), 'o' ) ; hold on 
end

%%
% least square regression 
T0 = ones( 1, length(x)); 
T1 = x; 
T2 = 2 * x.^2 - 1; 
T3 = 4*x.^3 - 3*x; 
T4 = 8*x.^4 -  8*x.^2 + 1; 
phi_reg1 = [T0; T1; T2; T3; T4];

v = [z_vec(1).*x, z_vec(2).*x, z_vec(3).*x, z_vec(4).*x];
T0 = ones( 1, length([z_vec(1).*x, z_vec(2).*x, z_vec(3).*x, z_vec(4).*x])); 
T1 = [z_vec(1).*x, z_vec(2).*x, z_vec(3).*x, z_vec(4).*x]; 
T2 = 2 * (v).^2 - 1; 
T3 = 4*(v).^3 - 3*(v); 
T4 = 8*v.^4 -  8*v.^2 + 1; 
phi_reg2 = [T0; T1; T2; T3; T4];
phi_reg = [phi_reg2];

Theta = eye(size(phi_reg,1))\(phi_reg*phi_reg') * phi_reg * y_tot; 

Theta = inv( phi_reg*phi_reg' ) * phi_reg * y'; 

v = z_vec(1).*x;
T0 = ones( 1, length(v)); 
T1 = v; 
T2 = 2 * (v).^2 - 1; 
T3 = 4*(v).^3 - 3*(v); 
T4 = 8*v.^4 -  8*v.^2 + 1; 
phi_reg2 = [T0; T1; T2; T3; T4];

y_hat = Theta'*phi_reg2; 
plot(v, y_hat, '-b'); 
