function handle = drawVehicleBody3(V,F,patchcolors,...
    pn, pe, pd, phi, theta, psi,...
    handle,mode)
V = rotate(V, phi, theta, psi); % body frame into NED frame
V = translate(V, pn , pe, pd);

M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
V = M_EO*V; % Transform from NED into E frame
if isempty(handle),
    handle = patch('Vertices', V', 'Faces', F, ....
        'FaceVertexCData', patchcolors,...
        'FaceColor', 'flat');%,...
    %'EraseMode', mode);
else
    set(handle,'Vertices', V', 'Faces', F);
    drawnow
end
end