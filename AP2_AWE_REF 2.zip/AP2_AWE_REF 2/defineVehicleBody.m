function [V,F,facecolors] = defineVehicleBody
scale = 5;
b_wing = 3.7*scale;
c_wing = 0.22*scale;
L_fuse = 1*scale;
b_fuse = 0.1*scale;
c_emp = 0.1*scale;
b_emp = 0.4*scale;
h_rud = 0.3*scale;
h_fuse = 0.1*scale;
x_nose = 0.5*scale;
x_tail = 1.5*scale;
b_fuse = 0.1*scale;
xp = 0.1*scale;
x_LE = 0.1*scale;
c_rud = 0.1*scale;
V = [...
    x_nose, 0, 0; %1
    x_nose-xp, b_fuse/2, -h_fuse/2; %2
    x_nose-xp, b_fuse/2, +h_fuse/2; %3
    x_nose-xp, -b_fuse/2, +h_fuse/2; %4
    x_nose-xp, -b_fuse/2, -h_fuse/2; %5
    -x_tail, 0, 0; %6
    x_LE, b_wing/2, 0;%7
    x_LE-c_wing, b_wing/2, 0;%8
    x_LE-c_wing, -b_wing/2, 0; %9
    x_LE, -b_wing/2, 0;  %10
    -x_tail, -b_emp/2, 0;... % 11
    -(x_tail+c_emp), -b_emp/2, 0;...% 12
    -(x_tail+c_emp), b_emp/2, 0;...% 13
    -x_tail, b_emp/2, 0;...% 14
    -(x_tail+c_emp), 0, 0;... % 15
    -(x_tail+c_emp+c_rud), 0, 0;...% 16
    -(x_tail+c_emp+c_rud), 0, -h_rud;...% 17
    -(x_tail+c_emp), 0, -h_rud;...% 18
    ]';
F = [...
    1,2,3,3;... % pyramid
    3,4,1,1;...
    1,4,5,5;...
    1,2,5,5;...
    3,4,6,6;...
    4,5,6,6;...
    2,5,6,6;...
    2,3,6,6;...
    2,5,6,6;...
    7,8,9,10;...
    11,12,13,14;...
    15,16,17,18;...
    ];
facecolors = [0,0,1];
end
