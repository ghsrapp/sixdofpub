clear all
close all
clc

sim_with_indx = 6;
optimize_longi_flag = -1; % 1: Long, -1: SP, 0: Lat
path2trimcase = 'Trim_results/case_1_phi35_mix_ft_and_alpha/';

% ============== Setup optimization ==================================================================================================
save('sim_with_indx', 'sim_with_indx');
save('optimize_longi_flag', 'optimize_longi_flag');

resume_string = 'no'; 

if strcmp(resume_string, 'no')
    delete('*.dat'); 
    delete('list_old_individuals.mat');
end

load([path2trimcase,'/G_save.mat']);
load([path2trimcase,'/rps_st.mat']);
load([path2trimcase,'/x0_save.mat']);
load([path2trimcase,'/u0_save.mat']);
load([path2trimcase,'/M_OB_init.mat']);

% bounds for longi PI-LQR
qs = [30,0,0,50];
qs_lbounds = 0*ones( length( qs ),1);
qs_lbounds(end) = 1;
qs_ubounds = 100*ones( length( qs ),1);
Q_long = diag( [0, qs] );
R_long = 1;

lat_low_bounds = [1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3];
lat_up_bounds = [10; 10; 1; 10; 10; 10];
lat_p_init = [0.04; 1/5; 1/sqrt(2); 3.86;4;4];

% Load the system matrices
A = G_save{sim_with_indx}.A(1:9, 1:9);
B = G_save{sim_with_indx}.B(1:9, 1:4);
A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
          A(3,1), A(3,3), A(3, 5), A(3,8);
          A(5,1), A(5,3), A(5, 5), A(5,8);
          A(8,1), A(8,3), A(8, 5), A(8,8)];
B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
C = [0,1,0,0];
A_long_aug = [A_long, zeros(4,1);
            -C, 0];
B_long_aug = [B_long; 0];
sys_trim.A_long = A_long_aug;
sys_trim.B_long = B_long_aug;

% Short period approximation
A_SP = [A_long(2,2), A_long(2,4); 
        A_long(4,2), A_long(4,4)];
B_SP = [B_long(2,1); B_long(4,1)];
A_SP_aug = [A_SP, zeros(2,1); 
    -1, 0, 0];
B_SP_aug = [B_SP; 0]; 
sys_trim.A_SP = A_SP_aug;
sys_trim.B_SP = B_SP_aug;
% bounds for longi PI-LQR
qs_sp = [30,0,50];
qs_lbounds_sp  = 0*ones( length( qs_sp ),1);
qs_lbounds_sp (end) = 1;
qs_ubounds_sp  = 100*ones( length( qs_sp ),1);

% Lateral dynamics
A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9); % beta
         A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9); % phi_tau
         A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9); % psi_tau
         A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9); % p 
         A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];% r

B_lat = [B(2,1),B(2,3);...
         B(4,1),B(4,3);...
         B(6,1),B(6,3);...
         B(7,1),B(7,3);...
         B(9,1),B(9,3)];
     
A_lat(3,:) = [];
A_lat(:,3) = [];
B_lat(3,:) = [];
C_control = zeros(2, size( A_lat,2) ); 
C_control(1,1) = 1; 
C_control(2,2) = 1;  
A_lat_aug = [A_lat, zeros(size( A_lat,2) ,2); 
    -C_control, zeros(2,2)]; 
B_lat_aug = [B_lat; zeros(2)]; 

sys_trim.A_lat = A_lat_aug;
sys_trim.B_lat = B_lat_aug;

save('sys_trim.mat', 'sys_trim');

% Optimize performance & robustness
if optimize_longi_flag == 1
    runOptimization_SOO_long(qs_ubounds,qs_lbounds, qs, resume_string);
elseif optimize_longi_flag == -1
    runOptimization_SOO_SP(qs_ubounds_sp,qs_lbounds_sp, qs_sp, resume_string);
else
    runOptimization_SOO_lat(lat_up_bounds, lat_low_bounds, lat_p_init,resume_string);
end



