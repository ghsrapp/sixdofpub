
x = 0 : 0.1 : L_end(1)+50;
x_ = L_end(1)+50 - x;
TT = 10;
f = -30*pi/180 * exp( - x_/TT );
plot(x_ , f)