%clear switchSolver3; % clear the persistent variables in switchSolver3
clear all
close all
clc 
load('x.mat');
init_new_AP2;

TSIM = 200; % upper bound

%load('x.mat'); 
assignOptVariables2SimWorkspace2(maxBandwidth,x)

%allocateOptVariables2Struct;

% Test
%Lbooth.a = paramStruct.a_booth*paramStruct.b_booth;
%Lbooth.b = paramStruct.b_booth;
%Lbooth.phi0 = paramStruct.phi0_booth; 

Lbooth.a = evalin('base','a_booth')*evalin('base','b_booth');
Lbooth.b = evalin('base','b_booth');
Lbooth.phi0 = evalin('base','phi0_booth'); 

%% simulate
simOut = sim('optAWE_Testbed_light', 'CaptureErrors','on');
assignin('base', 'visualization_stuff', simOut.visualization_stuff );

TSIM = simOut.sim_time(end); 
assignin('base', 'TSIM', TSIM );

%% Visualize
addpath('Visualization_Offline');
sim('visualize_offline_v2');
drawBooth;
rmpath('Visualization_Offline\');


%% print some results + high level set points
clc
disp(['Mean power output: ', num2str(mean( simOut.power_vr_tether.Data(:,1))/1000), ' kW' ]);
disp(['Tether force set point: ', num2str(  evalin('base','F_T_traction_set') ), ' N' ]);
disp(['Mean elevation angle: ', num2str(Lbooth.phi0*180/pi), ' degrees' ]);
disp(['path height: ',num2str(Lbooth.a), ' m' ]);
disp(['path width: ', num2str(Lbooth.b), '  m' ]);

