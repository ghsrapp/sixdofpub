clear all 
close all
clc

TSIM = 140; 
% call init script 
init_new;
close all;
maxBandwidth = aileron.w0; 
FitnessFunction = @(x)costFunctionRetract(x,maxBandwidth,TSIM); 
numberOfVariables = 6;

%% Retraction controller
lb_gain_chi_retract = 1;
ub_gain_chi_retract = 30;
lb_gain_chi_retract_i = 0;
ub_gain_chi_retract_i = 10;

lb_gain_gamma_retract = 1;
ub_gain_gamma_retract = 30;
lb_gain_gamma_retract_i = 0;
ub_gain_gamma_retract_i = 10;

lb_v_retraction_opt = -25;
ub_v_retraction_opt = -10; 

ub_gamma_retract_opt = 0;
lb_gamma_retract_opt = -30;

numPop = 20;%20; % lets see

lb = [lb_gain_chi_retract,lb_gain_chi_retract_i,lb_gain_gamma_retract,lb_gain_gamma_retract_i,...
     lb_v_retraction_opt,lb_gamma_retract_opt]; % vector with all the lower bounds
ub = [ub_gain_chi_retract,ub_gain_chi_retract_i,ub_gain_gamma_retract,ub_gain_gamma_retract_i,...
    ub_v_retraction_opt,ub_gamma_retract_opt]; % vector with all the upper bounds

load('pop_retrac_tmp1.mat');

% %factor_f_t_set_init = (ub_factor_f_t_set- lb_factor_f_t_set) * randi(  numPop,1 ) + lb_factor_f_t_set*ones(numPop,1);     
% gain_chi_tau_trans_init = randi( [lb_gain_chi_retract,ub_gain_chi_retract], size(population,1), 1 );
% gain_gamma_tau_trans_init = randi( [lb_gain_chi_retract_i,ub_gain_chi_retract_i], size(population,1), 1 );
% gain_gamma_tau_init =       randi( [lb_gain_gamma_retract,      ub_gain_gamma_retract], size(population,1), 1 );
% gain_gamma_tau_i_init =     randi( [lb_gain_gamma_retract_i,    ub_gain_gamma_retract_i], size(population,1), 1 );
% v_retraction_opt_init =  randi( [lb_v_retraction_opt,    ub_v_retraction_opt], size(population,1), 1 );
% gamma_retract_opt_init = randi( [lb_gamma_retract_opt,    ub_gamma_retract_opt], size(population,1), 1 );

% population = [population,gain_chi_tau_trans_init,...
%     gain_gamma_tau_trans_init,gain_gamma_tau_init,...
%     gain_gamma_tau_i_init,v_retraction_opt_init,gamma_retract_opt_init];                    
%                     
opts = optimoptions('ga', ...
                    'UseParallel',false,...
                    'PopulationSize', numPop, ...
                    'MaxGenerations', 50, ...
                    'EliteCount', 1, ...
                   'FunctionTolerance', 1e-16, ...
                    'PlotFcn', @myPlotFunc, ...
                     'InitialPopulation',pop_retraction_current);                    
                 
%%
IntCon = 1 : numberOfVariables; 
%parpool('local');
%pctRunOnAll(['addpath ', pwd]);
%addAttachedFiles(myPool,{'AWE_Testbed_opt.slx'});
%parfevalOnAll(@load_system,0,'AWE_Testbed_opt');

[x,fval,exitflag,output,population,scores] = ga(FitnessFunction, numberOfVariables, [],[],[],[], lb,ub, [],IntCon,opts);
save('re_population_solution1.mat', 'population');
save('opt_retractcontrol1.mat', 'x');

%delete(gcp);