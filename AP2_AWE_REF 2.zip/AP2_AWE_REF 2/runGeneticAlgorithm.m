%% Iterate through generations (Main Loop)
while iga<maxit % maxit is number of generations
  %  tic;
    iga=iga+1; % increments generation counter
    %_______________________________________________________
    % Pair and mate
    M=ceil((popsize-keep)/2); % number of matings (we always keep half of the popsize
    % prob=flipud([1:keep]'/sum([1:keep])); % weights chromosomes
    prob = [keep:-1:1]'/sum([1:keep]);
    odds=[0 cumsum(prob(1:keep))']; % probability distribution function
    % essentially: the probability that we choose a chromosome up to a
    % certain rank: e.g. rank1: simply the probability of rank1, up to
    % rank3: P(rank1)+P(rank2)+P(rank3) and so on.. probabiltiy that we
    % choose a chromosome up to rank 6 is of course 1 because we definitely
    % choose 1 of the 6.
    
    
    pick1=rand(1,M); % mate #1 (vector of length M with random #s between 0 and 1)
    pick2=rand(1,M); % mate #2
    % ma and pa contain the indices of the chromosomes that will mate
    % Choosing integer k with probability p(k)
    %
    % We look in which interval the three random variables are falling.
    % choose the chromosome index of the lower bound
    ic=1;
    while ic<=M
        for id=2:keep+1
            if pick1(ic)<=odds(id) && pick1(ic)>odds(id-1)
                ma(ic)=id-1;
            end
            if pick2(ic)<=odds(id) && pick2(ic)>odds(id-1)
                pa(ic)=id-1;
            end
        end
        ic=ic+1;
    end
    %_______________________________________________________
    % Performs mating using single point crossover
    ix=1:2:keep; % index of mate #1
    xp=ceil(rand(1,M)*Nt); % crossover point, choose randomly one of the parameters that you exchange
    r=rand(1,M); % mixing parameter (its the beta in the text)
    for ic=1:M
        % take ma(ic) chromosome, and the respective parameter (same for
        % pa)
        xy=par(ma(ic),xp(ic))-par(pa(ic),xp(ic)); % ma and pa mate % par is the sorted population (part of the weighting)
        
        par(keep+ix(ic),:)=par(ma(ic),:); % 1st offspring (replace in population everything after keep: so keep+1, keep+3
        par(keep+ix(ic)+1,:)=par(pa(ic),:); % 2nd offspring (same: keep+2, keep+4)
        
        par(keep+ix(ic),xp(ic))=par(ma(ic),xp(ic))-r(ic).*xy; % 1st % the linear weighting in the doc.
        par(keep+ix(ic)+1,xp(ic))=par(pa(ic),xp(ic))+r(ic).*xy; % 2nd
        
        if 0
            if xp(ic)<npar % crossover when last variable not selected: dont really get this part, it basically assign for the first
                %parent the last parameter of the second parent
                par_temp = par(keep+ix(ic),:);
                par(keep+ix(ic),:)=  [par(keep+ix(ic),  1:xp(ic)), par(keep+ix(ic)+1,xp(ic)+1:npar)]; % xm yd
                %par(keep+ix(ic)+1,:)=[par(keep+ix(ic)+1,1:xp(ic)), par(keep+ix(ic),  xp(ic)+1:npar)]; % xd xm
                par(keep+ix(ic)+1,:)=[par(keep+ix(ic)+1,1:xp(ic)), par_temp(1,  xp(ic)+1:npar)]; % xd xm
            end % if
        end
    end
    
    
    %_______________________________________________________
    % Mutate the population
    %mrow=sort(ceil(rand(1,nmut)*(popsize-1))+1); % mutation of chromosomes
    mrow = sort( ceil( popsize * rand(1,nmut) ) );
    mcol=ceil(rand(1,nmut)*Nt); % mutation of genes
    for ii=1:nmut
        if mcol(ii) == 1 % mutation of the first parameter has different bounds
            %par(mrow(ii),mcol(ii))=(hi1-lo1)*rand+lo1;
            indx = randi([1 length( feasible_set_coursePred)],1,1);
            par(mrow(ii),mcol(ii)) = feasible_set_coursePred(indx);
        elseif mcol(ii) == 14 || mcol(ii) == 15 || mcol(ii) == 16
            %feasible_set_rates = [30,25,20,15,10];
            indx = randi([1 length( feasible_set_rates)],1,1);
            par(mrow(ii),mcol(ii)) = feasible_set_rates(indx); 
        elseif mcol(ii) == 17 || mcol(ii) == 18 || mcol(ii) == 19 || mcol(ii) == 20 || mcol(ii) == 21
            %feasible_set_attitude = [1/2,1/3,1/4,1/5,1/6];
            indx = randi([1 length( feasible_set_attitude)],1,1);
            par(mrow(ii),mcol(ii)) = feasible_set_attitude(indx);   
        else
            %par(mrow(ii),mcol(ii))=(varhi-varlo)*rand+varlo; % just assign a new random variable.
            indx = randi([1 length( feasible_set_gains)],1,1);
            par(mrow(ii),mcol(ii)) = feasible_set_gains(indx);   
        end
        % mutation
    end % ii
    %_______________________________________________________
    % The new offspring and mutated chromosomes are
    % evaluated
    %cost=feval(ff,par); % evalute the new offspring.
    for cnt = 1 : popsize
       
        genesForGA_Lissajous;
        
        simOut = sim('AWE_Testbed_07', 'CaptureErrors', 'on');
        %simOut.getSimulationMetadata.ExecutionInfo
        
        if strcmp(simOut.ErrorMessage,'Simulation stopped because of a runtime error.') || max(simOut.sim_time) < TSIM
            cost_vec(cnt) = NaN;
        else
            evaluateFitnessFunc;
            figure(2)
            plot( iga,  F, '+c'); hold on; 
            cost_vec(cnt)=F;
        end
            %clear airdata omega_OB_rad course_tau_traction
      
         % calculates population cost using ff
         disp(['#individual=' num2str(cnt) ' current cost=' num2str(F(1))])
        

    end

    %_______________________________________________________
    % Sort the costs and associated parameters
    [cost,ind]=sort(cost_vec);
    par=par(ind,:); % rank the population according to fitness
    Coords{iga+1}=par;
    save('par_simple_PCH.mat', 'par'); % to keep always the current status.
    %_______________________________________________________
    % Do statistics for a single nonaveraging run
    minc(iga+1)=min(cost);
    meanc(iga+1)=mean(cost);
    figure(2); 
    plot( iga+1,  minc(iga+1), 'ob'); hold on; 
    plot( iga+1,   meanc(iga+1), 'xr'); hold on;
    xlabel('iga'); 
    ylabel('cost');    
    set(gca, 'TickLabelInterpreter','latex');
    %h=legend('min', 'avg'); 
%    set(h, 'interpreter', 'latex'); 
    %_______________________________________________________
    % Stopping criteria
    if iga>maxit || cost(1)<mincost
        break
    end
    disp(['#generations=' num2str(iga) ' best cost=' num2str(cost(1)) ' best genes=' num2str(par(1,:))])
   % figure(1); 
   % clf; 
   % visualization_stuff = simOut.visualization_stuff;
    %sim('Visualization_Offline\visualize_offline_v2.slx');
    %[iga cost(1)];
   % toc;
end %iga


%% Displays the output
day=clock;
disp(datestr(datenum(day(1),day(2),day(3),day(4),day(5),day(6)),0))
disp(['optimized function is ' ff])
format short g
disp(['popsize=' num2str(popsize) ' mutrate=' num2str(mutrate) ' # par=' num2str(npar)])
disp(['#generations=' num2str(iga) ' best cost=' num2str(cost(1))])
disp('best solution')
disp(num2str(par(1,:)))
disp('continuous genetic algorithm')
figure(1)
iters=0:length(minc)-1;

plot(iters,minc,iters,meanc,'-');
xlabel('generation');ylabel('cost');