function [cost_summary] = get_robustification_cost( time_domain_ref, frequ_domain_ref, A_long, B_long, K_long )

opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');

for i = 1:size(K_long,3)
    
    [stabmarg, CL] = getRobStabMargin_long( A_long, B_long, K_long(:,:,i), [0,1,0,0,0], opts, frequ_domain_ref);
    step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
    % Tracking cost
    % cost_Overshoot =  ( step_info.Overshoot*100 - time_domain_ref.Overshoot )^2;
    % cost_SettlingTime =   ( step_info.SettlingTime - time_domain_ref.SettlingTime )^2;
     cost_RiseTime(i) =   100*( step_info.RiseTime - time_domain_ref.RiseTime )^2;
    
    % Threshold cost
    cost_Overshoot(i) =  ( step_info.Overshoot*100 - time_domain_ref.Overshoot ) * max( step_info.Overshoot - time_domain_ref.Overshoot, 0)  ;
    cost_SettlingTime(i) =   ( step_info.SettlingTime - time_domain_ref.SettlingTime ) * max( step_info.SettlingTime - time_domain_ref.SettlingTime, 0)  ;
    %cost_RiseTime(i) =   2*( step_info.RiseTime - time_domain_ref.RiseTime ) * max( step_info.RiseTime - time_domain_ref.RiseTime, 0)  ;
    
    cost_time = cost_Overshoot(i) + ...
        cost_SettlingTime(i) + ...
        cost_RiseTime(i);
    
    %cost_robustness(i) =  10*(exp( max( 1-stabmarg.LowerBound, 0) ) - 1); % if its smaller than 1 penalize
    weight = 10; %50; 
    cost_robustness(i) =  max( -weight*stabmarg.LowerBound+weight, -weight);   %max( (-2-weight)/2*stabmarg.LowerBound+weight, -2 ); 
 
    
    cost_CriticalFrequency(i) =  0;% max( 1/(frequ_domain_ref.CriticalFrequ-stabmarg.CriticalFrequency), 0 );
    
    cost(i) = cost_time+cost_robustness(i);%+cost_CriticalFrequency(i);
    fprintf('Risetime: %d\n',  step_info.RiseTime); 
    fprintf('Stabmarg: %d\n',  stabmarg.LowerBound); 

end
cost_summary = [cost_Overshoot; cost_SettlingTime; cost_RiseTime; cost_robustness; cost_CriticalFrequency; cost];


end