% Params for Aersonade UAV
% Mass and inertia
P.g = 9.81; 
P.rho_air = 1.225;
P.mass = 4.778;4;
% New inertia tensor
P.Jx   = 1.7477; 
P.Jy   = 0.2780; 
P.Jz   = 1.8314;
P.Jxz  = -0.0166; 

% Old inertia data
P.Jx   = 1.82965; 
P.Jy   = 0.26512; 
P.Jz   = 2.08559;
P.Jxz  = 0.01669; 

P.J = [P.Jx, 0, -P.Jxz; 
    0, P.Jy, 0; 
    -P.Jxz, 0, P.Jz]; 
P.Jinv = inv( P.J ); 



% Wing
P.S_wing        = 0.7592;%0.7879;%0.55;
P.b             = 3.7;%2.8956;
P.c             = 0.22328;%0.2331;%0.18994;
P.M             = 20;
P.epsilon       = 0.1592;
P.alpha0        = 10*pi/180;
P.e             = 0.9; % guessed
P.AR = 17.376;

% Tether
P.Ctether = 1; 
P.dTether = 0.002; 

% The values are all compared to the values in the aerosonde model
% Lift coeffcient

% Big differences 
P.C_L_q         = 1* 7.267; 
P.C_m_q         = -16.374; %  compared to -3.6; 
P.C_n_beta      = 0.00103 * 180/pi; % compared to 0.25; !!! 
P.C_n_p         = -0.131; % compared to 0.022;  !!!
P.C_n_r         = -0.0335; % compared to -0.35; !!!
P.C_Y_beta      = -0.2435;% % compared to -0.98;
P.C_Y_p         = -0.133; % compared to 0
P.C_Y_r         = 0.172; % compared to 0.0;!!

% Linear part: Approximates CL(alpha) well between -8 and 2 deg
P.C_L_0         = 0.784; % 0.28; % with flaps
P.C_L_alpha     = 0.11*180/pi;  % with flaps
P.C_L_delta_e   = 0.0039584*180/pi;
P.C_D_p         = 0.026;% with flaps, at AoA with zero lift (approx. 7 deg) / tuning here
P.C_D_0         = 0.0356;
P.C_D_alpha     = 0.007*180/pi; 
P.C_D_q         = 0.0;
P.C_D_delta_e   = 0.0;

% Pitch moment coefficient
P.C_m_0         = 0.0351; % compared to: -0.02338;
P.C_m_alpha     = -0.667; % check. % compared to: -0.38;
P.C_m_delta_e   = -0.01545547*180/pi; 
% Sideforce coefficient
P.C_Y_0         = 0.0;
P.C_Y_delta_a   = 0.000212*180/pi; %compared to 0.0;
P.C_Y_delta_r   = 0.00289*180/pi; % compared to -0.17;
% Rollmoment coefficient
P.C_ell_0       = 0.0;
P.C_ell_beta    = -0.0640; % compared to -0.12;
P.C_ell_p       = -0.645; % compared to -0.26;
P.C_ell_r       = 0.219; % compared to 0.14;
P.C_ell_delta_r = 0.000102864*180/pi; % compared to 0.105;
P.C_ell_delta_a = -0.008534465*180/pi; % compared to 0.08; !!! 

% Yaw moment coeffcient
P.C_n_0         = 0.0;
P.C_n_delta_a   = 0.000172983259710744*180/pi; % compared to 0.06;
P.C_n_delta_r   = -0.000985*180/pi; % compared to -0.032;


%% New aerodynamic data - corresponding file: Kite05kWberegninger04tilEspen310118
% Lift coefficient is modeled as two fourth (low AoA:  [-8 : 2 : 10]) and second order
% (high AoA:  [10 : 2 : 44]) polynomials 

% fourth order polynomial until 10 degrees
P.CL_Theta1_0 = 0.7455;
P.CL_Theta1_1 =  5.1798;
P.CL_Theta1_2 =  -2.6206;
P.CL_Theta1_3 = 0;
P.CL_Theta1_4 =  -105.4176; % fourth

% For controller synthesis a second order polynomial can be used until 10
% degrees
P.CL_Theta_ctrl_0 = 0.7545;
P.CL_Theta_ctrl_1 = 5.1448;
P.CL_Theta_ctrl_2 = -5.4465;

% 
alpha_vec = [-8 : 0.1 : 10]*pi/180;
% % Test for inversion of CL(alpha)
CL_vec_test = P.CL_Theta_ctrl_0 + P.CL_Theta_ctrl_1 * alpha_vec + P.CL_Theta_ctrl_2 * alpha_vec.^2;
 CLalpha_test =P.CL_Theta1_0 + P.CL_Theta1_1 * alpha_vec +...
        P.CL_Theta1_2 * alpha_vec.^2 + P.CL_Theta1_3 * alpha_vec.^3 +...
        P.CL_Theta1_4 * alpha_vec.^4;

    

% alpha_vec_1 = (-P.CL_Theta_ctrl_1+sqrt(P.CL_Theta_ctrl_1^2 - 4 * (P.CL_Theta_ctrl_0-CL_vec_test)*P.CL_Theta_ctrl_2 ))./(2*P.CL_Theta_ctrl_2);
% alpha_vec_2 = (-P.CL_Theta_ctrl_1-sqrt(P.CL_Theta_ctrl_1^2 - 4 * (P.CL_Theta_ctrl_0-CL_vec_test)*P.CL_Theta_ctrl_2 ))./(2*P.CL_Theta_ctrl_2);

% second order polynomial from 10 until 44 degrees.
P.CL_Theta2_0 =  1.3759;
P.CL_Theta2_1 =  0.7633;
P.CL_Theta2_2 =  -1.1266;
P.CL_max =  max(CL_vec_test);

% drag full range
P.CD_Theta1_0 = 0.0527;
P.CD_Theta1_1 =  0.2370;
P.CD_Theta1_2 =   2.2131;
P.CD_Theta1_3 =  2.3448;
P.CD_Theta1_4 =  -3.8159; % fourth


%% REST CAN BE IGNORED !!!!!!!
CDalphatest = P.CD_Theta1_0 + P.CD_Theta1_1 * alpha_vec +...
    P.CD_Theta1_2 * alpha_vec.^2 + P.CD_Theta1_3 * alpha_vec.^3 +...
    P.CD_Theta1_4 * alpha_vec.^4;




% Propeller 
P.C_prop        = 1.0;
P.S_prop        = 0.2027;
P.k_motor       = 100;
P.k_T_P         = 1;
P.k_Omega       = sqrt(0.016);
P.lx = P.b/4; % lever arms
P.ly = P.b/4; 

% Control allocation matrix 
P.km = 0.32; %0.016 is double the value of the J.Wang paper (TODO-this is totally arbitrary!) P.k_T_P * P.k_Omega^2;
% Cmu = [P.C_ell_delta_a, 0, P.C_ell_delta_r, -P.ly, -P.ly, P.ly, P.ly  ; 
%        0, P.C_m_delta_e, 0, P.lx, -P.lx, -P.lx, P.lx; 
%        P.C_n_delta_a, 0, P.C_n_delta_r,P.km, -P.km, P.km, -P.km];
P.Cmu = [P.C_ell_delta_a, 0, P.C_ell_delta_r, -P.k_T_P*P.ly, -P.k_T_P*P.ly, P.k_T_P*P.ly, P.k_T_P*P.ly  ; 
       0,               P.C_m_delta_e, 0,    P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx, P.k_T_P*P.lx; 
       P.C_n_delta_a, 0, P.C_n_delta_r,      P.km, -P.km, P.km, -P.km];

P.Cmu_ =  [P.C_ell_delta_a, 0, P.C_ell_delta_r, -P.k_T_P*P.ly, -P.k_T_P*P.ly, P.k_T_P*P.ly, P.k_T_P*P.ly  ; 
            0,               P.C_m_delta_e, 0,    P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx, P.k_T_P*P.lx; 
            P.C_n_delta_a, 0, P.C_n_delta_r,      P.km, -P.km, P.km, -P.km;
            zeros(1,3), ones(1,4) ];

P.Cmu02 =  [P.C_ell_delta_a, 0, P.C_ell_delta_r, -P.k_T_P*P.ly, -P.k_T_P*P.ly, P.k_T_P*P.ly, P.k_T_P*P.ly  ; 
            0,               P.C_m_delta_e, 0,    P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx, P.k_T_P*P.lx; 
            P.C_n_delta_a, 0, P.C_n_delta_r,     0, 0, 0, 0;
            zeros(1,3), ones(1,4) ];
        
P.Cmu01 = [P.C_ell_delta_a, 0, P.C_ell_delta_r; 
            0, P.C_m_delta_e, 0; 
            P.C_n_delta_a, 0, P.C_n_delta_r];      
    
Cmu02 = [-P.k_T_P*P.ly, -P.k_T_P*P.ly,  P.k_T_P*P.ly,   P.k_T_P*P.ly  ; 
          P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx,   P.k_T_P*P.lx; 
          P.km,         -P.km,          P.km,          -P.km;
          1, 1, 1, 1];
       
Cmu03 = [-P.k_T_P*P.ly, -P.k_T_P*P.ly,  P.k_T_P*P.ly,   P.k_T_P*P.ly  ; 
          P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx,   P.k_T_P*P.lx; 
          P.km,         -P.km,          P.km,          -P.km];     
  
% yaw moments are fully allocated to the rudder     
Cmu04 = [-P.k_T_P*P.ly, -P.k_T_P*P.ly,  P.k_T_P*P.ly,   P.k_T_P*P.ly;
         P.k_T_P*P.lx, -P.k_T_P*P.lx, -P.k_T_P*P.lx,   P.k_T_P*P.lx; 
         1, 1, 1, 1];
     
P.C_A_inv = pinv( P.Cmu01) ; 
P.C_A2_inv = pinv( Cmu02 ) ; 
P.C_A3_inv = pinv( Cmu03 ) ; 
P.C_A4_inv = pinv( Cmu04 ); 

P.C_A_tot_inv = pinv( P.Cmu ); 
P.C_A_tot2_inv = pinv( P.Cmu_ ); 

% Aerodynamic force coefficient in X and Z direction 
P.CX0 = -0.0439; 
P.CXalpha = 0.8468;
P.CZ0 = -0.7116; 
P.CZalpha =   -5.6007;
P.CZp = -P.k_T_P; 

% Flight envelope limits 
CLmax = 1.2; % Full flaps 
CLmin = 0.1; % Hows CLmin actually defined? I think it makes rather sense to use the structural integrity limit here
safetyFactor = 1; 
P.q_min = P.mass * P.g / ( P.S_wing * CLmax ) * safetyFactor; 
P.q_max = P.mass * P.g / ( P.S_wing * CLmin ); 

% TEther
P.rho_t = 0.013; % mass density Kg/m

% Actuators 
P.ThrustMax = 30;
FThrustMax = P.ThrustMax * ones(4,1);
P.ThrustMin = -20;

%% Values from Holzapfel Diss.
omega0_actuator = 40; 25; 
zeta_actuator = 1.2; 
max_rates_actuator = 200*pi/180; 
max_deflection = 15*pi/180; 
max_rudder_deflection = 25*pi/180; 

% %% Sensor dynamics
% omega0_sensor = 200; 
% zeta0_sensor = 1; 

%% Autopilot 
P.AP_Ts = 0.01;
P.T_sensor = 0.02; 
P.sampling_rate_fcs = 50; 

   
   
  
