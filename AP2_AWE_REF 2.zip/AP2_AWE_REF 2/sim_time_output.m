function out = sim_time_output(in)
    global startTime simulationTime
    simTime = get_param('AWE_Testbed_07','SimulationTime');
    temp = clock;
    currentTime = temp(6) + temp(5) * 60 + temp(4) * 3600;
    
    if simTime == 0
        temp = clock;
        startTime = temp(6) + temp(5) * 60 + temp(4) * 3600;
    end

    if mod(simTime,1) == 0
        timeUsed = currentTime - startTime;
        perc2go = 1 - simTime/simulationTime;
        time2go = perc2go * timeUsed/(simTime/simulationTime);
        fprintf('%3.0f sec of %3.0f sec simulated => approx %1.1f seconds remaining\n\n',simTime,simulationTime,time2go)
    end
    
    if simTime == simulationTime
        timeUsed = currentTime - startTime;
        fprintf('============================================\n');
        fprintf('a total of %2.1f seconds were used\nthis means the simulation runs %2.1f times slower then reality\n',timeUsed,timeUsed/simulationTime);
        fprintf('============================================\n');
    end

    out = in; 

    
end