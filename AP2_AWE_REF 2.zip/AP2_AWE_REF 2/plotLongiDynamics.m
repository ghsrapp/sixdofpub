figure(2); 
clf 
drawBooth; 
axis([0 l_init+50, -Lbooth.b-50, Lbooth.b+50, 0, 200] );

figure(1); 
clf;

for cnt = 1 : cntr-1
    figure(1);
    load(['Acmpl_', num2str(cnt)]);
    title(['abs(A), ', 'Pos: ', num2str(s(cnt)/pi), '\pi']); hold on
    Acmpl =  [G_save{cnt}.A(1,:);
             G_save{cnt}.A(3,:); 
             G_save{cnt}.A(5,:);
             G_save{cnt}.A(8,:)];
    graphicalRepCoupling; 
    %print([eval('pwd'),'/AWESTRIM/','coupling_',num2str(cnt)], '-dpng', '-r300');
    
    figure(2); 
    plot3( pos_W_i_save(cnt,1),pos_W_i_save(cnt,2),pos_W_i_save(cnt,3), '*r' );
    view(90,30); 
    pause;
end
