%% Defines the geometrical properties of the figure of 8
LemPsRef.AlambdaRef = 80;
factor = 5; 
LemPsRef.AphiRef = LemPsRef.AlambdaRef/factor;
LemPsRef.blambdaRef = 1;
LemPsRef.bphiRef = 2;
LemPsRef.phi0 = 30;
LemPsRef.c0 = pi/4;

% Virtual target look-ahead distance
LemPsRef.deltaSol = 0.4; % with actuator

% Option for the root finding algorithm
%LemPsRef.lemni_options = optimset('MaxIter',5, 'TolX',1e-3); % show iterations
