function [bearing_W] = calculateCmdBearing(Chi_c,gamma_t_cmd, p_kite_W)
p_kite_W = p_kite_W / norm(p_kite_W); 

% Extract latitude/longitude with respect to the ground station
lat_kite = asin( p_kite_W(3) / norm(p_kite_W) );
long_kite = atan2( p_kite_W(2), p_kite_W(1) );

M_TW = [-sin(lat_kite)*cos(long_kite), -sin(lat_kite)*sin(long_kite), cos(lat_kite); 
    -sin(long_kite), cos(long_kite), 0; 
    -cos(lat_kite)*cos(long_kite), -cos(lat_kite)*sin(long_kite), -sin(lat_kite)];

bearing_W = M_TW' * [cos(Chi_c)*cos(gamma_t_cmd); sin(Chi_c)*cos(gamma_t_cmd); -sin(gamma_t_cmd)];

end

