function [ p_VT_W, c0, c_prev, p_kite_proj_W ] = getVTOnLemniscate(LemPs,LemPsRef, p_kite_W, c_prev, c0)
%GETVTONLEMNISCATE Summary of this function goes here
%   Detailed explanation goes here
lemni_options = optimset('MaxIter',5, 'TolX',1e-2); % show iterations

%[sol,FVAL,EXITFLAG] = fzero(@(c)func(c,p_kite_W,LemPs),c0,lemni_options);
intervalInit = [c0-pi/8, c0+pi/8];
[ sol, res, f ] = bisectionMethod( @(s) fun_bisec( s,p_kite_W, LemPs ), intervalInit );

sol = mod(sol, 2*pi);
c_prev = sol;


L = [LemPs.Alambda*sin(LemPs.blambda*sol');
    LemPs.Aphi*sin(LemPs.bphi*sol')+LemPs.phi0*pi/180];
p_kite_proj_W = [cos(L(1)).*cos(L(2));
    sin(L(1)).*cos(L(2));
    sin(L(2))];

c0 = sol;
%LemPs.deltaSol = 0.1;
sol_VT = mod( sol - LemPsRef.deltaSol, 2*pi);

L = [LemPs.Alambda*sin(LemPs.blambda*sol_VT');
    LemPs.Aphi*sin(LemPs.bphi*sol_VT')+LemPs.phi0*pi/180];

p_VT_W = [cos(L(1)).*cos(L(2));
    sin(L(1)).*cos(L(2));
    sin(L(2))];
end

