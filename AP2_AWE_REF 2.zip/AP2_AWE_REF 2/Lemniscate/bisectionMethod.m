function [ sol, res, f ] = bisectionMethod( fun,  interval )
%NEWTONMETHOD Summary of this function goes here
%   Detailed explanation goes here
res = 1; 
f=1; 
% Check interval bounds and adapt if necessary
while sign( fun(interval(1)) ) == sign( fun(interval(2)) )
        interval(1) =  interval(1)-0.1;
        interval(2) =  interval(2)+0.1;
end
m_prev = interval(1); 
m = m_prev;
k = 1; 
while res > 1e-3 && k < 10
    m = ( interval(1) + interval(2) )/2; 
    fm = fun(m); 
    fa = fun(interval(1)); 
    if sign( fm ) ~= sign( fa )
        interval(2) = m;
    else 
        interval(1) = m;
    end
    f = fun(m);
    res = abs( m - m_prev ); 
    m_prev = m; 
    k = k + 1;
end
sol = m; 
end

