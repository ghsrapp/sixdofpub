function [f] = fun_bisec(s,K, LemPs)
A1 = LemPs.Alambda; 
A2 = LemPs.Aphi;
a1 = LemPs.blambda; 
a2 = LemPs.bphi; 
a0 = LemPs.phi0; 
K1 = K(1);
K2 = K(2);
K3 = K(3);
L = [A1 * sin(a1*s);
     A2 * sin(a2*s)+a0*pi/180];
 
dLds = [ a1*A1*cos(a1*s);...
         a2*A2*cos(a2*s) ];
     
s_lambda = sin( L(1,:)  ); 
s_phi = sin( L(2,:)  );
c_lambda = cos( L(1,:)   ); 
c_phi = cos( L(2,:)  ); 


f = K1*(-s_lambda.*dLds(1).*c_phi-s_phi.*dLds(2).*c_lambda)+...
    K2*( c_lambda.*dLds(1).*c_phi-s_phi.*dLds(2).*s_lambda)+...
    K3*c_phi.*dLds(2);

