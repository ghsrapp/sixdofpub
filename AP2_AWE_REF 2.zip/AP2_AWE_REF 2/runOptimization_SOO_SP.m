function runOptimization_SOO_SP(paramUbounds, paramLbounds, paramsFull, resume_string)

global optimizer;
global runID
runID = 0;
s = RandStream('mt19937ar','Seed',1);

cluster = 'local'; 
try
   parpool(cluster, 2);
end

% delete all temp files
parfevalOnAll(gcp, @sdi.Repository.clearRepositoryFile, 0)

paramSigma = (paramUbounds - paramLbounds) * 0.3;       

opts = cmaes('defaults');
opts.EvalParallel = 'yes'; % objective function FUN accepts NxM matrix, with M>1?%            opts.EvalInitialX = 'yes'; % evaluation of initial solution
opts.EvalInitialX = 'yes'; % evaluation of initial solution
opts.PopSize = 8;%16; % (4 + floor(3*log(N)))  % population size, lambda
opts.Resume = resume_string; % resume former run from SaveFile
opts.DiagonalOnly = 0; % OPTS.DiagonalOnly > 1 defines the number of initial iterations, where the covariance matrix remains diagonal
opts.LBounds = paramLbounds;
opts.UBounds = paramUbounds;
opts.CMA.active = 1; % active CMA 1: neg. updates with pos. def. check, 2: neg. updates

XMIN = cmaes('runOneGeneration_SP', paramsFull, paramSigma, opts);
delete(gcp());

end
