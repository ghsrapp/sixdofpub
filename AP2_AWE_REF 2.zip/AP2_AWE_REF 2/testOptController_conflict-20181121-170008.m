clear all 
close all 
clc

TSIM = 300; 
init_new;
%load('current_opt_cnt.mat');
%load('opt_control13.mat');
%load('x_best_trac_tmp1.mat');
load('x_best_trac_tmp1.mat');

%x = current_best_ctrl;
max_bandwidth = aileron.w0;
%x(1:20) = x(1:20)/10; % to get the right accuracy
%% ====== Controller Gains ======
assignin('base','Kp_mu_traction',x(1));
assignin('base','Kp_alpha_traction',x(2));
assignin('base','Kp_beta_traction',x(3));

assignin('base','Ki_mu_traction',x(4));
assignin('base','Ki_alpha_traction',x(5));
assignin('base','Ki_beta_traction',x(6));

assignin('base','Kp_p',x(7));
assignin('base','Kp_q',x(8));
assignin('base','Kp_r',x(9));

assignin('base','Ki_p',x(10));
assignin('base','Ki_q',x(11));
assignin('base','Ki_r',x(12));

assignin('base','Kp_chi_tau',x(13));

%% ====== Filter Definition ======
assignin('base','w0_mu_traction',x(14)*x(17)*max_bandwidth);
assignin('base','w0_alpha_traction',x(15)*x(18)*max_bandwidth);
assignin('base','w0_beta_traction',x(16)*x(19)*max_bandwidth);

assignin('base','w0_p',x(17)*max_bandwidth);
assignin('base','w0_q',x(18)*max_bandwidth);
assignin('base','w0_r',x(19)*max_bandwidth);

%% ==== Path definitions ====
assignin('base','a_booth',x(20));
assignin('base','b_booth',100);x(21);
assignin('base','phi0_booth',x(22));

assignin('base','Ki_chi_tau',1*x(23)/10);

assignin('base','F_T_traction_set',1300);

assignin('base','Kp_chi_tau_trans',x(25)/100);

assignin('base','Kp_gamma_tau_trans',x(26)/100);
assignin('base','Kp_gamma_tau',x(27)/10);
assignin('base','Ki_gamma_tau',x(28)/10);

%% Retraction 
% retraction
assignin('base','Kp_chi_retract',FCS.Kp_chi_retract);
assignin('base','Ki_chi_retract',FCS.Ki_chi_retract);

assignin('base','Kp_gamma_retract',FCS.Kp_gamma_retract);
assignin('base','Ki_gamma_retract',FCS.Ki_gamma_retract);

assignin('base','v_retraction_opt',-25);
assignin('base','gamma_retract_opt',-20);

Lbooth.a = a_booth;
Lbooth.b = b_booth;
sim('testAWE_Testbed_opt4');

%%
Lbooth.a = a_booth*b_booth;%x(20)*x(21);
Lbooth.b = b_booth;%x(21);
Lbooth.phi0 = x(22)*pi/180;
figure(10);clf;
addpath('Visualization_Offline/')
sim('visualize_offline_v2');
hold on 
drawBooth;
