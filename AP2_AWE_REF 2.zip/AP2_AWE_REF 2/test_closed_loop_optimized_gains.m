clear all
close all
clc

trim_test_flag = 0; % if 1 only the simple nonlinear model is used, if 0 the complete model is used.

min_trim_indx = 7; 
max_trim_indx = 12; 
sim_with_indx = 1;   

addpath(genpath('MiscFiles'))
addpath(genpath('AWESTRIM'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))
s = [pi/2, 2*pi];

% ============== Initialize the simulation ==================================================================================================
%path_with_gains = 'Trim_results/case_1_phi35_mix_ft_and_alpha';
path_with_gains = 'Trim_results/case_1_test03';

addpath(path_with_gains);

load([path_with_gains,'/G_save.mat']);
load([path_with_gains,'/rps_st.mat']);
load([path_with_gains,'/x0_save.mat']);
load([path_with_gains,'/u0_save.mat']);
load([path_with_gains,'/M_OB_init.mat']);

load([path_with_gains,'/K_long_mat.mat']);
load([path_with_gains,'/K_lat_aileron_mat.mat']);
load([path_with_gains,'/K_lat_rudder_mat.mat']);
load([path_with_gains,'/K_SP_mat.mat']);


x0_sim = x0_save(:,sim_with_indx);
u0_sim = u0_save(:,sim_with_indx);

if trim_test_flag % for trim test
    lat_in = x0_sim(11); %80*pi/180;
else
    lat_in = 80*pi/180; %
    x0_sim(11) = lat_in;
end
x0_sim(12) = 300;


% Retraction controller (to be done: generate also here a gain scheduled
% controller
sim_with_indx = 1; 
[x0_trim_retract,u0_trim_retract,K_long_retract,K_lat_retract, HmInvHum_retract,...
    Ke_L1_retract, C1, Ts, F_long_retract, Kbl_retract, Am_retract, Bp_um_retract, B_aug_retract, Br_retract, A_long_aug, B_long_aug, A_lat_aug, B_lat_aug] =  generateRetractionPhaseController( sim_with_indx );

% Initialization
pos_init_W = [cos( x0_sim(10) ) * cos( lat_in );
    sin( x0_sim(10) ) * cos( lat_in );
    sin( lat_in )]*x0_sim(12);
[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams_variable_p_init_W(pos_init_W);
init_trimmed_state_for_sim; 

% Some additional scenario dependent values e.g. path elevation in power
% zone, tether force traction point and wind speed.
Phi_traction_vec = 30*pi/180;%[30, 40]*pi/180;
Ft_set_vec = 1800;%[800,1300,1800];
base_windspeed_vec = 5;%[4, 7, 10]; %[4,10];
adaptive_controller_flag_vec = 0;
cnta = 1;
params_mat = [];

if trim_test_flag
    phi_trac = x0_save(11);
    ad_flag = 0;
    Ft_set = u0_save(4);
    base_windspeed = 10;
    close all;
    yout = sim('AWES3_CL_BL_designModelTraction','ReturnWorkspaceOutputs','on');
else
    ad_flag = adaptive_controller_flag_vec(1);
    phi_trac = Phi_traction_vec(1);
    Ft_set = Ft_set_vec(1);
    for z = 1 : length( base_windspeed_vec )
        base_windspeed = base_windspeed_vec(z);
        close all;
        fprintf('Simulation running...');
        yout = sim('AWES3_CL_wTether_v2','ReturnWorkspaceOutputs','on');s
        if ad_flag == 0
            yout_baseline{cnt} = yout;
            fprintf('Done %.1f \n', cnt );
            cnt = cnt + 1;
        else
            yout_adaptive{cnta} = yout;
            fprintf('Adaptive sim done %.1f \n', cnta );
            cnta = cnta + 1;
        end
        params_mat = [params_mat; [ad_flag, phi_trac*180/pi, Ft_set/1000, base_windspeed]];
    end
end
%%
close all;
folder_name_results = 'case_SLQR_diffWS_optGains';
lw = 1.2;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
alpha_lvl = 1;
for cnt = 1 : length( base_windspeed_vec )
    N = length( yout_baseline{cnt}.TetherForce.Data(:,1) );
    samplesPerCycle = floor( N/yout_baseline{cnt}.cycleCounter.Data(end) );
    numbConsideredCycles = 1;
    from_sample = max( N - samplesPerCycle*numbConsideredCycles, 1);
    cd Trim_results
    if ~exist( folder_name_results )
        mkdir( folder_name_results );
    end
    cd(folder_name_results);
    sim_out = yout_baseline{cnt};
    save(['sim_out_',num2str(base_windspeed_vec(cnt)),'.mat'], 'sim_out');
    
    h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.alpha_save.Time(from_sample:end), yout_baseline{cnt}.alpha_save.Data(from_sample:end,2)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    axis([ yout_baseline{cnt}.alpha_save.Time(from_sample), yout_baseline{cnt}.alpha_save.Time(end), -10 15]);
    xlabel('$Time$ $(s)$');
    ylabel('$\alpha_a$ $(deg)$');
    
    h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.sideslip.Time(from_sample:end), yout_baseline{cnt}.sideslip.Data(from_sample:end,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$\beta_a$ $(deg)$');
    axis([ yout_baseline{cnt}.sideslip.Time(from_sample), yout_baseline{cnt}.sideslip.Time(end), -15 15]);
    
    h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.TetherForce.Time(from_sample:end), yout_baseline{cnt}.TetherForce.Data(from_sample:end,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$F_t$ $(N)$');
    axis([yout_baseline{cnt}.TetherForce.Time(from_sample) yout_baseline{cnt}.TetherForce.Time(end) 0 2]);
    
    h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
    axis tight
    
    
    h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.target_pos.Data(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.pos_W.Data(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$x_W$ $(m)$');
    ylabel('$y_W$ $(m)$');
    axis tight
    
    h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,1), 'Linewidth', lw, 'color', col1  ); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,1), 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$x_W$ $(m)$');
    axis tight
    
    h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,2), 'Linewidth', lw, 'color', col1); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,2), 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$y_W$ $(m)$');
    axis tight
    
    h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
    h_bl_ref = plot( yout_baseline{cnt}.target_pos.Time(from_sample:end,1), yout_baseline{cnt}.target_pos.Data(from_sample:end,3), 'Linewidth', lw, 'color', col1); hold on;
    h_bl_ref.Color(4) = alpha_lvl;
    h_bl = plot( yout_baseline{cnt}.pos_W.Time(from_sample:end,1), yout_baseline{cnt}.pos_W.Data(from_sample:end,3), 'Linewidth', lw, 'color', col2  ); hold on;
    h_bl.Color(4) = alpha_lvl;
    xlabel('$Time$ $(s)$');
    ylabel('$z_W$ $(m)$');
    axis tight
    
    
    Plot2LaTeX(h1,['angleofattack_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    Plot2LaTeX(h2,['sideslip_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    Plot2LaTeX(h3,['Tetherforce_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    
    Plot2LaTeX(h4,['path_xz',num2str(base_windspeed_vec(cnt) ) ]);
    Plot2LaTeX(h5,['path_xy',num2str(base_windspeed_vec(cnt) ) ]);
    
    Plot2LaTeX(h6,['path_x_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    Plot2LaTeX(h7,['path_y_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    Plot2LaTeX(h8,['path_z_vw_',num2str(base_windspeed_vec(cnt) ) ]);
    cd ..
    cd ..
end






%%
%close all
if 0
    cnt_idx = [1,2, 11, 12];
    cd Trim_results
    if 1
        load('yout_baseline.mat');
        load('yout_adaptive.mat');
    end
    
    for k = 1 : length( cnt_idx )
        close all;
        cnt = cnt_idx(k);
        h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_baseline{cnt}.alpha_save.Time, yout_baseline{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
        axis tight
        % figure;
        % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        % h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        % h_bl_ref.Color(4) = alpha_lvl;
        % h_bl.Color(4) = alpha_lvl;
        % xlabel('$Time$ $(s)$');
        % ylabel('$F_t$ $(kN)$');
        
        h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,1)*180/pi, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on;
        h_bl = plot( yout_adaptive{cnt}.alpha_save.Time, yout_adaptive{cnt}.alpha_save.Data(:,3)*180/pi, 'Linewidth', lw, 'color', col2); hold on;
        xlabel('$Time$ $(s)$');
        ylabel('$\alpha_a$ $(deg)$');
        axis tight
        
        h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref = plot( yout_baseline{cnt}.TetherForce.Time, yout_baseline{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl_ref.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$F_t$ $(kN)$');
        axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
        
        h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
        h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
        h_bl_ref.Color(4) = alpha_lvl;
        h_bl_ref.Color(4) = alpha_lvl;
        xlabel('$Time$ $(s)$');
        ylabel('$F_t$ $(kN)$');
        axis([0,yout_baseline{cnt}.TetherForce.Time(end), 0 2])
        
        h5 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_baseline{cnt}.target_pos.Data(:,1),...
            yout_baseline{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_baseline{cnt}.pos_W.Data(:,1),...
            yout_baseline{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 -300 300 ])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$y_W$ $(m)$');
        
        h6 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
            yout_adaptive{cnt}.target_pos.Data(:,2),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
            yout_adaptive{cnt}.pos_W.Data(:,2),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([ 0 600 -300 300])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$y_W$ $(m)$');
        
        h7 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_baseline{cnt}.target_pos.Data(:,1),...
            yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_baseline{cnt}.pos_W.Data(:,1),...
            yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 100 500])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$z_W$ $(m)$');
        
        h8 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
        plot( yout_adaptive{cnt}.target_pos.Data(:,1),...
            yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
        plot( yout_adaptive{cnt}.pos_W.Data(:,1),...
            yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
        %axis([0 600 100 500])
        axis equal;
        xlabel('$x_W$ $(m)$');
        ylabel('$z_W$ $(m)$');
        
        
        Plot2LaTeX(h1,['only_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h2,['only_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h3,['Ftonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h4,['Ftonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        
        Plot2LaTeX(h5,['xyonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h6,['xyonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h7,['xzonly_baseline_',num2str(10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        Plot2LaTeX(h8,['xzonly_adapt_',num2str( 10*params_mat(cnt,3) ),'_', num2str( params_mat(cnt,4) )]);
        
        
        
        
    end
    cd ..
    % figure;
    % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,1)/1000, 'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot( yout_adaptive{cnt}.TetherForce.Time, yout_adaptive{cnt}.TetherForce.Data(:,2)/1000, 'Linewidth', lw, 'color', col2  ); hold on;
    % h_bl_ref.Color(4) = alpha_lvl;
    % h_bl.Color(4) = alpha_lvl;
    % xlabel('$Time$ $(s)$');
    % ylabel('$F_t$ $(kN)$');
    % %
    % figure;
    % h_bl_ref = plot3( yout_baseline{cnt}.target_pos.Data(:,1),...
    %     yout_baseline{cnt}.target_pos.Data(:,2),...
    %     yout_baseline{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot3( yout_baseline{cnt}.pos_W.Data(:,1),...
    %     yout_baseline{cnt}.pos_W.Data(:,2),...
    %     yout_baseline{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
    % axis equal
    
    % figure;
    % h_bl_ref = plot3( yout_adaptive{cnt}.target_pos.Data(:,1),...
    %     yout_adaptive{cnt}.target_pos.Data(:,2),...
    %     yout_adaptive{cnt}.target_pos.Data(:,3),'Linewidth', lw, 'color', col1  ); hold on;
    % h_bl_ref = plot3( yout_adaptive{cnt}.pos_W.Data(:,1),...
    %     yout_adaptive{cnt}.pos_W.Data(:,2),...
    %     yout_adaptive{cnt}.pos_W.Data(:,3),'Linewidth', lw, 'color', col2 ); hold on;
end