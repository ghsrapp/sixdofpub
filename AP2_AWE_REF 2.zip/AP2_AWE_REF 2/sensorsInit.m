%% This script initializes the sensor paramters such as 
% the bandwidth, sensor range and the noise characteristics 
% Reference for the values are: Appendix H of "Small Umanned Aircraft
% Theory and Practice by Beard and Mc Lain, 2012"

% Rate Gyros: ADXRS450
Sensors.RateGyros.omega0 = 80 * 2*pi; % rad/s
Sensors.RateGyros.zeta = 0.9; % from Brockhaus, p. 366f
Sensors.RateGyros.range = 350*pi/180; % rad/s
Sensors.RateGyros.sigma = 0.13*pi/180; % rad/s
Sensors.RateGyros.Ts = P.AP_Ts ; %s


% Accelerometers: ADXL325
Sensors.Acc.omega0 = 100 * 2*pi; % rad/s
Sensors.Acc.zeta = 0.9; % from Brockhaus, p. 366f
Sensors.Acc.range = 6; % g's
Sensors.Acc.sigma = 0.0025; % g's
Sensors.Acc.Ts = P.AP_Ts; % s

% Absolute Pressure sensors: MP3H6115A
Sensors.AbsPressure.bias = 0.125*1e3; % N/m^2
Sensors.AbsPressure.sigma = 0.01*1e3; %N/m^2
Sensors.AbsPressure.Ts = P.AP_Ts; % s

% Differential Pressure (Airspeed) sensors: MPXV5004G
Sensors.DiffPressure.bias = 0.02*1e3; % N/m^2
Sensors.DiffPressure.sigma = 0.002*1e3; %N/m^2
Sensors.DiffPressure.Ts = P.AP_Ts; % s

% Airdata (angle of attack/sideslip)
Sensors.AoA.omega0 = 60; %rad/s Holzapfel diss. (BROCKHAUS!), Windvane 
Sensors.AoA.zeta = 0.1; %rad/s Holzapfel diss.
Sensors.beta.omega0 = 60; %rad/s Holzapfel diss.
Sensors.beta.zeta = 0.1; %rad/s Holzapfel diss.

% Digital compass/Magnetormeter: HMR3300
Sensors.Compass.Ts = 0.125; % s
Sensors.Compass.bias = 1*pi/180; % rad
Sensors.Compass.sigma = 0.3*pi/180; % rad

% GPS 
Sensors.GPS.Ts = 1; 
Sensors.GPS.sigmaNorth = 0.21; 
Sensors.GPS.sigmaEast = 0.21; 
Sensors.GPS.sigmaAltitude = 0.4; 
Sensors.GPS.TMarkov = 1/1100;

% Airdata (estimated, from literature, i.e. GTM model)
Sensors.alpha.sigma = 0.031*pi/180; 
Sensors.beta.sigma = 0.033*pi/180; 
Sensors.alpha.bias = 0; 
Sensors.beta.bias = 0; 

