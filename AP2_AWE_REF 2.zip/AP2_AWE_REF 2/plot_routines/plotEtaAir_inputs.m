set(gcf,'renderer','Painters')
close all
if 1 % color
   % col1 =  [ 6/255, 133/255, 135/255  ];
    %col2 =  [242/255, 177/255, 52/255 ];
   % col3 =  [237/255, 85/255, 59/255 ];
    
    col1 =  [ 57/255, 106/255, 177/255  ];
    col2 =  [218/255, 124/255, 48/255 ];
    col3 =  [62/255, 150/255, 81/255 ];
    
else
    col1 =  [85/255, 85/255, 85/255 ];
    col2 =  [170/255, 170/255, 170/255];
    col3 =  [116/255, 136/255, 140/255 ];
end

time = mu_a_save.Time;
%%
figure; 
plot(time, mu_a_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, mu_a_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, mu_a_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\mu_a', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$\mu_{a,c}$$','$$\mu_{a,r}$$','$$\mu_{a,is}$$');
set(h, 'interpreter', 'latex');
%%
figure; 
plot(alpha_a_save.Time, alpha_a_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:45000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(alpha_a_save.Time, alpha_a_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:50000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(alpha_a_save.Time, alpha_a_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:55000:length(alpha_a_save.Time), 'Markersize', 8); hold on  
plot( alpha_a_save.Time, alpha_a_max*180/pi*ones(length(mu_a_save.Time),1), '--k'); 
plot( alpha_a_save.Time, alpha_a_min*180/pi*ones(length(mu_a_save.Time),1), '--k'); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\alpha', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$\alpha_{c}$$','$$\alpha_{r}$$','$$\alpha_{is}$$','$$bounds$$');
set(h, 'interpreter', 'latex');
axis([0 140 -8 12])

%%

figure; 
plot(beta_a_save.Time, beta_a_save.Data(:,1), 'color', col1); hold on 
plot(beta_a_save.Time, beta_a_save.Data(:,2), 'color', col2); hold on 
plot(beta_a_save.Time, beta_a_save.Data(:,3), 'color', col3); hold on 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\beta', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis([0 140 -8 8])
h = legend('$$\beta_{c}$$','$$\beta_{r}$$','$$\beta_{is}$$');
set(h, 'interpreter', 'latex');


%% ***** INPUTS ****
tstart = 1;
tend = length(delta_a_meas.Time);
figure; 
plot(delta_a_meas.Time(tstart:tend), delta_a_meas.Data(tstart:tend,1)*180/pi, 'color', col1); hold on 
plot(delta_a_meas.Time(tstart:tend), delta_e_meas.Data(tstart:tend,1)*180/pi, 'color', col2); hold on 
plot(delta_a_meas.Time(tstart:tend), delta_r_meas.Data(tstart:tend,1)*180/pi, 'color', col3); hold on 
plot( delta_a_meas.Time, aileron.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '-.',  'color', col1); 
plot( delta_a_meas.Time, elevator.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--', 'color', col2); 
plot( delta_a_meas.Time, rudder.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--', 'color', col3); 

plot( delta_a_meas.Time, -aileron.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '-.',  'color', col1); 
plot( delta_a_meas.Time, -elevator.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--',  'color', col2);
plot( delta_a_meas.Time, -rudder.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--',  'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\delta_i', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
%axis tight
h = legend('$$\delta_a$$','$$\delta_e$$','$$\delta_r$$','$$\delta_{a,limit}$$','$$\delta_{e,limit}$$','$$\delta_{r,limit}$$');
set(h, 'interpreter', 'latex');
axis([80 160 -20 20]);

%% **** Path angles ***
figure; 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\chi_k', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$\chi_{k,c}$$','$$\chi_{k,r}$$','$$\chi_{k,is}$$');
set(h, 'interpreter', 'latex');
%axis([112 125 -20 5]);
%%
figure; 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on  
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\gamma_k', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$\gamma_{k,c}$$','$$\gamma_{k,r}$$','$$\gamma_{k,is}$$');
set(h, 'interpreter', 'latex');
%%

figure; 
plot(course_tau_traction.Time, course_tau_traction.Data(:,1)*180/pi,'-x', 'color', col1, 'MarkerIndices',1:5000:length(course_tau_traction.Time),'Markersize',8); hold on 
plot(course_tau_traction.Time, course_tau_traction.Data(:,2)*180/pi,'-v', 'color', col2, 'MarkerIndices',1:5000:length(course_tau_traction.Time),'Markersize',8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\chi_\tau', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$\chi_{\tau,c}$$','$$\chi_{\tau,is}$$');
set(h, 'interpreter', 'latex');
axis([ 0 150 -180 180])
%
%% Power vr tether
startTime = 1;%200/0.00025; 
endTime = 200/0.00025; 
tvec = power_vr_tether.Time(1:end);
powervec =  power_vr_tether.Data(1:end,:);
% power
figure('Renderer', 'painters', 'Position', [300 500 900 600]);
subplot(211)
%plot(tvec,powervec(:,1)/1000, 'color', col1); hold on 
plot(tvec,F_T_traction_set*ones(length(tvec),1)/1000,'--', 'color', col1); hold on  
plot(tvec,powervec(:,3)/1000, 'color', col2); 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
% Create ylabel
%ylabel(['$$','P', '$$',' ','$$','(kW)','$$'], 'interpreter', 'latex' ); 
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
axis([20 180 0.5 1.5]);
%h = legend(['$$P$$ ', '$$(kW)$$'],['$$F_t$$ ', '$$(kN)$$']);
h = legend('$$F_{t,c}$$','$$F_{t,is}$$' );
ylabel('$$Tether$$ $$force,$$ $$kN$$', 'interpreter', 'latex' ); 
set(h, 'interpreter', 'latex');
set(gca,'LooseInset',get(gca,'TightInset'))

% reel velocity
%figure; 
subplot(212)
tvec2 = power_vr_tether.Time(1:end);
powervec2 =  power_vr_tether.Data(1:end,:);
%plot(tvec,powervec(:,4), 'color', col1,'Marker','x','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
%plot(tvec,powervec(:,6), 'color', col2,'Marker','v','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
%plot(tvec,powervec(:,2), 'color', col3,'Marker','o','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
plot(tvec2,powervec2(:,2), 'color', col1); hold on 

set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
ylabel('$$Reelout$$ $$Velocity,$$ $$m/s$$', 'interpreter', 'latex' ); 
%h = legend('$$cmd$$ ','$$ref$$', '$$is$$');
set(gca,'LooseInset',get(gca,'TightInset'))
axis([20 180 0 8]);

%%
figure; 
%subplot(212)
plot(gustOneCosine.Time,-gustOneCosine.Data(:,1), 'color', col1); hold on 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$','v_{g,x_W}', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' ); 
%h = legend('$$cmd$$ ','$$ref$$', '$$is$$');
%set(h, 'interpreter', 'latex');



%% Evolution longitude and latitude 

%% airdata
figure('Renderer', 'painters', 'Position', [300 500 900 600]);
F_T_ac = sqrt( F_T_B_N.Data(:,1).^2+ F_T_B_N.Data(:,2).^2+ F_T_B_N.Data(:,3).^2) ;
lift = -0.5*1.225*P.S_wing*CL_A_save.Data.*airdata.Data(:,1).^2;
plot(F_T_B_N.Time,lift/1000, 'color', col1 ); hold on ; 
plot(F_T_B_N.Time,F_T_ac/1000, 'color', col2 ); hold on ; 
plot(F_T_B_N.Time,power_vr_tether.Data(:,3)/1000, 'color', col3 ); hold on ; 

% set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$Time,$$ $$s$$'], 'interpreter', 'latex' );
h = legend('$$Lift$$ $$(kN)$$ ','$$F_{t,ac}$$ $$(kN)$$','$$F_{t,gnd}$$ $$(kN)$$)');
 set(h, 'interpreter', 'latex');
ylabel(['$$F_{i},$$ $$kN$$'], 'interpreter', 'latex' ); 
% axis tight
axis([20 180 0.9 1.15]);
set(gca,'LooseInset',get(gca,'TightInset'))
set(gca,'FontSize',20,'TickLabelInterpreter','latex');

%axis([210 400 -1 5]);
%%

%subplot(212)
% fxfy_tau = sqrt( Ftot_wo_Ft_tau.Data(:,1).^2 + Ftot_wo_Ft_tau.Data(:,2).^2 ); 
% plot(airdata.Time,fxfy_tau/1000, 'color', col1); hold on 
% axis tight;
% xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
% ylabel(['$$F_{\tau,xy}$$ $$(kN)','$$'], 'interpreter', 'latex' ); 
% set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% axis([60 100 0 0.4]);

%% tangential plane angles
figure; 
tstart = 1;
tend = TSIM/0.00025; 
plot(eta_tether.Time(tstart:tend,1),eta_tether.Data(tstart:tend,1), 'color', col2); hold on 
%plot(eta_tether.Time,eta_tether.Data(:,2), 'color', col2); hold on 
%plot(eta_tether.Time,eta_tether.Data(:,3), 'color', col3); hold on 
% approx theta_t 
%gamma_a = asin( wind_save.Data(:,3) ./ airdata.Data(:,1) ); 
%theta_c_approx = asin( cos( mu_a_save.Data(:,3)*pi/180) .* sin( alpha_a_save.Data(:,3)*pi/180 ) );
ylabel(['$$','\Phi_\tau', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' );
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
 xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
% h = legend('$$\Phi_\tau$$ $$(^\circ)$$','$$\Theta_\tau$$ $$(^\circ)$$','$$\Psi_\tau$$ $$(^\circ)$$');
 h = legend('$$Booth$$','$$Lissajous$$','location','Best');
set(gca,'LooseInset',get(gca,'TightInset'))
 set(h, 'interpreter', 'latex');
% %axis tight
axis([60 100 -12 12]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex');



%% Wind 
figure; 
plot(wind_save.Time, wind_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:50000:length(wind_save.Time), 'Markersize', 10); hold on 
plot(wind_save.Time, wind_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:50000:length(wind_save.Time), 'Markersize', 10); hold on 
plot(wind_save.Time, wind_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:50000:length(wind_save.Time), 'Markersize', 10); hold on  

ylabel(['$$','v_W', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' );
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
 xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
 h = legend('$$v_{w,x}$$','$$v_{w,y}$$','$$v_{w,z}$$','location','Best');
set(gca,'LooseInset',get(gca,'TightInset'))
 set(h, 'interpreter', 'latex');

 %% plot path
z_ = -[cos(Lbooth.phi0); 
     0; 
     sin(Lbooth.phi0)];
y_ = [0;1;0];
x_ = cross(y_,z_); 
M_tauW = [x_'; y_'; z_'];
pos_W_tau = M_tauW * pos_W.Data';
pos_W_tau(3,:) = 0;

[Lem] = updateBoothLemniscate(l_tether,Lbooth);
s = 0 : 0.005 : 2*pi;
%a = a/l_tether;
long = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
lat=   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
%% transform into cartesian coordinates 
p = [ cos(long).*cos(lat);
      sin(long).*cos(lat);
      sin(lat)]*l_tether;
p_tau = M_tauW * p; 

figure;
plot( p_tau(2,:), p_tau(1,:), 'color', col2, 'Linewidth', 4 ); hold on 
plot(  pos_W_tau(2,:),pos_W_tau(1,:), 'color', col1);

set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$ y_{\tau}$$ $$(m)$$'], 'interpreter', 'latex' ); hold on 
ylabel(['$$ x_{\tau}$$ $$(m) $$'], 'interpreter', 'latex' );
%h = legend('$$\bm \Gamma$$','$$v_{w,y}$$','$$v_{w,z}$$','location','Best');
%set(h, 'interpreter', 'latex'); 
axis tight
axis equal

axis([-100 100 -40 160]); hold on 

%% Kinematic vs. airspeed
%% Power vr tether
startTime = 1;%200/0.00025; 
endTime = 200/0.00025; 
tvec = airdata.Time;
figure('Renderer', 'painters', 'Position', [300 500 900 600]);
subplot(211)
plot(tvec,airdata.Data(:,1), 'color', col1); 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
axis([20 180 30 50]);
ylabel('$$Aerodynamic$$ $$Velocity,$$ $$m/s$$', 'interpreter', 'latex' ); 
set(gca,'LooseInset',get(gca,'TightInset'))

subplot(212)
plot(tvec,v_k_tot_save.Data, 'color', col1); hold on 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
ylabel('$$Kinematic$$ $$Velocity,$$ $$m/s$$', 'interpreter', 'latex' ); 
set(gca,'LooseInset',get(gca,'TightInset'))
axis([20 180 30 50]);

%% Longitude / Lattitude
tvec = v_k_tot_save.Time;
figure('Renderer', 'painters', 'Position', [300 500 900 600]);
%subplot(211)
plot(tvec,v_k_tot_save.Data, 'color', col1); hold on 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
ylabel('$$Kinematic$$ $$Velocity,$$ $$m/s$$', 'interpreter', 'latex' ); 
set(gca,'LooseInset',get(gca,'TightInset'))
axis([20 180 25 50]);
%subplot(212)
plot(tvec,long_lat_kite.Data(:,2)*180/pi+8, 'color', col2); hold on 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xlabel('$$Time,$$ $$s$$', 'interpreter', 'latex' );
ylabel('$$Lattitude$$,  $$^\circ$$', 'interpreter', 'latex' ); 
set(gca,'LooseInset',get(gca,'TightInset'))
axis([20 180 0 50]);

%% freuency analysis 
% Latitude
tstart0 = 80; 
tend0 = 110;
%long_lat_kite.Data = long_lat_kite.Data * pi/180; 
%
dt = long_lat_kite.Time(3,1)-long_lat_kite.Time(2,1);
Fs = 1/dt; 
T = 1/Fs;
L = length( long_lat_kite.Time(tstart0/dt:tend0/dt) )-1; 
t = long_lat_kite.Time(tstart0/dt:tend0/dt); 
X = long_lat_kite.Data(tstart0/dt:tend0/dt,2); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;
%
figure('Renderer', 'painters', 'Position', [300 400 900 600]);
stem(f(2:end),P1(2:end)/max(P1(2:end)), 'color', col1); hold on 
xlabel('$$Frequency,$$ $$Hz$$', 'interpreter', 'latex')
ylabel('Amplitudes', 'interpreter', 'latex')
%axis([0 1 0 1] ); 
axis([0 3 0 1]); 
title('Latitude angle variations')
%%
% ----------------------------------------------------------------------- *
tstart0 = 20; 
tend0 = 90;
dt = v_k_tot_save.Time(3,1)-v_k_tot_save.Time(2,1);
Fs = 1/dt; 
T = 1/Fs;
L = length( v_k_tot_save.Time(tstart0/dt:tend0/dt) ); 
t = v_k_tot_save.Time(tstart0/dt:tend0/dt); 
X = v_k_tot_save.Data(tstart0/dt:tend0/dt,1); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;
stem(f(2:end),P1(2:end)/max(P1(2:end)), 'color', col2); hold on 
%
tstart0 = 20; 
tend0 = 80;
dt = power_vr_tether.Time(3,1)-v_k_tot_save.Time(2,1);
Fs = 1/dt; 
T = 1/Fs;
L = length( power_vr_tether.Time(tstart0/dt:tend0/dt) ); 
t = power_vr_tether.Time(tstart0/dt:tend0/dt); 
X = power_vr_tether.Data(tstart0/dt:tend0/dt,2); 
Y = fft(X);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;
stem(f(2:end),P1(2:end)/max(P1(2:end)), 'color', col3); hold on 


axis([0 0.6 0 1.5]); 
set(gca,'LooseInset',get(gca,'TightInset'))
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
 h = legend('$$kinematic$$ $$speed$$ $$A/C$$','$$latitude$$ $$A/C$$','$$reeling$$ $$out$$ $$speed$$','location','Best');
 set(h, 'interpreter', 'latex');