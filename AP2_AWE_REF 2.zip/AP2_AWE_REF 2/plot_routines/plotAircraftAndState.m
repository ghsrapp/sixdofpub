close all;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
clf
tvec = 20:0.5:132;
tvec = 20:0.05:40;

%pos_vec_x = -squeeze(visualization_stuff.Data(1,:,tvec/0.1));
%pos_vec_y = squeeze(visualization_stuff.Data(2,:,tvec/0.1));
%pos_vec_z = -squeeze(visualization_stuff.Data(3,:,tvec/0.1));
figure(1);
color = [   128, 128, 128   ]/255;

tstart0 = tvec(1);
tend0 = tvec(end);

%%
%% plot path
z_ = -[cos(Lbooth.phi0);
    0;
    sin(Lbooth.phi0)];
y_ = [0;1;0];
x_ = cross(y_,z_);
M_tauW = [x_'; y_'; z_'];
pos_W_tau = M_tauW * pos_W.Data';
pos_W_tau(3,:) = 0;

[Lem] = updateBoothLemniscate(l_tether,Lbooth);
s = 0 : 0.005 : 2*pi;
%a = a/l_tether;
long = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
lat=   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
%% transform into cartesian coordinates
p = [ cos(long).*cos(lat);
    sin(long).*cos(lat);
    sin(lat)]*l_tether;
p_tau = M_tauW * p;
figure(1);
subplot(211)
%plot( p_tau(2,:), p_tau(1,:), 'color', col1, 'Linewidth', 4 ); hold on
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$ y_{\tau}$$ $$(m)$$'], 'interpreter', 'latex' ); hold on
ylabel(['$$ x_{\tau}$$ $$(m) $$'], 'interpreter', 'latex' );
%h = legend('$$\bm \Gamma$$','$$v_{w,y}$$','$$v_{w,z}$$','location','Best');
%set(h, 'interpreter', 'latex');
axis tight
axis equal
axis([-100 100 -40 50]); hold on
%%
figure(1);
subplot(211)
%plot( pos_W_tau(2,:), pos_W_tau(1,:), 'color',col1, 'Linewidth', 1.5);

for t = 1 : length( tvec )
    tpoint = tvec(t);
    subplot(211)
    idx = find( F_T_B_N.Time == tpoint );
    plot(  pos_W_tau(2,idx),pos_W_tau(1,idx),'.', 'color', col1, 'Markersize',10);

    %  clf
    set(gca,'LooseInset',get(gca,'TightInset'))
    subplot(212)
    F_T_ac = sqrt( F_T_B_N.Data(:,1).^2+ F_T_B_N.Data(:,2).^2+ F_T_B_N.Data(:,3).^2) ;
    lift = -0.5*1.225*P.S_wing*CL_A_save.Data.*airdata.Data(:,1).^2;
    %plot(F_T_B_N.Time(tstart0/dt:tend0/dt),(F_T_ac(tstart0/dt:tend0/dt)-lift(tstart0/dt:tend0/dt))./lift(tstart0/dt:tend0/dt), 'color', col1 ); hold on ;
    plot(  F_T_B_N.Time(idx),(F_T_ac(idx)-lift(idx))./lift(idx),'.', 'color', col1, 'Markersize',10);
    
    % set(gca,'FontSize',14,'TickLabelInterpreter','latex');
    xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
    % h = legend('$$Lift$$ $$(kN)$$ ','$$F_{t}$$ $$(kN)$$','$$F_{\tau,z}$$ $$(kN)$$)');
    % set(h, 'interpreter', 'latex');
    ylabel(['$$|L-F_t|/L$$'], 'interpreter', 'latex' );
    set(gca,'LooseInset',get(gca,'TightInset'))
    set(gca,'FontSize',14,'TickLabelInterpreter','latex');
    axis([20 40 -0.05 0.05]); hold on


    
    % print([eval('pwd'),'/video/','vidPic_traj_',num2str(t)], '-dpng', '-r300');
    %%
    
    %    figure(2);
    %     subplot(211);
    %     idx = find( power_vr_tether.Time == tpoint );
    %     %plot(power_vr_tether.Time(tstart0/dt:tend0/dt),power_vr_tether.Data(tstart0/dt:tend0/dt,3)/1000, 'color', col1); hold on
    %     %plot(power_vr_tether.Time(idx),power_vr_tether.Data(idx,3)/1000,'Marker','o', 'color', col2, 'Markersize',10);
    %     %plot(eta_tether.Time(tstart0/dt:tend0/dt,1),abs(eta_tether.Data(tstart0/dt:tend0/dt,1)), 'color', col1); hold on
    %     %plot(eta_tether.Time(idx,1),abs(eta_tether.Data(idx)),'o', 'color', col2, 'Markersize',10);
    %     plot(airdata.Time(tstart0/dt:tend0/dt,1),airdata.Data(tstart0/dt:tend0/dt,1), 'color', col1); hold on
    %     plot(airdata.Time(idx,1),abs(airdata.Data(idx,1)),'o', 'color', col2, 'Markersize',10);
    %
    %
    %     set(gca,'FontSize',14,'TickLabelInterpreter','latex');
    %     ylabel(['$$','\Phi_\tau', '$$',' ','$$','(deg)','$$'], 'interpreter', 'latex' );
    %     xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
    %     axis tight
    %     set(gca,'LooseInset',get(gca,'TightInset'));
    %subplot(212)
    %     figure(2);
    %     tvec2 = power_vr_tether.Time(startTime:endTime);
    %     powervec =  power_vr_tether.Data(startTime:endTime,:);
    %     idx = find( tvec2 == tpoint );
    %     plot(tvec2(tstart0/dt:tend0/dt),powervec(tstart0/dt:tend0/dt,4), 'color', col1); hold on
    %     plot(tvec2(idx),powervec(idx,4),'Marker','o', 'color', col2, 'Markersize',10);
    %
    %     set(gca,'FontSize',14,'TickLabelInterpreter','latex');
    %     ylabel(['$$','F_t', '$$',' ','$$','(kN)','$$'], 'interpreter', 'latex' );
    %     xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
    %     axis tight
    %     set(gca,'LooseInset',get(gca,'TightInset'));
   % pause(0.1);
    %pause;
    % print([eval('pwd'),'/video/','vidPic_pow_',num2str(t)], '-dpng', '-r300');
end
