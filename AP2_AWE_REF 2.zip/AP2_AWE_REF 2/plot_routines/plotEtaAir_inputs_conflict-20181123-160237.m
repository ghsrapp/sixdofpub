set(gcf,'renderer','Painters')
close all
if 0 % color
   % col1 =  [ 6/255, 133/255, 135/255  ];
    %col2 =  [242/255, 177/255, 52/255 ];
   % col3 =  [237/255, 85/255, 59/255 ];
    
    col1 =  [ 57/255, 106/255, 177/255  ];
    col2 =  [218/255, 124/255, 48/255 ];
    col3 =  [62/255, 150/255, 81/255 ];
    
else
    col1 =  [85/255, 85/255, 85/255 ];
    col2 =  [170/255, 170/255, 170/255];
    col3 =  [116/255, 136/255, 140/255 ];
end

time = mu_a_save.Time;
%%
figure; 
plot(time, mu_a_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, mu_a_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, mu_a_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\mu_a', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$cmd$$','$$ref$$','$$is$$');
set(h, 'interpreter', 'latex');
%%
figure; 
plot(time, alpha_a_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, alpha_a_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on 
plot(time, alpha_a_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(alpha_a_save.Time), 'Markersize', 8); hold on  
plot( time, alpha_a_max*180/pi*ones(length(mu_a_save.Time),1), '--k'); 
plot( time, alpha_a_min*180/pi*ones(length(mu_a_save.Time),1), '--k'); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\alpha', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$cmd$$','$$ref$$','$$is$$','$$bounds$$');
set(h, 'interpreter', 'latex');
axis([0 180 -8 13])

%%
figure; 
plot(time, beta_a_save.Data(:,1), 'color', col1); hold on 
plot(time, beta_a_save.Data(:,2), 'color', col2); hold on 
plot(time, beta_a_save.Data(:,3), 'color', col3); hold on 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\beta', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis([0 180 -6 6])
h = legend('$$cmd$$','$$ref$$','$$is$$');
set(h, 'interpreter', 'latex');


%% ***** INPUTS ****
tstart = 1;
tend = length(delta_a_meas.Time);
figure; 
plot(delta_a_meas.Time(tstart:tend), delta_a_meas.Data(tstart:tend,1)*180/pi, 'color', col1); hold on 
plot(delta_a_meas.Time(tstart:tend), delta_e_meas.Data(tstart:tend,1)*180/pi, 'color', col2); hold on 
plot(delta_a_meas.Time(tstart:tend), delta_r_meas.Data(tstart:tend,1)*180/pi, 'color', col3); hold on 
plot( delta_a_meas.Time, aileron.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '-.',  'color', col1); 
plot( delta_a_meas.Time, elevator.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--', 'color', col2); 
plot( delta_a_meas.Time, rudder.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--', 'color', col3); 

plot( delta_a_meas.Time, -aileron.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '-.',  'color', col1); 
plot( delta_a_meas.Time, -elevator.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--',  'color', col2);
plot( delta_a_meas.Time, -rudder.max_deflection*180/pi*ones(length(delta_a_meas.Time),1), '--',  'color', col3); 
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\delta_i', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
%axis tight
h = legend('$$\delta_a$$','$$\delta_e$$','$$\delta_r$$','$$\delta_{a,limit}$$','$$\delta_{e,limit}$$','$$\delta_{r,limit}$$');
set(h, 'interpreter', 'latex');
axis([80 160 -20 20]);

%% **** Path angles ***
figure; 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, chi_a_retraction.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\chi_k', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$cmd$$','$$ref$$','$$is$$');
set(h, 'interpreter', 'latex');
axis([112 125 -20 5]);
%%
figure; 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(chi_a_retraction.Time, gamma_a_retraction.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:5000:length(chi_a_retraction.Time), 'Markersize', 8); hold on  
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\gamma_k', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$cmd$$','$$ref$$','$$is$$');
set(h, 'interpreter', 'latex');
%%

figure; 
plot(course_tau_traction.Time, course_tau_traction.Data(:,1)*180/pi,'-x', 'color', col1, 'MarkerIndices',1:5000:length(course_tau_traction.Time),'Markersize',8); hold on 
plot(course_tau_traction.Time, course_tau_traction.Data(:,2)*180/pi,'-v', 'color', col2, 'MarkerIndices',1:5000:length(course_tau_traction.Time),'Markersize',8); hold on 
%plot( time, mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
%plot( time, -mu_a_max*180/pi*ones(length(mu_a_save.Time),1), 'color', col3); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
ylabel(['$$','\chi_\tau', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' ); 
axis tight
h = legend('$$cmd$$','$$is$$');
set(h, 'interpreter', 'latex');
axis([ 0 150 -180 180])
%
%% Power vr tether
startTime = 1;%200/0.00025; 
endTime = 100/0.00025; 
tvec = power_vr_tether.Time(startTime:endTime);
powervec =  power_vr_tether.Data(startTime:endTime,:);
% power
figure; 
%plot(tvec,powervec(:,1)/1000, 'color', col1); hold on 
plot(tvec,F_T_traction_set*ones(length(tvec),1)/1000,'--', 'color', col1); hold on  
plot(tvec,powervec(:,3)/1000, 'color', col2); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
% Create ylabel
%ylabel(['$$','P', '$$',' ','$$','(kW)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
%axis([210 400 -1 5]);
%h = legend(['$$P$$ ', '$$(kW)$$'],['$$F_t$$ ', '$$(kN)$$']);
h = legend('$$cmd$$','is' );
ylabel('$$F_t$$ $$(kN)$$', 'interpreter', 'latex');
set(h, 'interpreter', 'latex');

%% reel velocity
figure; 
tvec2 = power_vr_tether.Time(1:end);
powervec2 =  power_vr_tether.Data(1:end,:);
%plot(tvec,powervec(:,4), 'color', col1,'Marker','x','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
%plot(tvec,powervec(:,6), 'color', col2,'Marker','v','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
%plot(tvec,powervec(:,2), 'color', col3,'Marker','o','MarkerIndices',1:5000:length(tvec), 'Markersize', 8); hold on 
plot(tvec2,powervec2(:,2), 'color', col1); hold on 

set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$','v_r', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' ); 
%h = legend('$$cmd$$ ','$$ref$$', '$$is$$');
set(h, 'interpreter', 'latex');
%%
figure; 
plot(gustOneCosine.Time,-gustOneCosine.Data(:,1), 'color', col1); hold on 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$','v_{g,x_W}', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' ); 
%h = legend('$$cmd$$ ','$$ref$$', '$$is$$');
set(h, 'interpreter', 'latex');


%% Evolution longitude and latitude 

%% airdata
F_T_ac = sqrt( F_T_B_N.Data(:,1).^2+ F_T_B_N.Data(:,2).^2+ F_T_B_N.Data(:,3).^2) ;
lift = -0.5*1.225*P.S_wing*CL_A_save.Data.*airdata.Data(:,1).^2; 
 
figure; 
%subplot(211)
plot(airdata.Time,lift/1000, 'color', col1); hold on 
%plot(airdata.Time,power_vr_tether.Data(:,3)/1000, 'color', col2); hold on
plot(F_T_B_N.Time,F_T_ac/1000, 'color', col2); hold on 
%plot(Ftot_wo_Ft_tau.Time , -Ftot_wo_Ft_tau.Data(:,3)/1000, 'color', col3); hold on 
%plot(F_T_B_N.Time,(F_T_ac-lift), 'color', col2 ); hold on ; 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
h = legend('$$Lift$$ $$(kN)$$ ','$$F_{t}$$ $$(kN)$$','$$F_{\tau,z}$$ $$(kN)$$)');
set(h, 'interpreter', 'latex');
%ylabel(['$$','V_a', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' ); 
axis tight
axis([60 100 0.7 1.6]);

%axis([210 400 -1 5]);
%%

%subplot(212)
fxfy_tau = sqrt( Ftot_wo_Ft_tau.Data(:,1).^2 + Ftot_wo_Ft_tau.Data(:,2).^2 ); 
plot(airdata.Time,fxfy_tau/1000, 'color', col1); hold on 
axis tight;
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$F_{\tau,xy}$$ $$(kN)','$$'], 'interpreter', 'latex' ); 
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
axis([60 100 0 0.4]);

%% tangential plane angles
figure; 
tstart = 1;
tend = TSIM/0.00025; 
plot(eta_tether.Time(tstart:tend,1),eta_tether.Data(tstart:tend,1), 'color', col2); hold on 
%plot(eta_tether.Time,eta_tether.Data(:,2), 'color', col2); hold on 
%plot(eta_tether.Time,eta_tether.Data(:,3), 'color', col3); hold on 
% approx theta_t 
%gamma_a = asin( wind_save.Data(:,3) ./ airdata.Data(:,1) ); 
%theta_c_approx = asin( cos( mu_a_save.Data(:,3)*pi/180) .* sin( alpha_a_save.Data(:,3)*pi/180 ) );
ylabel(['$$','\Phi_\tau', '$$',' ','$$','(^\circ)','$$'], 'interpreter', 'latex' );
set(gca,'FontSize',20,'TickLabelInterpreter','latex');
 xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
% h = legend('$$\Phi_\tau$$ $$(^\circ)$$','$$\Theta_\tau$$ $$(^\circ)$$','$$\Psi_\tau$$ $$(^\circ)$$');
 h = legend('$$Booth$$','$$Lissajous$$','location','Best');
set(gca,'LooseInset',get(gca,'TightInset'))
 set(h, 'interpreter', 'latex');
% %axis tight
axis([60 100 -12 12]);
% 


%% Wind 
figure; 
plot(wind_save.Time, wind_save.Data(:,1),'-x', 'color', col1,'MarkerIndices',1:100:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(wind_save.Time, wind_save.Data(:,2),'-v', 'color', col2,'MarkerIndices',1:100:length(chi_a_retraction.Time), 'Markersize', 8); hold on 
plot(wind_save.Time, wind_save.Data(:,3),'-o', 'color', col3,'MarkerIndices',1:100:length(chi_a_retraction.Time), 'Markersize', 8); hold on  

ylabel(['$$','v_W', '$$',' ','$$','(m/s)','$$'], 'interpreter', 'latex' );
set(gca,'FontSize',14,'TickLabelInterpreter','latex');
 xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
 h = legend('$$v_{w,x}$$','$$v_{w,y}$$','$$v_{w,z}$$','location','Best');
set(gca,'LooseInset',get(gca,'TightInset'))
 set(h, 'interpreter', 'latex');

