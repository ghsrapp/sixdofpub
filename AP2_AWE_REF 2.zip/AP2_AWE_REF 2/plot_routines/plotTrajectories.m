
if 0
    col1 =  [ 52/255, 152/255, 219/255  ];
    col2 =  [203/255, 67/255, 53/255 ];
    col3 =  [218/255, 165/255, 32/255 ];
else
    col1 =  [160/255, 160/255, 160/255 ];
    col2 =  [112/255, 138/255, 144/255];
    col3 =  [10/255, 10/255, 10/255 ];
end
%%
figure;

load('TrajFile1_1_2.mat');
sig1 = pos_W;
plot3( sig1.Data(:,1), sig1.Data(:,2), sig1.Data(:,3),'color', col1);
hold on
load('TrajFile1_1_3.mat');
sig1 = pos_W;
plot3( sig1.Data(:,1), sig1.Data(:,2), sig1.Data(:,3),'color', col2);

set(gca,'FontSize',12,'TickLabelInterpreter','latex');
% Create ylabel
xlabel(['$$','x_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' );
ylabel(['$$','y_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' );
zlabel(['$$','z_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' );
legend('only feedback', 'feedback + feedforward')

%%
figure;

load('power1_1_1.mat');
sig1 = power_vr_tether;
plot( sig1.Time(:,1), sig1.Data(:,1)/1000,'color', col1); hold on 
plot( sig1.Time(:,1), ones(length(sig1.Time),1)*mean(sig1.Data(:,1)/1000),'color', col1, 'Linestyle', '--');

hold on
load('power1_1_2.mat');
sig1 = power_vr_tether;
plot( sig1.Time(:,1), sig1.Data(:,1)/1000,'color', col2);
plot( sig1.Time(:,1), ones(length(sig1.Time),1)*mean(sig1.Data(:,1)/1000),'color', col2, 'Linestyle', '--');

hold on
load('power1_1_3.mat');
sig1 = power_vr_tether;
plot( sig1.Time(:,1), sig1.Data(:,1)/1000,'color', col3);
plot( sig1.Time(:,1), ones(length(sig1.Time),1)*mean(sig1.Data(:,1)/1000),'color', col3, 'Linestyle', '--');


set(gca,'FontSize',12,'TickLabelInterpreter','latex');
% Create ylabel
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$','P', '$$',' ','$$','(kW)','$$'], 'interpreter', 'latex' );
legend('only fb', '\mu_{fb}','fb + ff', '\mu_{fb+fb}')

%% compare tight curves with large curves 
figure;

title(['\kappa_{\Gamma_1} < \kappa_{\Gamma_2}'])
hold on
load('power1_1_5.mat');
sig1 = power_vr_tether;
plot( sig1.Time(:,1), sig1.Data(:,1)/1000,'color', col1);
plot( sig1.Time(:,1), ones(length(sig1.Time),1)*mean(sig1.Data(:,1)/1000),'color', col1, 'Linestyle', '--');

hold on
load('power1_1_3.mat');
sig1 = power_vr_tether;
plot( sig1.Time(:,1), sig1.Data(:,1)/1000,'color', col2);
plot( sig1.Time(:,1), ones(length(sig1.Time),1)*mean(sig1.Data(:,1)/1000),'color', col2, 'Linestyle', '--');


set(gca,'FontSize',12,'TickLabelInterpreter','latex');
% Create ylabel
xlabel(['$$','Time', '$$',' ','$$','(s)','$$'], 'interpreter', 'latex' );
ylabel(['$$','P', '$$',' ','$$','(kW)','$$'], 'interpreter', 'latex' );
legend('\Gamma_1', '\mu_{\Gamma_1}','\Gamma_2', '\mu_{\Gamma_2}')


