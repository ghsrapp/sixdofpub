close 
clc
%%
power = power_vr_tether.Data(:,1); 
vr = power_vr_tether.Data(:,2); 
tether_force = power_vr_tether.Data(:,3); 
vref = power_vr_tether.Data(:,4); 
tvec = power_vr_tether.Time;
%%
color = [0.5 0.5 0.5];
color2 = [0.2 0.2 0.2];
figure;
subplot(311); 
plot(tvec, power/1000, 'color', color2) ; 
set(gca, 'TickLabelInterpreter', 'latex');
ylabel('$$P$$ $$(kW)$$', 'interpreter', 'latex'); 
axis tight

subplot(312)
plot(tvec, vr, 'color', color) ; hold on 
plot(tvec, vref, 'color', color2, 'Linestyle', '-'); 
set(gca, 'TickLabelInterpreter', 'latex');
ylabel('$$v_r$$ $$(m/s)$$', 'interpreter', 'latex'); 
axis tight
axis([0 tvec(end) -11 6] ); 

subplot(313)
plot(tvec, tether_force/1000, 'color', color) ;  hold on 
plot(tvec, tether_force*0+1, 'color', color2, 'Linestyle', '--'); 
set(gca, 'TickLabelInterpreter', 'latex');
ylabel('$$F_t$$ $$(kN)$$', 'interpreter', 'latex'); 
axis tight
xlabel('$$Time$$ $$(s)$$', 'interpreter', 'latex');
axis([0 tvec(end) 0 2] ); 