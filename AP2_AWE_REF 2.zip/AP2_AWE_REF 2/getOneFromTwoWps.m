function [wp_infront_W, cnt] = getOneFromTwoWps(wp_W_list,dlong,dlat, cnt,p_W)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

long = atan2( p_W(2), p_W(1) ); 
lat = asin( p_W(3) ); 
wp_long = atan2( wp_W_list(cnt, 2), wp_W_list(cnt, 1) );
wp_lat = asin(  wp_W_list(cnt, 3) );

if cnt == 1 
    if long > wp_long - dlong && lat < wp_lat + dlat
        cnt = 2;
    else
        cnt = 1; 
    end
else 
    if long < wp_long + dlong && lat < wp_lat + dlat
        cnt = 1; 
    else
        cnt = 2; 
    end
end

wp_infront_W = wp_W_list(cnt,:)';