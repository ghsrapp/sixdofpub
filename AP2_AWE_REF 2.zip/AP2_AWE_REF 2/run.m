% Run this script to initialize the simulation and to 
% run the simulink model. 

init; 
simName = 'RigidWing_Testbed_v01'; 
open(simName); 
sim(simName);

