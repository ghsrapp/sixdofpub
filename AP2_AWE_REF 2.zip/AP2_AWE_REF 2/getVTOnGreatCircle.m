function [p_VT_W,p_kite_proj_W] = getVTOnGreatCircle(right_bottom_abs_W, left_top_abs_W, p_kite_W,deltaVTGreatCircle)

e1 = [left_top_abs_W(2)*right_bottom_abs_W(3)-left_top_abs_W(3)*right_bottom_abs_W(2); 
       left_top_abs_W(3)*right_bottom_abs_W(1)-left_top_abs_W(1)*right_bottom_abs_W(3); 
       left_top_abs_W(1)*right_bottom_abs_W(2)-left_top_abs_W(2)*right_bottom_abs_W(1)];
e1 = e1/norm(e1);

e2 = [e1(2)*left_top_abs_W(3)-e1(3)*left_top_abs_W(2); 
       e1(3)*left_top_abs_W(1)-e1(1)*left_top_abs_W(3); 
       e1(1)*left_top_abs_W(2)-e1(2)*left_top_abs_W(1)];

e3 = left_top_abs_W;

M_GcW = [e3'; e2'; e1']; % Transformation matrix from W to Great Circle Frame 
M_WGc = [e3, e2, e1];
% Transform the position into the GC1 frame
p_kite_Gc = M_GcW * p_kite_W;
% Remove third component
p_kite_Gc(3) = 0;
% This is acutally equivalent to the normal projection into the great
% circle plane:  V = [e2, e3]; p_kite_W_projTest = V*V'*p_kite_W;
p_kite_Gc = p_kite_Gc/norm(p_kite_Gc); %% moving the position onto the circle

% Move the projection with this angle along the great circle (which is a
% simple rotation!)
M_gc_z = [cos(deltaVTGreatCircle), -sin(deltaVTGreatCircle),0;
    sin(deltaVTGreatCircle), cos(deltaVTGreatCircle),0;
    0, 0, 1];

p_VT_W = M_WGc * M_gc_z * p_kite_Gc;

% Transform back to E
p_kite_proj_W = M_WGc * p_kite_Gc;

