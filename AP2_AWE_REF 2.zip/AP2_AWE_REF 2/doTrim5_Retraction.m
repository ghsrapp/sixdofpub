clear all
close all
clc
addpath(genpath('AWESTRIM/'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
plot_flag = 1; 
save_plots = 1;
initValues.CurvedFlightFlag = 1;

cnt = 2;

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams();

a_booth_vec = 0.5; %[0.5, 0.75, 1];
b_booth_vec = 160; %[120, 160, 200];
phi0_booth_vec = 30*pi/180; %&[30, 45, 60]*pi/180;%[30, 45, 60]*pi/180;
Va_vec = 20 : 2.5 : 40;
Ft_vec = 50; %400 : 400 : 1800;
initValues.Va  = 30;

alpha_save_all = [];
phi_save_all = [];
v_reel_save_all = [];
v_a_save_all = [];


v_ro_set = -10;

% initValues.Va= Va_vec(zzzz);
v_w_vec = 12.5;%[5 , 12.5 , 20];
initValues.l_tether = 700;
l_tether = initValues.l_tether;
drawBooth2;axis equal;
close all
h1 = figure(1);
h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]*0.8);
h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]*0.8);
h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]*0.8);
windDirection_rad = pi;
svec = linspace(pi,2*pi, 21);
svec(1) = [];
svec =3/2*pi;
svec = 0;
for s_idx = 1 : length(svec)
    s = svec(s_idx);
    cnt = s_idx; % for saving
    for idx_ft = 1 : length( Ft_vec )
        % for idx_ft = 1 : length( phi0_booth_vec )
        %  Ft = Ft_vec(1);
        Ft = Ft_vec(idx_ft);
        
        for idx = 1 : length(v_w_vec)
            v_w_x_vec = v_w_vec(idx);
            %for idx = 1 : length(phi0_booth_vec)
            
            % v_w_x_vec = v_w_vec(1);
            
            params.a_booth = a_booth_vec(1);
            params.b_booth = b_booth_vec(1);
            params.phi0_booth =  phi0_booth_vec(1);
            fprintf('a = %.2f | b = %.2f | phi = %.2f\n', params.a_booth, params.b_booth, params.phi0_booth)
            %%
            
            initValues.Lbooth = Lbooth;
            initValues.phi=0;
            initValues.theta=-10*pi/180;
            omega_OB_init = zeros(3,1);
            initValues.beta  = 0;
            initValues.alpha = -5*pi/180; %0*pi/180; % max. CL/CD
            
            initValues.Ft_trim = 100;
            initValues.chi_tau_trim_norm = -1.255;
            
            vel_w_W = [v_w_x_vec(1);0;0];
            [long, lat] = setUpInitValuesForPathTrim(params, initValues,s);
            
            [ ops_st, rps_st, saveStruct, ss_long, ss_lat, G_save, ss_tot, x0_save, u0_save, M_OB_init, v_reeling,gamma_vec,AoA_vec,converged_alpha_count] = ...
                setAndSolveTrimProblem_retraction(params, constr, initValues,vel_w_W, ENVMT.windDirection_rad, long, lat, s, v_ro_set, Va_vec, Ft, act);
            rps_st_all{idx} = rps_st; 
          
            %%
            if plot_flag
                ind_conv = find( converged_alpha_count > 0 ) ; 
                k_max = length(ind_conv);
                for iter = 1 : k_max
                    k = converged_alpha_count(iter); 
                    if iter == 1
                        ind = 1 : k ; 
                        new_start = k + 1; 
                    else
                       ind = new_start : new_start + k - 1 ; 
                       new_start = new_start + k ; 
                    end
                    if idx == 1
                        col_ = col1;
                    elseif idx == 2
                        col_ = col2;
                    elseif idx == 3
                        col_ = col3;
                    end
                    
                    lw = 1.2;
                    
                    alpha_high = 0.3;
                    alpha_low = 1;
                    
                    if k_max == 1
                        a_mks = 1;
                    else
                        a_mks = (iter-1)/(k_max-1);
                    end
                    alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
                    figure(2);
                    if size(ind) == 1
                        b_h = plot( x0_save(3, ind)*180/pi, x0_save(1,ind), '*', 'color', col_, 'Linewidth', lw); hold on; drawnow
                    else
                        b_h = plot( x0_save(3, ind)*180/pi, x0_save(1,ind), '-', 'color', col_, 'Linewidth', lw); hold on; drawnow
                    end
                    b_h.Color(4) = alpha_lvl;
                    xlabel('$\alpha_\mathrm{a}$ (deg)');
                    ylabel('$\mathrm{v}_\mathrm{a}$ (m/s)');
                    
                    figure(3);
                    if size(ind) == 1
                        b_h=plot(  x0_save(3, ind)*180/pi, v_reeling(1, ind), '*', 'color', col_, 'Linewidth', lw); hold on; drawnow   
                    else
                        b_h=plot(  x0_save(3, ind)*180/pi, v_reeling(1, ind), '-', 'color', col_, 'Linewidth', lw); hold on; drawnow
                    end
                    b_h.Color(4) = alpha_lvl;
                    xlabel('$\alpha_\mathrm{a}$ (deg)');
                    ylabel('$\mathrm{v}_\mathrm{r}$ (m/s)');
                    
                    figure(4);
                    if size(ind) == 1
                        b_h=plot(  x0_save(3, ind)*180/pi, u0_save(4, ind), '*', 'color', col_, 'Linewidth', lw); hold on; drawnow   
                    else
                        b_h=plot(  x0_save(3, ind)*180/pi, u0_save(4, ind), '-', 'color', col_, 'Linewidth', lw); hold on; drawnow
                    end
                    b_h.Color(4) = alpha_lvl;
                    xlabel('$\alpha_\mathrm{a}$ (deg)');
                    ylabel('$\mathrm{F}_\mathrm{t}$ (N)');
                    
                end
                %%
            end
        end
    end
    
    if isempty(ops_st)
        folder_name = ['trim_case_',num2str(cnt)];
        cnt = cnt + 1;
        if ~exist(folder_name)
            cd Trim_results
            mkdir( folder_name );
        end
        not_converged = [  params.a_booth,  params.b_booth,  params.phi0_booth, v_w_x_vec, initValues.Ft_trim/1000, initValues.Va];
        save([folder_name,'/not_converged.mat'], 'not_converged');
        cd ..
    else
        %%
        for k = 1 : numel( rps_st )
            [K_lat, K_long, A_tot, B_tot, Ks, A_long, A_lat, B_long, B_lat, B_long_wFt] = lqr_w_psi_wVa_test_decoupled(G_save{k});
            % Gd_scaled = extractDisturbanceGd( A_long, B_long_wFt , constr, act  );
            % analyse_closed_loop_performance( A_long, B_long, eye( size(A_long,1) ), [0, 1, 0, 0], K_long );
            % Gd_scaled_s{k} = Gd_scaled;
            K_delta_e(k,:) = K_long(1,:);
            K_delta_a(k,:) = K_lat(1,:);
            K_delta_r(k,:) = K_lat(2,:);
            A_long_s{k} = A_long;
            A_lat_s{k} = A_lat;
            B_long_s{k} = B_long;
            B_lat_s{k} = B_lat;
            Ks_save{k} = Ks;
            K_delta_tot_a(k,:) = Ks(1,:);
            K_delta_tot_e(k,:) = Ks(2,:);
            K_delta_tot_r(k,:) = Ks(3,:);
            A_tot_s{k} =  G_save{k}.A(1:9,1:9);
            B_tot_s{k} =  G_save{k}.B(1:9,1:3);
        end
        sim_with_indx = 1 ;
        K_long = K_delta_e(sim_with_indx,:);
        K_lat = [K_delta_a(sim_with_indx,:);...
            K_delta_r(sim_with_indx,:)];
        %Ks = Ks_save{sim_with_indx};
        
        x0_trim = x0_save(:,sim_with_indx);
        u0_trim = u0_save(:,sim_with_indx);
        
        sim_with_indx = 1;%length(s);
        x0_sim = x0_save(:,sim_with_indx);
        u0_sim = u0_save(:,sim_with_indx);
        Lbooth.init_sol = s(sim_with_indx);
        A_long_design = A_long_s{1};
        B_long_design = B_long_s{1};
        M_OB = M_OB_init{sim_with_indx};
        
        cd('Trim_results');
        
        folder_name = ['em_analysis_retr_trim_case2_',num2str(cnt)];
        cnt = cnt + 1;
        if ~exist(folder_name)
            mkdir( folder_name );
        end
        save([folder_name,'/G_save.mat'], 'G_save');
        save([folder_name,'/A_tot_s.mat'], 'A_tot_s');
        save([folder_name,'/B_tot_s.mat'], 'B_tot_s');
        save([folder_name,'/A_long_s.mat'], 'A_long_s');
        save([folder_name,'/B_long_s.mat'], 'B_long_s');
        save([folder_name,'/A_lat_s.mat'], 'A_lat_s');
        save([folder_name,'/B_lat_s.mat'], 'B_lat_s');
        save([folder_name,'/params.mat'], 'params');
        save([folder_name,'/initValues.mat'], 'initValues');
        save([folder_name,'/x0_save.mat'], 'x0_save');
        save([folder_name,'/u0_save.mat'], 'u0_save');
        save([folder_name,'/rps_st.mat'], 'rps_st');
        save([folder_name,'/s.mat'], 's');
        save([folder_name,'/M_OB_init.mat'], 'M_OB_init');
        
        cd ..
    end
end

cd(['Trim_results/']);
if save_plots
    Plot2LaTeX2(h2,['v_a_over_alpha_trim_retr_', num2str(ceil(v_w_x_vec))]);
    Plot2LaTeX2(h3,['v_r_over_alpha_trim_retr_', num2str(ceil(v_w_x_vec))]);
    Plot2LaTeX2(h4,['ft_over_alpha_trim_retr_',  num2str(ceil(v_w_x_vec))]);
end
cd ..
