l = 250; 
theta = 0 : 0.01 : 2*pi; 
r = CircleParam.radius;
p_circ_C = [cos(theta);
    sin(theta);
    0*theta]*CircleParam.radius;


alpha = asin(  CircleParam.radius/l ) ;
d = cos(alpha);

e_c_x = [-sin(CircleParam.mean_elevevation); 0; cos(CircleParam.mean_elevevation)];
e_c_y = [0; 1; 0];
e_c_z = -[cos(CircleParam.mean_elevevation); 0; sin(CircleParam.mean_elevevation)];

M_CW = [e_c_x'; e_c_y'; e_c_z'];
M_WC = M_CW';
p_co_W = d*[cos(CircleParam.mean_elevevation);0; sin(CircleParam.mean_elevevation)];

wp_1_C = [0;r;0]; 
wp_1_W = M_WC * wp_1_C; 

wp_4_C = [0;-r;0];
wp_4_W = M_WC * wp_4_C; 
%%
p_circ_W = M_WC * p_circ_C + p_co_W*l;
%%
%figure;
view(90,30); hold on 
plot3( p_circ_W(1,:), p_circ_W(2,:), p_circ_W(3,:), 'color', [0.3, 0.3 ,0.3] ); hold on
