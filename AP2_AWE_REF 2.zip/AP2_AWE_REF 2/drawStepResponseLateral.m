function [rt_beta_95,os_beta_95,st_beta_95,rt_phi_95, os_phi_95, st_phi_95, beta_95, rt_beta_nom, rt_phi_nom, os_beta_nom, os_phi_nom, st_beta_nom, st_phi_nom, beta_induced_nom] = drawStepResponseLateral(CL, save_flag, name_beta, name_phi, alpha_lvl,lw, n_MC)
opt = stepDataOptions;
opt.StepAmplitude = 10*pi/180;
tvec = 0 : 0.1 : 12;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
%% BETA
% h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);

h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);

rt_beta = zeros( n_MC,1 ); 
rt_phi = zeros( n_MC,1 ); 
os_beta= zeros( n_MC,1 );
os_phi= zeros( n_MC,1 );
st_beta= zeros( n_MC,1 );
st_phi= zeros( n_MC,1 );
beta_induced= zeros( n_MC,1 );
G_s =  usample(CL, n_MC); 
sum_A = zeros( 6,6 ); 
for n = 1 : n_MC
    G = G_s(:,:,n); 
    sum_A = G.A + sum_A; 
    s_beta = stepinfo(G(1,1),'RiseTimeLimits',[0,0.95]);
    s_phi = stepinfo(G(2,2),'RiseTimeLimits',[0,0.95]);
    
    rt_beta(n) = s_beta.RiseTime;
    rt_phi(n) = s_phi.RiseTime;
    
    os_beta(n) = s_beta.Overshoot;
    os_phi(n) = s_phi.Overshoot;
    
    st_beta(n) = s_beta.SettlingTime;
    st_phi(n) = s_phi.SettlingTime;
    [y,t] = step(G,tvec,opt);
    beta_induced(n) = max( abs( y(:,1,2)*180/pi ));

    if save_flag
        figure(1);
        ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', lw, 'color', col1); hold on
        ph2=plot( t, y(:,2,1)*180/pi, 'Linewidth', lw, 'color', col3); hold on
        xlabel('$Time$ $(s)$');
        ylabel('$\beta_a$ $(deg)$');
        ph1.Color(4) = alpha_lvl;
        ph2.Color(4) = alpha_lvl;
        
        %% PHI
        %[y,t] = step(sys_phi,tvec,opt);
        figure(2);
        ph1=plot( t, y(:,2,2)*180/pi, 'Linewidth', lw, 'color', col3); hold on
        ph2=plot( t, y(:,1,2)*180/pi, 'Linewidth', lw, 'color', col1); hold on
        
        xlabel('$Time$ $(s)$');
        ylabel('$\Phi_{\tau}$ $(deg)$');
        ph1.Color(4) = alpha_lvl;
        ph2.Color(4) = alpha_lvl;
    end
    
end
[y,t] = step( CL.NominalValue,tvec,opt);
figure(1);
plot( t, t./t*10, '--', 'Linewidth', 1.2, 'color', col2); hold on
ph1=plot( t, y(:,1,1)*180/pi, 'Linewidth', 1.2, 'color', 'c'); hold on
ph2=plot( t, y(:,2,1)*180/pi, 'Linewidth', 1.2, 'color', 'g'); hold on
axis([0 6 -2 12]); hold on
yticks([-2 0 2 4 6 8 10 12])
box on ;

figure(2);
plot( t, t./t*10, '--', 'Linewidth', 1.2, 'color', col2); hold on
ph1=plot( t, y(:,2,2)*180/pi, 'Linewidth', 1.2, 'color', 'g'); hold on
ph2=plot( t, y(:,1,2)*180/pi, 'Linewidth', 1.2, 'color', 'c'); hold on
axis([0 6 -2 12]); hold on
yticks([-2 0 2 4 6 8 10 12])
box on ;
if save_flag
    cd('Trim_results/');
    try
        Plot2LaTeX(h1,name_beta);
        Plot2LaTeX(h2,name_phi);
    end
    cd ..
end


s_beta = stepinfo( CL.NominalValue(1,1),'RiseTimeLimits',[0,0.95]);
s_phi = stepinfo( CL.NominalValue(2,2),'RiseTimeLimits',[0,0.95]);

rt_beta_nom(1) = s_beta.RiseTime;
rt_phi_nom(1) = s_phi.RiseTime;

os_beta_nom(1) = s_beta.Overshoot;
os_phi_nom(1) = s_phi.Overshoot;

st_beta_nom(1) = s_beta.SettlingTime;
st_phi_nom(1) = s_phi.SettlingTime;

beta_induced_nom(1) = max( abs( y(:,1,2)*180/pi ));

%% Statistical Analyis
% mu_rt_beta = mean( rt_beta );
% mu_rt_phi = mean( rt_phi );
% CI95_rt_beta = [mu_rt_beta - 1.96*std(rt_beta)/sqrt(n_MC), mu_rt_beta + 1.96*std(rt_beta)/sqrt(n_MC)];
% CI95_rt_phi =[mu_rt_phi - 1.96*std(rt_phi)/sqrt(n_MC), mu_rt_phi + 1.96*std(rt_phi)/sqrt(n_MC)];
% 
% mu_os_beta = mean( os_beta );
% mu_os_phi = mean( os_phi );
% CI95_os_beta = [mu_os_beta - 1.96*std(os_beta)/sqrt(n_MC), mu_os_beta + 1.96*std(os_beta)/sqrt(n_MC)];
% CI95_os_phi =[mu_os_phi - 1.96*std(os_phi)/sqrt(n_MC), mu_os_phi + 1.96*std(os_phi)/sqrt(n_MC)];
% 
% mu_st_beta = mean( st_beta );
% mu_st_phi = mean( st_phi );
% CI95_st_beta = [mu_st_beta - 1.96*std(st_beta)/sqrt(n_MC), mu_st_beta + 1.96*std(st_beta)/sqrt(n_MC)];
% CI95_st_phi =[mu_st_phi - 1.96*std(st_phi)/sqrt(n_MC), mu_st_phi + 1.96*std(st_phi)/sqrt(n_MC)];

% interesting is also the 95% quantile two sided for beta (97.5 below or
% 97.5 above)
n_95 = ( 0.95*n_MC );

rt_beta_sort = sort( rt_beta, 'ascend' );
rt_beta_95 = rt_beta_sort(n_95);

os_beta_sort = sort( os_beta, 'ascend' );
os_beta_95 = os_beta_sort(n_95);

st_beta_sort = sort( st_beta, 'ascend' );
st_beta_95 = st_beta_sort(n_95);
%
rt_phi_sort = sort( rt_phi, 'ascend' );
rt_phi_95 = rt_phi_sort(n_95);

os_phi_sort = sort( os_phi, 'ascend' );
os_phi_95 = os_phi_sort(n_95);

st_phi_sort = sort( st_phi, 'ascend' );
st_phi_95 = st_phi_sort(n_95);
%
beta_induced_sort = sort( beta_induced, 'ascend' );
beta_95 = beta_induced_sort(n_95);
