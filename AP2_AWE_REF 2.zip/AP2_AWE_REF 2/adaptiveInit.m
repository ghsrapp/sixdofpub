% Rate Loop
A = -diag([KRollRate, KPitchRate, KYawRate]);
B = eye(3);
Q = 2*eye(3); 
PP = lyap( A', Q ); 

kappa = 0.0001; 

% course loop 
A = -FCS.Kp_chi_predictive;
B = 1;
Q = 2*eye(1); 
PP = lyap( A', Q ); 


%% Rate Loop
n3 = 1; 
n2 = 3; % 5 should be enough (Stevens,Lewis, Johnson)
n1 = 3; 
V_init = 0.01*rand(n1+1, n2);  
W_init = 0.01*rand(n2+1, n3); 

% gem�� holzapfel herleitung
gamma_ = (omega_rate_ref*0.1)^2*KRollRate/ ( 1 + n2/4 );
%gamma_ = 300; 
Gamma_w = gamma_*eye(n3); 
Gamma_v = gamma_*eye(n1+1); 

Gamma_w = 1; 
Gamma_v = 1; 

%% Flight path loop 
n3fp = 1; 
n2fp = 5; 
n1fp = 6;
Vfp_init = 0.01*rand(n1fp+1, n2fp);  
Wfp_init = 0.01*rand(n2fp+1, n3fp); 

%gamma_ =(FCS.w0_*0.8)^2*Kp_course/ ( 1 + n2fp/4 );
Gammafp_w = 10;%gamma_*eye(n3fp); 
Gammafp_v = 10;%gamma_*eye(n1fp+1); 

% Reference model flight path
Afp = -diag([ FCS.Kp_chi_predictive]);
Bfp = eye(n3fp);
Q = 2*eye(n3fp); 
PPfp = lyap( Afp', Q ); 

%% LESO init (damn its soo easy..)
% funny: could be also abbreviated with EKF, and extended Kalman filter ;-)

LESO.A = [zeros(3), eye(3); 
    zeros(3), zeros(3)];
LESO.B = [eye(3); zeros(3)];
LESO.Q = 100*diag([0.1, 0.1, 0.1, 100, 100, 100] ); 
LESO.R = eye(3); 
LESO.C = [eye(3), zeros(3)]; 
LESO.K = lqr(LESO.A', LESO.C', LESO.Q, LESO.R ); 
LESO.L = LESO.K';
LESO.factor = 10; 
LESO.L =  0.5*[LESO.factor*FCS.w0_p, 0, 0; 
        0, (LESO.factor*FCS.w0_q), 0; 
        0, 0, (LESO.factor*FCS.w0_r); 
        0.2*(LESO.factor*FCS.w0_p), 0, 0; 
        0, 0.2*(LESO.factor*FCS.w0_q), 0; 
        0, 0, 0.2*(LESO.factor*FCS.w0_r)];

%%
LESO.Acourse = [0,1; 
    0, 0];
LESO.Bcourse = [1; 0];
LESO.Lcourse =  [20;0.1];
%%
A = [0,1; 
    -FCS.w0_p^2, -2*FCS.w0_p*FCS.zeta0_p];






