clear all 
close all
clc 


phi_vec =  [25, 30, 35]*pi/180;
lambda_vec = [80, 90, 100];
fac_vec = [2.8,3,3.2,3.4,3.6,3.8,4,4.2,4.4,4.6];

for cnt1 = 1 : length(phi_vec)
    batch_run_phi0 = phi_vec(cnt1); 
    for cnt2 = 1 : length( lambda_vec)
        batch_run_alambda = lambda_vec(cnt2); 
        for cnt3 = 1 : length( fac_vec )
            batch_run_fac = fac_vec(cnt3);
            init_new;
            sim('AWE_Testbed_07');
            cd 'res'
             save(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat'], 'pos_W'); 
             save(['power',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat'], 'power_vr_tether'); 
             cd ..
             figure(1); 
             plot3( pos_W.Data(:,1), pos_W.Data(:,2), pos_W.Data(:,3) );
             figure(2); 
             plot( power_vr_tether );
             pause(1);
        end
    end
end
            
    