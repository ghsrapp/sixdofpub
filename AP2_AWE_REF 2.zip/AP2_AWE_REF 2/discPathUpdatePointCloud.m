function [ waypointsPathUpdate ] = discPathUpdatePointCloud( l_tether, pathReference, latChoose  )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
% pathReference must have the structure: [long, lat, tetherLength]

M_rot = [cos(latChoose), 0, sin(latChoose); 
         0, 1, 0; 
         -sin(latChoose), 0, cos(latChoose)]; 
     
longs_SE = pathReference(:,1) .* pathReference(:,3)/l_tether; 
lats_SE = pathReference(:,2) .* pathReference(:,3)/l_tether; 
waypointsPathUpdate = [cos(longs_SE).*cos(lats_SE), sin(longs_SE).*cos(lats_SE), sin(lats_SE)] * l_tether;

waypointsPathUpdate = waypointsPathUpdate * M_rot; 
end

