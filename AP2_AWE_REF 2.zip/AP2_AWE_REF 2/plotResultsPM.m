function plotResultsPM( yout_mat, save_flag, mother_file_name, mean_phi0 )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];


for j = 1 : length( yout_mat )
    
    N = length( yout_mat(j).TetherForce.Data );
    plot_indx_from = N- yout_mat(j).sample_counter.Data+1; % was 120
    plot_indx_to = N;

    close all;

    p = squeeze(  yout_mat(j).pos_W.Data )'; 
    tp = squeeze(  yout_mat(j).target_pos.Data ); 

%     %% va
%     h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
%     plot( yout_mat(j).va_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).va_save.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
% %   axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  26 34 ] );
%      % axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  28 36 ] );
%     xlabel('$Time$ $(s)$');
%     ylabel('$v_{a}$ $(m/s)$');
%        
     %% Path tracking error
    l =   sqrt( sum(p(plot_indx_from:plot_indx_to,1:3).*p(plot_indx_from:plot_indx_to,1:3)  ,2 ) ); 
    l_t = sqrt( sum(tp(plot_indx_from:plot_indx_to,1:3).*tp(plot_indx_from:plot_indx_to,1:3) , 2 ) ); 
    
%       %% Path tracking error
%     l =   sqrt( sum(p(:,1:3).*p(:,1:3)  ,2 ) ); 
%     l_t = sqrt( sum(tp(:,1:3).*tp(:,1:3) , 2 ) );
    h2 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    cte = acos( ( sum( p(plot_indx_from:plot_indx_to,1:3).*tp(plot_indx_from:plot_indx_to,1:3),2 ) )./l_t./l ) .* l; 
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), cte, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,2)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,2), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,3)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,3), 'color', col3, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
   % yticks([-12 -8 -4 0 4 8 12]); 
    %yticklabels({'-12', '-8','-4', '0', '4', '8','12'})    
    ylabel('$e_p$ $(m)$');
    xlabel('$Time$ $(s)$');
    
    %% path projection 
    M_WP = [cos(mean_phi0),0, -sin(mean_phi0);0, 1, 0;  sin(mean_phi0),0, cos(mean_phi0)];  
%     p_P = M_WP'*[ p(:,1), p(:,2),  p(:,3)]';
%     pt_P = M_WP'*[tp(:,1),  tp(:,2),  tp(:,3)]';
%     
   p_P = M_WP'*[ p(plot_indx_from:plot_indx_to,1), p(plot_indx_from:plot_indx_to,2),  p(plot_indx_from:plot_indx_to,3)]';
   pt_P = M_WP'*[tp(plot_indx_from:plot_indx_to,1),  tp(plot_indx_from:plot_indx_to,2),  tp(plot_indx_from:plot_indx_to,3)]';
    
    h3 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( p_P(2,:), p_P(3,:), 'color', col1, 'Linewidth', 1, 'Linestyle', '-' ); hold on
    plot( pt_P(2,:), pt_P(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on
    xlabel('$y_P$ $(m)$');
    ylabel('$z_P$ $(m)$');
    axis equal
    
    %% path in xz plane to show reeling speed change
    h4 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot(p(plot_indx_from:plot_indx_to,1), p(plot_indx_from:plot_indx_to,3), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( tp(plot_indx_from:plot_indx_to,1), tp(plot_indx_from:plot_indx_to,3), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
  %  axis([-50 550 100 400] )
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
  %  axis equal
    
      %% path in xy plane to show reeling speed change
    h5 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot(p(plot_indx_from:plot_indx_to,1), p(plot_indx_from:plot_indx_to,2), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( tp(plot_indx_from:plot_indx_to,1), tp(plot_indx_from:plot_indx_to,2), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    axis([-50 550 -200 200] )
    xlabel('$x_W$ $(m)$');
    ylabel('$y_W$ $(m)$');
    axis equal
    
    
     h6 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
     plot( yout_mat(j).v_w_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).v_w_W.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
  %  axis([ceil(yout_mat(j).phi_tau.Time(plot_indx_from)) ceil(yout_mat(j).phi_tau.Time(plot_indx_to))  -30 30 ] );
  xlabel('$Time$ $(s)$');
    ylabel('$v_{w,x,W}$ $(deg)$');
    
    
    if save_flag
        cd('Trim_results/');
       % Plot2LaTeX(h1,[mother_file_name,'_va_',num2str(j)]);
        Plot2LaTeX(h2,[mother_file_name,'_pE_',num2str(j)]);
        Plot2LaTeX(h3,[mother_file_name,'_path_proj_',num2str(j)]);
        Plot2LaTeX(h4,[mother_file_name,'_path_xz_',num2str(j)]);
        Plot2LaTeX(h5,[mother_file_name,'_path_xy_',num2str(j)]);
       Plot2LaTeX(h6,[mother_file_name,'_vwx_',num2str(j)]);
        cd ..
    end

end

end