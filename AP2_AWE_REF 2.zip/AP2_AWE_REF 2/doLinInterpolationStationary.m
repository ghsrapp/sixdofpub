function [v_w_O] = doLinInterpolationStationary(pos_W,xvec,yvec,zvec,windDirection_rad,u_tau, mat_3D_Windfield_u,mat_3D_Windfield_v, mat_3D_Windfield_w)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


pos_W(1) = min( max( pos_W(1), xvec(1)), xvec(end));
pos_W(2) = min( max( pos_W(2), yvec(1)), yvec(end));
pos_W(3) = min( max( pos_W(3), zvec(1)), zvec(end));

x_vec = [pos_W]';

% Determine boundaries
[ interval_bounds_x, interval_indices_x ] = searchIntervalBounds( xvec, x_vec(1) ); % x
[ interval_bounds_y, interval_indices_y ] = searchIntervalBounds( yvec, x_vec(2) ); % y
[ interval_bounds_z, interval_indices_z ] = searchIntervalBounds( zvec, x_vec(3) ); % z


x_min = interval_bounds_x(1);
x_max = interval_bounds_x(2);
y_min = interval_bounds_y(1);
y_max = interval_bounds_y(2);
z_min = interval_bounds_z(1);
z_max = interval_bounds_z(2);

p_vec_max = [x_max, y_max, z_max];
p_vec_min = [x_min, y_min, z_min];

% interpolation ratios
Theta = (x_vec - p_vec_min)./(p_vec_max - p_vec_min);
Theta = Theta';

Theta1 = Theta(1);
Theta2 = Theta(2);
Theta3 = Theta(3);

% xi = 1; 
% for n = 1 : length(Theta)
%        xi = [ (1-Theta(n)) * xi,  Theta(n) * xi] ; 
% end
xi = [ -(Theta1 - 1)*(Theta2 - 1)*(Theta3 - 1),...
    Theta1*(Theta2 - 1)*(Theta3 - 1),...
    Theta2*(Theta1 - 1)*(Theta3 - 1),...
    -Theta1*Theta2*(Theta3 - 1),...
    Theta3*(Theta1 - 1)*(Theta2 - 1),...
    -Theta1*Theta3*(Theta2 - 1),...
    -Theta2*Theta3*(Theta1 - 1),...
    Theta1*Theta2*Theta3];


%% Calculation of the vertex weights
% => normally we would get also an index with that i.e.
% x_max_idx = ... , z_min_idx = ... . We will choose arbitray values here:
x_min_idx = interval_indices_x(1); x_max_idx = x_min_idx+1;
y_min_idx = interval_indices_y(1); y_max_idx = y_min_idx+1;
z_min_idx = interval_indices_z(1); z_max_idx = z_min_idx+1;

if y_max_idx > length( yvec )
    1;
end


idx_vec_max = [x_max_idx,y_max_idx,z_max_idx];
idx_vec_min = [x_min_idx,y_min_idx,z_min_idx];

% we now create a matrix that associates the indices to max/min values
% Create vertices
numb_param = 3; % spatial coordinates with time

Vbin_max = [zeros(1,numb_param);
    de2bi(1:2^numb_param-1)];
Vbin_min = Vbin_max == 0;

max_v_mat = repmat( idx_vec_max, 2^numb_param,1,1);
min_v_mat = repmat( idx_vec_min, 2^numb_param,1,1);

V_indices = max_v_mat .* Vbin_max + min_v_mat .* Vbin_min;

if V_indices(2,1) > 29
    1;
end

[vel_inter_x ] = interpolateVelocityVectorStat(mat_3D_Windfield_u,xi,V_indices);
[vel_inter_y ] = interpolateVelocityVectorStat(mat_3D_Windfield_v,xi,V_indices);  
[vel_inter_z ] = interpolateVelocityVectorStat(mat_3D_Windfield_w,xi,V_indices);

v_w_W = [vel_inter_x; vel_inter_y; vel_inter_z];

v_w_O = u_tau*transformFromWtoO(windDirection_rad, v_w_W );


end

