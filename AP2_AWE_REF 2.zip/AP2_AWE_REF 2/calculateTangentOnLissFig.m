function t_c = calculateTangentOnLissFig(sol, LemPs )

L_sol = [LemPs.Alambda*sin(LemPs.blambda*sol');
    LemPs.Aphi*sin(LemPs.bphi*sol')+LemPs.phi0];
dLds = [ LemPs.Alambda*cos(LemPs.blambda*sol);...
    2*LemPs.Aphi*cos(LemPs.bphi*sol) ];

s_lambda = sin( L_sol(1,:)  );
s_phi = sin( L_sol(2,:)  );
c_lambda = cos( L_sol(1,:)   );
c_phi = cos( L_sol(2,:)  );

% Tangent
direction_ = -1;
t_c = direction_ * [-s_lambda.*dLds(1).*c_phi-s_phi.*dLds(2).*c_lambda;
    c_lambda.*dLds(1).*c_phi-s_phi.*dLds(2).*s_lambda;
    c_phi.*dLds(2)]*10;