x = 1 : 1 : 60; 
max_bandwidth = 1; 
logOptParams;
assignOptVariables2SimWorkspace2(max_bandwidth,x); 
cd params/
exportTmpBestParams2(x);