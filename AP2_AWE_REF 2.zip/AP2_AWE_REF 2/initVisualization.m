%% ==== Plotting
l_tether = 200;
r_SE = r_d / l_tether; % This is the radius on the small earth
lat = latChoose;
% l_tether = 200;
t = linspace( 0,2*pi , 100);
phi = linspace(0,2*pi, 100);
grid on
t1 = linspace( 2*pi, pi , 100);
t2 = linspace( pi, 0 , 100);
t3 = linspace( 0, 2*pi, 100);
close all;
FigHandle = figure(1);
grid on; hold on;
axis equal; hold on;
xlabel('Downwind (m)'); hold on;
ylabel('y'); hold on;
zlabel('z'); hold on;
view(90,latChoose*180/pi); hold on;
set(FigHandle, 'Position', [100, 100, 649, 500]);
if 0
    [X,Y,Z] = sphere(50);
    s = surf(X*l_tether, Y*l_tether, Z*l_tether);
    set(s, 'FaceAlpha', 1, 'edgecolor', [0.5, 0.5, 0.5]);
    cmap = [0.8,0.8,0.8];
    colormap(cmap);
end

if  figIndx == 1 || figIndx == 2 
    
    longLeft = -asin(maxWidth/2 / (cos(latChoose)*l_tether) );
    if figIndx == 1
        x_circle1 = r_SE * cos(t3);
        y_circle1 = r_SE* sin(t3);
    else
        x_circle1 = r_SE * cos(t1);
        y_circle1 = r_SE* sin(t1);
    end
    
    % Circle two
    x_circle2 = r_SE * cos(t2);
    y_circle2 = r_SE* sin(t2);
    z_circle = zeros(1, length(x_circle1));
    v_circ1 = [ x_circle1; y_circle1; z_circle] * l_tether;
    v_circ2 = [ x_circle2; y_circle2; z_circle] * l_tether;
    
    % First circle
    M_NE_left = [-sin(latChoose)*cos(longLeft), -sin(latChoose)*sin(longLeft), cos(latChoose);
        -sin(longLeft), cos(longLeft), 0;
        -cos(latChoose)*cos(longLeft), -cos(latChoose)*sin(longLeft), -sin(latChoose)];
    M_EN_left = M_NE_left';
    v_circ_E1 = M_EN_left * v_circ1;
    
    % This is important: Definitions of the center of the circle
    deltaAngle = asin( r_SE );
    s = cos(deltaAngle);
    p_circO1_E =  s*[cos(longLeft)*cos(latChoose);...
        sin(longLeft)*cos(latChoose);...
        sin(latChoose)];
    
    % sommit
    p01_E = M_EN_left * [0;0;-1];
    
    % Second circle
    longRight = -longLeft;
    M_NE_right = [-sin(latChoose)*cos(longRight), -sin(latChoose)*sin(longRight), cos(latChoose);
        -sin(longRight), cos(longRight), 0;
        -cos(latChoose)*cos(longRight), -cos(latChoose)*sin(longRight), -sin(latChoose)];
    
    
    M_EN_right = M_NE_right';
    v_circ_E2 = M_EN_right * v_circ2;
    
    % This is important: Definitions of the center of the circle
    p_circO2_E = s*[cos(longRight)*cos(latChoose);...
        sin(longRight)*cos(latChoose);...
        sin(latChoose)];
    
    % Sommit
    p02_E = M_EN_right * [0;0;-1];
    col = [0.4 0.4 0.4];
    
    % Definition of the waypoints
    left_top = [r_SE; 0; 0];
    left_bottom = [-r_SE; 0; 0];
    left_top_E = M_EN_left * left_top;
    left_bottom_E = M_EN_left * left_bottom;
    left_top_abs_E = p_circO1_E + left_top_E;
    left_bottom_abs_E = p_circO1_E + left_bottom_E;
    
    right_bottom = [-r_SE; 0; 0];
    right_top = [r_SE; 0; 0];
    right_bottom_E = M_EN_right * right_bottom;
    right_bottom_abs_E = p_circO2_E + right_bottom_E;
    right_top_E = M_EN_right * right_top;
    right_top_abs_E = p_circO2_E + right_top_E;
    
    
    
    % middle point
    lat_bottom = asin( right_bottom_abs_E(3)/norm(right_bottom_abs_E) );
    mid_bottom_abs_E = [right_bottom_abs_E(1);0;right_bottom_abs_E(3)];%l_tether*[cos(lat_bottom);0;sin(lat_bottom)]; %
   
    % Waypoints
    if 0
        plot3(left_top_abs_E(1)/norm(left_top_abs_E)*l_tether, left_top_abs_E(2)/norm(left_top_abs_E)*l_tether, left_top_abs_E(3)/norm(left_top_abs_E)*l_tether, 'color',col, 'Marker', '+');
        plot3(left_bottom_abs_E(1)/norm(left_bottom_abs_E)*l_tether, left_bottom_abs_E(2)/norm(left_bottom_abs_E)*l_tether, left_bottom_abs_E(3)/norm(left_bottom_abs_E)*l_tether, 'color',col, 'Marker', '+');
        plot3(right_bottom_abs_E(1)/norm(right_bottom_abs_E)*l_tether, right_bottom_abs_E(2)/norm(right_bottom_abs_E)*l_tether, right_bottom_abs_E(3)/norm(right_bottom_abs_E)*l_tether,  'color',col, 'Marker', '+');
        plot3(right_top_abs_E(1)/norm(right_top_abs_E)*l_tether, right_top_abs_E(2)/norm(right_top_abs_E)*l_tether, right_top_abs_E(3)/norm(right_top_abs_E)*l_tether, 'color',col, 'Marker', '+');
    end
    
    % calculate normal vector
    rot_vec_1 = cross( right_top_abs_E/norm(right_top_abs_E), left_bottom_abs_E/norm(left_bottom_abs_E));
    %rot_vec_2 = cross( left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_2 = cross( mid_bottom_abs_E/norm(mid_bottom_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_3 = cross( left_top_abs_E/norm(left_top_abs_E), mid_bottom_abs_E/norm(mid_bottom_abs_E));
    rot_vec_4 = cross( left_bottom_abs_E/norm(left_bottom_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    rot_vec_5 = cross( mid_bottom_abs_E/norm(mid_bottom_abs_E), right_top_abs_E/norm(right_top_abs_E));
    rot_vec_6 = cross( left_top_abs_E/norm(left_top_abs_E), right_top_abs_E/norm(right_top_abs_E));
    rot_vec_7 = cross( left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E));
    
    
    
    rot_vec_8 = cross( zenith_pos/norm(zenith_pos), reference_pos/norm(reference_pos));
    %rot_vec_trans = cross( zenith_E/norm(zenith_E), left_top_abs_E/norm(left_top_abs_E));
    
    % Calculate orthonormal basis that lies in the great circle plane:
    e_x_1 = right_top_abs_E/norm(right_top_abs_E); e_z_1 = rot_vec_1/norm(rot_vec_1);e_y_1 = cross(e_z_1,e_x_1);
    %e_x_2 = left_top_abs_E/norm(left_top_abs_E); e_z_2 = rot_vec_2/norm(rot_vec_2);e_y_2 = cross(e_z_2,e_x_2);
    e_x_2 = mid_bottom_abs_E/norm(mid_bottom_abs_E); e_z_2 = rot_vec_2/norm(rot_vec_2);e_y_2 = cross(e_z_2,e_x_2);
    e_x_3 = left_top_abs_E/norm(left_top_abs_E); e_z_3 = rot_vec_3/norm(rot_vec_3);e_y_3 = cross(e_z_3,e_x_3);
    e_x_4 = left_bottom_abs_E/norm(left_bottom_abs_E); e_z_4 = rot_vec_4/norm(rot_vec_4);e_y_4 = cross(e_z_4,e_x_4);
    e_x_5 = mid_bottom_abs_E/norm(mid_bottom_abs_E); e_z_5 = rot_vec_5/norm(rot_vec_5);e_y_5 = cross(e_z_5,e_x_5);
    e_x_6 = left_top_abs_E/norm(left_top_abs_E); e_z_6 = rot_vec_6/norm(rot_vec_6);e_y_6 = cross(e_z_6,e_x_6);
    e_x_7 = left_top_abs_E/norm(left_top_abs_E); e_z_7 = rot_vec_7/norm(rot_vec_7);e_y_7 = cross(e_z_7,e_x_7);
    
    
    if 1
        % angle between the two waypoints
        ang1 = acos( right_top_abs_E' * left_bottom_abs_E); % great circle is from 0 to ang1
        t1 = linspace( 0, ang1, 10);
        % angle between the two waypoints
        ang2 = acos( left_top_abs_E' * right_bottom_abs_E); % great circle is from 0 to ang1
        t2 = linspace( 0, ang2, 10);
    end
    
    
    
    % zenith
    e_x_8 = zenith_pos/norm(zenith_pos); e_z_8 = rot_vec_8/norm(rot_vec_8);e_y_8 = cross(e_z_8,e_x_8);
    %e_x_trans = zenith_E/norm(zenith_E); e_z_trans = rot_vec_trans/norm(rot_vec_trans);e_y_trans = cross(e_z_trans,e_x_trans);
    
    % Plotting the great circles
    M_GE_1 = [e_x_1'; e_y_1'; e_z_1'];
    M_GE_2 = [e_x_2'; e_y_2'; e_z_2'];
    M_GE_3 = [e_x_3'; e_y_3'; e_z_3'];
    M_GE_4 = [e_x_4'; e_y_4'; e_z_4'];
    M_GE_5 = [e_x_5'; e_y_5'; e_z_5'];
    M_GE_6 = [e_x_6'; e_y_6'; e_z_6'];
    M_GE_7 = [e_x_7'; e_y_7'; e_z_7'];
    M_GE_8 = [e_x_8'; e_y_8'; e_z_8'];
    %   M_GE_trans = [e_x_trans'; e_y_trans'; e_z_trans'];
    
    great_circle_1_G =   [cos(t); sin(t); zeros(1,length(t))] * l_tether;
    great_circle_1_G_mod =   [cos(t1); sin(t1); zeros(1,length(t1))] * l_tether;
    great_circle_7_G_mod =   [cos(t2); sin(t2); zeros(1,length(t1))] * l_tether;
    
    great_circle_1_E = M_GE_1' * great_circle_1_G_mod;
    great_circle_2_E = M_GE_2' * great_circle_1_G;
    great_circle_3_E = M_GE_3' * great_circle_1_G;
    great_circle_4_E = M_GE_4' * great_circle_1_G;
    great_circle_5_E = M_GE_5' * great_circle_1_G;
    great_circle_6_E = M_GE_6' * great_circle_1_G;
    great_circle_7_E = M_GE_7' * great_circle_7_G_mod;
    great_circle_8_E = M_GE_8' * great_circle_1_G;
    % great_circle_trans_E = M_GE_trans' * great_circle_1_G;
    waypointsPath = discPathUpdateGcC( l_tether, r_d, latChoose, maxWidth,1);
    zenith_E = [0;0;1];
    if figIndx ==2
        plot3( great_circle_1_E(1,:), great_circle_1_E(2,:), great_circle_1_E(3,:),'color',col, 'Linewidth', 1.4 ); hold on
        plot3( great_circle_7_E(1,:), great_circle_7_E(2,:), great_circle_7_E(3,:),'color',col, 'Linewidth', 1.4 ); hold on
        plot3(v_circ_E1(1,:)+p_circO1_E(1)* l_tether, v_circ_E1(2,:)+p_circO1_E(2)* l_tether, v_circ_E1(3,:)+p_circO1_E(3)* l_tether,'color',col, 'Linewidth', 1.4 );  hold on
        plot3(v_circ_E2(1,:)+p_circO2_E(1)* l_tether, v_circ_E2(2,:)+p_circO2_E(2)* l_tether, v_circ_E2(3,:)+p_circO2_E(3)* l_tether,'color',col, 'Linewidth', 1.4 );  hold on
        %plot3( waypointsPath(:,1), waypointsPath(:,2), waypointsPath(:,3),'Marker','o', 'color','red'); hold on
        %plot3( [waypointsPath(1,1) waypointsPath(end,1)],[waypointsPath(1,2) waypointsPath(end,2)],[waypointsPath(1,3) waypointsPath(end,3)] ,'Marker','o', 'color','red'); hold on
        %axis equal;
    elseif figIndx == 1
        plot3(v_circ_E1(1,:)+p_circO1_E(1)* l_tether, v_circ_E1(2,:)+p_circO1_E(2)* l_tether, v_circ_E1(3,:)+p_circO1_E(3)* l_tether,'color',col, 'Linewidth', 1.4 );  hold on
    end
elseif figIndx == 4
    plot3( lemniscate_W_real(:,1),  lemniscate_W_real(:,2), lemniscate_W_real(:,3), '--o', 'color', [0.5, 0.5, 0.5], 'Linewidth',2); hold on
    plot3( [lemniscate_W_real(1,1) lemniscate_W_real(end,1)], [lemniscate_W_real(1,2) lemniscate_W_real(end,2)], [lemniscate_W_real(1,3) lemniscate_W_real(end,3)], '--o', 'color', [0.5, 0.5, 0.5],'Linewidth', 2); hold on
    plot3( lemniscate_W_real(wp_idx_init,1),lemniscate_W_real(wp_idx_init,2),lemniscate_W_real(wp_idx_init,3), '*g');
    %axis equal;
elseif figIndx == 5
    LemPs.Alambda = LemPsRef.AlambdaRef/l_tether;
    LemPs.Aphi = LemPsRef.AphiRef/l_tether;
    LemPs.blambda = LemPsRef.blambdaRef;
    LemPs.bphi = LemPsRef.bphiRef;
    LemPs.phi0 = LemPsRef.phi0;
    
    Alambda = LemPs.Alambda ;
    Aphi = LemPs.Aphi;
    blambda = LemPs.blambda;
    bphi = LemPs.bphi;
    phi0 = LemPs.phi0;
    s = 0 : 0.01 : 2*pi; % Remark: 0 to Pi -> lambda >0, pi to 2*pi -> lambda < 0
    L = [Alambda * sin(blambda*s);
        Aphi    * sin(bphi*s) + phi0*pi/180];
    L_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))];
    L_W_k = L_W * l_tether;
    plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;
    axis equal; grid on;hold on;
    axis([-1.5 l_tether*2 -LemPsRef.AlambdaRef-10 LemPsRef.AlambdaRef+10 0 l_tether*2])
    %[x,y,z]= sphere(100);
    %surf(y*l_tether,x*l_tether,z*l_tether, 'FaceColor', [0.5 0.5 0.5]); hold on;
    drawnow;
elseif figIndx == figIndxLissajousVecF
  
   drawLissajous;
end