function drawFrequencyDomainStuff(indx, G_dFt_to_alphac, G_dFt_to_alphac_unc,So,To, save_flag, name_plot )
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);


h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);


alpha_lvl_max = 1; 
alpha_lvl_min = 0.3; 

omegas = logspace( -2, 2, 1000); 
for m = 1 : numel( G_dFt_to_alphac ) 
    
    lambda = (m -1 )/(numel( G_dFt_to_alphac )-1);
    alpha_lvl = (1-lambda)*alpha_lvl_min + lambda*alpha_lvl_max;
    
    j = indx(m); 
    figure(1); 
    ph1=semilogx( omegas, 20*log10( squeeze( abs( freqresp(G_dFt_to_alphac{j}, omegas ) ) ) ) , 'color', col1, 'Linewidth', 1.2 ); hold on 
    ph2=semilogx( omegas, 20*log10( squeeze( abs( freqresp(G_dFt_to_alphac_unc{j}, omegas ) ) ) ) , 'color', col2, 'Linewidth', 1.2 ); hold on 
    
    figure(2); 
    ph3=semilogx( omegas, 20*log10( squeeze( abs( freqresp(So{j}, omegas ) ) ) ) , 'color', col1, 'Linewidth', 1.2 ); hold on 
    ph4=semilogx( omegas, 20*log10( squeeze( abs( freqresp(To{j}, omegas ) ) ) ) , 'color', col2, 'Linewidth', 1.2 ); hold on 
    
    ph1.Color(4) = alpha_lvl;
    ph2.Color(4) = alpha_lvl;
    ph3.Color(4) = alpha_lvl;
    ph4.Color(4) = alpha_lvl;
end

figure(1); 
xlabel('$Frequency$ $(rad/s)$'); hold on 
ylabel('$Magnitude$ $(dB)$')

figure(2); 
xlabel('$Frequency$ $(rad/s)$');  hold on 
ylabel('$Magnitude$ $(dB)$')

if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,[name_plot,'_G_dFt_to_alphac']);
    Plot2LaTeX(h2,[name_plot,'_SoTo_alphac']);
    cd ..
end