clear
close all



results_path = 'Trim_results/case_1_phi35_mix_ft_and_alpha';
%test_idx = 2;
load([results_path,'/x0_save']);
for test_idx = 7 : 12
    
    addpath(results_path);
    load('G_save.mat');
    A = G_save{test_idx}.A(1:9, 1:9);
    B = G_save{test_idx}.B(1:9, 1:4);
    
    % =========== Longi controller ==================================================================
   load(['list_old_individuals_long_',num2str( test_idx - 6 ) ,'.mat']);
  %  load(['list_old_individuals_long_',num2str(6),'.mat']);

    [val,idx] = min( list_old_individuals(end,:) );
    
    qs = list_old_individuals(1:4, idx);
    
    Q_long = diag([0;qs]);
    R_long = 1;
    
    A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
        A(3,1), A(3,3), A(3, 5), A(3,8);
        A(5,1), A(5,3), A(5, 5), A(5,8);
        A(8,1), A(8,3), A(8, 5), A(8,8)];
    B_long = [B(1,2);B(3,2);B(5,2);B(8,2)];
    C = [0,1,0,0];
    A_long = [A_long, zeros(4,1);
        -C, 0];
    B_long = [B_long; 0];
    
    K_long_mat(test_idx,:) = lqr( A_long, B_long, Q_long, R_long );
    
    [time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();
    opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
    yOUTlog  = get_robustification_cost( time_domain_ref_long, frequ_domain_ref_long, A_long, B_long,  K_long_mat(test_idx,:)  );
    
    [stabmarg, CL] = getRobStabMargin_long( A_long, B_long, K_long_mat(test_idx,:), [0,1,0,0,0], opts, frequ_domain_ref_long);
    step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
    figure;
    step( CL );hold on
    step( CL.NominalValue );
    
     stabmarg_long_for_trimpoint_mat(test_idx,1:3) = [x0_save(1,test_idx), stabmarg.LowerBound, stabmarg.UpperBound];

     if 0 
    % =========== SP controller ==================================================================
    load(['list_old_individuals_SP_',num2str( test_idx - 6 ),'.mat']);
    
    [val,idx] = min( list_old_individuals(end,:) );
    
    qs = list_old_individuals(1:3, idx);
    
    Q_SP = diag(qs);
    R_SP = 1;
    
    % Short period approximation
    A_SP = [A_long(2,2), A_long(2,4);
        A_long(4,2), A_long(4,4)];
    B_SP = [B_long(2,1); B_long(4,1)];
    A_SP = [A_SP, zeros(2,1);
        -1, 0, 0];
    B_SP = [B_SP; 0];
    
    K_SP_mat(test_idx,:) = lqr( A_SP, B_SP, Q_SP, R_SP );
    
    [time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();
    opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
    yOUTlog  = get_robustification_cost_SP( time_domain_ref_long, frequ_domain_ref_long, A_SP, B_SP,  K_SP_mat(test_idx,:)  );
    
    [stabmarg, CL] = getRobStabMargin_SP( A_SP, B_SP, K_SP_mat(test_idx,:), [1,0,0], opts, frequ_domain_ref_long);
    step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
    figure;
    step( CL );hold on
    step( CL.NominalValue );
    
     stabmarg_SP_for_trimpoint_mat(test_idx,1:3) = [x0_save(1,test_idx), stabmarg.LowerBound, stabmarg.UpperBound];
     end
    % =========== Lateral controller ==================================================================
    
    A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9); % beta
        A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9); % phi_tau
        A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9); % psi_tau
        A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9); % p
        A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];% r
    
    B_lat = [B(2,1),B(2,3);...
        B(4,1),B(4,3);...
        B(6,1),B(6,3);...
        B(7,1),B(7,3);...
        B(9,1),B(9,3)];
    
    A_lat(3,:) = [];
    A_lat(:,3) = [];
    B_lat(3,:) = [];
    C_control = zeros(2, size( A_lat,2) );
    C_control(1,1) = 1;
    C_control(2,2) = 1;
    A_lat = [A_lat, zeros(size( A_lat,2) ,2);
        -C_control, zeros(2,2)];
    B_lat = [B_lat; zeros(2)];
    
    load(['list_old_individuals_lat_',num2str( test_idx - 6 ),'.mat']);
    
    [val,idx] = min( list_old_individuals(end,:) );
    
    K_lat = doEigenstructureAssignment( A_lat, B_lat, list_old_individuals(1:6,idx ) );
    
    [time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();
    opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
    yOUTlog  = get_robustification_cost_lat( time_domain_ref_lat, frequ_domain_ref_lat, A_lat, B_lat, K_lat );
    
    [stabmarg, CL] = getRobStabMargin_lat( A_lat, B_lat, K_lat, [1,0,0,0,0,0;0,1,0,0,0,0 ], opts, frequ_domain_ref_lat);
    step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
    figure;
    step( CL );hold on
    step( CL.NominalValue );
    
    K_lat_aileron_mat(test_idx,:) = K_lat(1,:);
    K_lat_rudder_mat(test_idx,:) = K_lat(2,:);
    stabmarg_lat_for_trimpoint_mat(test_idx,1:3) = [x0_save(1,test_idx), stabmarg.LowerBound, stabmarg.UpperBound];
end

cd(results_path)
save('K_long_mat.mat', 'K_long_mat');
save('K_lat_aileron_mat.mat', 'K_lat_aileron_mat');
save('K_lat_rudder_mat.mat', 'K_lat_rudder_mat');
%save('K_SP_mat.mat', 'K_SP_mat');

save('stabmarg_lat_for_trimpoint_mat.mat', 'stabmarg_lat_for_trimpoint_mat');
save('stabmarg_long_for_trimpoint_mat.mat', 'stabmarg_long_for_trimpoint_mat');
%save('stabmarg_SP_for_trimpoint_mat.mat', 'stabmarg_SP_for_trimpoint_mat');

 
          