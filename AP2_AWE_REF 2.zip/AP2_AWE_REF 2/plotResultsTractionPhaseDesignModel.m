function plotResultsTractionPhaseDesignModel( yout_mat, save_flag, mother_file_name, mean_elevation )

col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];

plot_indx_from = 120/0.01;
plot_indx_to = 160/0.01;

for j = 1 : length( yout_mat )
    close all;
    %% alpha
    h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).alpha_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).alpha_save.Data(plot_indx_from:plot_indx_to,3)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).alpha_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).alpha_save.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
   % axis([ceil(yout_mat(j).alpha_save.Time(plot_indx_from)) ceil(yout_mat(j).alpha_save.Time(plot_indx_to)) 5 11] );
   % yticks([5,6,7,8,9,10,11]); 
    xlabel('$Time$ $(s)$');
    ylabel('$\alpha_a$ $(deg)$');
    
    %% phi
    h2 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
     plot( yout_mat(j).phi_tau.Time(plot_indx_from:plot_indx_to), yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,2)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).phi_tau.Time(plot_indx_from:plot_indx_to), yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    axis([ceil(yout_mat(j).phi_tau.Time(plot_indx_from)) ceil(yout_mat(j).phi_tau.Time(plot_indx_to))  -30 30 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$\Phi_{\tau}$ $(deg)$');
    
    %% sideslip
    h3 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).beta_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).beta_save.Data(plot_indx_from:plot_indx_to,2)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).beta_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).beta_save.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
   % axis([ceil(yout_mat(j).beta_save.Time(plot_indx_from)) ceil(yout_mat(j).beta_save.Time(plot_indx_to))  -2 2 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$\beta_{a}$ $(deg)$');
    
    %% va
    h4 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).va_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).va_save.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
%   axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  26 34 ] );
      axis([ceil(yout_mat(j).va_save.Time(plot_indx_from)) ceil(yout_mat(j).va_save.Time(plot_indx_to))  28 36 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$v_{a}$ $(m/s)$');
    
    %% pos_W
    h5 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,2), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,3), 'color', col3, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    
    plot( yout_mat(j).target_pos.Time(plot_indx_from:plot_indx_to), yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1), 'color', 'black', 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    plot( yout_mat(j).target_pos.Time(plot_indx_from:plot_indx_to), yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,2), 'color', 'black', 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    plot( yout_mat(j).target_pos.Time(plot_indx_from:plot_indx_to), yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,3), 'color', 'black', 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$p_W$ $(m)$');
    


    %% controls
    h6 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).controls.Time(plot_indx_from:plot_indx_to), yout_mat(j).controls.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).controls.Time(plot_indx_from:plot_indx_to), yout_mat(j).controls.Data(plot_indx_from:plot_indx_to,2)*180/pi, 'color', col2, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).controls.Time(plot_indx_from:plot_indx_to), yout_mat(j).controls.Data(plot_indx_from:plot_indx_to,3)*180/pi, 'color', col3, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    axis([ceil(yout_mat(j).beta_save.Time(plot_indx_from)) ceil(yout_mat(j).beta_save.Time(plot_indx_to))  -10 10 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$controls$ $(deg)$');
    
    %% wind field
    h7 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).controls.Time(plot_indx_from:plot_indx_to), yout_mat(j).v_w_W_save.Data(plot_indx_from:plot_indx_to,1), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$v_{x,W}$ $(m/s)$');
    
    %% Path tracking error
    l =   sqrt( sum(yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3)  ,2 ) ); 
    l_t = sqrt( sum(yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3) , 2 ) ); 
    h8 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    cte = acos( ( sum( yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,1:3).*yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,1:3),2 ) )./l_t./l ) .* l; 
    plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), cte, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,2)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,2), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    %plot( yout_mat(j).pos_W.Time(plot_indx_from:plot_indx_to), yout_mat(j).pos_W.Data(plot_indx_from:plot_indx_to,3)-yout_mat(j).target_pos.Data(plot_indx_from:plot_indx_to,3), 'color', col3, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
   % yticks([-12 -8 -4 0 4 8 12]); 
    %yticklabels({'-12', '-8','-4', '0', '4', '8','12'})    
    ylabel('$e_p$ $(m)$');
    xlabel('$Time$ $(s)$');

    %% tracking error alpha
    h9 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).alpha_save.Time(plot_indx_from:plot_indx_to), yout_mat(j).alpha_save.Data(plot_indx_from:plot_indx_to,3)*180/pi-yout_mat(j).alpha_save.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    xlabel('$Time$ $(s)$');
    ylabel('$e_\alpha$ $(deg)$');
    
    %% tracking error phi
    h10 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
     plot( yout_mat(j).phi_tau.Time(plot_indx_from:plot_indx_to), yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,2)*180/pi-yout_mat(j).phi_tau.Data(plot_indx_from:plot_indx_to,1)*180/pi, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    axis([ceil(yout_mat(j).phi_tau.Time(plot_indx_from)) ceil(yout_mat(j).phi_tau.Time(plot_indx_to))  -10 10 ] );
    xlabel('$Time$ $(s)$');
    ylabel('$e_{\Phi,\tau}$ $(deg)$');
    
   %% path projection 
    M_WP = [cos(mean_elevation),0, -sin(mean_elevation);0, 1, 0;  sin(mean_elevation),0, cos(mean_elevation)];  
    p_P = M_WP'*[ yout_mat(j).pos_W.Data(:,1),  yout_mat(j).pos_W.Data(:,2),  yout_mat(j).pos_W.Data(:,3)]';
    pt_P = M_WP'*[ yout_mat(j).target_pos.Data(:,1),  yout_mat(j).target_pos.Data(:,2),  yout_mat(j).target_pos.Data(:,3)]';
    h11 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( p_P(2,:), p_P(3,:), 'color', col1, 'Linewidth', 1, 'Linestyle', '-' ); hold on
    plot( pt_P(2,:), pt_P(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on
    xlabel('$y_P$ $(m)$');
    ylabel('$z_P$ $(m)$');
    axis equal
    
    %% path in xz plane to show reeling speed change
    h12 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
    plot( yout_mat(j).pos_W.Data(:,1), yout_mat(j).pos_W.Data(:,3), 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    plot( yout_mat(j).pos_W.Data(:,1), yout_mat(j).pos_W.Data(:,3), 'color', col2, 'Linewidth', 1.2, 'Linestyle', '--' ); hold on
    xlabel('$x_W$ $(m)$');
    ylabel('$z_W$ $(m)$');
    axis equal
    
    
    
    if save_flag
        cd('Trim_results/');
        Plot2LaTeX(h1,[mother_file_name,'_AoA_',num2str(j)]);
        Plot2LaTeX(h2,[mother_file_name,'_phi_',num2str(j)]);
        Plot2LaTeX(h3,[mother_file_name,'_beta_',num2str(j)]);
        Plot2LaTeX(h4,[mother_file_name,'_va_',num2str(j)]);
        Plot2LaTeX(h5,[mother_file_name,'_posW_',num2str(j)]);
        Plot2LaTeX(h6,[mother_file_name,'_controls_',num2str(j)]);
        Plot2LaTeX(h7,[mother_file_name,'_vW_',num2str(j)]);
        Plot2LaTeX(h8,[mother_file_name,'_pE_',num2str(j)]);
        Plot2LaTeX(h9,[mother_file_name,'_alpha_e_',num2str(j)]);
        Plot2LaTeX(h10,[mother_file_name,'_phi_e_',num2str(j)]);
        Plot2LaTeX(h11,[mother_file_name,'_path_proj_',num2str(j)]);
        Plot2LaTeX(h12,[mother_file_name,'_path_xz_',num2str(j)]);
        cd ..
    end
    
    
    
end

end