
v_w_vec =  [5 , 12.5 , 20];
v_r_vec = 0 : 1 : 12;
phi = 35*pi/180;
l_tether = 400;

for n = 1 : length( v_w_vec )
    vw = v_w_vec(n);
    for l = 1 : length( v_r_vec )
        v_r = v_r_vec(l);
        [Ft_tmp, va_est_tmp] = get_quasi_steady_ft_va(alpha_vec, P_AP2, T, v_r, vw, phi, l_tether);
        % Ft(n,l) = Ft_tmp;
        % va_est_tmp(l) = va_est_tmp;
        if n == 1
            plot( alpha_vec*180/pi, Ft_tmp, '-b'); hold on;
        elseif n == 2
            plot( alpha_vec*180/pi, Ft_tmp, '-r'); hold on;
        else
            plot( alpha_vec*180/pi, Ft_tmp, '-g'); hold on;
        end 
    end
end