Kp_p_traction_pert = randi([min_gains_rates, max_gains_rates],numPop,1);
Kp_q_traction_pert =  randi([min_gains_rates, max_gains_rates],numPop,1);
Kp_r_traction_pert =  randi([min_gains_rates, max_gains_rates],numPop,1);

Ki_p_traction_pert = randi([min_gains_rates, max_gains_rates],numPop,1);
Ki_q_traction_pert = randi([min_gains_rates, max_gains_rates],numPop,1);
Ki_r_traction_pert = randi([min_gains_rates, max_gains_rates],numPop,1);

w0_p_traction_pert = randi([min_w0_rates, max_w0_rates],numPop,1);%max( min( w0_p_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);
w0_q_traction_pert = randi([min_w0_rates, max_w0_rates],numPop,1);%max( min( w0_q_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);
w0_r_traction_pert = randi([min_w0_rates, max_w0_rates],numPop,1);%max( min( w0_r_traction/maxBandwidth*10 + randi([-delta_pert_rates,delta_pert_rates],numPop,1) ,max_w0_rates), min_w0_rates);

w0_mu_traction_pert = randi([min_w0_attitudes, max_w0_attitudes],numPop,1);%max( min( w0_mu_traction/w0_p_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);
w0_alpha_traction_pert = randi([min_w0_attitudes, max_w0_attitudes],numPop,1);%max( min( w0_alpha_traction/w0_q_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);
w0_beta_traction_pert =randi([min_w0_attitudes, max_w0_attitudes],numPop,1); %max( min( w0_beta_traction/w0_r_traction*10 + randi([-delta_pert_attitude,delta_pert_attitude],numPop,1) ,max_w0_attitudes), min_w0_attitudes);

Kp_chi_tau_traction_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 
Ki_chi_tau_traction_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 
Kp_chi_tau_trans_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 

Kp_gamma_tau_traction_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 
Ki_gamma_tau_traction_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 
Kp_gamma_tau_trans_pert = randi([min_Kp_path, max_Kp_path],numPop,1); 

Kp_mu_traction_pert = randi([min_Kp_att, max_Kp_att],numPop,1); 
Kp_alpha_traction_pert = randi([min_Kp_att, max_Kp_att],numPop,1); 
Kp_beta_traction_pert =randi([min_Kp_att, max_Kp_att],numPop,1); 

Ki_mu_traction_pert = randi([min_Kp_att, max_Kp_att],numPop,1); 
Ki_alpha_traction_pert = randi([min_Kp_att, max_Kp_att],numPop,1); 
Ki_beta_traction_pert = randi([min_Kp_att, max_Kp_att],numPop,1); 

a_booth_pert = max( min( a_booth*10 + randi([-delta_a_booth,delta_a_booth],numPop,1), max_a_booth), min_a_booth);
b_booth_pert = max( min( b_booth + randi([-delta_b_booth,delta_b_booth],numPop,1), max_b_booth), min_b_booth);
phi_booth_pert = randi([min_phi, max_phi],numPop,1); 

F_t_pert = max( min(   (max_F_t+min_F_t)/2 + 10*randi([-delta_F_t,delta_F_t],numPop,1) ,max_F_t), min_F_t);
