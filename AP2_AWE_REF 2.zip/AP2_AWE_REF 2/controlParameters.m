%% Tuning parameters.
fixedTetherLength = 1;
if fixedTetherLength
    % Fixed tether length
    %theta_t_CMD = -3*pi/180;%3 * pi / 180; % pitch angle between body fixed frame and the tether frame.
    if figIndx == 1 % circle
        theta_t_CMD = -5 * pi/180;
        Phi_T_EULER_MAX = 20*pi/180;
        Theta_T_EULER_MAX = 30*pi/180;
        mu_k_max = 20*pi/180;
    elseif figIndx == 2
        theta_t_CMD =  -5 * pi/180; % Without tether 2 * pi/180;
        Phi_T_EULER_MAX = 30*pi/180;
        Theta_T_EULER_MAX = 30*pi/180;
        mu_k_max = 30*pi/180;
    else
        theta_t_CMD =  -5 * pi/180; % Without tether 2 * pi/180;
        Phi_T_EULER_MAX = 40*pi/180;
        Theta_T_EULER_MAX = 30*pi/180;
        mu_k_max = 45*pi/180;
    end
    Kp_course = 20;
    Ki_course = 1;
    v_RO =0; % with v_w = 8 m/s 
    a_chi_ref = 20; 
    


    Kp_rollangle = 10; % Kp_rollangle = 50; % Kite mode
    Kp_pitch = 10;
    Kp_yaw = 10; 
    
   
    Kp_att = 40; 
    Ki_att = 40; 
    Ki_rollangle = 40;
    
    %% Holzapfel suggests to choose these terms at least as big as the 1/T of the rate dynamics 
    % Furthermore, the gains for all axis can be chosen the same, although the dynamics are not equally fast. 
    
    %% Reference dynamics 
    % Time constant choice
    % Limit for the inner loop time constants 
    safety_factor =  2.5;1.5; % works but, performance not very good: with actuator
    T_min = safety_factor / ( 2 * zeta_actuator * omega0_actuator );
    omega_rate_max = 1/T_min;
    
    % Reference filter rate dynamics 
    omega_rate_ref = omega_rate_max; 
    omega_yawrate_ref = omega_rate_max * 1; 
    
     % Reference filter for the attitude dynamics 
    omega_att_ref = omega_rate_ref/4; 
    omega_yawatt_ref  = omega_yawrate_ref/4; 
    
    %% with actuator
    KRollRate = 30.*omega_rate_ref; 10; 
    KPitchRate = 30.* omega_rate_ref;20;
    KYawRate = 30.*omega_rate_ref;10; 
    Ki_rate = 0.1;

    %% without actuator
%     KRollRate = 1.*omega_rate_ref; 10; 
%     KPitchRate = 1.* omega_rate_ref;20;
%     KYawRate = 1.*omega_rate_ref;10
%     Ki_rate = 0.5;

    
    %Kp_rate = 50; 
    %Ki_rate = 5;200;
    %Kp_rollrate = Kp_rate;80;%200; 
    Ki_rollrate = Ki_rate;200;%100; 
    Kp_yawrate = 20; 
    
    %% Attitude error controller gains
    Kitemode.Kp_rollangle = 0.5*omega_att_ref;5;20;
    Kitemode.Kp_pitch = 0.5*omega_att_ref;20;
    Kitemode.Kp_yaw = 0.5*omega_att_ref;
    Kitemode.Ki_att = 0.1; 
    
        % Course reference dynamics are depending on the dynamic pressure
    Va_max = 60;
    dyn_p_max = 0.5 * P.rho_air * 60^2; 
    dyn_p_min = 0.5 * P.rho_air * 20^2; 
    omega_course_ref = omega_att_ref/2; % actuator /2; 
    
    Ki_course = omega_course_ref; 
    Kp_course = omega_course_ref; 
    
    % Rate limitations 
    omega_OB_max = 400*pi/180; 
else
   
    theta_t_CMD = 0 * pi / 180; % pitch angle between body fixed frame and the tether frame.
    Kp_course = 30;
    Ki_course = 50;
    v_RO = v_w_E(1)*0.3; % with v_w = 8 m/s 
    a_chi_ref = 10; 
    AoA_CMD = 8*pi/180;
end

