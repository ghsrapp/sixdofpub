function [pos_target_W, sol] = getTargetOnTransCircle( pos_W, transCircle,radius )

pos_C = transCircle.M_CW * pos_W;
pos_C_proj = pos_C; 
pos_C_proj(3) = 0;
pos_C_proj_2 = pos_C_proj/norm(pos_C_proj)*radius;

sol = atan2(pos_C_proj_2(2),pos_C_proj_2(1));

pos_target_W = transCircle.M_CW'*pos_C_proj_2;