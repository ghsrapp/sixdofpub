function [A_lat_s, B_lat_s, x0_retract, u0_retract ] = setUpLTIs_Lat( path2models, sim_with_indx_vec )


load([path2models,'/G_save.mat']);
load([path2models,'/x0_save.mat']);
load([path2models,'/u0_save.mat']);
x0_retract = x0_save; 
u0_retract = u0_save; 

for k = 1 : length( sim_with_indx_vec )
    ii = sim_with_indx_vec(k);
    
    %%
    A = G_save{ii}.A(1:9, 1:9);
    B = G_save{ii}.B(1:9, 1:4);
    A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9);
        A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9);
        A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9);
        A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9);
        A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];
    
    B_lat = [B(2,1),B(2,3);...
        B(4,1),B(4,3);...
        B(6,1),B(6,3);...
        B(7,1),B(7,3);...
        B(9,1),B(9,3)];
    A_lat(3,:) = [];
    A_lat(:,3) = [];
    B_lat(3,:) = [];
    
    %C = zeros(2, 5);
    C = zeros(2, size(B_lat,1));
    C(1,1) = 1;
    C(2,2) = 1;
    
    
    
    A_lat_s(:,:,k) = [A_lat, zeros(size(A_lat,1),2);
        -C, zeros(2)];
    B_lat_s(:,:,k) = [B_lat; zeros(2)];
end