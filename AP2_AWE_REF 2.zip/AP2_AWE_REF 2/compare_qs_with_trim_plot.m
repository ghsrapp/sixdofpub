function compare_qs_with_trim_plot( Ft_vec, alpha_reshaped, Va_reshaped, va_est_tmp,Ft_tmp )

z = Ft_vec'; 
Y = alpha_reshaped; 
X = Va_reshaped; 
Z = repmat(z,1,size(X,1) )';

figure(9); 
surf( X,Y,Z); hold on 
surf( va_est_tmp, alpha_reshaped, Ft_tmp);

