
Ap = [-8.4502    0.8967;
  -24.4208   -3.5059]; 
Bp = [-0.5608;
  -42.0146]; 

[HmInvHum, Ke_L1, C1, Ts, F_long, Kbl, Am, Bp_um] = test_simple_piecewise_L1_sp(Ap, Bp, K); 
