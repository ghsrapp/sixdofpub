function [stabmarg, CL] = getRobStabMargin_long( A_long, B_long, K, C, opts, frequ_domain_ref_long )


upper_bound_A = A_long; 
lower_bound_A = A_long; 

upper_bound_B = B_long; 
lower_bound_B = B_long; 

upper_bound_A(1:4,1:4) = A_long(1:4,1:4)*(1+frequ_domain_ref_long.unc_factor);
lower_bound_A(1:4,1:4) = A_long(1:4,1:4)*(1-frequ_domain_ref_long.unc_factor);

upper_bound_B(1:4,1) = B_long(1:4,1)*(1+frequ_domain_ref_long.unc_factor);
lower_bound_B(1:4,1) = B_long(1:4,1)*(1-frequ_domain_ref_long.unc_factor);

mean_A = A_long;
mean_B = B_long;

for r = 1 : size( lower_bound_A, 1 )
    for c = 1 : size( lower_bound_A, 2)
        if abs( lower_bound_A(r,c) - upper_bound_A(r,c) ) < 1e-6
            A_unc(r,c) = mean_A(r,c);
        else
            if lower_bound_A(r,c) < upper_bound_A(r,c) % if sign is negative
                A_unc(r,c) = ureal(['A_',num2str(r),num2str(c)], mean_A(r,c) ,'Range',[lower_bound_A(r,c), upper_bound_A(r,c)]);
            else
                A_unc(r,c) = ureal(['A_',num2str(r),num2str(c)], mean_A(r,c) ,'Range',[upper_bound_A(r,c), lower_bound_A(r,c)]);
            end
            
        end
    end
end

for r = 1 : size( lower_bound_B, 1 )
    for c = 1 : size( lower_bound_B, 2)
        if abs( lower_bound_B(r,c) - upper_bound_B(r,c) ) < 1e-6
            B_unc(r,c) = mean_B(r,c);
        else
            if lower_bound_B(r,c) < upper_bound_B(r,c) % if sign is negative
                B_unc(r,c) = ureal(['B_',num2str(r),num2str(c)], mean_B(r,c) ,'Range',[lower_bound_B(r,c), upper_bound_B(r,c)]);
            else
                B_unc(r,c) = ureal(['B_',num2str(r),num2str(c)], mean_B(r,c) ,'Range',[ upper_bound_B(r,c), lower_bound_B(r,c)]);
            end
        end
    end
end
 


A_cl = A_unc - B_unc * K; 
B_cl = [zeros(4,1);1]; 
C_cl = C; 
D_cl = 0; 
CL = ss( A_cl, B_cl, C_cl, D_cl ); 
[stabmarg,wcu,info] = robstab(CL,opts);

%% Test if wcu leads to an unstable system 
%CL_unst = usubs(CL, wcu ); 
1;




