function [F_a_B, M_a_B] = getAeroForcesAndMoments( omega_OB_rad, u_rb, airdata,  P_AP2)

% Rotational Rates
p = omega_OB_rad(1); 
q = omega_OB_rad(2); 
r = omega_OB_rad(3); 

Va = airdata(1); 
alpha = airdata(2);
beta = airdata(3); 

delta_a = u_rb(1); 
delta_e = u_rb(2); 
delta_r = u_rb(3); 

%% Force coefficients 
% Cx calculation
Cx_0 = P_AP2.Cx_0_0 + P_AP2.Cx_0_alpha * alpha + P_AP2.Cx_0_alpha2 * alpha^2; 
Cx_q = P_AP2.Cx_q_0 + P_AP2.Cx_q_alpha * alpha + P_AP2.Cx_q_alpha2 * alpha^2; 
Cx_deltaE  = P_AP2.Cx_deltaE_0  + P_AP2.Cx_deltaE_alpha * alpha + P_AP2.Cx_deltaE_alpha2 * alpha^2; 
Cx = Cx_0 + Cx_q*P_AP2.c*q/(2*Va) + Cx_deltaE*delta_e; 

% Cy calculation
Cy_beta = P_AP2.Cy_beta_0 + P_AP2.Cy_beta_alpha * alpha + P_AP2.Cy_beta_alpha2 * alpha^2; 
Cy_p = P_AP2.Cy_p_0  + P_AP2.Cy_p_alpha * alpha + P_AP2.Cy_p_alpha2 * alpha^2;  
Cy_r = P_AP2.Cy_r_0  + P_AP2.Cy_r_alpha * alpha + P_AP2.Cy_r_alpha2 * alpha^2;  
Cy_deltaA =P_AP2.Cy_deltaA_0 + P_AP2.Cy_deltaA_alpha * alpha + P_AP2.Cy_deltaA_alpha2 * alpha^2;  
Cy_deltaR =P_AP2.Cy_deltaR_0 + P_AP2.Cy_deltaR_alpha * alpha + P_AP2.Cy_deltaR_alpha2 * alpha^2;  
Cy = Cy_beta*beta + Cy_p*P_AP2.b*p/(2*Va) + Cy_r*P_AP2.b*r/(2*Va) + Cy_deltaA*delta_a + Cy_deltaR*delta_r;


% Cz calculation
Cz_0 = P_AP2.Cz_0_0 + P_AP2.Cz_0_alpha * alpha + P_AP2.Cz_0_alpha2 * alpha^2; 
Cz_q = P_AP2.Cz_q_0 + P_AP2.Cz_q_alpha * alpha + P_AP2.Cz_q_alpha2 * alpha^2; 
Cz_deltaE  = P_AP2.Cz_deltaE_0 + P_AP2.Cz_deltaE_alpha * alpha + P_AP2.Cz_deltaE_alpha2 * alpha^2; 
Cz = Cz_0 + Cz_q*P_AP2.c*q/(2*Va) + Cz_deltaE*delta_e; 

F_a_B = 0.5*Va^2*P_AP2.S_ref*1.225* [Cx;Cy; Cz];

%% Moment coefficients 

% Cm
Cm_0 = P_AP2.Cm_0_0  + P_AP2.Cm_0_alpha * alpha + P_AP2.Cm_0_alpha2 * alpha^2; 
Cm_q = P_AP2.Cm_q_0  + P_AP2.Cm_q_alpha * alpha + P_AP2.Cm_q_alpha2 * alpha^2; 
Cm_deltaE = P_AP2.Cm_deltaE_0  + P_AP2.Cm_deltaE_alpha * alpha + P_AP2.Cm_deltaE_alpha2 * alpha^2; 
Cm = Cm_0 + Cm_q*P_AP2.c*q/(2*Va) + Cm_deltaE*delta_e; 

% Cl calculation
Cl_beta = P_AP2.Cl_beta_0 + P_AP2.Cl_beta_alpha * alpha + P_AP2.Cl_beta_alpha2 * alpha^2; 
Cl_p = P_AP2.Cl_p_0  +  P_AP2.Cl_p_alpha * alpha + P_AP2.Cl_p_alpha2 * alpha^2;  
Cl_r = P_AP2.Cl_r_0  + P_AP2.Cl_r_alpha * alpha + P_AP2.Cl_r_alpha2 * alpha^2;  
Cl_deltaA =P_AP2.Cl_deltaA_0 + P_AP2.Cl_deltaA_alpha * alpha + P_AP2.Cl_deltaA_alpha2 * alpha^2;  
Cl_deltaR =P_AP2.Cl_deltaR_0 + P_AP2.Cl_deltaR_alpha * alpha + P_AP2.Cl_deltaR_alpha2 * alpha^2;  
Cl = Cl_beta*beta + Cl_p*P_AP2.b*p/(2*Va) + Cl_r*P_AP2.b*r/(2*Va) + Cl_deltaA*delta_a + Cl_deltaR*delta_r;

% Cn calculation
Cn_beta = P_AP2.Cn_beta_0 + P_AP2.Cn_beta_alpha * alpha + P_AP2.Cn_beta_alpha2 * alpha^2; 
Cn_p = P_AP2.Cn_p_0  + P_AP2.Cn_p_alpha * alpha + P_AP2.Cn_p_alpha2 * alpha^2;  
Cn_r = P_AP2.Cn_r_0  + P_AP2.Cn_r_alpha * alpha + P_AP2.Cn_r_alpha2 * alpha^2;  
Cn_deltaA =P_AP2.Cn_deltaA_0 + P_AP2.Cn_deltaA_alpha * alpha + P_AP2.Cn_deltaA_alpha2 * alpha^2;  
Cn_deltaR =P_AP2.Cn_deltaR_0 + P_AP2.Cn_deltaR_alpha * alpha + P_AP2.Cn_deltaR_alpha2 * alpha^2;  
Cn = Cn_beta*beta + Cn_p*P_AP2.b*p/(2*Va) + Cn_r*P_AP2.b*r/(2*Va) + Cn_deltaA*delta_a + Cn_deltaR*delta_r;

M_a_B = 0.5*Va^2*P_AP2.S_ref*1.225* [P_AP2.b*Cl;...
                                     P_AP2.c*Cm;...
                                     P_AP2.b*Cn];

