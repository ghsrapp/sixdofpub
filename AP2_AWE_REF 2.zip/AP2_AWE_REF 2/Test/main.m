myCluster = parcluster('local');
parfor i = 1 : 10
 for k = 1 : 10 
     k
 end
end