%% ======= Actuators ====
% The bandwidth of the system is restricted by the actuator bandwidth.
% The actuators are modeled as second order spring-damper elements.
zeta_actutaor = 1;%1.2;
omega_actuator = 50;%35;
% laut Holzapfel: Ti muss groesser als 1/(2*zeta*omega)

% Aperiodisch! 2 Timeconstants:
% T2 = ( (2*zeta_actuator*omega_actuator) + sqrt( 4 * zeta_actutaor^2 * omega_actuator^2 - 4 * omega_actuator^2 ) ) / (2*omega_actuator^2);
% T2_ = ( (2*zeta_actuator*omega_actuator) - sqrt( 4 * zeta_actutaor^2 * omega_actuator^2 - 4 * omega_actuator^2 ) ) / (2*omega_actuator^2);
% T1 = 1/(T2*omega_actuator^2);
% T_act = min( [T1, T2, T2_] );

% % maximal Bandwidth = omega_actuator
% omega_rates = 1/3 * omega_actuator;
% omega_attitude = 1/2 * omega_rates;
% omega_course = 1/2.5* omega_attitude;
% omega_gamma = 1/2 * omega_attitude;
%


omega_rates = omega_actuator;
omega_attitude = 10;%1/3*omega_rates ;
omega_course = 2;%1/6 * omega_attitude;
omega_gamma = 2; %1/6 * omega_attitude;

%% Chosen reference frequencies and damping
FCS.w0_p = 35;%factor_w0_p;
FCS.w0_mu_traction = 1/3*FCS.w0_p;
FCS.w0_mu_retraction = 1/5*FCS.w0_p;
FCS.w0_chi = factor_w0_chi*FCS.w0_mu_retraction;
factor_w0_chi = 1/FCS.w0_mu_retraction;
FCS.w0_chi_retract = factor_w0_chi*FCS.w0_mu_retraction;
%FCS.T_p = 0.05;%1/FCS.w0_p;

FCS.w0_q = 30;%factor_w0_q;
FCS.w0_alpha_traction = 1/5*FCS.w0_q ;
FCS.w0_alpha_retraction = factor_w0_alpha*FCS.w0_q ;

FCS.w0_gamma = factor_w0_gamma*FCS.w0_alpha_traction;
FCS.w0_gamma_retract =factor_w0_gamma*FCS.w0_alpha_retraction;

FCS.w0_r = 20;%factor_w0_r;
FCS.w0_beta = factor_w0_beta*FCS.w0_r;


FCS.zeta_chi = 1;
FCS.zeta_gamma =1;
FCS.zeta_chi_retract  = 1;
FCS.zeta_gamma_retract  = 1;
FCS.zeta_mu = 1;
FCS.zeta_alpha = 1;
FCS.zeta_beta = 1;
FCS.zeta0_p = 1;
FCS.zeta0_q = 1;
FCS.zeta0_r = 1;

%% =====================================================
% P and I feedback gains
%
%% Factors are used for the tuning script/for now we use the same factors for the retraction and traction phase and same factor for P and I gain
FCS.Kp_chi_predictive = 0.5; 
FCS.Ki_chi_predictive = 1e-3;

FCS.Kp_chi = factor_chi*FCS.w0_chi^2;
FCS.Ki_chi = factor_chi*2*FCS.w0_chi*FCS.zeta_chi;

FCS.Kp_chi_retract = factor_chi*FCS.w0_chi_retract^2;
FCS.Ki_chi_retract = factor_chi*0.1*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;

FCS.Kp_mu_traction = 0.1*FCS.w0_mu_traction ^2;
FCS.Ki_mu_traction = 0.1 * 2 * FCS.zeta_mu * FCS.w0_mu_traction ;

FCS.Kp_mu_retraction = factor_mu*FCS.w0_mu_retraction ^2;
FCS.Ki_mu_retraction = 0.4 * 2 * FCS.zeta_mu * FCS.w0_mu_retraction ;


factor_p = 2;
FCS.Kp_p = factor_p*FCS.w0_p^2;
FCS.Ki_p = factor_p*2*FCS.w0_p*FCS.zeta0_p;
%
FCS.Kp_gamma = factor_gamma*FCS.w0_gamma^2;
FCS.Ki_gamma = factor_gamma*2*FCS.w0_gamma*FCS.zeta_gamma;

FCS.Kp_gamma_retract = factor_gamma*FCS.w0_gamma_retract^2;

FCS.Ki_gamma_retract = factor_gamma*2*FCS.w0_gamma_retract*FCS.zeta_gamma_retract;


FCS.Kp_alpha_traction =  0.1*FCS.w0_alpha_traction^2;
FCS.Ki_alpha_traction =  0.1*2 * FCS.zeta_alpha * FCS.w0_alpha_traction;
FCS.Kd_alpha_traction = 1;

FCS.Kp_alpha_retraction =  factor_alpha*FCS.w0_alpha_retraction^2;
FCS.Ki_alpha_retraction =  factor_alpha*2 * FCS.zeta_alpha * FCS.w0_alpha_retraction;

factor_q = 1; 
FCS.Kp_q =  factor_q*FCS.w0_q^2;
factor_q = 0.6; 
FCS.Ki_q =  factor_q*2*FCS.w0_q*FCS.zeta0_q;
%
FCS.Kp_beta =  factor_beta*FCS.w0_beta^2;
FCS.Ki_beta =  factor_beta*2*FCS.zeta_beta * FCS.w0_beta;
FCS.Kd_beta = 1;

factor_r = 1.5;
FCS.Kp_r =  factor_r*FCS.w0_r^2;
factor_r = 1; 
FCS.Ki_r = factor_r*2*FCS.w0_r*FCS.zeta0_r;
%% =====================================================

% FCS.omegaGammaDot = 25;
% FCS.zetaGammaDot = 0.8;

%% ======= Rate Controller Gains =======
% %FCS.Kp_rate = diag( [10,30,25] );
% FCS.Kp_rate = diag( [10,20,25] );
%
% FCS.Ki_rate = 0.5*diag( [10,10,10] );
% FCS.ARefRate = -omega_rates* eye(3);%5*FCS.ARefAttitude;
% FCS.BRefRate = omega_rates* eye(3);%5*FCS.BRefAttitude;
%

%% Control Allocation
FCS.C_A = [P.C_ell_delta_a, 0,P.C_ell_delta_r;
    0,P.C_m_delta_e ,0;
    P.C_n_delta_a, 0,P.C_n_delta_r];
FCS.C_A_inv = FCS.C_A \ eye(3);


%% Model parameters
FCS.J = P.J;
FCS.Jinv = P.Jinv;

%% Winch controller
omega_winch = 10;


P_gain_winch = 0.5;
Va_max = 80;
Va_min = 20;
hysteris_e = 5;