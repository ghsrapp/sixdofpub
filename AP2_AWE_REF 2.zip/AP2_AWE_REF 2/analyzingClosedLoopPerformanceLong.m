function analyzingClosedLoopPerformanceLong( G, K )
% in case of LQR with servo: we have state feedback 
S = inv(1+K*G); 

bodemag( S ) 

end