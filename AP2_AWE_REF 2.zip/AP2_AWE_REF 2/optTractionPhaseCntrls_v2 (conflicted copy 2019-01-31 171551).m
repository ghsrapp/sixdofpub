clear all
close all
clc


% call init script
init_new;
TSIM = 80;
% init gains
%load('param_set_EMMA_04.mat');
load('paramStruct.mat');


%% ---------------------------- TRACTION ----------------------------
% Bandwidths
assignin('base','w0_mu_traction',paramStruct.w0_mu_traction);
assignin('base','w0_alpha_traction',paramStruct.w0_alpha_traction);
assignin('base','w0_beta_traction',paramStruct.w0_beta_traction);

assignin('base','w0_p_traction',paramStruct.w0_p_traction);
assignin('base','w0_q_traction',paramStruct.w0_q_traction);
assignin('base','w0_r_traction',paramStruct.w0_r_traction);

% Gains
assignin('base','Kp_chi_tau_traction',paramStruct.Kp_chi_tau_traction);
assignin('base','Ki_chi_tau_traction',paramStruct.Ki_chi_tau_traction);
assignin('base','Kp_chi_tau_trans',paramStruct.Kp_chi_tau_trans);
assignin('base','Kp_gamma_tau_trans',paramStruct.Kp_gamma_tau_trans);
assignin('base','Kp_gamma_tau_traction',paramStruct.Kp_gamma_tau_traction);
assignin('base','Ki_gamma_tau_traction',paramStruct.Ki_gamma_tau_traction);

assignin('base','Kp_mu_traction',paramStruct.Kp_mu_traction);
assignin('base','Kp_alpha_traction',paramStruct.Kp_alpha_traction);
assignin('base','Kp_beta_traction',paramStruct.Kp_beta_traction);
assignin('base','Ki_mu_traction',paramStruct.Ki_mu_traction);
assignin('base','Ki_alpha_traction',paramStruct.Ki_alpha_traction);
assignin('base','Ki_beta_traction',paramStruct.Ki_beta_traction);

assignin('base','Kp_p_traction',paramStruct.Kp_p_traction);
assignin('base','Kp_q_traction',paramStruct.Kp_q_traction);
assignin('base','Kp_r_traction',paramStruct.Kp_r_traction);
assignin('base','Ki_p_traction',paramStruct.Ki_p_traction);
assignin('base','Ki_q_traction',paramStruct.Ki_q_traction);
assignin('base','Ki_r_traction',paramStruct.Ki_r_traction);

assignin('base','a_booth',paramStruct.a_booth); %0.7;
assignin('base','b_booth',paramStruct.b_booth);% 90/100;
assignin('base','phi0_booth',paramStruct.phi0_booth);
assignin('base','F_T_traction_set',paramStruct.F_T_traction_set)
%
maxBandwidth = aileron.w0;
FitnessFunction = @(x)costFunctionAP2(x,maxBandwidth,TSIM,paramStruct);

numPop = 60;
min_w0_rates = 2;
max_w0_rates = 7;
min_w0_attitudes = 2;
max_w0_attitudes = 7;
min_Kp_path = 1;
max_Kp_path = 50;
min_Kp_att = 10;
max_Kp_att = 500;
delta_pert_rates = 2;
delta_pert_attitude = 2;
delta_pert_path = 10;
delta_pert_att_gains = 10;

delta_a_booth = 2;
min_a_booth = 5;
max_a_booth = 8;

delta_b_booth = 20;
min_b_booth = 170;
max_b_booth = 300;

delta_phi = 10;
min_phi = 25;
max_phi = 35;

delta_F_t = 50;
min_F_t = 1500;
max_F_t = 1800;

delta_gains_rates = 400;
max_gains_rates = 500;
min_gains_rates = 10;


lb = [min_w0_rates,min_w0_rates,min_w0_rates,min_w0_attitudes,min_w0_attitudes,min_w0_attitudes, min_Kp_path, min_Kp_path, ...
    min_Kp_path, min_Kp_path, min_Kp_path, min_Kp_path, min_Kp_att, min_Kp_att, min_Kp_att, min_Kp_att, min_Kp_att, min_Kp_att,...
    min_a_booth,min_b_booth,min_phi, min_F_t, min_gains_rates*ones(1,6) ];
ub = [max_w0_rates,max_w0_rates,max_w0_rates,max_w0_attitudes,max_w0_attitudes,max_w0_attitudes, max_Kp_path, max_Kp_path, ...
    max_Kp_path, max_Kp_path, max_Kp_path, max_Kp_path, max_Kp_att, max_Kp_att, max_Kp_att, max_Kp_att, max_Kp_att, max_Kp_att,...
    max_a_booth,max_b_booth,max_phi, max_F_t, max_gains_rates*ones(1,6)];

initPopPertubations;
%initPopRandom;


if 0 % initialize with given gains, that are perturbed
    population = round( [w0_p_traction_pert,w0_q_traction_pert,w0_r_traction_pert,w0_mu_traction_pert,w0_alpha_traction_pert,w0_beta_traction_pert,...
        Kp_chi_tau_traction_pert,Ki_chi_tau_traction_pert,Kp_chi_tau_trans_pert,Kp_gamma_tau_traction_pert,Ki_gamma_tau_traction_pert,...
        Kp_gamma_tau_trans_pert,Kp_mu_traction_pert,Kp_alpha_traction_pert,Kp_beta_traction_pert,Ki_mu_traction_pert,Ki_alpha_traction_pert,Ki_beta_traction_pert,...
        a_booth_pert,b_booth_pert,phi_booth_pert,F_t_pert, Kp_p_traction_pert, Kp_q_traction_pert, Kp_r_traction_pert,...
        Ki_p_traction_pert, Ki_q_traction_pert, Ki_r_traction_pert]);
else % continue optimizing using a current population.
    %load('pop_19-Dec-2018.mat');
    load('pop_current.mat');

    population = pop_current;
end
numPop = size( population, 1);
numberOfVariables = size(population,2);

opts = optimoptions('ga', ...
    'UseParallel', false,...
    'PopulationSize', numPop, ...
    'MaxGenerations', 100, ...
    'EliteCount', 1, ...
    'FunctionTolerance', 1e-18, ...
    'PlotFcn', @myPlotFunc, ...
    'InitialPopulation',population);

%%
IntCon = 1 : numberOfVariables;
%myPool = parpool('local'); % start parallel processing.
%pctRunOnAll(['addpath ',pwd]);
%addAttachedFiles(myPool,{'AWE_TB_morphing.slx',pwd});

%parfevalOnAll(@load_system, 0, 'AWE_TB_morphing');
% spmd
%     currDir = pwd;
%     addpath(currDir);
%     tmpDir = tempname;
%     mkdir(tmpDir);
%     cd(tmpDir);
%     load_system('AWE_TB_morphing');
% end

[x,fval,exitflag,output,population,scores] = ga(FitnessFunction, numberOfVariables, [],[],[],[], lb,ub, [],IntCon,opts);
if exist(['pop_',date,'.mat']) == 2 
   save(['pop_',date,'_2_.mat'], 'population');
else 
    save(['pop_',date,'.mat'], 'population');
end

if exist(['cntrl_',date,'.mat']) == 2
    save(['cntrl_',date,'_2_.mat'], 'x');
else    
    save(['cntrl_',date,'.mat'], 'x');
end