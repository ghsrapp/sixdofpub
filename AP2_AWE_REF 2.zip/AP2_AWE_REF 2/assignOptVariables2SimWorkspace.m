
%% ---------------------------- TRACTION ----------------------------

%% ====== Controller Gains ======
% Bandwidths
assignin('base','w0_p_traction',x(1)*maxBandwidth);
assignin('base','w0_q_traction',x(2)*maxBandwidth);
assignin('base','w0_r_traction',x(3)*maxBandwidth);

assignin('base','w0_mu_traction',x(4)*x(1)*maxBandwidth);
assignin('base','w0_alpha_traction',x(5)*x(2)*maxBandwidth);
assignin('base','w0_beta_traction',x(6)*x(3)*maxBandwidth);
 
% Gains
assignin('base','Kp_chi_tau_traction',  x(7)/10 );
assignin('base','Ki_chi_tau_traction',  x(8)/100 );
assignin('base','Kp_chi_tau_trans',     x(9)/10 );
assignin('base','Kp_gamma_tau_trans',   x(10)/10 );
assignin('base','Kp_gamma_tau_traction', x(11)/10 );
assignin('base','Ki_gamma_tau_traction',  x(12)/100);

assignin('base','Kp_mu_traction', x(13));
assignin('base','Kp_alpha_traction',x(14));
assignin('base','Kp_beta_traction',x(15));
assignin('base','Ki_mu_traction',x(16));
assignin('base','Ki_alpha_traction',x(17));
assignin('base','Ki_beta_traction',x(18));

assignin('base','a_booth',x(19)*0.1); %0.7;
assignin('base','b_booth',x(20));% 90/100;
assignin('base','phi0_booth',x(21)*pi/180);
assignin('base','F_T_traction_set',x(22));

assignin('base','Kp_p_traction',x(23)/10);
assignin('base','Kp_q_traction',x(24)/10);
assignin('base','Kp_r_traction',x(25)/10);
assignin('base','Ki_p_traction',x(26)/10);
assignin('base','Ki_q_traction',x(27)/10);
assignin('base','Ki_r_traction',x(28)/10);

%% ---------------------------- RE-TRACTION ----------------------------
assignin('base','w0_mu_retraction',evalin('base','  w0_mu_traction'));
assignin('base','w0_alpha_retraction',evalin('base','  w0_mu_retraction'));
assignin('base','w0_beta_retraction',evalin('base','  w0_mu_retraction'));

assignin('base','w0_p_retraction',evalin('base','  w0_p_traction'));
assignin('base','w0_q_retraction',evalin('base','  w0_q_traction'));
assignin('base','w0_r_retraction',evalin('base','  w0_r_traction'));


assignin('base','w0_chi_retraction',0.5*paramStruct.w0_chi_retraction);
assignin('base','w0_gamma_retraction',0.5*paramStruct.w0_gamma_retraction);

assignin('base','Kp_chi_retraction',paramStruct.Kp_chi_retraction);
assignin('base','Ki_chi_retraction',paramStruct.Ki_chi_retraction);

assignin('base','Kp_gamma_retraction',paramStruct.Kp_gamma_retraction);
assignin('base','Ki_gamma_retraction',paramStruct.Ki_gamma_retraction);

assignin('base','Kp_mu_retraction',evalin('base','  Kp_mu_traction'));
assignin('base','Kp_alpha_retraction',evalin('base','  Kp_alpha_traction'));
assignin('base','Kp_beta_retraction',evalin('base','Kp_beta_traction'));
assignin('base','Ki_mu_retraction',evalin('base','  Ki_mu_traction'));
assignin('base','Ki_alpha_retraction',evalin('base','  Ki_alpha_traction'));
assignin('base','Ki_beta_retraction',evalin('base','  Ki_beta_traction'));

assignin('base','Kp_p_retraction',evalin('base','  Kp_p_traction'));
assignin('base','Kp_q_retraction',evalin('base','  Kp_q_traction'));
assignin('base','Kp_r_retraction',evalin('base','  Kp_r_traction'));
assignin('base','Ki_p_retraction',evalin('base','  Ki_p_traction'));
assignin('base','Ki_q_retraction',evalin('base','  Ki_q_traction'));
assignin('base','Ki_r_retraction',evalin('base','  Ki_r_traction'));

% retraction phase parameters
assignin('base','kp_winch', 0.0384);
assignin('base','ki_winch',x(30));

assignin('base','Ki_q_retraction',evalin('base','  Ki_q_traction'));
assignin('base','Ki_r_retraction',evalin('base','  Ki_r_traction'));

assignin('base','gamma_retract_opt',-5);
assignin('base','v_retraction_opt',-5);

% general cycle parameters 
assignin('base','l_tether_max',650);
assignin('base','l_tether_min',350);

% winch parameters 
assignin('base','kp_winch_retraction',  0.0640);
assignin('base','ki_winch_retraction', 0.0623);
assignin('base','F_set_retraction',200);
assignin('base','w0_ftset_filters',0.25);

assignin('base','alpha_star_flag',0);
assignin('base','alpha_star',FCS.AoA_Traction*pi/180);




