addpath('AWESTRIM');
load(['Trim_results/case_1_phi35_mix_ft_and_denser_alpha/x0_save']); 
load(['Trim_results/case_1_phi35_mix_ft_and_denser_alpha/u0_save']); 

x_test_comp_qs = x0_save(:, end-6); % alpha=4, ft=1800,
u_test_comp_qs = u0_save(:, end-6);

delta_a = u_test_comp_qs(1); 
delta_e = u_test_comp_qs(2); 
delta_r = u_test_comp_qs(3); 
p = x_test_comp_qs(7); 
q = x_test_comp_qs(8); 
r = x_test_comp_qs(9); 
Va = x_test_comp_qs(1); 

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams();

alpha_vec = [0 : 0.1 : 10]*pi/180;
beta =  0;

for n = 1 : length( alpha_vec )
    alpha = alpha_vec(n);
    
    Cx_0 = P_AP2.Cx_0_0 + P_AP2.Cx_0_alpha * alpha + P_AP2.Cx_0_alpha2 * alpha.^2;
    Cx_q = P_AP2.Cx_q_0 + P_AP2.Cx_q_alpha * alpha + P_AP2.Cx_q_alpha2 * alpha.^2;
    Cx_deltaE  = P_AP2.Cx_deltaE_0  + P_AP2.Cx_deltaE_alpha * alpha + P_AP2.Cx_deltaE_alpha2 * alpha.^2;
    Cx = Cx_0; %+ Cx_q*P_AP2.c*q/(2*Va) + Cx_deltaE*delta_e;
    
    % Cy calculation
    Cy_beta = P_AP2.Cy_beta_0 + P_AP2.Cy_beta_alpha * alpha + P_AP2.Cy_beta_alpha2 * alpha.^2;
    Cy_p = P_AP2.Cy_p_0  + P_AP2.Cy_p_alpha * alpha + P_AP2.Cy_p_alpha2 * alpha.^2;
    Cy_r = P_AP2.Cy_r_0  + P_AP2.Cy_r_alpha * alpha + P_AP2.Cy_r_alpha2 * alpha.^2;
    Cy_deltaA =P_AP2.Cy_deltaA_0 + P_AP2.Cy_deltaA_alpha * alpha + P_AP2.Cy_deltaA_alpha2 * alpha.^2;
    Cy_deltaR =P_AP2.Cy_deltaR_0 + P_AP2.Cy_deltaR_alpha * alpha + P_AP2.Cy_deltaR_alpha2 * alpha.^2;
    Cy = Cy_beta*beta;%+ Cy_p*P_AP2.b*p/(2*Va) + Cy_r*P_AP2.b*r/(2*Va) + Cy_deltaA*delta_a + Cy_deltaR*delta_r;
    %Cy = 0; 
    % Cz calculation
    Cz_0 = P_AP2.Cz_0_0 + P_AP2.Cz_0_alpha * alpha + P_AP2.Cz_0_alpha2 * alpha.^2;
    Cz_q = P_AP2.Cz_q_0 + P_AP2.Cz_q_alpha * alpha + P_AP2.Cz_q_alpha2 * alpha.^2;
    Cz_deltaE  = P_AP2.Cz_deltaE_0 + P_AP2.Cz_deltaE_alpha * alpha + P_AP2.Cz_deltaE_alpha2 * alpha.^2;
    Cz = Cz_0;%+Cz_q*P_AP2.c*q/(2*Va) + Cz_deltaE*delta_e;
    
    %%
    M_AB = [cos(alpha)*cos(beta), sin(beta), sin(alpha)*cos(beta);
        -cos(alpha)*sin(beta), cos(beta), -sin(alpha)*sin(beta);
        -sin(alpha), 0, cos(alpha)];
    F_B = [Cx;Cy;Cz];
    F_A = M_AB*F_B;
    CL = -F_A(3); 
    r = 400; 
    Cdt = 1/4*( T.CD_tether*T.d_tether/P_AP2.S_wing*r); 
    Cdk(n) = -F_A(1); 
    CD = Cdt + Cdk(n); 
    CL_over_CD(n) = CL/CD;
    
    L = 1/2*1.225*P_AP2.S_wing*CL; 
    Dk = 1/2*1.225*P_AP2.S_wing*Cdk(n); 
    Dt = 1/8*1.225*T.CD_tether*r*T.d_tether; 
    D = Dk + Dt; 
    %CL_over_CD(n) = -F_A(3)/(-F_A(1)+1/8*1.225*T.CD_tether*r*T.d_tether);

    
    phi = 35*pi/180;
    lam = 0;
    vr = 12;
    vw = 20;
    f = vr/vw;
    LoverD(n) = L/D;
    %va_est(n) = vw * (sin(pi/2-phi)*cos(lam)-f)*sqrt( 1 + (CL_over_CD(n) )^2);
     va_est(n) = vw * (sin(pi/2-phi)*cos(lam)-f)*sqrt( 1 + (L/D)^2 );

    
    qq = 1/2*1.225*vw^2;
    CR = sqrt( CL^2 + CD^2 ); 
    Ft(n) = qq*P_AP2.S_wing*CR*( 1 + (L/D)^2 )*( sin(pi/2-phi)*cos(lam)-f )^2;
    
end
%%
figure; 
subplot(211)
plot( alpha_vec*180/pi, va_est); 
hold on 
subplot(212)
plot( alpha_vec*180/pi,Ft); 




