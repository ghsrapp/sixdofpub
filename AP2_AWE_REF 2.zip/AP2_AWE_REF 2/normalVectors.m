

l_tether = 200;
%% ================ Great Circle ================
if 1
    % Normalvector great circle planes
    n1Right = cross(left_top_abs_E/norm(left_top_abs_E), right_bottom_abs_E/norm(right_bottom_abs_E) );
    n1Left = cross(right_top_abs_E/norm(right_top_abs_E), left_bottom_abs_E/norm(left_bottom_abs_E) );
    
    %plot vectors
    %q_n1 = quiver3( 0, 0, 0, n1(1)*200, n1(2)*200,n1(3)*200);
    %set(q_n1, 'Linewidth', 1.2, 'color', 'blue');
    
    % calculate angle between left_top_abs_E and right_bottom_abs_E
    alpha_ = acos( left_top_abs_E'*right_bottom_abs_E / norm(right_bottom_abs_E) / norm(left_top_abs_E) );
    
    % take a fraction of it
    alpha_trans = 0.9 * alpha_;
    
    % in order to rotate a vector on the great circle plane a orthonormal basis
    % has to be calculated:
    
    e_x_1_right = left_top_abs_E/norm(left_top_abs_E); e_z_1_right = n1Right/norm(n1Right);e_y_1_right = cross(e_z_1_right,e_x_1_right);
    e_x_1_left = right_top_abs_E/norm(right_top_abs_E); e_z_1_left = n1Left/norm(n1Left);e_y_1_left = cross(e_z_1_left,e_x_1_left);
    
    if 0 % orthonormal basis
        q_x1 = quiver3( 0, 0, 0, 200*e_x_1(1), 200*e_x_1(2), 200*e_x_1(3));
        q_y1 = quiver3( 0, 0, 0, 200*e_y_1(1), 200*e_y_1(2), 200*e_y_1(3));
        q_z1 = quiver3( 0, 0, 0, 200*e_z_1(1), 200*e_z_1(2), 200*e_z_1(3));
        set([q_x1, q_y1, q_z1], 'Linewidth', 1.2, 'color', 'blue');
    end
    
    % the great circle frame is denoted by: Gc1 and the transformation from W to Gc1 is M_Gc1W
    M_Gc1W_right = [e_x_1_right'; e_y_1_right'; e_z_1_right'];
    M_Gc1W_left = [e_x_1_left'; e_y_1_left'; e_z_1_left'];
    
    M_WGc1_right = M_Gc1W_right';
    M_WGc1_left = M_Gc1W_left';
    
    % transform the vector into the great circle plane:
    left_top_abs_Gc1 = M_Gc1W_right * left_top_abs_E;
    right_top_abs_Gc1 = M_Gc1W_left * right_top_abs_E;
    
    % Now, rotate the upper waypoint vector by alpha_trans to obtain p_trans
    RotMRight = [cos(alpha_trans), -sin(alpha_trans), 0;
        sin(alpha_trans), cos(alpha_trans), 0;
        0,0,1];
    RotMLeft = [cos(alpha_trans), -sin(alpha_trans), 0;
        sin(alpha_trans), cos(alpha_trans), 0;
        0,0,1];
    
    p_trans_Gc1_right = RotMRight * left_top_abs_Gc1;
    p_trans_Gc1_left = RotMLeft * right_top_abs_Gc1;
    
    % Transform back to World frame
    p_trans_W_right = M_WGc1_right * p_trans_Gc1_right * l_tether;
    p_trans_W_left = M_WGc1_left * p_trans_Gc1_left * l_tether;
    
    %q_trans = quiver3( 0, 0, 0, p_trans_W(1), p_trans_W(2), p_trans_W(3));
    %set(q_trans, 'Linewidth', 1.2, 'color', 'red');
    
    % tangentenvector
    p_trans_t_W_right = cross(  n1Right/norm(n1Right), p_trans_W_right/norm(p_trans_W_right) );
    p_trans_t_W_right = p_trans_t_W_right * l_tether;
    
    p_trans_t_W_left = cross(  n1Left/norm(n1Left), p_trans_W_left/norm(p_trans_W_left) );
    p_trans_t_W_left = p_trans_t_W_left * l_tether;
    
    if 0
        q_tangRight = quiver3( p_trans_W_right(1), p_trans_W_right(2), p_trans_W_right(3), p_trans_t_W_right(1), p_trans_t_W_right(2), p_trans_t_W_right(3));
        q_tangLeft = quiver3( p_trans_W_left(1), p_trans_W_left(2), p_trans_W_left(3), p_trans_t_W_left(1), p_trans_t_W_left(2), p_trans_t_W_left(3));
        set([q_tangRight, q_tangLeft], 'Linewidth', 1.2, 'color', 'green');
    end
    % with these vectors the plane halfspace is fully defined
    % If ( pos_kite -  p_trans_W )' * p_trans_t_W >= 0 then x is in halfspace,
    % this triggers the transition.
    
    if 1
        % plotting the plane: p' * n - r' * n = 0
        normal1 = p_trans_t_W_right / norm(p_trans_t_W_right);
        d = -p_trans_W_right' * normal1;
        [xx,yy]=ndgrid(linspace(100, 200, 10),linspace(0, 100, 10));
        % calculate corresponding z
        z = (-normal1(1)*xx - normal1(2)*yy - d)/ normal1(3);
        m = mesh(xx,yy,z, 'edgecolor', 'm');
        set(m, 'Linewidth', 1.2);
        set(m, 'FaceAlpha', 0);
        
        normal1 = p_trans_t_W_left / norm(p_trans_t_W_left);
        d = -p_trans_W_left' * normal1;
        [xx,yy]=ndgrid(linspace(100, 200, 10),linspace(0, -100, 10));
        % calculate corresponding z
        z = (-normal1(1)*xx - normal1(2)*yy - d)/ normal1(3);
        m = mesh(xx,yy,z, 'edgecolor', 'm');
        set(m, 'Linewidth', 1.2);
        set(m, 'FaceAlpha', 0);
    end
end
if 0
    long = 20 * pi/180;
    lat = 50 * pi/180;
    %pos_kite = l_tether * [cos(long)*cos(lat); sin(long)*cos(lat); sin(lat)];
    pos_kite = [183; 30.77; 81.92];
    plot3( pos_kite(1), pos_kite(2), pos_kite(3), '*b');
    b = ( pos_kite -  p_trans_W )' * p_trans_t_W;
end
if 1
    %% ================ Circle ================
    %q_circ_origin = quiver3(0,0,0, p_circO2_E(1)*200, p_circO2_E(2)*200, p_circO2_E(3)*200);
    deltaAngle = asin( r_d/l_tether  );
    s = cos(deltaAngle)*l_tether;
    circle_origin_right = s * p_circO2_E/norm(p_circO2_E);%*l_tether;
    circle_origin_left = s * p_circO1_E/norm(p_circO2_E);%*l_tether;
  %  plot3( circle_origin_left(1), circle_origin_left(2), circle_origin_left(3),'*r');
  %  plot3( circle_origin_right(1), circle_origin_right(2), circle_origin_right(3),'*r');
    
    ex_circ_right = (right_bottom_abs_E*l_tether-circle_origin_right)/norm(right_bottom_abs_E*l_tether-circle_origin_right);
    ez_circ_right = p_circO2_E/norm(p_circO2_E);
    ey_circ_right = cross( ez_circ_right, ex_circ_right);
    
    ex_circ_left = (left_bottom_abs_E*l_tether-circle_origin_left)/norm(left_bottom_abs_E*l_tether-circle_origin_left);
    ez_circ_left = p_circO1_E/norm(p_circO1_E);
    ey_circ_left = cross( ez_circ_left, ex_circ_left);
    
    
    
    if 0
        % plot orthonormal basis
        qex = quiver3(circle_origin_left(1),circle_origin_left(2),circle_origin_left(3), ex_circ_left(1)*100, ex_circ_left(2)*100, ex_circ_left(3)*100 ); hold on
        qey = quiver3(circle_origin_left(1),circle_origin_left(2),circle_origin_left(3), ey_circ_left(1)*100, ey_circ_left(2)*100, ey_circ_left(3)*100 );
        qez = quiver3(circle_origin_left(1),circle_origin_left(2),circle_origin_left(3), ez_circ_left(1)*100, ez_circ_left(2)*100, ez_circ_left(3)*100 );
        set([qex, qey, qez],  'Linewidth', 1.2, 'color', 'blue');
    end
    alpha_rot_right = 0.9 * pi;
    alpha_rot_left = -alpha_rot_right;
    
    RotMRight = [cos(alpha_rot_right), -sin(alpha_rot_right), 0;
        sin(alpha_rot_right), cos(alpha_rot_right), 0;
        0,0,1];
    RotMLeft = [cos(alpha_rot_left), -sin(alpha_rot_left), 0;
        sin(alpha_rot_left), cos(alpha_rot_left), 0;
        0,0,1];
    
    % the circle frame is denoted by: Circ1 and the transformation from W to Circ1 is M_Circ1W
    M_CircRightW = [ex_circ_right'; ey_circ_right'; ez_circ_right'];
    M_WCircRight = M_CircRightW';
    
    M_CircLeftW = [ex_circ_left'; ey_circ_left'; ez_circ_left'];
    M_WCircLeft = M_CircLeftW';
    
    % transform the vector into the great circle plane:
    right_bottom_abs_CircRight = M_CircRightW * ex_circ_right;
    left_bottom_abs_CircLeft = M_CircLeftW * ex_circ_left;
    
    p_trans_CircRight = RotMRight * right_bottom_abs_CircRight;
    p_trans_CircLeft = RotMLeft * left_bottom_abs_CircLeft;
    
    % Transform back to World frame
    p_trans_W_right = M_WCircRight * p_trans_CircRight * r_d + circle_origin_right;
    p_trans_W_left = M_WCircLeft * p_trans_CircLeft * r_d + circle_origin_left;
    
   % plot3( p_trans_W_right(1),p_trans_W_right(2),p_trans_W_right(3), '*r' );
   % plot3( p_trans_W_left(1),p_trans_W_left(2),p_trans_W_left(3), '*r' );
    
    % tangentenvector
    p_trans_t_W_right = M_WCircRight * cross( [0;0;1], p_trans_CircRight );
    p_trans_t_W_right = p_trans_t_W_right / norm( p_trans_t_W_right ) * 100;
    
    p_trans_t_W_left = M_WCircLeft * cross( [0;0;1], p_trans_CircLeft );
    p_trans_t_W_left = p_trans_t_W_left / norm( p_trans_t_W_left ) * 100;
    
    if 1
        q_tangRight = quiver3( p_trans_W_right(1), p_trans_W_right(2), p_trans_W_right(3), p_trans_t_W_right(1), p_trans_t_W_right(2), p_trans_t_W_right(3));
        q_tangLeft = quiver3( p_trans_W_left(1), p_trans_W_left(2), p_trans_W_left(3), p_trans_t_W_left(1), p_trans_t_W_left(2), p_trans_t_W_left(3));
        
        set([q_tangRight, q_tangLeft], 'Linewidth', 1.2, 'color', 'green');
        
        % with these vectors the plane halfspace is fully defined
        % If ( pos_kite -  p_trans_W )' * p_trans_t_W >= 0 then x is in halfspace,
        % this triggers the transition.
        % plotting the plane
        normal1 = p_trans_t_W_right / norm(p_trans_t_W_right);
        d = -p_trans_W_right' * normal1;
        [xx,yy]=ndgrid(linspace(50, 200, 10),linspace(0, 100, 10));
        z = (-normal1(1)*xx - normal1(2)*yy - d)/ normal1(3);
        m = mesh(xx,yy,z, 'edgecolor', 'm');
        set(m, 'Linewidth', 1.2);
        set(m, 'FaceAlpha', 0);
        
        normal1 = p_trans_t_W_left / norm(p_trans_t_W_left);
        d = -p_trans_W_left' * normal1;
        [xx,yy]=ndgrid(linspace(50, 200, 10),linspace(0, -100, 10));
        z = (-normal1(1)*xx - normal1(2)*yy - d)/ normal1(3);
        m = mesh(xx,yy,z, 'edgecolor', 'm');
        set(m, 'Linewidth', 1.2);
        set(m, 'FaceAlpha', 0);
    end
    if 0
        %% ================ Test ================
        long = 20 * pi/180;
        lat = 50 * pi/180;
        %pos_kite = l_tether * [cos(long)*cos(lat); sin(long)*cos(lat); sin(lat)];
        pos_kite = [183; 30.77; 81.92];
        plot3( pos_kite(1), pos_kite(2), pos_kite(3), '*c');
        b = ( pos_kite -  p_trans_W )' * p_trans_t_W;
    end
end