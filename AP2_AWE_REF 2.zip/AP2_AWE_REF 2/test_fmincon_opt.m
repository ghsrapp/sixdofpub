
qs = [30,0,0,50];
qs_lbounds = 0*ones( length( qs ),1);
qs_lbounds(end) = 1;
qs_ubounds = 100*ones( length( qs ),1);
Q_long = diag( [0, qs] );
R_long = 1;


A = [];
b = [];
Aeq = [];
beq = [];

options = optimoptions('fmincon','Display','iter','Algorithm','sqp');
[x,fval,exitflag,output,lambda,grad,hessian]  = fmincon(@quadraticCost,qs,A,b,Aeq,beq,qs_lbounds,qs_ubounds,[], options);
%%
[time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings();
load('sys_trim.mat');
A_long = sys_trim.A_long;
B_long = sys_trim.B_long;
qs(1) =  0;
qs(2) =  x(1);
qs(3) =  x(2);
qs(4) =  x(3);
qs(5) =  x(4);
Q_long = diag( qs );
R_long = 1;
K_long = lqr( A_long, B_long, Q_long, R_long );

[cost_summary] = get_robustification_cost( time_domain_ref_long, frequ_domain_ref_long, A_long, B_long, K_long );


[stabmarg, CL] = getRobStabMargin_long( A_long, B_long, K_long, [0,1,0,0,0], opts, frequ_domain_ref_long);
step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);



