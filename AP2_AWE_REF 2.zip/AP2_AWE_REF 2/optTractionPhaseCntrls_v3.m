clear all
close all
clc


% call init script
init_new_AP2;
TSIM = 500; % max. simulation time

FitnessFunction = @(x)costFunctionAP2b(x,maxBandwidth,pumpCycSucc, gs, alpha_a_max, TSIM);

[lb,ub] = initOptParamsBounds();

flag = 0; % if 1 generate random population otherwise use existing population
numPop = 30; 
if 0
    population = repmat( ub-lb, numPop, 1) .* rand(numPop, length(ub) ) + repmat( lb, numPop, 1);
else % continue optimizing using a current population.
    load('x.mat'); 
    population = repmat( x', numPop, 1); 
end
numberOfVariables = size(population,2);

opts = optimoptions('ga', ...
    'UseParallel', false,...
    'PopulationSize', numPop, ...
    'MaxGenerations', 100, ...
    'EliteCount', 1, ...
    'FunctionTolerance', 1e-18, ...
    'PlotFcn', @myPlotFunc, ...
    'InitialPopulation',population);

logOptParams;

%% Launch GA Optimization
[x,fval,exitflag,output,population,scores] = ga(FitnessFunction, numberOfVariables, [],[],[],[], lb,ub, [],[],opts);

