

numb_param = 2;
% % Set 1: only sideslip
beta1 = 0:4:16;
beta1_flip = -flip(beta1(1:1:end));
beta1 = [beta1_flip(1:end-1),  beta1(1:1:end-1), 16];
CY_data = [0.000,0.004,0.009,0.017,0.023,0.030,0.037,0.044,0.050];
CY_data = CY_data(1:2:end);
CY_data_flip = -flip(CY_data(1:1:end));
CY_data = [CY_data_flip(1:end-1),  CY_data(1:1:end)];

% flip CY_data, because a positive sideslip angle in the Excel sheet
% corresponds to a negative sideslip. 
CY_data = flip(CY_data); 

% Set 2: Rudder 4 deg, beta
beta2 = -16:4:16;
CN = [-0.060,-0.049,-0.035,-0.021,-0.006,-0.002,0.013,0.028,0.042]';
CY_data_2 = CN;
CY_data_2 = flip(CY_data_2); 

% Set 3: Rudder 8 deg
CN = [-0.068,-0.059,-0.047,-0.034,-0.017,-0.013,0.002,0.017,0.032];
CY_data_3 = CN';
CY_data_3 = flip(CY_data_3); 


% Rudder 12 deg
CN = [-0.074;-0.069;-0.058;-0.044;-0.029;-0.024;-0.009;0.006;0.021];
CY_data_4 = CN;
CY_data_4 = flip(CY_data_4); 

% Rudder 16 deg
CN = [-0.077;-0.074;-0.068;-0.055;-0.043;-0.035;-0.021;-0.005;0.010];
CY_data_5 = CN;
CY_data_5 = flip(CY_data_5); 

% Rudder 20 deg
CN = [-0.078;-0.078;-0.077;-0.065;-0.055;-0.046;-0.032;-0.016;0.000];
CY_data_6 = CN;
CY_data_6 = flip(CY_data_6); 


%% negative rudder deflection; 
% Set 2: Rudder -4 deg, beta
beta2 = -16:4:16;
CY_data_7 = -flip(CY_data_2);

% Set 3: Rudder -8 deg
CY_data_8 = -flip(CY_data_3);

% Rudder -12 deg
CY_data_9 = -flip(CY_data_4);

% Rudder -16 deg
CY_data_10 = -flip(CY_data_5);

% Rudder -20 deg
CY_data_11 = -flip(CY_data_6);

%% Create the lookup table 
CY_lookup_x_beta =  -16:4:16; 
CY_lookup_y_delta_r = -20 : 4 : 20; 
CY_lookup_data = [CY_data_6'; 
                 CY_data_5'; 
                 CY_data_4';
                 CY_data_3';
                 CY_data_2';
                 CY_data;
                 CY_data_7';
                 CY_data_8';
                 CY_data_9'; 
                 CY_data_10';
                 CY_data_11']';


