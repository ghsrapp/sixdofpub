% In the excel sheet the rollcoefficient is incorrectly normalized, 
% since as a normalization constant the chord and not the wingspan is used
% All Cell values will be muliplied by cbar/b
cbar = 0.22308; 
b = 3.7; 

% flaps 10 of course
beta0 = 0 : 2 : 20; 
beta_tot = [-20:2:20];
beta_tot = -16:4:16;
% Without delta_a
Cell_0 = [0.00025
-0.03241
-0.06448
-0.09255
-0.12209
-0.15109
-0.17872
-0.20517
-0.23266
-0.25777
-0.27673]*cbar/b;
% sideslip angle is defined differently: flip CL and change the sign,
% because Cell is defined inversely in the sheet
Cell_0_tot = [-flip(Cell_0(2:end)); Cell_0];
Cell_0_tot = -flip(Cell_0_tot);  
Cell_0_tot = Cell_0_tot(3:2:end-2);

%% Dependency on rudder deflection
% With beta
beta_tot_2 = -16:4:16; 
Cell_delta_r_4 = [0.31054
0.24108
0.16830
0.08893
0.01141
-0.07713
-0.15384
-0.22708
-0.29963]*cbar/b;
Cell_delta_r_4 = -flip( Cell_delta_r_4 ); % because differnet beta definiion (flip) and different Cell def (-)

Cell_delta_r_8 = [0.31285
0.24621
0.17405
0.09388
0.01740
-0.07078
-0.14857
-0.22232
-0.29465]*cbar/b;
Cell_delta_r_8 = -flip( Cell_delta_r_8 ); 

Cell_delta_r_20 = [0.31863
0.25645
0.19090
0.11559
0.03125
-0.05100
-0.12930
-0.20331
-0.27691]*cbar/b;
Cell_delta_r_20 = -flip( Cell_delta_r_20 ); 


%% Create the lookup table 
Cell_lookup_x_beta =  -16:4:16; 
Cell_lookup_y_delta_r = [-20, -8, -4, 0,4,8,20]; 
Cell_lookup_data_1 = [Cell_delta_r_20'; 
                 Cell_delta_r_8'; 
                 Cell_delta_r_4';
                 Cell_0_tot';
                 -flip(Cell_delta_r_4)';
                 -flip(Cell_delta_r_8)';
                 -flip(Cell_delta_r_20)']';
%% Linear approximation 
%% test surface plot
%figure; 
%[X,Y] = meshgrid(Cell_lookup_x_beta,Cell_lookup_y_delta_r);
%surf( X,Y,Cell_lookup_data_1','FaceAlpha',1, 'EdgeColor', 'none'); hold on;
%% Creae a linear approximation in the interval alpha = [-8, 10] degrees.
beta_small = Cell_lookup_x_beta(3:7);
delta_e_small = Cell_lookup_y_delta_r;
Cell_lookup_data_2_small = Cell_lookup_data_1(3:7,:);

[Xsmall,Ysmall] = meshgrid(beta_small,delta_e_small);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

phi = [ones(length(x_wrap_small),1), x_wrap_small,y_wrap_small, x_wrap_small.*y_wrap_small ]; 
Cell_wrap = reshape( Cell_lookup_data_2_small', size(Cell_lookup_data_2_small',1)*size(Cell_lookup_data_2_small',2), 1);
[theta] = doMultiVarLinReg( phi, Cell_wrap);

%% test
[Xsmall,Ysmall] = meshgrid(-8:1:8,Cell_lookup_y_delta_r);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

Cell_lookup_approx = theta(1) + theta(2).*x_wrap_small + theta(3).*y_wrap_small + theta(4).*x_wrap_small.*y_wrap_small;
CL_lookup_approx_wrap = reshape( Cell_lookup_approx, size(Xsmall,1), size(Xsmall,2) );
%plot3( x_wrap_small, y_wrap_small, Cell_lookup_approx, '+r'); 
%xlabel(['$\beta$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$\delta_r$', ' $[^\circ]$'], 'interpreter','latex'); 
%zlabel('$C_{l}$','interpreter','latex'); 

%%
dCelldelta_r = theta(3) + theta(4).*x_wrap_small;
%figure; 
%plot( x_wrap_small, dCelldelta_r);
%xlabel(['$\beta$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$dC_l/d\delta_r$'], 'interpreter','latex');
C_ell_beta = theta(2);
C_ell_delta_r_0 = theta(3); 


%% ======================= Dependency on alpha and aileron deflection
% with alpha delta_a = 15, beta = 0; 
C_ell_da_0 = [0.00011
-0.00007
-0.00041
0.00025
0.00712
-0.00970
-0.01142
0.01089
0.00992
0.00970
-0.00959
0.00936
-0.00851
-0.00446
0.00089
-0.00017
0.00055
0.00080
0.00033]*cbar/b; 
C_ell_da_0 = -C_ell_da_0; 

C_ell_da_15 = [1.22547
1.27314
1.29915
1.30170
1.28279
1.24609
1.18459
1.12102
0.99004
0.74131
0.57174
0.47813
0.39554
0.35574
0.33258
0.30845
0.29084
0.28263
0.26587]*cbar/b;
C_ell_da_15 = -C_ell_da_15; 
%
C_ell_da_3 = [0.25471
0.26020
0.26245
0.26410
0.24714
0.23508
0.21963
0.20134
0.17190
0.10690
0.10509
0.06706
0.05806
0.05765
0.05471
0.05085
0.05167
0.04805
0.04674]*cbar/b;
C_ell_da_3 = -C_ell_da_3; 
%%
alpha_vec = -6 : 2 : 30; 
Cell_lookup_x_alpha =  alpha_vec; 
Cell_lookup_y_delta_a = [-15, -3, 0, 3,15]; 
Cell_lookup_data_2 = [-C_ell_da_15'; 
                 -C_ell_da_3'; 
                 C_ell_da_0';
                 C_ell_da_3';
                 C_ell_da_15';
                 ]';

% Note: In the excel sheet: aileron pos left means that the left (port)
% aileron goes up by the displayed value and the right side goes 1/3 of
% this value down. This leads to a negative rollmoment (it would lead to a
% positive rollmoment according to the def. in the excel sheet (x-axis
% pointing backwards.)

%% Linear approximation 
%% test surface plot
%figure; 
%[X,Y] = meshgrid(Cell_lookup_x_alpha,Cell_lookup_y_delta_a);
%surf( X,Y,Cell_lookup_data_2','FaceAlpha',1, 'EdgeColor', 'none'); hold on;
%% Creae a linear approximation in the interval alpha = [-8, 10] degrees.
alpha_max_idx = 9;
alpha_small = Cell_lookup_x_alpha(1:alpha_max_idx);
delta_e_small = Cell_lookup_y_delta_a;
Cell_lookup_data_2_small = Cell_lookup_data_2(1:alpha_max_idx,:);

[Xsmall,Ysmall] = meshgrid(alpha_small,delta_e_small);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

phi = [ones(length(x_wrap_small),1), x_wrap_small,y_wrap_small, x_wrap_small.*y_wrap_small ]; 
Cell_wrap = reshape( Cell_lookup_data_2_small', size(Cell_lookup_data_2_small',1)*size(Cell_lookup_data_2_small',2), 1);
[theta] = doMultiVarLinReg( phi, Cell_wrap);

%% test
[Xsmall,Ysmall] = meshgrid(-6:1:10,-15:1:15);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

Cell_lookup_approx =theta(1) + theta(2).*x_wrap_small + theta(3).*y_wrap_small + theta(4).*x_wrap_small.*y_wrap_small;
CL_lookup_approx_wrap = reshape( Cell_lookup_approx, size(Xsmall,1), size(Xsmall,2) );

%plot3( x_wrap_small, y_wrap_small, Cell_lookup_approx, '+b'); 

%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$\delta_a$', ' $[^\circ]$'], 'interpreter','latex'); 
%zlabel('$C_{l}$','interpreter','latex'); 
%set(gca,'TickLabelInterpreter','latex');
%%
dCelldelta_a = theta(3) + theta(4).*x_wrap_small;
%figure; 
%plot( x_wrap_small, dCelldelta_a);
%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$dC_l/d\delta_a$'], 'interpreter','latex'); 

C_ell_delta_a_0 = theta(3); 
C_ell_delta_a_1 = theta(4); % multiply by alpha at runtime.
C_ell_alpha = theta(2);
C_ell_alphadelta_a = theta(4);


