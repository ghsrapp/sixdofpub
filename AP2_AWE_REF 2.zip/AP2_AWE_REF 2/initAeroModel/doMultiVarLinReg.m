function [theta] = doMultiVarLinReg( Phi, Y)

theta = Phi'*Phi\eye( size( Phi, 2 )) * Phi' * Y;


end