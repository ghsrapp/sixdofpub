
% no elevator deflection
% only f
a_vec_0 = -8 : 2 : 44;
CL_delta_e_0 = [-0.053;
0.151;0.354;0.554;0.754;0.929;
1.098;1.250;1.374;1.468;1.497;1.491;
1.501;1.504;1.505;1.504;1.500;1.492;
1.482;1.466;1.447;1.429;1.409;1.387;
1.362;1.331;1.298];
CL_delta_e_0_stall = CL_delta_e_0(11);
figure; 
plot( a_vec_0, CL_delta_e_0); 
%% smaller angle of attack region with flap deflection
a_vec = [-8, -4, 0, 4, 8, 10, 12]; % i removed 10 for even distribution
%  elevator deflection: -4
CL_delta_e_1 = [-0.032;
0.375;0.772;
1.114;1.389;
1.482;1.511];
e_1 = CL_delta_e_1(end)- CL_delta_e_0_stall;
CL_delta_e_1 = [CL_delta_e_1; 
                CL_delta_e_0(12:end)+e_1]; % approximation post stall

%  elevator deflection: -8
CL_delta_e_2 = [-0.013;
0.396;0.791;1.135;
1.407;1.501;1.526];
e_2 = CL_delta_e_2(end)- CL_delta_e_0_stall;
CL_delta_e_2 = [CL_delta_e_2; 
                CL_delta_e_0(12:end)+e_2]; % approximation post stall
            
%  elevator deflection: 4
CL_delta_e_3 = [-0.070;
0.335;0.731;1.076;1.352;1.447;1.479];
e_3 = CL_delta_e_3(end)- CL_delta_e_0_stall;
CL_delta_e_3 = [CL_delta_e_3; 
                CL_delta_e_0(12:end)+e_3]; % approximation post stall
%  elevator deflection: 8
CL_delta_e_4 = [-0.086;
0.315;0.703;1.055;
1.332;1.427;1.459];
e_4 = CL_delta_e_4(end)- CL_delta_e_0_stall;
CL_delta_e_4 = [CL_delta_e_4; 
                CL_delta_e_0(12:end)+e_4]; % approximation post stall

%% Create the lookup table 
CL_lookup_x_alpha = [a_vec,a_vec_0(12:end)]; 
CL_lookup_y_delta_e = -8 : 4 : 8; 
CL_lookup_data = [CL_delta_e_4'; CL_delta_e_3';
    [CL_delta_e_0(1:2:10)', CL_delta_e_0(10:end)'];
    CL_delta_e_1'; CL_delta_e_2']';

%% Crude estimate of the CL curve 
[CL_min,idmin] = min( CL_lookup_data(:,3) );
[CL_max,idmax] = max( CL_lookup_data(:,3) );
alpha_max = CL_lookup_x_alpha(idmax); 
aero_ctrl.dCLdalpha = (1.5 - CL_min )/(10+8);
aero_ctrl.CL_0 = 0.7; 
aero_ctrl.clmax = CL_max; 
aero_ctrl.clmin = CL_min; 
%%
%figure; 
%plot( CL_lookup_x_alpha, CL_0+dCLdalpha*CL_lookup_x_alpha)
