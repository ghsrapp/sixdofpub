% dependency of Cm mainly alpha and delta_e

a_vec_0 = -8 : 2 : 44;
Cm_delta_e_0 = [0.08576
0.06867
0.05388
0.03715
0.02442
-0.00260
-0.02595
-0.04572
-0.07587
-0.10674
-0.13910
-0.17926
-0.22548
-0.27723
-0.32903
-0.37889
-0.42681
-0.46766
-0.49880
-0.52583
-0.55038
-0.57119
-0.59024
-0.60805
-0.62512
-0.64080
-0.65642];

Cm_delta_e_0_stall = Cm_delta_e_0(11);

% elevator -4
alpha_vec_1 =[-8:4:8, 10, 12]; 
Cm_delta_e_m4 = [0.01040
-0.02628
-0.05936
-0.10624
-0.16035
-0.18968
-0.21963];
e_1 = Cm_delta_e_m4(end)- Cm_delta_e_0_stall;
Cm_delta_e_m4 = [Cm_delta_e_m4; 
                Cm_delta_e_0(12:end)+e_1]; % approximation post stall



% elevator -8
Cm_delta_e_m8 = [-0.06922
-0.11019
-0.14501
-0.18527
-0.23585
-0.26191
-0.28539];
e_1 = Cm_delta_e_m8(end)- Cm_delta_e_0_stall;
Cm_delta_e_m8 = [Cm_delta_e_m8; 
                Cm_delta_e_0(12:end)+e_1]; % approximation post stall

% elevator 4
Cm_delta_e_4 = [0.15983
0.13487
0.10964
0.05465
-0.00351
-0.03753
-0.07467];
e_1 = Cm_delta_e_4(end)- Cm_delta_e_0_stall;
Cm_delta_e_4 = [Cm_delta_e_4; 
                Cm_delta_e_0(12:end)+e_1]; % approximation post stall


% elevator 8 
Cm_delta_e_8 = [0.22425
0.21426
0.18629
0.13507
0.07569
0.04101
0.00218];
e_1 = Cm_delta_e_8(end)- Cm_delta_e_0_stall;
Cm_delta_e_8 = [Cm_delta_e_8; 
                Cm_delta_e_0(12:end)+e_1]; % approximation post stall

%legend('\delta_e = 0^\circ', '\delta_e = -4^\circ','\delta_e = -8^\circ', '\delta_e = 4^\circ', '\delta_e = 8^\circ'); 

% Important remark!! Positive elevator deflection is defined the other way 
% Take this into account when constructing the lookup tables, by putting
% the columns with negative deflection in the place for the positive
% deflections. For the plot i just flipped the entries of the legend.

%% Create lookup tables 
Cm_lookup_x_alpha =  [a_vec_0(1:2:9), a_vec_0(10:end)]; 
Cm_lookup_y_delta_a = [-8, -4, 0, 4,8]; 
Cm_lookup_data = [Cm_delta_e_8'; 
                 Cm_delta_e_4'; 
                 [Cm_delta_e_0(1:2:9)', Cm_delta_e_0(10:end)'];
                 Cm_delta_e_m4';
                 Cm_delta_e_m8';
                 ]';
% %%
% figure; 
% plot( Cm_lookup_x_alpha, Cell_lookup_data_2(:,1) ); hold on 
% plot( Cm_lookup_x_alpha, Cell_lookup_data_2(:,2) ); hold on 
% plot( Cm_lookup_x_alpha, Cell_lookup_data_2(:,3) ); hold on 
% plot( Cm_lookup_x_alpha, Cell_lookup_data_2(:,4) ); hold on 
% plot( Cm_lookup_x_alpha, Cell_lookup_data_2(:,5) ); hold on 
% legend('-8', '-4', '0', '4', '8'); 

%% Linear approximation 
%% test surface plot
% figure; 
% [X,Y] = meshgrid(Cm_lookup_x_alpha,Cm_lookup_y_delta_a);
% surf( X,Y,Cm_lookup_data','FaceAlpha',1, 'EdgeColor', 'none'); hold on;
%% Creae a linear approximation in the interval alpha = [-8, 10] degrees.
alpha_small = Cm_lookup_x_alpha(1:6);
delta_e_small = Cm_lookup_y_delta_a;
Cell_lookup_data_2_small = Cm_lookup_data(1:6,:);

[Xsmall,Ysmall] = meshgrid(alpha_small,delta_e_small);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

phi = [ones(length(x_wrap_small),1), x_wrap_small,y_wrap_small, x_wrap_small.*y_wrap_small ]; 
Cell_wrap = reshape( Cell_lookup_data_2_small', size(Cell_lookup_data_2_small',1)*size(Cell_lookup_data_2_small',2), 1);
[theta] = doMultiVarLinReg( phi, Cell_wrap);

%% test
[Xsmall,Ysmall] = meshgrid(-8:1:10,-8:1:8);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

Cell_lookup_approx = theta(1) + theta(2).*x_wrap_small + theta(3).*y_wrap_small + theta(4).*x_wrap_small.*y_wrap_small;
CL_lookup_approx_wrap = reshape( Cell_lookup_approx, size(Xsmall,1), size(Xsmall,2) );
%plot3( x_wrap_small, y_wrap_small, Cell_lookup_approx, '+r'); 

%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$\delta_e$', ' $[^\circ]$'], 'interpreter','latex'); 
%zlabel('$C_{m}$','interpreter','latex'); 
%set(gca,'TickLabelInterpreter','latex')

dCelldelta_a = theta(3) + theta(4).*x_wrap_small;
%figure; 
%plot( x_wrap_small, dCelldelta_a); hold on 
%plot( x_wrap_small, 1./dCelldelta_a); hold on 

%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$dC_m/d\delta_e$'], 'interpreter','latex'); 

C_m_delta_e_0 =  theta(3);
C_m_delta_e_1 =  theta(4);
C_m_0 = theta(1); 
C_m_alpha = theta(2);
