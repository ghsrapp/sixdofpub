%% generates the lookup table data 
% source: Kite05kWberegninger04tilEspen310118

% Static
generateCLdata;
generateCYdata;
generateCDdata;
generateCelldata;
generateCmdata;
generateCndata;

%% Damping as defined in: CCE12012017_0001.pdf
aer.CLq = 7.267; 
aer.Cmq = -16.374; 
aer.CYp = -0.133; 
aer.CYr = 0.172; 
aer.Cellp = -0.645;
aer.Cellr = 0.219; 
aer.Cnp = -0.131; 
aer.Cnr = -0.0335; 

%% Stability derivatives linear regime 
stab_dervs_lin.C_ell_beta = C_ell_beta;

stab_dervs_lin.C_m_0 = C_m_0;
stab_dervs_lin.C_m_alpha = C_m_alpha;

stab_dervs_lin.C_n_beta = C_n_beta;


%% Control derivatives 
ctrl_dervs.C_ell_delta_a_0 = C_ell_delta_a_0;
ctrl_dervs.C_ell_delta_a_1 = C_ell_delta_a_1; % factor before alpha
ctrl_dervs.C_ell_delta_r_0 = C_ell_delta_r_0;

ctrl_dervs.C_m_delta_e_0 = C_m_delta_e_0;
ctrl_dervs.C_m_delta_e_1 = C_m_delta_e_1; % alpha

ctrl_dervs.C_n_delta_r_0 = C_n_delta_r_0;
ctrl_dervs.C_n_delta_a_0 = C_n_delta_a_0;
ctrl_dervs.C_n_delta_a_1 = C_n_delta_a_1; % alpha

%% Check for singularities: 
alpha_sing_1 = - ctrl_dervs.C_m_delta_e_0 / ctrl_dervs.C_m_delta_e_1 ;
alpha_sing_2 = (ctrl_dervs.C_ell_delta_a_0*ctrl_dervs.C_n_delta_r_0-ctrl_dervs.C_ell_delta_r_0*ctrl_dervs.C_n_delta_a_0) /...
    (ctrl_dervs.C_ell_delta_r_0*ctrl_dervs.C_n_delta_a_1-ctrl_dervs.C_ell_delta_a_1*ctrl_dervs.C_n_delta_r_0);
alpha_test = -10:1:20;
f = (ctrl_dervs.C_ell_delta_a_0+ctrl_dervs.C_ell_delta_a_1*alpha_test)*ctrl_dervs.C_n_delta_r_0 - ...
    ctrl_dervs.C_ell_delta_r_0*(ctrl_dervs.C_n_delta_a_0+ctrl_dervs.C_n_delta_a_1*alpha_test);
