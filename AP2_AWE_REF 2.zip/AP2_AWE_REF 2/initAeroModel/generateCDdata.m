
% no elevator deflection
% only f
a_vec_0 = -8 : 2 : 44;
CD_delta_e_0 = [0.0585
0.0453;0.0408;0.0437;0.0524;0.0677;0.0883;0.1131;
0.1421;0.1740;0.2076;0.2482;0.3060;0.3715;0.4437;
0.5209;0.6018;0.6828;0.7663;0.8439;0.9184;0.9885;
1.0544;1.1166;1.1767;1.2340;1.2893];

%% Create the lookup table 
CD_lookup_x_alpha = -8 : 2 : 44;
CD_lookup_data = CD_delta_e_0;

%%
CD_lookup_x_alpha_pre = [CD_lookup_x_alpha(1:2:9),CD_lookup_x_alpha(10:end) ];
CD_lookup_data_pre = [CD_delta_e_0(1:2:9);CD_delta_e_0(10:end)];


%plot( CD_lookup_x_alpha_pre, CD_lookup_data_pre )
fitobject = fit(CD_lookup_x_alpha_pre',CD_lookup_data_pre,'poly2');
aero_ctrl.CD_0 = fitobject.p3;
aero_ctrl.CD_alpha = fitobject.p2;
aero_ctrl.CD_alpha2 = fitobject.p1;

%figure; 
%plot(CD_lookup_x_alpha_pre, fitobject.p1 * CD_lookup_x_alpha_pre.^2 + fitobject.p2 * CD_lookup_x_alpha_pre+fitobject.p3);