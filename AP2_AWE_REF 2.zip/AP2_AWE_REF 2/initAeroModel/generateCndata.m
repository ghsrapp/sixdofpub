% In the excel sheet the rollcoefficient is incorrectly normalized, 
% since as a normalization constant the chord and not the wingspan is used
% All Cell values will be muliplied by cbar/b
cbar = 0.22308; 
b = 3.7; 

% Major influence: rudder deflection and aileron deflection as well as sideslip, additonally the dependence

% flaps 10 of course
beta0 = 0 : 2 : 20; 
beta_tot = [-20:2:20];

Cn_0 = [0.00169
0.02766
0.06234
0.09988
0.13562
0.17111
0.20632
0.23953
0.27182
0.30299
0.33360]*cbar/b;
Cn_0_tot = [-flip(Cn_0(2:end)); Cn_0];
Cn_0_tot = -flip( Cn_0_tot ); % beta inversely defined (flipped), moment inversely defined (-)

% With beta
beta_tot_2 = -16:4:16; 
Cn_delta_r_4 = [-0.32294
-0.26685
-0.20089
-0.12946
-0.05666
-0.00539
0.06562
0.13697
0.20616]*cbar/b;
Cn_delta_r_4 = -flip(Cn_delta_r_4); 

Cn_delta_r_8 = [-0.37346
-0.33065
-0.27009
-0.20047
-0.12342
-0.07026
0.00127
0.07279
0.14437]*cbar/b;
Cn_delta_r_8 = -flip(Cn_delta_r_8); 

Cn_delta_r_12 = [-0.41709;
-0.39095;
-0.33702;
-0.26716;
-0.19139;
-0.13616;
-0.06375;
0.00933;
0.08194]*cbar/b;
Cn_delta_r_12 = -flip(Cn_delta_r_12); 

Cn_delta_r_16 = [-0.43723;
-0.42737;
-0.40035;
-0.33444;
-0.26174;
-0.20149;
-0.12900;
-0.05472;
0.02012]*cbar/b;
Cn_delta_r_16 = -flip(Cn_delta_r_16); 

Cn_delta_r_20 = [-0.45554
-0.45568
-0.45880
-0.39807
-0.32561
-0.26646
-0.19460
-0.11859
-0.04257]*cbar/b;
Cn_delta_r_20 = -flip(Cn_delta_r_20); 

%% Create the lookup table 
Cn_lookup_x_beta =  -16:4:16; 
Cn_lookup_y_delta_r = -20:4:20; 
Cn_lookup_data_1 = [Cn_delta_r_20'; 
                 Cn_delta_r_16';
                 Cn_delta_r_12'; 
                 Cn_delta_r_8'; 
                 Cn_delta_r_4'; 
                 Cn_0_tot(3:2:end-2)';
                 -flip(Cn_delta_r_4)';
                 -flip(Cn_delta_r_8)';
                 -flip(Cn_delta_r_12)';
                 -flip(Cn_delta_r_16)';
                -flip(Cn_delta_r_20)']';
% figure; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,1) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,2) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,3) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,4) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,5) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,6) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,7) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,8) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,9) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,10) ); hold on; 
% plot( Cn_lookup_x_beta, Cn_lookup_data_1(:,11) ); hold on; 
% legend('-20','-16','-12','-8', '-4', '0', '4','8','12','16', '20'); 

%% Linear approximation 
%% test surface plot
%figure; 
%[X,Y] = meshgrid(Cn_lookup_x_beta,Cn_lookup_y_delta_r);
%surf( X,Y,Cn_lookup_data_1','FaceAlpha',1, 'EdgeColor', 'none'); hold on;
%% Creae a linear approximation in the interval alpha = [-8, 10] degrees.
alpha_small = Cn_lookup_x_beta(3:7);
delta_e_small = Cn_lookup_y_delta_r;
Cell_lookup_data_2_small = Cn_lookup_data_1(3:7,:);

[Xsmall,Ysmall] = meshgrid(alpha_small,delta_e_small);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

phi = [ones(length(x_wrap_small),1), x_wrap_small,y_wrap_small, x_wrap_small.*y_wrap_small ]; 
Cell_wrap = reshape( Cell_lookup_data_2_small', size(Cell_lookup_data_2_small',1)*size(Cell_lookup_data_2_small',2), 1);
[theta] = doMultiVarLinReg( phi, Cell_wrap);

%% test
[Xsmall,Ysmall] = meshgrid(-8:1:10,-20:1:20);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

Cell_lookup_approx = theta(1) + theta(2).*x_wrap_small + theta(3).*y_wrap_small + theta(4).*x_wrap_small.*y_wrap_small;
%CL_lookup_approx_wrap = reshape( Cell_lookup_approx, size(Xsmall,1), size(Xsmall,2) );
%plot3( x_wrap_small, y_wrap_small, Cell_lookup_approx, '+r'); 

%xlabel(['$\beta$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$\delta_r$', ' $[^\circ]$'], 'interpreter','latex'); 
%zlabel('$C_{n}$','interpreter','latex'); 
%set(gca,'TickLabelInterpreter','latex')

dCndelta_r = theta(3) + theta(4).*x_wrap_small;
%figure; 
%plot( x_wrap_small, dCndelta_r);
%xlabel(['$\beta$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$dC_n/d\delta_r$'], 'interpreter','latex');

C_n_delta_r_0 = theta(3) ;
C_n_beta = theta(2);

%% Dependency on the aileron deflection and angle of attack
C_n_da_0 = [0.00082
0.00056
-0.00107
0.00169
0.00715
-0.00539
-0.00183
-0.00152
-0.00448
-0.00651
0.00771
-0.00561
-0.00013
0.00076
0.00096
-0.00054
-0.00056
-0.00156
-0.00006]*cbar/b;

C_n_da_0 = -C_n_da_0; % because z axis is defined upwards in the excel sheet
% Update regarding axis: I'm not sure about that anymore (have to ask
% Sture)

alpha_vec = -6 : 2 : 30; 
C_n_da_15 = [-0.11475
-0.10860
-0.09756
-0.08875
-0.07056
-0.05164
-0.03334
-0.02442
-0.02199
-0.04102
-0.06535
-0.08311
-0.09504
-0.11358
-0.11635
-0.13257
-0.13947
-0.14513
-0.13847]*cbar/b;

C_n_da_15 = -C_n_da_15; 

C_n_da_3 = [-0.03231
-0.03043
-0.02821
-0.01445
-0.02676
-0.02012
-0.01504
-0.00955
-0.00477
-0.00851
-0.02117
-0.01628
-0.02117
-0.02726
-0.02871
-0.03073
-0.03494
-0.02832
-0.02981]*cbar/b;

C_n_da_3 = -C_n_da_3; 


Cn_lookup_x_alpha =  alpha_vec; 
Cn_lookup_y_delta_a =[-15, -3, 0, 3, 15]; 
Cn_lookup_data_2 = [-C_n_da_15'; 
                 -C_n_da_3';
                 C_n_da_0'; 
                 C_n_da_3'; 
                 C_n_da_15']';
%%
% figure; 
% plot(alpha_vec, Cn_lookup_data_2(:,1)); hold on
% plot(alpha_vec, Cn_lookup_data_2(:,2)); 
% plot(alpha_vec, Cn_lookup_data_2(:,3));
% plot(alpha_vec, Cn_lookup_data_2(:,4));
% plot(alpha_vec, Cn_lookup_data_2(:,5)); 
% legend('-15','-3','0','3','15')
% 
%% Linear approximation 
%% test surface plot
%figure; 
%[X,Y] = meshgrid(Cn_lookup_x_alpha,Cn_lookup_y_delta_a);
%surf( X,Y,Cn_lookup_data_2','FaceAlpha',1, 'EdgeColor', 'none'); hold on;
%% Creae a linear approximation in the interval alpha = [-8, 10] degrees.
alpha_small = Cn_lookup_x_alpha(1:9);
delta_e_small = Cn_lookup_y_delta_a;
Cell_lookup_data_2_small = Cn_lookup_data_2(1:9,:);

[Xsmall,Ysmall] = meshgrid(alpha_small,delta_e_small);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

phi = [ones(length(x_wrap_small),1), x_wrap_small,y_wrap_small, x_wrap_small.*y_wrap_small ]; 
Cell_wrap = reshape( Cell_lookup_data_2_small', size(Cell_lookup_data_2_small',1)*size(Cell_lookup_data_2_small',2), 1);
[theta] = doMultiVarLinReg( phi, Cell_wrap);

%% test
[Xsmall,Ysmall] = meshgrid(-6:1:10,-15:1:15);
x_wrap_small = reshape( Xsmall, size(Xsmall,1)*size(Xsmall,2), 1);
y_wrap_small = reshape( Ysmall, size(Ysmall,1)*size(Ysmall,2), 1);

Cell_lookup_approx = theta(1) + theta(2).*x_wrap_small + theta(3).*y_wrap_small + theta(4).*x_wrap_small.*y_wrap_small;
%CL_lookup_approx_wrap = reshape( Cell_lookup_approx, size(Xsmall,1), size(Xsmall,2) );
%plot3( x_wrap_small, y_wrap_small, Cell_lookup_approx, '+r'); 

%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$\delta_a$', ' $[^\circ]$'], 'interpreter','latex'); 
%zlabel('$C_{n}$','interpreter','latex'); 
%set(gca,'TickLabelInterpreter','latex');


dCndelta_a = theta(3) + theta(4).*x_wrap_small;
%figure; 
%plot( x_wrap_small, dCndelta_a);
%xlabel(['$\alpha$', ' $[^\circ]$'], 'interpreter','latex'); 
%ylabel(['$dC_n/d\delta_a$'], 'interpreter','latex');

C_n_delta_a_0 = theta(3) ;
C_n_delta_a_1 = theta(4) ;
