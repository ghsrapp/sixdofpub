%% ======= Actuators ====
% The bandwidth of the system is restricted by the actuator bandwidth.
% The actuators are modeled as second order spring-damper elements.
zeta_actutaor = 1;%1.2;
omega_actuator = 50;%35;
% laut Holzapfel: Ti muss groesser als 1/(2*zeta*omega)

% Aperiodisch! 2 Timeconstants:
% T2 = ( (2*zeta_actuator*omega_actuator) + sqrt( 4 * zeta_actutaor^2 * omega_actuator^2 - 4 * omega_actuator^2 ) ) / (2*omega_actuator^2);
% T2_ = ( (2*zeta_actuator*omega_actuator) - sqrt( 4 * zeta_actutaor^2 * omega_actuator^2 - 4 * omega_actuator^2 ) ) / (2*omega_actuator^2);
% T1 = 1/(T2*omega_actuator^2);
% T_act = min( [T1, T2, T2_] );

% % maximal Bandwidth = omega_actuator
% omega_rates = 1/3 * omega_actuator;
% omega_attitude = 1/2 * omega_rates;
% omega_course = 1/2.5* omega_attitude;
% omega_gamma = 1/2 * omega_attitude;
%

omega_rates = omega_actuator;
omega_attitude = 10;%1/3*omega_rates ;
omega_course = 2;%1/6 * omega_attitude;
omega_gamma = 2; %1/6 * omega_attitude;
%omega_course = 1/5 * omega_attitude;
%omega_gamma = 1/5 * omega_attitude;
if 0
    %% ======= Flightpath reference models ====
    FCS.ARefFlightPath = -omega_course*eye(2);
    FCS.ARefFlightPath(2,2) = 1*FCS.ARefFlightPath(2,2);
    FCS.BRefFlightPath = -FCS.ARefFlightPath;
    FCS.ARefVel = -10;
    FCS.BRefVel = 10;
    
    FCS.Kp_FlightPath = 1*diag( [1,1] ); %10
    FCS.Ki_FlightPath = 0*0.1*diag( [1,1] );
    
    FCS.Ki_FlightPath_retraction = 0.1*diag( [0,0] );
    FCS.Kp_FlightPath_retraction = 1*diag( [2,5] ); %10
    
    FCS.Kp_Velocity = 0.1;
    FCS.Ki_Velocity = 0.1;
    
    %% ======= Attitude Controller Gains =======
    FCS.Kp_attitude = diag( [50,20,30  ] ); % Airdata
    FCS.Ki_attitude = 0  * diag( [0,1,1  ] );
    
    %% Attitude Reference Filter Parameter
    FCS.ARefAttitude = -omega_attitude*eye(3);
    FCS.BRefAttitude = -FCS.ARefAttitude;
    
    %% ======== Desired Damping and Frequency for Path dynamics ================
end


%% Chosen reference frequencies and damping
FCS.w0_p = factor_w0_p;
FCS.w0_mu = factor_w0_mu*FCS.w0_p;
FCS.w0_chi = factor_w0_chi*FCS.w0_mu;
FCS.w0_chi_retract = factor_w0_chi*FCS.w0_mu;
%FCS.T_p = 0.05;%1/FCS.w0_p;

FCS.w0_q = factor_w0_q;
FCS.w0_alpha = factor_w0_alpha*FCS.w0_q ;
FCS.w0_gamma = factor_w0_gamma*FCS.w0_alpha;
FCS.w0_gamma_retract =factor_w0_gamma*FCS.w0_alpha;

FCS.w0_r = factor_w0_r;
FCS.w0_beta = factor_w0_beta*FCS.w0_r;


FCS.zeta_chi = 1;
FCS.zeta_gamma =1;
FCS.zeta_chi_retract  = 1;
FCS.zeta_gamma_retract  = 1;
FCS.zeta_mu = 1;
FCS.zeta_alpha = 1;
FCS.zeta_beta = 1;
FCS.zeta0_p = 1;
FCS.zeta0_q = 1;
FCS.zeta0_r = 1;

%% =====================================================
% P and I feedback gains
%
%% Factors are used for the tuning script/for now we use the same factors for the retraction and traction phase and same factor for P and I gain
FCS.Kp_chi_predictive = 0.5; 

FCS.Kp_chi = factor_chi*FCS.w0_chi^2;
FCS.Ki_chi = factor_chi*2*FCS.w0_chi*FCS.zeta_chi;

FCS.Kp_chi_retract = factor_chi*FCS.w0_chi_retract^2;
FCS.Ki_chi_retract = factor_chi*0.1*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;

FCS.Kp_mu = factor_mu*FCS.w0_mu^2;
FCS.Ki_mu = factor_mu * 2 * FCS.zeta_mu * FCS.w0_mu;

FCS.Kp_p = factor_p*FCS.w0_p^2;
FCS.Ki_p = factor_p*2*FCS.w0_p*FCS.zeta0_p;
%
FCS.Kp_gamma = factor_gamma*FCS.w0_gamma^2;
FCS.Ki_gamma = factor_gamma*2*FCS.w0_gamma*FCS.zeta_gamma;

FCS.Kp_gamma_retract = factor_gamma*FCS.w0_gamma_retract^2;
FCS.Ki_gamma_retract = factor_gamma*2*FCS.w0_gamma_retract*FCS.zeta_gamma_retract;

FCS.Kp_alpha =  factor_alpha*FCS.w0_alpha^2;
FCS.Ki_alpha =  factor_alpha*2 * FCS.zeta_alpha * FCS.w0_alpha;

FCS.Kp_q =  factor_q*FCS.w0_q^2;
FCS.Ki_q =  factor_q*2*FCS.w0_q*FCS.zeta0_q;
%
FCS.Kp_beta =  factor_beta*FCS.w0_beta^2;
FCS.Ki_beta =  factor_beta*2*FCS.zeta_beta * FCS.w0_beta;
FCS.Kd_beta = 0;

FCS.Kp_r =  factor_r*FCS.w0_r^2;
FCS.Ki_r = factor_r*2*FCS.w0_r*FCS.zeta0_r;
%% =====================================================
% Updated retraction gains 
FCS.w0_mu_retraction = 5;%1/4*FCS.w0_p;
FCS.w0_chi_retract = 0.4*FCS.w0_mu_retraction;
FCS.w0_alpha_retraction =   8.33331/3*10 ;
FCS.w0_gamma_retract =   3.3333;%1/2.5*FCS.w0_alpha_retraction;
FCS.zeta_chi_retract  = 1;
FCS.zeta_gamma_retract  = 1;

%
FCS.Kp_r_retraction = 40;%FCS.w0_r;
FCS.Kp_chi_retract =2;%1.2;% factor_chi_p*FCS.w0_chi_retract^2;
FCS.Ki_chi_retract = 0.4;%factor_chi_i*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;
FCS.Kp_mu_retraction = 2.5;%0.1*FCS.w0_mu_retraction ^2;
FCS.Ki_mu_retraction = 2;%0.2 * 2 * FCS.zeta_mu * FCS.w0_mu_retraction ;

factor_gamma = 0.6;
FCS.Kp_gamma_retract = 15;%0.8*FCS.w0_gamma_retract^2;
FCS.Ki_gamma_retract = 0;%1;%0*0.001*2*FCS.w0_gamma_retract*FCS.zeta_gamma_retract;

FCS.Kp_alpha_retraction =   20.8333;%10;%0.3*FCS.w0_alpha_retraction^2;
FCS.Ki_alpha_retraction =   16.6667;%1*2 * FCS.zeta_alpha * FCS.w0_alpha_retraction;

FCS.Kp_beta_retraction =  1;%0.01*factor_beta*FCS.w0_beta^2;
FCS.Ki_beta_retraction =  0.1;%0.01*FCS.w0_beta;
FCS.Kd_beta_retraction = 0.1*FCS.w0_beta;

FCS.Kp_p_retraction = 30;%1*FCS.w0_p;
FCS.Ki_p_retraction = 36;%$1.2*FCS.w0_p;

FCS.Kp_q_retraction = 125;% 5*FCS.w0_q;
FCS.Ki_q_retraction = 125;% 5*FCS.w0_q; 

FCS.Kp_r_retraction = 40;%2*FCS.w0_r; % was 7
FCS.Ki_r_retraction = 60;%3*FCS.w0_r; 

%% Control Allocation
FCS.C_A = [P.C_ell_delta_a, 0,P.C_ell_delta_r;
    0,P.C_m_delta_e ,0;
    P.C_n_delta_a, 0,P.C_n_delta_r];
FCS.C_A_inv = FCS.C_A \ eye(3);


%% Model parameters
FCS.J = P.J;
FCS.Jinv = P.Jinv;

%% Winch controller
omega_winch = 10;


P_gain_winch = 0.5;
Va_max = 80;
Va_min = 20;
hysteris_e = 5;

