%T.l0 = (norm( pos_O_init )) / (T.np+1);
T.l0 = tether_inital_lenght/(T.np+1);
simInit.pos_p_init = [];
pos_W_init = transformFromOtoW(windDirection_rad, pos_O_init');
e_t = pos_W_init/norm(pos_W_init);
for p = 1 : T.np
    pos_p_init = [pos_p_init; p*e_t*T.l0];
end
vel_p_init = 0 * pos_p_init;
% Test plot tether
% figure;
% plot3( pos_p_init(1:3:end-2), pos_p_init(2:3:end-1), pos_p_init(3:3:end) , '-ob' ); hold on;
% % last segment
% plot3( [pos_p_init(end-2)  pos_W_init(1)],[pos_p_init(end-1) pos_W_init(2)],[pos_p_init(end) pos_W_init(3)], '-or' ); hold on;
% % first segment
% plot3( [pos_p_init(end-2)  0],[pos_p_init(end-1) 0],[pos_p_init(end) 0], '-or' ); hold on;