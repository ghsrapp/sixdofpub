% Uwes paper
T.c0 =  614600 ; 
T.d0 = 473;
T.rho_t =  0.013;
T.d_tether = 0.004;
T.CD_tether = 1;
T.np = 5;

% Kitemill data (devotek document)
T.d_tether = 2e-3; %also AP2 (G.L thesis)

% tether mass at 170m
% M = 0.518
T.rho_t = 0.518/170;
T.CD_tether = 1.065;
T.CD_tether = 1.2; %AP2 (G.L thesis)

T.E = 5.3e9; % from Fagiano
T.eps = 0.02;
T.springconstant_un = T.E*pi*T.d_tether^2/(4*0.02);

