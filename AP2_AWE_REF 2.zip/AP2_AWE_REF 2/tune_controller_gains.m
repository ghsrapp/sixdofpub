%% This script uses a defined grid for the
factor_chi_vec = 0.8;%[0.8, 0.75];
factor_mu_vec = 0.6;
factor_p_vec=0.8;%[0.8, 0.75];
factor_gamma_vec = 0.8;%[0.8, 0.75];
factor_alpha_vec = 0.6;
factor_q_vec= 0.8;%[0.8, 0.75];
factor_beta_vec = 1;
factor_r_vec = 1;%[0.8, 0.75];
cnt = 1;
factor_p = 1;
factor_q = 1;
factor_r = 1;
for ia = 1 : length( factor_chi_vec )
    factor_chi = factor_chi_vec(ia);
    for ib = 1 : length( factor_mu_vec )
        factor_mu = factor_mu_vec(ib);
        for ic = 1 : length( factor_p_vec )
            factor_p = factor_p_vec(ic);
            for id = 1 : length( factor_gamma_vec )
                factor_gamma = factor_gamma_vec(id);
                for ie = 1 : length( factor_alpha_vec )
                    factor_alpha = factor_alpha_vec(ie);
                    for iff = 1 : length( factor_q_vec )
                        factor_q = factor_q_vec(iff);
                        for ig = 1 : length( factor_beta_vec )
                            factor_beta = factor_beta_vec(ig);
                            for ih = 1 : length( factor_r_vec )
                                factor_r = factor_r_vec(ih);
                                initControllerGains;
                                sim('AWE_Testbed_05.slx');
                                if 0
                                    savefig(['.\tuning\path_',num2str(ia),'_',num2str(ib),'_',num2str(ic),'_',num2str(id),'_',...
                                        num2str(ie),'_',num2str(iff),'_',num2str(ig),'_',num2str(ih),'.fig'])
                                    clf
                                end
                                figure(2);
                                subplot(311)
                                plot(mu_save.Time, mu_save.Data(:,1), 'b'); hold on
                                plot(mu_save.Time, mu_save.Data(:,2), 'r'); hold on
                                plot(mu_save.Time, mu_save.Data(:,3), 'g'); hold on
                                ylabel('\mu (deg)')
                                axis tight
                                subplot(312)
                                plot(mu_save.Time, alpha_save.Data(:,1), 'b'); hold on
                                plot(mu_save.Time, alpha_save.Data(:,2), 'r'); hold on
                                plot(mu_save.Time, alpha_save.Data(:,3), 'g'); hold on
                                ylabel('\alpha (deg)')
                                axis tight
                                subplot(313)
                                plot(mu_save.Time, beta_save.Data(:,1), 'b'); hold on
                                plot(mu_save.Time, beta_save.Data(:,2), 'r'); hold on
                                plot(mu_save.Time, beta_save.Data(:,3), 'g'); hold on
                                ylabel('\beta (deg)')
                                xlabel('t (s)');
                                axis tight
                                
                                e_mu = mu_save.Data(:,2) - mu_save.Data(:,3);
                                e_alpha = alpha_save.Data(:,2) - alpha_save.Data(:,3);
                                e_beta = beta_save.Data(:,2) - beta_save.Data(:,3);
                                
                                mu_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_mu'*e_mu)./sqrt( mu_save.Data(:,2)'*mu_save.Data(:,2)),...
                                    max(abs(e_mu))/max( abs(mu_save.Data(:,2)) ),...
                                    ia,ib,ic,id,ie,iff,ig,ih];
                                alpha_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_alpha'*e_alpha)./sqrt( alpha_save.Data(:,2)'*alpha_save.Data(:,2)),...
                                    max(abs(e_alpha))/max( abs(alpha_save.Data(:,2)) ),...
                                    ia,ib,ic,id,ie,iff,ig,ih];
                                beta_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_beta'*e_beta),...
                                    max(abs(e_beta)),...
                                    ia,ib,ic,id,ie,iff,ig,ih];
                                
                                cnt = cnt + 1;
                                
                                if 0
                                    savefig(['.\tuning\eta_',num2str(ia),'_',num2str(ib),'_',num2str(ic),'_',num2str(id),'_',...
                                        num2str(ie),'_',num2str(iff),'_',num2str(ig),'_',num2str(ih),'.fig'])
                                    cnt = cnt + 1;
                                end
                            end
                        end
                    end%q
                end
            end
        end%p
    end
end




