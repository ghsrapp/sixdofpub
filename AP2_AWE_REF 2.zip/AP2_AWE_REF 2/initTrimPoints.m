clear all
close all
clc
addpath('Visualization_Offline/');
init_new_AP2;
%%
initValues.l_tether = 250;
l_tether = initValues.l_tether;
Lbooth.b = 186;
Lbooth.a = 93;
Lbooth.phi0 = 28*pi/180;
drawBooth; hold on;
axis([0 l_tether+50, -Lbooth.b-50, Lbooth.b+50, 0, 300] );
vel_w_W = [12;0;0];
initValues.Lbooth = Lbooth;
initValues.phi_t=0;
initValues.theta_t=0;
omega_OB_init = zeros(3,1);
initValues.beta  = 0;
initValues.alpha = 5*pi/180;

%% Boundary conditions: Maximum dynamic pressure
initValues.Ft_trim = 1800;
initValues.Va=50;
initValues.CurvedFlightFlag = 1;
initValues.chi_tau_trim_norm = 0;

s = pi+0.25*pi : -pi/32 : 0;
s = 2*pi  : -pi/16 : 0; 
c0 = s(1);

[long, lat] = setUpInitValuesForPathTrim(Lem, initValues,s);
pointOnPath_vec = 1 : 1 : length(long);

[saveStruct,G_save,A_long,B_long,A_lat,B_lat] = ...
    doTrimming(pointOnPath_vec, initValues,vel_w_W, windDirection_rad, long, lat, s);

%%Trim condition
u_trim = saveStruct.cntrl_input'; u_trim( find(abs(u_trim)<1e-6) ) = 0; u_trim0 = u_trim(:,1); 
Ft_trim = saveStruct.ft_save; Ft_trim = Ft_trim(1); 
x_A_trim = [saveStruct.Va_save;zeros(1,length(saveStruct.Va_save));saveStruct.alpha_save]; x_A_trim( find(abs(x_A_trim)<1e-6) ) = 0; x_A_trim0 =  x_A_trim(:,1) ; 
omega_OB_trim = saveStruct.omega_OB_save'; omega_OB_trim( find(abs(omega_OB_trim)<1e-6) ) = 0; omega_OB_trim0 = omega_OB_trim(:,1); 
eta_tau_trim = saveStruct.phi_t_save'; eta_tau_trim( find(abs(eta_tau_trim)<1e-6) ) = 0;  eta_tau_trim0 = eta_tau_trim(:,1); 
pos_sp_trim = [long',lat',l_tether*ones(length(long),1)]'; pos_sp_trim0 = pos_sp_trim(:,1);

%% Design Controllers at trim points
for z = 1 : 1;%length( A_long ) 
    A_ = A_long{z}; B_ = B_long{z};
    [K] = getLQRShortPeriodGain(A_, B_, z);
    K_long_mat{z} = K;
    A_ = A_lat{z}; B_ = B_lat{z};
    [K] = getLQRLateralGain(A_,B_,z);
    K_lat_mat{z} = K;
end



%% Sim
sim('AWES2_CLSim'); 
sim('trim_offline_visualization');
%drawBooth;

