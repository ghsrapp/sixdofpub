
function [kappa, svec, L_] = calcPlanarCurvature(params)
direction = -1;
svec = 0:0.01:2*pi;
l_tether = 400;
Lbooth.a = params.a_booth*params.b_booth; % height
Lbooth.b = params.b_booth; % length
Lbooth.phi0 = params.phi0_booth; %

[Lem] = updateBoothLemniscate(l_tether,Lbooth);

for k = 1 : length(svec)
    s = svec(k);
    
    a = Lem.a;
    b = Lem.b;
    L = [ b * sin(s) ./( 1+(a/b*cos(s)).^2 );
        a * sin(s).*cos(s) ./ ( 1+(a/b*cos(s)).^2 ) ] ;
    L_(k,:) = L'*l_tether; 
    dLds = [ ( b^3*cos(s).*(2*a^2-a^2*cos(s).^2+b^2)./(a^2*cos(s).^2+b^2).^2 );
        ( (cos(s).^2*(a^3*b^2+2*a*b^4) - a*b^4)./(a^2*cos(s).^2+b^2).^2 )];
    
    d2Lds2 =  [ ( -( (a^4*b^3*sin(s).^5-b^3*sin(s).*(5*a^4+4*(a*b)^2-b^4)+b^3*sin(s).^3 *(4*a^4+6*(a*b)^2 ))./(b^2-a^2*(sin(s).^2 - 1 ) ).^3 ) );
        ( (2*a*b^2*cos(s).^3.*sin(s)*(a^4+2*(a*b)^2)-a*b^2*cos(s).*sin(s)*(3*(a*b)^2+2*b^4)*2)./(a^2*cos(s).^2 + b^2 ).^3 )];
    
    xdot = dLds(1)*l_tether;
    ydot = dLds(2)*l_tether;
    x2dot = d2Lds2(1)*l_tether;
    y2dot = d2Lds2(2)*l_tether;
    
    kappa(k) = getKapa( xdot, ydot, y2dot, x2dot);
end

col1 =  [ 57/255, 106/255, 177/255  ];
h1 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
plot(svec, kappa, 'color', col1, 'Linewidth', 1.2); 
xlabel('$s$ $(rad)$'); 
ylabel('$\kappa$ $(-)$'); %
ab = floor(params.a_booth*10); 
name = ['curvature_plot_aIS_',num2str(ab),'_bIS_',num2str(params.b_booth)]; 
Plot2LaTeX(h1,name)

end




function kappa = getKapa( xdot, ydot, y2dot, x2dot)

kappa = (xdot.*y2dot - ydot.*x2dot)./(xdot.^2+ydot.^2).^(3/2);

end