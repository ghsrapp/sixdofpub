function [vel_inter] = interpolateVelocityVectorStat(mat_3D_Windfield,xi, V_indices)

vel_inter = 0;
if vel_inter == 1
    1;
end

for n = 1 : size( V_indices, 1)
    vertex_vector =  mat_3D_Windfield( V_indices(n,2), V_indices(n,1), V_indices(n,3) );
    vel_inter = vel_inter + xi(1,n)*vertex_vector;
end


