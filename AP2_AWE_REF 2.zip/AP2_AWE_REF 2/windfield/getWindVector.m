function [v_w_O] = getWindVector(mat_4D_Windfield_u, pos_W, xvec, yvec, zvec, tvec)
%GETWINDVECTOR Summary of this function goes here
%   Detailed explanation goes here
t_test = 0; 
x_test = [pos_W; t_test];

v_w_W = [interpolateVelocityVector( mat_4D_Windfield_u,xvec, yvec, zvec,tvec, x_test);
    interpolateVelocityVector( mat_4D_Windfield_v,xvec, yvec, zvec,tvec, x_test);
    interpolateVelocityVector( mat_4D_Windfield_w,xvec, yvec, zvec,tvec, x_test)];

v_w_O = transformFromWtoO(windDirection_rad, v_w_W );

end

