function [ interval_bounds, interval_indices ] = searchIntervalBounds2( array, x, prev_indices )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% Input array with numbers and value within the interval x
% interval bounds: returns the interval in which x lies
% interval indices: returns the position of the lower and upper bounds in
% the array.
flag = 1;
n = 1;
interval_bounds = [array(prev_indices(1)), array(prev_indices(2))];
interval_indices = zeros(1,2);
if x<prev_bounds(2) && x>prev_bounds(1) % x is still in the same interval
    interval_bounds = prev_bounds;
    interval_indices = prev_indices;
elseif x>=prev_bounds(2)
    interval_bounds(2) = array( min( prev_indices(2)+1), length(array)  );
    interval_bounds(1) = prev_bounds(2);
    interval_indices = [prev_indices(2), prev_indices(2)+1];
elseif x<=prev_bounds(1)
    interval_bounds(1) = array( max( prev_indices(1)-1), 1 );
    interval_bounds(2) = prev_bounds(1);
    interval_indices = [prev_indices(1)-1, prev_indices(1)];
end
% Check if new interval is valid, if not search array for correct bounds
if x<prev_bounds(2) && x>prev_bounds(1) % x is still in the same interval
    interval_bounds = prev_bounds;
    interval_indices = prev_indices;
else
    
    while flag && n < length(array)
        if x >= array(n) && x <= array(n+1)
            interval_bounds = [array(n), array(n+1)];
            interval_indices = [n,n+1];
            flag = 0;
            n = n;
        else
            n = n+1;
        end
    end
    
end