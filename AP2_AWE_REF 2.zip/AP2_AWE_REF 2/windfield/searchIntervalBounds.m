function [ interval_bounds, interval_indices ] = searchIntervalBounds( array, x )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% Input array with numbers and value within the interval x
% interval bounds: returns the interval in which x lies 
% interval indices: returns the position of the lower and upper bounds in
% the array. 
flag = 1;
n = 1;
interval_bounds = zeros(1,2);
interval_indices = zeros(1,2); 
while flag && n < length(array)           
    if x >= array(n) && x <= array(n+1) 
      interval_bounds = [array(n), array(n+1)];
      interval_indices = [n,n+1];
      flag = 0;
      n = n;
    else
      n = n+1; 
    end     
end
if interval_indices(2) > length(array)
    interval_indices(2) = length(array); 
    interval_indices(1) = interval_indices(2)-1;
end