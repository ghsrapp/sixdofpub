function [vel_inter] = interpolateVelocityVector( mat_4D_Windfield,x_total_interval, y_total_interval, z_total_interval,...
    t_total_interval, x_vec) 

[ interval_bounds_x, interval_indices_x ] = searchIntervalBounds( x_total_interval, x_vec(1) ); % x
[ interval_bounds_y, interval_indices_y ] = searchIntervalBounds( y_total_interval, x_vec(2) ); % y 
[ interval_bounds_z, interval_indices_z ] = searchIntervalBounds( z_total_interval, x_vec(3) ); % z 
[ interval_bounds_t, interval_indices_t ] = searchIntervalBounds( t_total_interval, x_vec(4) ); % t 

t_min = interval_bounds_t(1); 
t_max = interval_bounds_t(2); 
x_min = interval_bounds_x(1);  
x_max = interval_bounds_x(2); 
y_min = interval_bounds_y(1);  
y_max = interval_bounds_y(2);  
z_min = interval_bounds_z(1);  
z_max = interval_bounds_z(2); 

p_vec_max = [x_max, y_max, z_max, t_max]; 
p_vec_min = [x_min, y_min, z_min, t_min]; 

% interpolation ratios
Theta = (x_vec - p_vec_min)./(p_vec_max - p_vec_min);
Theta = Theta';

% Loop through all the convex coordinates = number of vertices
% to determine the weight of each vertex. If the point lays on one 
% vertex the weight is one and all other weights are zero.
xi = 1; 
%for n = 1 : length(Theta)
 %      xi = [ (1-Theta(n)) * xi,  Theta(n) * xi] ; 
%end
theta1 = Theta(1); 
theta2 = Theta(2); 
theta3 = Theta(3); 
theta4 = Theta(4); 

xi =[ (theta1 - 1)*(theta2 - 1)*(theta3 - 1)*(theta4 - 1),...
      -theta1*(theta2 - 1)*(theta3 - 1)*(theta4 - 1),...
      -theta2*(theta1 - 1)*(theta3 - 1)*(theta4 - 1),...
      theta1*theta2*(theta3 - 1)*(theta4 - 1),...
      -theta3*(theta1 - 1)*(theta2 - 1)*(theta4 - 1),...
      theta1*theta3*(theta2 - 1)*(theta4 - 1),...
      theta2*theta3*(theta1 - 1)*(theta4 - 1),...
      -theta1*theta2*theta3*(theta4 - 1),...
      -theta4*(theta1 - 1)*(theta2 - 1)*(theta3 - 1),...
      theta1*theta4*(theta2 - 1)*(theta3 - 1),...
      theta2*theta4*(theta1 - 1)*(theta3 - 1),...
      -theta1*theta2*theta4*(theta3 - 1),...
      theta3*theta4*(theta1 - 1)*(theta2 - 1),...
      -theta1*theta3*theta4*(theta2 - 1),...
      -theta2*theta3*theta4*(theta1 - 1),...
      theta1*theta2*theta3*theta4];

%% Calculation of the vertex weights
% => normally we would get also an index with that i.e. 
% x_max_idx = ... , z_min_idx = ... . We will choose arbitray values here:
t_min_idx = interval_indices_t(1); t_max_idx = t_min_idx+1;
x_min_idx = interval_indices_x(1); x_max_idx = x_min_idx+1;
y_min_idx = interval_indices_y(1); y_max_idx = y_min_idx+1;
z_min_idx = interval_indices_z(1); z_max_idx = z_min_idx+1;

idx_vec_max = [x_max_idx,y_max_idx,z_max_idx,t_max_idx];
idx_vec_min = [x_min_idx,y_min_idx,z_min_idx,t_min_idx];

% we now create a matrix that associates the indices to max/min values
% Create vertices 
numb_param = 4; % spatial coordinates with time 

Vbin_max = [zeros(1,numb_param);
        de2bi(1:2^numb_param-1)];    
Vbin_min = Vbin_max == 0;
 
max_v_mat = repmat( idx_vec_max, 2^numb_param,1,1); 
min_v_mat = repmat( idx_vec_min, 2^numb_param,1,1); 

V_indices = max_v_mat .* Vbin_max + min_v_mat .* Vbin_min;

% Ok know we know where we have to look up the vertices. We can simply look
% them up in the dataset. For each row in V_indices we get a vector,
% corresponding to the "weight" at this point
vel_inter = 0; 
for n = 1 : size( V_indices, 1)
    % Get vertex values
    %mat_spatial = mat_4D_Windfield;%{ V_indices(n,4) }; % time 
    mat_spatial = mat_4D_Windfield{ V_indices(n,4) }; % time 
    vertex_vector =  mat_spatial( V_indices(n,1), V_indices(n,2), V_indices(n,3) );
    vel_inter = vel_inter + xi(1,n)*vertex_vector;
end

% this would output the interpolated velocity. 


