% File structure
filename = './AWESCO_dataset_PDBL.h5';
groupname = '/time_serie_01/';

% Display content list of dataset
%h5disp(filename)

% ----------------------- %
%   LOAD FROM HDF5 FILE   %
% ----------------------- %
% Load time series
time = h5read(filename,[groupname,'time_array']); % non-dimensional

%%% Load grid
xvec = h5read(filename,[groupname,'xvec']);
yvec = h5read(filename,[groupname,'yvec']);
zvec = h5read(filename,[groupname,'zvec']);

% Grid dimensions
xvec = 1e3*xvec;
yvec = 1e3*yvec;
zvec = 1e3*zvec; % Note that zvec doesn't span from 0 to Lz but from dz/2 to Lz-dz/2

% choose spatial boundaries (symetric in y direction)
xmax = 700;
ymax = 200;
ymin = -ymax;
zmax = 500;

[ x_interval, x_interval_indices ] = searchIntervalBounds( xvec, xmax );
[ y_interval, y_interval_indices ] = searchIntervalBounds( yvec, ymax );
[ y_interval, y_interval_indices2 ] = searchIntervalBounds( yvec, ymin );
[ z_interval, z_interval_indices ] = searchIntervalBounds( zvec, zmax );

xvec = xvec(1:x_interval_indices(2));
yvec = yvec(y_interval_indices2(1):y_interval_indices(2));
zvec = zvec(1:z_interval_indices(2));


%% --------------------- %
%   DATASET DIMENSION   %
% --------------------- %
% Time step
Nt = length(time);
dt = time(2) - time(1);

% Tuning parameters
z_ref = 100; % Reference height in [m]
U_ref = 14; % Reference velocity in [m/s] at reference height
h = 1000; % Boundary layer height
u_tau = U_ref*0.4/log(z_ref/0.1);
deltat = dt*h/u_tau;

tvec = 0 : deltat : length(time)*deltat;

% Load dataset
% - specify subgroupname (here '/time_serie_01/u/')
% - specify time (here random time from time serie)

% specify time horizon
t0 = 0;
t1 = 535;
t1 = min( t1, tvec(end) );
[ time_interval, interval_indices ] = searchIntervalBounds( tvec, t1 );
tvec = tvec(1:interval_indices(2) );

if stationaryWindfieldFlag
    randt = time( randi( length(time) ) );
    %[ time_interval, interval_indices ] = searchIntervalBounds( tvec, t1 );
    %randt = time(interval_indices(2) );
    
    % Init spatial matrices at random time
    sgrpname = [groupname,'u/'];
    dsetname = ['field_t_',num2str((randt),'%10.8f')];
    dataset_tmp = h5read(filename,[sgrpname,dsetname]);
    dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
    mat_3D_Windfield_u = permute(dataset_tmp,[2,1,3,4]);
    
    sgrpname = [groupname,'v/'];
    dsetname = ['field_t_',num2str((randt),'%10.8f')];
    dataset_tmp = h5read(filename,[sgrpname,dsetname]);
    dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
    mat_3D_Windfield_v = permute(dataset_tmp,[2,1,3,4]);
    
    sgrpname = [groupname,'w/'];
    dsetname = ['field_t_',num2str((randt),'%10.8f')];
    dataset_tmp = h5read(filename,[sgrpname,dsetname]);
    dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
    mat_3D_Windfield_w = permute(dataset_tmp,[2,1,3,4]);
    
else
    if exportWindDataFlag
        for ti = 1 : interval_indices(2)
            ti
            sgrpname = [groupname,'u/'];
            randt = time(ti);
            
            dsetname = ['field_t_',num2str((randt),'%10.8f')];
            dataset_tmp = h5read(filename,[sgrpname,dsetname]);
            dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
            mat_4D_Windfield_u = permute(dataset_tmp,[2,1,3,4]);
            name_u = ['mat_4D_Windfield_u_', num2str(ti),'.mat'];
            save(name_u,'mat_4D_Windfield_u');
            
            sgrpname = [groupname,'v/'];
            dsetname = ['field_t_',num2str((randt),'%10.8f')];
            dataset_tmp = h5read(filename,[sgrpname,dsetname]);
            dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
            mat_4D_Windfield_v = permute(dataset_tmp,[2,1,3,4]);
            name_v = ['mat_4D_Windfield_v_', num2str(ti),'.mat'];
            save(name_v,'mat_4D_Windfield_v');
            
            sgrpname = [groupname,'w/'];
            dsetname = ['field_t_',num2str((randt),'%10.8f')];
            dataset_tmp = h5read(filename,[sgrpname,dsetname]);
            dataset_tmp = dataset_tmp(1:x_interval_indices(2), y_interval_indices2(1):y_interval_indices(2), 1:z_interval_indices(2));
            mat_4D_Windfield_w = permute(dataset_tmp,[2,1,3,4]);
            name_w = ['mat_4D_Windfield_w_', num2str(ti),'.mat'];
            save(name_w,'mat_4D_Windfield_w');
        end
        %save('mat_4D_Windfield_u.mat','mat_4D_Windfield_u');
        %save('mat_4D_Windfield_v.mat','mat_4D_Windfield_v');
        %save('mat_4D_Windfield_w.mat','mat_4D_Windfield_w');
        
        
    end
    %% Init first spatial matrices
    % u
    utmp = load('./mat_4D_Windfield_u_1.mat');
    u_mat_spatial_1 = cell2mat( struct2cell( utmp ) );
    utmp = load('./mat_4D_Windfield_u_2.mat');
    u_mat_spatial_2 = cell2mat( struct2cell( utmp ) );
    % v
    utmp = load('./mat_4D_Windfield_v_1.mat');
    v_mat_spatial_1 = cell2mat( struct2cell( utmp ) );
    utmp = load('./mat_4D_Windfield_v_2.mat');
    v_mat_spatial_2 = cell2mat( struct2cell( utmp ) );
    % w
    utmp = load('./mat_4D_Windfield_w_1.mat');
    w_mat_spatial_1 = cell2mat( struct2cell( utmp ) );
    utmp = load('./mat_4D_Windfield_w_2.mat');
    w_mat_spatial_2 = cell2mat( struct2cell( utmp ) );
end
