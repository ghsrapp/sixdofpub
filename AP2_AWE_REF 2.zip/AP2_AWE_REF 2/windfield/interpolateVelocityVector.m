function [vel_inter, mat_spatial_1, mat_spatial_2] = interpolateVelocityVector(flag_keep_spat_mats,spat_mat_u1,spat_mat_u2,xi, V_indices, uvw, x_total_interval, y_total_interval, z_total_interval)

vel_inter = 0;

coder.extrinsic('num2str');
coder.extrinsic('cell2mat');

if flag_keep_spat_mats
    mat_spatial_1 = spat_mat_u1;
    mat_spatial_2 = spat_mat_u2;
else
    mat_spatial_1 =  zeros( length(y_total_interval), length(x_total_interval), length(z_total_interval) );
    mat_spatial_2 = mat_spatial_1;
    
    name = ['mat_4D_Windfield_',uvw,'_',num2str(V_indices(1,4)),'.mat'];
    utmp = load(['./windfield/',name]);
    mat_spatial_1 = cell2mat( struct2cell( utmp ) );
    
    name = ['mat_4D_Windfield_',uvw,'_',num2str(V_indices(size(V_indices,1)/2,4)),'.mat'];
    utmp = load(['./windfield/',name]);
    mat_spatial_2 = cell2mat( struct2cell( utmp ) );
end
% for n = 1 : size( V_indices, 1)
%     % Get vertex values
%     %mat_spatial = mat_4D_Windfield;%{ V_indices(n,4) }; % time
%     %mat_spatial = mat_4D_Windfield{ V_indices(n,4) }; % time
%     %     name = ['mat_4D_Windfield_',uvw,'_',num2str(V_indices(n,4)),'.mat'];
%     %     utmp = load(['./windfield/',name]);
%     %     mat_spatial = cell2mat( struct2cell( utmp ) );
%     if n <= size(V_indices,1)/2
%         mat_spatial = mat_spatial_1;
%     else
%         mat_spatial = mat_spatial_2;
%     end
%     vertex_vector =  mat_spatial( V_indices(n,1), V_indices(n,2), V_indices(n,3) );
%     vel_inter = vel_inter + xi(1,n)*vertex_vector;
% end
vel_inter = xi(1,1)* mat_spatial_1( V_indices(1,2), V_indices(1,1), V_indices(1,3) )+...
xi(1,2)* mat_spatial_1( V_indices(2,2), V_indices(2,1), V_indices(2,3) )+...
xi(1,3)* mat_spatial_1( V_indices(3,2), V_indices(3,1), V_indices(3,3) )+...
xi(1,4)* mat_spatial_1( V_indices(4,2), V_indices(4,1), V_indices(4,3) )+...
xi(1,5)* mat_spatial_1( V_indices(5,2), V_indices(5,1), V_indices(5,3) )+...
xi(1,6)* mat_spatial_1( V_indices(6,2), V_indices(6,1), V_indices(6,3) )+...
xi(1,7)* mat_spatial_1( V_indices(7,2), V_indices(7,1), V_indices(7,3) )+...
xi(1,8)* mat_spatial_1( V_indices(8,2), V_indices(8,1), V_indices(8,3) )+...
xi(1,9)* mat_spatial_2( V_indices(9,2), V_indices(9,1), V_indices(9,3) )+...
xi(1,10)* mat_spatial_2( V_indices(10,2), V_indices(10,1), V_indices(10,3) )+...
xi(1,11)* mat_spatial_2( V_indices(11,2), V_indices(11,1), V_indices(11,3) )+...
xi(1,12)* mat_spatial_2( V_indices(12,2), V_indices(12,1), V_indices(12,3) )+...
xi(1,13)* mat_spatial_2( V_indices(13,2), V_indices(13,1), V_indices(13,3) )+...
xi(1,14)* mat_spatial_2( V_indices(14,2), V_indices(14,1), V_indices(14,3) )+...
xi(1,15)* mat_spatial_2( V_indices(15,2), V_indices(15,1), V_indices(15,3) )+...
xi(1,16)* mat_spatial_2( V_indices(16,2), V_indices(16,1), V_indices(16,3) );
% this would output the interpolated velocity.


