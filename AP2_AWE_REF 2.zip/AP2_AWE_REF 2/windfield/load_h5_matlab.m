%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load_h5.m                                                               %
% Script to open hdf5 file in MATLAB                                      %
% Author: Thomas Haas, KULeuven                                           %
% Date: 02/01/2018                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear
close all

% ----------------------- %
%   HDF5 FILE STRUCTURE   %
% ----------------------- %

% File structure
filename = './AWESCO_dataset_PDBL.h5';
groupname = '/time_serie_01/';
subgroupname = 'u/';

% Display content list of dataset
h5disp(filename)

% ----------------------- %
%   LOAD FROM HDF5 FILE   %
% ----------------------- %

% Load time series
time = h5read(filename,[groupname,'time_array']);

% Load grid 
xvec = h5read(filename,[groupname,'xvec']);
yvec = h5read(filename,[groupname,'yvec']);
zvec = h5read(filename,[groupname,'zvec']);

% Load dataset 
% - specify subgroupname (here '/time_serie_01/u/')
% - specify time (here random time from time serie)
sgrpname = [groupname,subgroupname];
randt = time(randi(length(time)));
dsetname = ['field_t_',num2str((randt),'%10.8f')];
dataset = h5read(filename,[sgrpname,dsetname]);

% --------------------- %
%   DATASET DIMENSION   %
% --------------------- %

% Time step 
Nt = length(time);
dt = time(2) - time(1);

% Grid dimensions
xvec = 1e3*xvec;
yvec = 1e3*yvec;
zvec = 1e3*zvec; % Note that zvec doesn't span from 0 to Lz but from dz/2 to Lz-dz/2

% Number of grid points
Nx = length(xvec);
Ny = length(yvec);
Nz = length(zvec);
 
% Grid size
dx = xvec(2) - xvec(1);
dy = yvec(2) - yvec(1);
dz = zvec(2) - zvec(1);

% Domain size
Lx = xvec(end) - xvec(1);
Ly = yvec(end) - yvec(1);
Lz = zvec(end) - zvec(1) + dz/2;

% Compute grid
[X,Y,Z] = meshgrid(xvec,yvec,zvec);

% -------------------- %
%   VELOCITY SCALING   %
% -------------------- %

% The computed velocity fields are non-dimensional. The non-dimensional
% logarithmic velocity profile u* is given by:
%                   u* = u_tau/kappa * log( z*/z0 )
% with u_tau=1 the friction velocity, kappa=0.41 the von K�rman constant, 
% z0=0.001 the non-dimensional roughness length and z* the non-dimensional
% height. The friction velocity is computed as u_tau=sqrt(dpdx * h*)
% where the non-dimensional boundary layer height is h*=1 and dpdx=1 is the
% driving pressure gradient. Multiply the three velocity components from
% the datasets (in the subgroups u/, v/ and w/) with the scaling factor 
% u_tau to have a physical velocity field. The time step also needs to be 
% scaled with respect to reference speed and length (ABL height) 

% Tuning parameters
z_ref = 100; % Reference height in [m]
U_ref = 8; % Reference velocity in [m/s] at reference height
h = 1000; % Boundary layer height
u_tau = U_ref*0.4/log(z_ref/0.1);
deltat = dt*h/u_tau;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ------------------------ %
%   VELOCITY FIELD PLOTS   %
% ------------------------ %

%% Plot 1. 3D velocity field (axial component u)

% Axis and figure definition (size in centimeters)
% > Create figure
fig = figure(1);
fig.Units = 'centimeters';
fig.Position(1:4) = [1 1 16 10]; %[left bottom width height];
ax1 = axes('units', 'centimeters', 'position', [2 1 11 8]);

for k = 1:100:Nt

    % Load fields
    sgrpname = [groupname,'u/'];
    dsetname = ['field_t_',num2str(time(k),'%10.8f')];
    data = h5read(filename,[sgrpname,dsetname]);
    V = permute(data,[2,1,3,4]);
    
    % Plot 3D slices
    figure(1)
    slice(X,Y,Z,V(:,:,:,1),[xvec(end)],[yvec(end)],[zvec(1)])

    % Plot layout
    caxis([0 25])
    shading interp
    axis equal
    cb = colorbar;    
    cb.Location = 'manual';
    cb.Units = 'centimeters';
    cb.Position = [13 2 0.5 6];
    cb.Label.String = 'U [-]';
    cb.FontSize = 12;
    xlabel('X [m]')
    ylabel('Y [m]')
    zlabel('Z [m]')
    title(['Non-dimensional U field at time t = ',num2str(time(k), '%10.6f')])
    box on
    ax = gca;
    ax.BoxStyle = 'full';
    set(gca,'XLim',[0 Lx],'XTick',[linspace(0,Lx,5)])
    set(gca,'YLim',[-Ly/2 Ly/2],'YTick',[linspace(-Ly/2,Ly/2,3)])
    set(gca,'ZLim',[0 1000],'ZTick',[linspace(0,1000,5)])
    set(gca,'FontSize', 12)

    % Pause
    pause(0.1)

end

% Save figure
saveas(gcf,'subdomain','png')

%%
% Plot 2. 2D velocity fields (scaled axial component u)

% Axis and figure definition (size in centimeters)
% > Size of first subplot
h1 = 5;
l1 = 2;
b1 = 2;
w1 = Lx/Lz*h1;
% > Size of second subplot
l2 = l1 + w1 + l1;
b2 = b1;
w2 = Ly/Lz*h1;
h2 = h1;
% > Picture size
hfig = h1 + 2*b1;
wfig = ceil(l2 + w2) + 4; 
% > Create figure
fig = figure(2);
fig.Units = 'centimeters';
fig.Position(1:4) = [1 1 wfig hfig]; %[left bottom width height];
% > Create axes
ax1 = axes('units', 'centimeters', 'position', [ l1, b1, w1, h1]);
ax2 = axes('units', 'centimeters', 'position', [ l2, b2, w2, h2]);

for k = 1:100:Nt

    % Load fields
    sgrpname = [groupname,'u/'];
    dsetname = ['field_t_',num2str(time(k),'%10.8f')];
    data = h5read(filename,[sgrpname,dsetname]);
    V = u_tau*permute(data,[2,1,3,4]);
    
    % Rearrange arrays (subplot 1) 
    Xp1 = squeeze(X(1,:,:));
    Zp1 = squeeze(Z(1,:,:));
    Vp1 = squeeze(V(1,:,:));

    % Rearrange arrays (subplot 2)
    Yp2 = squeeze(Y(:,1,:));
    Zp2 = squeeze(Z(:,1,:));
    Vp2 = squeeze(V(:,1,:));
    
    % Color scale
    if (k == 1)
        Vmax = max(max(max(V)));
        if ( mod( floor(Vmax), 2 ) ~= 0 )
            Vmax = floor(Vmax + 1);
        else
            Vmax = floor(Vmax);
        end
    end
    
    % Plot in XZ-plane (y = 0)
    figure(2)
    subplot(ax1) 
    pcolor( Xp1, Zp1, Vp1)
    xlabel('X [m]')
    ylabel('Z [m]')
    caxis([0 Vmax])
    shading interp
    set(gca,'XLim',[0 Lx],'XTick',[linspace(0,Lx,5)])
    set(gca,'YLim',[0 1000],'YTick',[linspace(0,1000,5)])
    set(gca,'FontSize', 12)
    
    % Plot in YZ-plane (x = Lx)
    figure(2)
    subplot(ax2) 
    pcolor( Yp2, Zp2, Vp2)
    xlabel('Y [m]')
    ylabel('Z [m]')
    caxis([0 Vmax])
    shading interp
    set(gca,'XLim',[-Ly/2 Ly/2],'XTick',[linspace(-Ly/2,Ly/2,3)])
    set(gca,'YLim',[0 1000],'YTick',[linspace(0,1000,5)])
    set(gca,'FontSize', 12)
    
    % Colorbar
    cb = colorbar;
    cb.Location = 'manual';
    cb.Units = 'centimeters';
    cb.Position = [l2+w2+1, b2, 0.5, h2];
    cb.Label.String = 'U [m/s]';
    cb.FontSize = 12;
    
    %
    t_str = ['Velocity U at time t = ',num2str((k-1)*deltat,'%6.4f'),' sec. in XZ- and YZ-plane'];
    title(t_str)
    set(get(gca,'title'),'Units','centimeters','Position',[-1 6])
    
    % Pause
    pause(0.1)
    
end

% Save figure
saveas(gcf,'planes','png')
