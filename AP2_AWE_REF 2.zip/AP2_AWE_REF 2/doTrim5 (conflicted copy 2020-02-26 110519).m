clear all
close all
clc
addpath(genpath('AWESTRIM/'));
addpath('Visualization_Offline/'); 
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams();
a_booth_vec = 0.5 : 0.25 : 2;
for z = 1 : length(  a_booth_vec )
    params.a_booth = a_booth_vec(z);
    params.b_booth = 180;
    params.phi0_booth = 30*pi/180;
    
    windDirection_rad = ENVMT.windDirection_rad;
    %%
    initValues.l_tether = 250;
    l_tether = initValues.l_tether;
   drawBooth2;axis equal;
    vel_w_W = [12;0;0];
    initValues.Lbooth = Lbooth;
    initValues.phi_t=0;
    initValues.theta_t=0;
    omega_OB_init = zeros(3,1);
    initValues.beta  = 0;
    initValues.alpha = 10*pi/180;
    
    v_w_x_vec = 15;
    
    s = 3/2*pi; %2*pi : -pi/6 : pi;
    s( s == 0 ) = [];
    s( s == pi ) = [];
    initValues.Ft_trim = 1800;
    initValues.Va=30;
    initValues.CurvedFlightFlag = 1;
    initValues.chi_tau_trim_norm = -1.255;
    
    %% Boundary conditions: Maximum dynamic pressure
    for n = 1 : length(v_w_x_vec)
        vel_w_W = [v_w_x_vec(n);0;0];
        
        [long, lat] = setUpInitValuesForPathTrim(params, initValues,s);
        
        [ ops_st, rps_st, saveStruct, ss_long, ss_lat, G_save, ss_tot] = doTrimming3(constr, initValues,vel_w_W, ENVMT.windDirection_rad, long, lat, s);
        
        disp('Finished trimming and linearizing.');
        
        %if 0
        %%
        if 1
            for idx =1 :length(s)
                
                A =  G_save{idx}.A(2:9,2:9);
                B =  G_save{idx}.B(2:9,1:3);
                draw_matrix_with_col_and_numbs(10, G_save{idx}.A(2:9,2:9), size(G_save{idx}.A(2:9,2:9),1) , size(G_save{idx}.A(2:9,2:9),2) );
                % draw_matrix_with_col_and_numbs( ss_long{idx}.A(2:end,2:end), size(ss_long{idx}.A(2:end,2:end),1) , size(ss_long{idx}.A(2:end,2:end),2) );
                xticks([1:9]);
                yticks([1:9]);
                %xticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
                %yticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
                xticklabels({'\beta','\alpha','\Phi_{\tau}', '\Theta_{\tau}', '\Psi_{\tau}', 'p', 'q', 'r'});
                yticklabels({'$\dot{\beta}$','\dot{\alpha}','\dot{\Phi}_{\tau}', '\dot{\Theta}_{\tau}', '\dot{\Psi}_{\tau}', '\dot{p}', '\dot{q}', '\dot{r}'});
                
                %xticklabels({'\alpha', '\Theta_{\tau}', 'q'});
                %yticklabels({'\alpha', '\Theta_{\tau}', 'q'});
                set(gca,'xaxisLocation','top')
                fprintf('idx: %.02f | position: %.02f\n',idx, s(idx) );
                1;
            end
        end
        %end
        %%
        %     draw_matrix_with_col_and_numbs( ss_long{1}.B, size(ss_long{1}.B,1), size(ss_long{1}.B,2)  );
        %     xticks([1]);
        %     yticks([1:5]);
        %     yticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
        %     xticklabels({'\delta_e'});
        %     set(gca,'xaxisLocation','top')
        %%
        for j = 1 : numel( ss_tot )
            C = zeros(3,8);
            C(1,1) = 1;
            C(2,2) = 1;
            C(3,3) = 1;
            sys = ss(  ss_tot{j}.A(2:9,2:9),  ss_tot{j}.B(2:9,1:4), C, [] );
            G_tot = tf( sys );
            G{j} = G_tot(1:3,1:3);
            Gd{j} = G_tot(1:3,4);
            figure(2);
            pzmap(G{j}); hold on
            
            %
            omegas = linspace( 0 , 50 , 1e4 );
            [De, Du, Dd] = scalingMatrices( constr, act );
            G_scaled = inv(De)*G{j}*Du;
            Gd_scaled = inv(De)*Gd{j}*Dd;
            
            G_scaled_min = minreal( G_scaled );
            Gd_scaled_min = minreal( Gd_scaled );
            Msmin(j) = calcSensitivityPeaks(G_scaled_min);
            % figure;
            % pzmap( G_scaled_min );
            
            frequ_resp = freqresp( G_scaled, omegas );
            for k = 1 : length( omegas )
                [U,S,V] = svd( frequ_resp(:,:,k) );
                min_sv(k) = S(end, end);
                max_sv(k) = S(1, 1);
                condi_sv(k) =max_sv(k)./ min_sv(k);
            end
            figure(3);
            subplot(211);
            semilogx( omegas,  max_sv); hold on
            ylabel('\sigma_{max} (G)');
            subplot(212);
            semilogx( omegas,  min_sv ); hold on
             ylabel('\sigma_{min}(G)');
            %subplot(313);
           % semilogx( omegas, condi_sv); hold on
           % ylabel('\kappa(G)');
            xlabel('\omega (rad/s)');
            drawnow;
            if max( condi_sv ) > 1000
                Gtest=evalfr( G_scaled, 0 );
                [U,S,V] = svd(Gtest);
                
                u_test = V(:,3); % input in direcion of smallest SV
                u_test_p = u_test+0.01*V(:,1); % ouput change in direction of largest SV
                (Gtest*u_test)./(Gtest*u_test_p)
                
                %(Gtest*1.1*u_test)
                
            end
            %     figure(4);
            %     bodemag( G_scaled ) ; hold on
        end
    end
%%
end
%%
idx = 1; 
[De, Du, Dd] = scalingMatrices( constr, act ); 
G_scaled = inv(De)*G{idx}*Du; 
Gd_scaled = inv(De)*Gd{idx}*Dd; 

G_scaled_min = minreal( G_scaled ); 
Gd_scaled_min = minreal( Gd_scaled ); 
Msmin = calcSensitivityPeaks(G_scaled_min);
% figure; 
% pzmap( G_scaled_min ); 

frequ_resp = freqresp( G_scaled, omegas );
for n = 1 : length( omegas )
   [U,S,V] = svd( frequ_resp(:,:,n) );
   min_sv(n) = S(end, end);
   max_sv(n) = S(1, 1);
end
figure(3); 
plot( omegas, max_sv./min_sv ); hold on 



[RGAw, RGA, RGAno,RGAno2, omega] = getRGA( G );
plotRGAStuff( RGA );
1;
%%
z = zero(G); 
p = pole(G); 
%% Some analyis stuff
if 0
    %%
    
end
if 0%%
    pause;
    % for cnt = 1 : cntr-1
    %     %figure;
    %     %title(['abs(A), ', 'Pos: ', num2str(s(cnt)/pi), '\pi']); hold on
    %     Acmpl =  G_save{cnt}.A(1:9,1:9);
    %     %graphicalRepCoupling;
    %     save(['Acmpl_', num2str(cnt)]);
    %     %print([eval('pwd'),'/AWESTRIM/','coupling_',num2str(cnt)], '-dpng', '-r300');
    % end
    %%
    plotAMatrix; % + corresponding position on path
    
    %% ==================================================================================================================================
    pause;
    if 1; % complete (not long/lat) decoupled
        %for l = 1 : cntr-1
        Acmpl = G_save{l}.A(1:11, 1:11);
        Bcmpl = G_save{l}.B(1:11, 1:4);
        [V,D] =  eig(Acmpl);
        lmbds =  diag(D);
        myColorOrder = [228,26,28;
            55,126,184;
            77,175,74;
            152,78,163;
            255,127,0;
            0,0,0;
            166,86,40;
            247,129,191;
            153,153,153]./255;
        
        %
        %color = myColorOrder(l,:);
        %%
        drawEVStar(V(:,1),1, myColorOrder, 'Roll');
        drawEVStar(V(:,2),2, myColorOrder, 'Short Period');
        drawEVStar(V(:,4),4, myColorOrder, 'Dutch Roll');
        drawEVStar(V(:,6),6, myColorOrder, 'Phygoide');
        drawEVStar(V(:,8),8, myColorOrder, 5);
        drawEVStar(V(:,10),10, myColorOrder, 6);
        drawEVStar(V(:,11),11, myColorOrder, 7);
        
        figure;
        plot(lmbds(1:12), '*'); hold on
        %%
        %        for z = 9 : 12
        %            drawEVStar(V(:,z),z,'--');
        %        end
        %end
    else
        for l = 1 : cntr-1
            [V,D] =  eig(A_lat{l});
            lmbds =  diag(D);
            figure(3);
            title('Lateral modes'); hold on
            plot( diag(D), '+'); hold on
            
            myColorOrder = [228,26,28;
                55,126,184;
                77,175,74;
                152,78,163;
                255,127,0;
                0,0,0;
                166,86,40;
                247,129,191;
                153,153,153]./255;
            
            %for l = 1 : cntr-1
            color = myColorOrder(l,:);
            figure(4);
            v1 = V(:,1)/norm(V(:,1));
            title('Rollmode'); hold on
            for m = 1 : length(v1)
                quiver(0,0, real(v1(m)), imag(v1(m)),1, 'linewidth', 2, 'color',color); hold on
                % legend('Va', '\alpha', '\Theta_t', 'q');
                legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
            end
            axis equal;
            
            figure(5);
            v2 = V(:,2)/norm(V(:,2));
            title('Dutch Roll'); hold on
            for m = 1 : length(v2)
                quiver(0,0, real(v2(m)), imag(v2(m)),1, 'linewidth', 2, 'color',color); hold on
                legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
            end
            axis equal;
            
            figure(6);
            v3 = V(:,4)/norm(V(:,4));
            title('Spiralmode?'); hold on
            for m = 1 : length(v2)
                quiver(0,0, real(v3(m)), imag(v3(m)),1, 'linewidth', 2, 'color',color); hold on
                legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
            end
            axis equal;
            
            figure(7);
            v4 = V(:,5)/norm(V(:,5));
            title('\Psi_t mode?'); hold on
            for m = 1 : length(v2)
                quiver(0,0, real(v4(m)), imag(v4(m)),1, 'linewidth', 2, 'color',color); hold on
                legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
            end
            axis equal;
        end
        
        %% Longitudinal modes
        [V,D] =  eig(A_long{l});
        lmbds =  diag(D);
        
        figure;
        title('Longitudinal modes'); hold on
        for l = 1 : cntr-1
            plot(lmbds, '+'); hold on
        end
        
        figure;
        v1 = V(:,1)/norm(V(:,1));
        title('Short Period'); hold on
        for m = 1 : length(v1)
            quiver(0,0, real(v1(m)), imag(v1(m)),1, 'linewidth', 2); hold on
            legend('Va', '\alpha', '\Theta_t', 'q');
        end
        axis equal;
        
        figure(5);
        v2 = V(:,3)/norm(V(:,3));
        title('Phygoide'); hold on
        for m = 1 : length(v2)
            quiver(0,0, real(v2(m)), imag(v2(m)),1, 'linewidth', 2); hold on
            legend('Va', '\alpha', '\Theta_t', 'q');
        end
        axis equal;
        
    end
end