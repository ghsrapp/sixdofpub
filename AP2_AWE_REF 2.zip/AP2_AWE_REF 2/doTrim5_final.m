clear all
close all
clc
try 
    bdclose('AWES3')
end
addpath(genpath('AWESTRIM/'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];

initValues.CurvedFlightFlag = 1;

cnt = 2;

[act, aeroModel, base_windspeed, constr, crosswind_speed,...
    ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
    requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams();
%%
a_booth_vec = 0.5; %0.5; %[0.5, 0.75, 1];
b_booth_vec = 160; %160; %[120, 160, 200];
phi0_booth_vec = 35*pi/180; %[30, 45, 60]*pi/180;%[30, 45, 60]*pi/180;
Va_vec = 12.5;%20 : 2.5 : 40;
Ft_vec = 1400; %400 : 400 : 1800;
initValues.Va  = 30;

alpha_save_all = [];
phi_save_all = [];
v_reel_save_all = [];
v_a_save_all = [];

save_plots = 1;
plot_flag = 1;
for z = 1 : length(  a_booth_vec )
    for zz = 1 : length(  a_booth_vec )
        for zzz = 1 : length(  a_booth_vec )
            % initValues.Va= Va_vec(zzzz);
            v_w_vec =  12.5;%[5,12.5,20];
            initValues.l_tether = 400;
            l_tether = initValues.l_tether;
            drawBooth2;axis equal;
            close all
            h1 = figure(1);
            h2 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
            h3 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
            h4 = figure('Renderer', 'painters', 'Position', [0 0 300 200]);
            windDirection_rad = ENVMT.windDirection_rad;
            svec = linspace(pi,2*pi, 21);
            svec(1) = [];
            svec = 2*pi;
            for s_idx = 1 : length(svec)
                s = svec(s_idx);
                cnt = s_idx; % for saving
                for idx_ft = 1 : length( Ft_vec )
                    % for idx_ft = 1 : length( phi0_booth_vec )
                    %  Ft = Ft_vec(1);
                    Ft = Ft_vec(idx_ft);
                    
                    v_w_x_vec = v_w_vec(1);
                    params.phi0_booth =  phi0_booth_vec(1);
                    
                    for idx = 1 : length(v_w_vec)
                    v_w_x_vec = v_w_vec(idx);
                    
                    %for idx = 1 : length(phi0_booth_vec)
                     %   params.phi0_booth =  phi0_booth_vec(idx);

                        params.a_booth = a_booth_vec(z);
                        params.b_booth = b_booth_vec(zz);
                        fprintf('a = %.2f | b = %.2f | phi = %.2f\n', params.a_booth, params.b_booth, params.phi0_booth)
                        %%
                        
                        vel_w_W = [12;0;0];
                        initValues.Lbooth = Lbooth;
                        initValues.phi_t=0;
                        initValues.theta_t=0;
                        omega_OB_init = zeros(3,1);
                        initValues.beta  = 0;
                        initValues.alpha = 8*pi/180; %0*pi/180; % max. CL/CD
                        
                        
                        
                        %linspace(2*pi,pi,10); %[3/2*pi];
                        % s( s == 0 ) = [];
                        % s( s == pi ) = [];
                        initValues.Ft_trim = 1600; %1800;
                        %0.9*sqrt(initValues.Ft_trim); %sqrt(   initValues.Ft_trim ) ;
                        initValues.chi_tau_trim_norm = -1.255;
                        if v_w_x_vec > 12
                            v_ro_set = v_w_x_vec*0.3;
                        else
                            v_ro_set = v_w_x_vec*0.3;
                        end
                        
                        vel_w_W = [v_w_x_vec(1);0;0];
                        [long, lat] = setUpInitValuesForPathTrim(params, initValues,s);
                        
                        [ops_st, rps_st, saveStruct, ss_long, ss_lat, G_save, ss_tot, x0_save, u0_save, M_OB_init, gamma_tau, p_mech, term_string, v_reeling,Ft_vec,AoA_vec] = ...
                            setAndSolveTrimProblem(params, constr, initValues,vel_w_W, ENVMT.windDirection_rad, long, lat, s, v_ro_set, Va_vec, Ft, act);
                        
                        alpha_reshaped = reshape( x0_save(3,:), length(AoA_vec), length( Ft_vec ) );
                        Va_reshaped = reshape( x0_save(1,:), length(AoA_vec), length( Ft_vec ) );
                        v_reeling_reshaped = reshape( v_reeling, length(AoA_vec), length( Ft_vec ) );
                        
                        p_OB_reshaped = reshape( x0_save(7,:), length(AoA_vec), length( Ft_vec ) );
                        q_OB_reshaped = reshape( x0_save(8,:), length(AoA_vec), length( Ft_vec ) );
                        r_OB_reshaped = reshape( x0_save(9,:), length(AoA_vec), length( Ft_vec ) );

                        delta_a_reshaped = reshape( u0_save(1,:), length(AoA_vec), length( Ft_vec ) );
                        delta_e_reshaped = reshape( u0_save(2,:), length(AoA_vec), length( Ft_vec ) );
                        delta_r_reshaped = reshape( u0_save(3,:), length(AoA_vec), length( Ft_vec ) );

                        if plot_flag
                            k_max = length( Ft_vec );
                            for k = 1 : k_max
                                
                                if idx == 1
                                    col_ = col1;
                                elseif idx == 2
                                    col_ = col2;
                                elseif idx == 3
                                    col_ = col3;
                                end
                                
                                lw = 1.2;
                                
                                alpha_high = 0.3;
                                alpha_low = 1;
                                
                                k_max = numel( Ft_vec );
                                if k_max == 1
                                    a_mks = 1;
                                else
                                    a_mks = (k-1)/(k_max-1);
                                end
                                alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
                                %% Adding the quasi-steady solutions to it: rows are results for different reeling speeds  
                                [Ft_tmp, va_est_tmp] = get_quasi_steady_ft_va(alpha_reshaped(:,k), P_AP2, T, v_reeling_reshaped(:,k),...
                                    v_w_x_vec(1), 35*pi/180, 400);
                                Ft_tot_qs(:,k) = Ft_tmp;
                                va_tot_qs(:,k) = va_est_tmp';

                                %% Plots 
                                h2=figure(2);
                                b_h = plot( alpha_reshaped(:,k)*180/pi, Va_reshaped(:,k), '-', 'color', col_, 'Linewidth', lw); hold on; drawnow
                                b_h.Color(4) = alpha_lvl;
                                plot( alpha_reshaped(:,k)*180/pi, Va_reshaped(:,k), 'x', 'color', 'k'); hold on; drawnow
                                xlabel('$\alpha$ $(deg)$');
                                ylabel('$v_a$ $(m/s)$');
                                
                                h3=figure(3);
                                b_h=plot( alpha_reshaped(:,k)*180/pi, v_reeling_reshaped(:,k), '-', 'color', col_, 'Linewidth', lw); hold on; drawnow
                                b_h.Color(4) = alpha_lvl;
                                xlabel('$\alpha$ $(deg)$');
                                ylabel('$v_r$ $(m/s)$');
                                
                                %%                                 
                            end
                         %   compare_qs_with_trim_plot( Ft_vec, alpha_reshaped, Va_reshaped, va_tot_qs,Ft_tot_qs );
                        end
                    end
                end
                
                if isempty(ops_st)
                    folder_name = ['case_',num2str(cnt)];
                    cnt = cnt + 1;
                    if ~exist(folder_name)
                        cd Trim_results
                        mkdir( folder_name );
                    end
                    not_converged = [  params.a_booth,  params.b_booth,  params.phi0_booth, v_w_x_vec, initValues.Ft_trim/1000, initValues.Va];
                    save([folder_name,'/not_converged.mat'], 'not_converged');
                    cd ..
                else
                    %%
                    if 1
                        for k = 1 : numel( rps_st )
                            [K_lat, K_long, A_tot, B_tot, Ks, A_long, A_lat, B_long, B_lat, B_long_wFt] = lqr_w_psi_wVa_test_decoupled(G_save{k});
                            % Gd_scaled = extractDisturbanceGd( A_long, B_long_wFt , constr, act  );
                            % analyse_closed_loop_performance( A_long, B_long, eye( size(A_long,1) ), [0, 1, 0, 0], K_long );
                            % Gd_scaled_s{k} = Gd_scaled;
                            K_delta_e(k,:) = K_long(1,:);
                            K_delta_a(k,:) = K_lat(1,:);
                            K_delta_r(k,:) = K_lat(2,:);
                            A_long_s{k} = A_long;
                            A_lat_s{k} = A_lat;
                            B_long_s{k} = B_long;
                            B_lat_s{k} = B_lat;
                            Ks_save{k} = Ks;
                            K_delta_tot_a(k,:) = Ks(1,:);
                            K_delta_tot_e(k,:) = Ks(2,:);
                            K_delta_tot_r(k,:) = Ks(3,:);
                            A_tot_s{k} =  G_save{k}.A(1:9,1:9);
                            B_tot_s{k} =  G_save{k}.B(1:9,1:3);
                        end
                        sim_with_indx = 1 ;
                        K_long = K_delta_e(sim_with_indx,:);
                        K_lat = [K_delta_a(sim_with_indx,:);...
                            K_delta_r(sim_with_indx,:)];
                        %Ks = Ks_save{sim_with_indx};
                        
                        x0_trim = x0_save(:,sim_with_indx);
                        u0_trim = u0_save(:,sim_with_indx);
                        
                        sim_with_indx = 1;%length(s);
                        x0_sim = x0_save(:,sim_with_indx);
                        u0_sim = u0_save(:,sim_with_indx);
                        Lbooth.init_sol = s(sim_with_indx);
                        A_long_design = A_long_s{1};
                        B_long_design = B_long_s{1};
                        M_OB = M_OB_init{sim_with_indx};
                    end
                    cd('Trim_results');
                    
                    folder_name = ['case_',num2str(cnt)];
                    cnt = cnt + 1;
                    if ~exist(folder_name)
                        mkdir( folder_name );
                    end
                    save([folder_name,'/G_save.mat'], 'G_save');
                  %   save([folder_name,'/A_tot_s.mat'], 'A_tot_s');
                   %  save([folder_name,'/B_tot_s.mat'], 'B_tot_s');
                    % save([folder_name,'/A_long_s.mat'], 'A_long_s');
                    % save([folder_name,'/B_long_s.mat'], 'B_long_s');
                    % save([folder_name,'/A_lat_s.mat'], 'A_lat_s');
                    % save([folder_name,'/B_lat_s.mat'], 'B_lat_s');
                    % save([folder_name,'/params.mat'], 'params');
                    % save([folder_name,'/initValues.mat'], 'initValues');
                    save([folder_name,'/x0_save.mat'], 'x0_save');
                    save([folder_name,'/u0_save.mat'], 'u0_save');
                    % save([folder_name,'/p_mech.mat'], 'p_mech');
                    save([folder_name,'/rps_st.mat'], 'rps_st');
                    %   save([folder_name,'/term_string.mat'], 'term_string');
                    save([folder_name,'/s.mat'], 's');
                    save([folder_name,'/M_OB_init.mat'], 'M_OB_init');
                    %  converged = [params.a_booth, params.b_booth, params.phi0_booth, v_w_x_vec, initValues.Ft_trim/1000, initValues.Va];
                    %  save([folder_name,'/converged.mat'], 'converged');
                    cd ..
                end
            end
        end
    end
end



cd(['Trim_results/']);
if save_plots
    %Plot2LaTeX2(h2,'v_a_over_alpha_trim_35phi_b250_a08');
    %Plot2LaTeX2(h3,'v_r_over_alpha_trim_35phi_b250_a08');
    Plot2LaTeX2(h2,'v_a_over_alpha_trim_35phi_b250_a08_gridPoints');
    Plot2LaTeX2(h3,'v_r_over_alpha_trim_35phi_b250_a08_gridPoints');
end
cd ..


if 0
    %sim('test_coupled');
    %  K1 = hinf_design( )
    % load('K1_red');
    % disp('Finished trimming and linearizing.');
    %%
    %if 0
    %%
    if 0
        %%
        for idx =1 :length(s)
            set(groot,'defaultAxesTickLabelInterpreter','latex');
            A =  G_save{idx}.A(2:9,2:9);
            B =  G_save{idx}.B(2:9,1:3);
            draw_matrix_with_col_and_numbs(10, G_save{idx}.A(2:9,2:9), size(G_save{idx}.A(2:9,2:9),1) , size(G_save{idx}.A(2:9,2:9),2) );
            % draw_matrix_with_col_and_numbs( ss_long{idx}.A(2:end,2:end), size(ss_long{idx}.A(2:end,2:end),1) , size(ss_long{idx}.A(2:end,2:end),2) );
            xticks([1:9]);
            yticks([1:9]);
            %xticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
            %yticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
            xticklabels({'$\beta$','$\alpha$','$\Phi_{\tau}$', '$\Theta_{\tau}$', '$\Psi_{\tau}$', '$p$', '$q$', '$r$'});
            yticklabels({'$\dot{\beta}$','$\dot{\alpha}$','$\dot{\Phi}_{\tau}$',...
                '$\dot{\Theta}_{\tau}$', '$\dot{\Psi}_{\tau}$', '$\dot{p}$', '$\dot{q}$', '$\dot{r}$'});
            
            %xticklabels({'\alpha', '\Theta_{\tau}', 'q'});
            %yticklabels({'\alpha', '\Theta_{\tau}', 'q'});
            set(gca,'xaxisLocation','top')
            fprintf('idx: %.02f | position: %.02f\n',idx, s(idx) );
            1;
        end
    end
    
    %end
    %%
    %     draw_matrix_with_col_and_numbs( ss_long{1}.B, size(ss_long{1}.B,1), size(ss_long{1}.B,2)  );
    %     xticks([1]);
    %     yticks([1:5]);
    %     yticklabels({'V_a', '\alpha', '\Theta_{\tau}', 'q'});
    %     xticklabels({'\delta_e'});
    %     set(gca,'xaxisLocation','top')
    %%
    
    
    %% Instead of using the complete SS use the long lat models and test
    for j = 1 : numel( G_save )
        C = zeros(4,9);
        C(1,1) = 1;
        C(2,2) = 1;
        C(3,3) = 1;
        C(4,4) = 1;
        %             sys = ss(  ss_tot{j}.A(2:9,2:9),  ss_tot{j}.B(2:9,1:4), C, [] );
        %
        
        A = G_save{j}.A(1:9, 1:9);
        B = G_save{j}.B(1:9, 1:4);
        
        A_long = [A(1,1), A(1,3), A(1, 5), A(1,8);
            A(3,1), A(3,3), A(3, 5), A(3,8);
            A(5,1), A(5,3), A(5, 5), A(5,8);
            A(8,1), A(8,3), A(8, 5), A(8,8)];
        
        A_long_s = [A(1,1), A(1,3), A(1, 5), A(1,8), 0;
            A(3,1), A(3,3), A(3, 5), A(3,8), 0;
            A(5,1), A(5,3), A(5, 5), A(5,8), 0;
            A(8,1), A(8,3), A(8, 5), A(8,8), 0;
            0, -1, 0, 0, 0];
        %B_long = [B(1,2),B(1,4);B(3,2),B(3,4);B(5,2),B(5,4);B(8,2),B(8,4)];
        B_long = [B(1,2);
            B(3,2);
            B(5,2);
            B(8,2)];
        B_long_s = [B(1,2);
            B(3,2);
            B(5,2);
            B(8,2);
            0];
        
        C_long = [0,1,0,0];
        
        A_lat = [A(2,2), A(2,4), A(2, 6), A(2,7), A(2,9);
            A(4,2), A(4,4), A(4, 6), A(4,7), A(4,9);
            A(6,2), A(6,4), A(6, 6), A(6,7), A(6,9);
            A(7,2), A(7,4), A(7, 6), A(7,7), A(7,9);
            A(9,2), A(9,4), A(9, 6), A(9,7), A(9,9)];
        
        A_lat_s = [A_lat, zeros(5,2);
            [-1, zeros(1,6); 0, -1, zeros(1,5)]];
        
        B_lat = [B(2,1),B(2,3);...
            B(4,1),B(4,3);...
            B(6,1),B(6,3);...
            B(7,1),B(7,3);...
            B(9,1),B(9,3)];
        
        B_lat_s = [B_lat; zeros(2,2)];
        
        C_lat = zeros(2, 5);
        C_lat(1,1) = 1;
        C_lat(2,2) = 1;
        
        sys_long_s = ss( A_long_s, B_long_s,eye(5), [] );
        sys_long = ss( A_long, B_long,C_long, [] );
        sys_tot = ss( A, B,C, [] );
        sys_lat = ss( A_lat, B_lat,C_lat, [] );
        sys_lat_s = ss( A_lat_s, B_lat_s, eye(7), [] );
        
        % analyse SVs
        % TO-DO: CHECK IF SCALING  IS CORRECT!!!
        
        % close(figure(3));
        G_scaled_min_long = analyseSVsLongi( sys_long,  constr, act, col1 );
        
        omegas = linspace( 0 , 30 , 1e4 );
        S_long_s = inv( eye(5) + tf(sys_long_s)*K_long );
        frequ_resp = freqresp( S_long_s, omegas );
        for k = 1 : length( omegas )
            [U,S,V] = svd( frequ_resp(:,:,k) );
            min_sv(k) = S(end, end);
            max_sv(k) = S(1, 1);
            condi_sv(k) =max_sv(k)./ min_sv(k);
        end
        
        
        %analyzingClosedLoopPerformanceLong( tf(sys_long_s), K_long );
        %analyzingClosedLoopPerformanceLat( tf(sys_lat_s), K_lat );
        
        
        G_scaled_min_lat = analyseSVsLat( sys_lat,  constr, act, col2 );
        G_scaled_min_tot = analyseSVsMIMO( sys_tot,  constr, act, col3 );
        axis normal
        legend('Longi','Lat');
        1;
        
        [RGAw, RGA, RGAno,RGAno2, omega] = getRGA( G_scaled_min_tot );
        plotRGAStuff( RGA , omega );
        
        %
        %             if max( condi_sv ) > 1000
        %                 Gtest=evalfr( G_scaled, 0 );
        %                 [U,S,V] = svd(Gtest);
        %
        %                 u_test = V(:,3); % input in direcion of smallest SV
        %                 u_test_p = u_test+0.01*V(:,1); % ouput change in direction of largest SV
        %                 (Gtest*u_test)./(Gtest*u_test_p)
        %
        %                 %(Gtest*1.1*u_test)
        %
        %             end
        %     figure(4);
        %     bodemag( G_scaled ) ; hold on
    end
    %%
end
% if 0
%     %%
%     idx = 1;
%     [De, Du, Dd] = scalingMatrices( constr, act );
%     G_scaled = inv(De)*G{idx}*Du;
%     Gd_scaled = inv(De)*Gd{idx}*Dd;
%
%     G_scaled_min = minreal( G_scaled );
%     Gd_scaled_min = minreal( Gd_scaled );
%     Msmin = calcSensitivityPeaks(G_scaled_min);
%     % figure;
%     % pzmap( G_scaled_min );
%
%     frequ_resp = freqresp( G_scaled, omegas );
%     for n = 1 : length( omegas )
%         [U,S,V] = svd( frequ_resp(:,:,n) );
%         min_sv(n) = S(end, end);
%         max_sv(n) = S(1, 1);
%     end
%     figure(3);
%     plot( omegas, max_sv./min_sv ); hold on
%
%
%
%     [RGAw, RGA, RGAno,RGAno2, omega] = getRGA( G );
%     plotRGAStuff( RGA );
%     1;
%     %%
%     z = zero(G);
%     p = pole(G);
%     %% Some analyis stuff
%     if 0
%         %%
%
%     end
%     if 0%%
%         pause;
%         % for cnt = 1 : cntr-1
%         %     %figure;
%         %     %title(['abs(A), ', 'Pos: ', num2str(s(cnt)/pi), '\pi']); hold on
%         %     Acmpl =  G_save{cnt}.A(1:9,1:9);
%         %     %graphicalRepCoupling;
%         %     save(['Acmpl_', num2str(cnt)]);
%         %     %print([eval('pwd'),'/AWESTRIM/','coupling_',num2str(cnt)], '-dpng', '-r300');
%         % end
%         %%
%         plotAMatrix; % + corresponding position on path
%
%         %% ==================================================================================================================================
%         pause;
%         if 1; % complete (not long/lat) decoupled
%             %for l = 1 : cntr-1
%             Acmpl = G_save{l}.A(1:11, 1:11);
%             Bcmpl = G_save{l}.B(1:11, 1:4);
%             [V,D] =  eig(Acmpl);
%             lmbds =  diag(D);
%             myColorOrder = [228,26,28;
%                 55,126,184;
%                 77,175,74;
%                 152,78,163;
%                 255,127,0;
%                 0,0,0;
%                 166,86,40;
%                 247,129,191;
%                 153,153,153]./255;
%
%             %
%             %color = myColorOrder(l,:);
%             %%
%             drawEVStar(V(:,1),1, myColorOrder, 'Roll');
%             drawEVStar(V(:,2),2, myColorOrder, 'Short Period');
%             drawEVStar(V(:,4),4, myColorOrder, 'Dutch Roll');
%             drawEVStar(V(:,6),6, myColorOrder, 'Phygoide');
%             drawEVStar(V(:,8),8, myColorOrder, 5);
%             drawEVStar(V(:,10),10, myColorOrder, 6);
%             drawEVStar(V(:,11),11, myColorOrder, 7);
%
%             figure;
%             plot(lmbds(1:12), '*'); hold on
%             %%
%             %        for z = 9 : 12
%             %            drawEVStar(V(:,z),z,'--');
%             %        end
%             %end
%         else
%             for l = 1 : cntr-1
%                 [V,D] =  eig(A_lat{l});
%                 lmbds =  diag(D);
%                 figure(3);
%                 title('Lateral modes'); hold on
%                 plot( diag(D), '+'); hold on
%
%                 myColorOrder = [228,26,28;
%                     55,126,184;
%                     77,175,74;
%                     152,78,163;
%                     255,127,0;
%                     0,0,0;
%                     166,86,40;
%                     247,129,191;
%                     153,153,153]./255;
%
%                 %for l = 1 : cntr-1
%                 color = myColorOrder(l,:);
%                 figure(4);
%                 v1 = V(:,1)/norm(V(:,1));
%                 title('Rollmode'); hold on
%                 for m = 1 : length(v1)
%                     quiver(0,0, real(v1(m)), imag(v1(m)),1, 'linewidth', 2, 'color',color); hold on
%                     % legend('Va', '\alpha', '\Theta_t', 'q');
%                     legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
%                 end
%                 axis equal;
%
%                 figure(5);
%                 v2 = V(:,2)/norm(V(:,2));
%                 title('Dutch Roll'); hold on
%                 for m = 1 : length(v2)
%                     quiver(0,0, real(v2(m)), imag(v2(m)),1, 'linewidth', 2, 'color',color); hold on
%                     legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
%                 end
%                 axis equal;
%
%                 figure(6);
%                 v3 = V(:,4)/norm(V(:,4));
%                 title('Spiralmode?'); hold on
%                 for m = 1 : length(v2)
%                     quiver(0,0, real(v3(m)), imag(v3(m)),1, 'linewidth', 2, 'color',color); hold on
%                     legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
%                 end
%                 axis equal;
%
%                 figure(7);
%                 v4 = V(:,5)/norm(V(:,5));
%                 title('\Psi_t mode?'); hold on
%                 for m = 1 : length(v2)
%                     quiver(0,0, real(v4(m)), imag(v4(m)),1, 'linewidth', 2, 'color',color); hold on
%                     legend('\beta', '\Phi_t', '\Psi_t', 'p', 'r');
%                 end
%                 axis equal;
%             end
%
%             %% Longitudinal modes
%             [V,D] =  eig(A_long{l});
%             lmbds =  diag(D);
%
%             figure;
%             title('Longitudinal modes'); hold on
%             for l = 1 : cntr-1
%                 plot(lmbds, '+'); hold on
%             end
%
%             figure;
%             v1 = V(:,1)/norm(V(:,1));
%             title('Short Period'); hold on
%             for m = 1 : length(v1)
%                 quiver(0,0, real(v1(m)), imag(v1(m)),1, 'linewidth', 2); hold on
%                 legend('Va', '\alpha', '\Theta_t', 'q');
%             end
%             axis equal;
%
%             figure(5);
%             v2 = V(:,3)/norm(V(:,3));
%             title('Phygoide'); hold on
%             for m = 1 : length(v2)
%                 quiver(0,0, real(v2(m)), imag(v2(m)),1, 'linewidth', 2); hold on
%                 legend('Va', '\alpha', '\Theta_t', 'q');
%             end
%             axis equal;
%
%         end
%     end
% end