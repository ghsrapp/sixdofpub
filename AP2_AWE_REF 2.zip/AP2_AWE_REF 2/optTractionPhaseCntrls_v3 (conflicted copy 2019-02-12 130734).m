clear all
close all
clc


% call init script
init_new_AP2;
TSIM = 500; % max. simulation time

FitnessFunction = @(x)costFunctionAP2b(x,maxBandwidth,TSIM, gs, alpha_a_max);

[lb,ub] = initOptParamsBounds();

flag = 1; % if 1 generate random population otherwise use existing population
numPop = 30; 
if 1 
    population = repmat( ub-lb, numPop, 1) .* rand(numPop, length(ub) ) + repmat( lb, numPop, 1);
else % continue optimizing using a current population.
    load('x.mat'); 
    population = repmat(x', numPop, 1 ); 
end

numPop = size( population, 1);
numberOfVariables = size(population,2);

opts = optimoptions('ga', ...
    'UseParallel', false,...
    'PopulationSize', numPop, ...
    'MaxGenerations', 30, ...
    'EliteCount', 1, ...
    'FunctionTolerance', 1e-18, ...
    'PlotFcn', @myPlotFunc, ...
    'InitialPopulation',population);

logOptParams;


%% Launch GA Optimization
[x,fval,exitflag,output,population,scores] = ga(FitnessFunction, numberOfVariables, [],[],[],[], lb,ub, [],[],opts);
if exist(['pop_',date,'.mat']) == 2 
   save(['pop_',date,'_2_.mat'], 'population');
else 
    save(['pop_',date,'.mat'], 'population');
end

if exist(['cntrl_',date,'.mat']) == 2
    save(['cntrl_',date,'_2_.mat'], 'x');
else    
    save(['cntrl_',date,'.mat'], 'x');
end