function [path_k,pos_target_W]  = uTestCircleNav2(pos_O, longlat, CircleParam, nav,  windDirection_rad)


pos_W = transformFromOtoW(windDirection_rad, pos_O );
%pos_W = pos_W/norm(pos_W); 



% Update 
r = CircleParam.radius;%/l_tether;
alpha = asin( r/norm(pos_W) ) ;
d = cos(alpha)*norm(pos_W);

e_c_x = [-sin(CircleParam.mean_elevevation); 0; cos(CircleParam.mean_elevevation)];
e_c_y = [0; 1; 0];
e_c_z = -[cos(CircleParam.mean_elevevation); 0; sin(CircleParam.mean_elevevation)];

M_CW = [e_c_x'; e_c_y'; e_c_z'];
M_WC = M_CW'; 
p_co_W = d*[cos(CircleParam.mean_elevevation);0; sin(CircleParam.mean_elevevation)];

%% Determine point on circle and calculate the course and the path angle to fly towards it

pos_C = M_CW * ( pos_W - p_co_W );
pos_proj_C = [pos_C(1);pos_C(2);0];% - e_c_z*(e_c_z'*pos_C);
pos_target_C = pos_proj_C/norm(pos_proj_C) * r;
pos_target_W = M_CW'*pos_target_C + p_co_W;

[chi_tau_perp,~, bearing_perp_W] = calcBearingToWp(pos_target_W, pos_W);

long = longlat(1);
lat = longlat(2);

% Vector field following
% Determine tangent on curve
s = atan2( pos_target_C(2), pos_target_C(1) );
if CircleParam.clockwise
    t_c = [-sin(s); cos(s); 0];
else
    t_c = [sin(s); -cos(s); 0];
end
target_bearing_W = M_WC * t_c;

target_bearing_tau = transformFromWtoTau(   long,lat, target_bearing_W );
chi_target_tau = atan2( target_bearing_tau(2), target_bearing_tau(1) );

% get commanded course in tangential plane depending on the distance of the
% kite to the target
%delta = acos( min( max( pos_W'/norm(pos_W) * pos_target_W/norm(pos_target_W), -1),1 ) ) * l_tether;
delta = acos( min( max( pos_W'/norm(pos_W) * pos_target_W/norm(pos_target_W), -1),1 ) )*norm(pos_W);

[Chi_t_cmd,Delta_chi] = calculateCommandedCourse(target_bearing_W,bearing_perp_W, delta, CircleParam.d0, chi_target_tau, pos_target_W, pos_W);

[bearing_W] = calculateCmdBearing(Chi_t_cmd,nav.gamma_t_cmd, pos_W);
bearing_W = bearing_W'/norm(bearing_W);

% Transform bearing vector into O frame (represents the desired
% velocity vector in the O frame.
[bearing_O] = transformFromWtoO(windDirection_rad,bearing_W');
bearing_O = bearing_O/norm(bearing_O);

% Calculate Course and Flightpath angle (common aerospace definition -
% between K and O frame)
Gamma_cmd = -asin( bearing_O(3)/norm(bearing_O) );
Chi_cmd = atan2( bearing_O(2), bearing_O(1) );

path_k = [Chi_cmd; Gamma_cmd];


