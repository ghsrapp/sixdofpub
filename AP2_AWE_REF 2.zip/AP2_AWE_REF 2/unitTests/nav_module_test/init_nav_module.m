clear 
close all
clc

initLissajous;
windDirection_rad = pi;% if equals pi = wind is blowing south.