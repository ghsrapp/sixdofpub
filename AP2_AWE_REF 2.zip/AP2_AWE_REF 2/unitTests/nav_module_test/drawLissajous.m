[ LemPs ] = updateLissajous( l_tether, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;

theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';

L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];

figure(1);
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];

L_W_k = L_W * l_tether;
Delta0 = 0.5 * max( L_W_k(2,: ) );
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;
axis equal; grid on;hold on; view(90,0);

theta_point = pi/2;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];
L_W_k = L_W * 200;
if 0
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), '*r'); hold on;
% horizontal reference line
p_end = [0; L_W_k(2); L_W_k(3) ];
plot3( [L_W_k(1) p_end(1)],[L_W_k(2) p_end(2)],[L_W_k(3) p_end(3)],'-k')
%% Test point
theta_point = -0.1;%1.2*pi;%sol_init;
L = [Alambda * sin(blambda*theta_point');
    Aphi    * sin(bphi*theta_point') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];
test = L_W * 200;
plot3(test(1,:), test(2,:),test(3,:), '+m'); hold on;
% desired course 
if test(2) > 0
chi_cmd = pi - atan2(abs(2*Delta0-test(2,:)), Delta0 );
else
chi_cmd = -pi + atan2( 2*Delta0-abs(test(2,:)), Delta0 );
end   
% bearing 
bearing_ = [cos(chi_cmd);sin(chi_cmd);0]*20;
plot3( [test(1) test(1)+bearing_(1)],[test(2) test(2)+bearing_(2)],[test(3) test(3)+bearing_(3)],'-b' );

end

