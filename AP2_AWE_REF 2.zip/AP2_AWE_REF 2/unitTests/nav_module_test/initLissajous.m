%% Defines the geometrical properties of the figure of 8
l_tether = 200; 
LemPsRef.AlambdaRef = 100;
LemPsRef.factor = 4.5; 
LemPsRef.AphiRef = LemPsRef.AlambdaRef/LemPsRef.factor;
LemPsRef.blambdaRef = 1;
LemPsRef.bphiRef = 2;
LemPsRef.phi0 = 30*pi/180;
LemPsRef.c0 = pi/4;
LemPsRef.deltaSol = 0.1;


