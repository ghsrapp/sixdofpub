function [ sol,p_C_W ] = getTargetOnLissajous(LemPs, p_kite_W, c0, l_tether)
%GETVTONLEMNISCATE Summary of this function goes here
%   Detailed explanation goes here
p_kite_W = p_kite_W/norm(p_kite_W); 
%intervalInit = [c0-pi/8, c0+pi/8 ];
intervalInit = [c0-pi/8, c0+pi/8];



% use a bisection method to compute closest point on path relative to kite
% position.
[ sol, res, f ] = bisec( intervalInit, p_kite_W, LemPs, c0 );

sol = mod(sol, 2*pi);

L = [LemPs.Alambda * sin(LemPs.blambda*sol');
    LemPs.Aphi    * sin(LemPs.bphi*sol') + LemPs.phi0];

p_C_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
end