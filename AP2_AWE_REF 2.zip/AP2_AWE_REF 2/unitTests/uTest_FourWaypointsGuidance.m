clear all
close all
clc 

windDirection_rad = pi; 

lat = 45 * pi/180;
long = 0 * pi/180;
p_W = [cos(lat)*cos(long); cos(lat)*sin(long); sin(lat)];

initFourWps;

figure;
plot3( wp_plot(1,1), wp_plot(1,2), wp_plot(1,3), 'ob'); hold on
plot3( wp_plot(2,1), wp_plot(2,2), wp_plot(2,3), 'ob');
plot3( wp_plot(3,1), wp_plot(3,2), wp_plot(3,3), 'ob');
plot3( wp_plot(4,1), wp_plot(4,2), wp_plot(4,3), 'ob');
view(90,30); axis equal;
drawnow; 

l = l_init;
p_W = p_W * l;

%% "Simulator"
for n = 1 : 1000
    
    p_W = p_W/norm(p_W);
    phi = asin( p_W(3) );
    lamb = atan2( p_W(2), p_W(1) );
    
    M_tauW = [-sin(phi)*cos(lamb), -sin(phi)*sin(lamb), cos(phi);
        -sin(lamb), cos(lamb), 0;
        -cos(phi)*cos(lamb), -cos(phi)*sin(lamb), -sin(phi)];
    M_Wtau = M_tauW';
    
    [wp_W_list] = update4WpList(l, FourWpConfig);
    
    wp_plot = wp_W_list * l;
    
    
    [wp_infront_W, cnt] = getOneFromFourWps(wp_W_list,FourWpConfig, cnt,p_W);
    [chi_tau_new, bearing_W] = calcBearingToWp(wp_infront_W, p_W);
    
    % Delay, to create a turn
    exp_avg_const = FourWpConfig.exp_avg_const;
    if n == 1
        chi_tau = chi_tau_new;
    end
    chi_tau = chi_tau * exp_avg_const + chi_tau_new * (1-exp_avg_const);
    
    bearing_tau = [cos(chi_tau); sin(chi_tau); 0];
    bearing_W = M_Wtau*bearing_tau;
    
    p_W = p_W + bearing_W*0.01;
    
    p_W = p_W/norm(p_W)*l;
    
    plot3( p_W(1), p_W(2), p_W(3), '.r');
        
    pause(0.01);
end

