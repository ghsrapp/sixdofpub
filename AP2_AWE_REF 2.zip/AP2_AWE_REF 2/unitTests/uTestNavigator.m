% plot figure
%============== DO NOT TOUCH ! ==========================================
figIndx = 1;  
scenarioFig8;
r_d = 60;
initVisualization;
axis([-l_tether 200 -l_tether l_tether -50 200 ]); hold on
%========================================================================

% Kite test position
lat_test = 70*pi/180;
long_test = -80 * pi/180;
p_kite_W = [cos(long_test)*cos(lat_test);
    sin(long_test)*cos(lat_test);
    sin(lat_test)]*l_tether;

%plot3( p_kite_W(1), p_kite_W(2), p_kite_W(3), '.r', 'Markersize', 15, 'Linewidth', 2);

% Update the flight path
p_kite_W = p_kite_W/norm(p_kite_W);
[ left_top_abs_W, left_bottom_abs_W,...
    right_top_abs_W,right_bottom_abs_W,M_CW_left,M_CW_right,...
    p_circO1_W, p_circO2_W, r_SE ] = updateFlightPath( p_kite_W, r_d,maxWidth, lat, l_tether);

deltaAlphaLeft = deltaVTCircle;
deltaAlphaRight = -deltaAlphaLeft;

% Angles
long_right_bottom = atan( right_bottom_abs_W(2) / right_bottom_abs_W(1) );
long_right_top = atan( right_top_abs_W(2) / right_top_abs_W(1) );
long_left_top = atan( left_top_abs_W(2) / left_top_abs_W(1) );
long_left_bottom = atan( left_bottom_abs_W(2) / left_bottom_abs_W(1) );
lat_right_top = asin( right_top_abs_W(3) / norm(right_top_abs_W) );
lat_left_top = asin(left_top_abs_W(3) / norm(left_top_abs_W) );
lat_left_bottom = asin(left_bottom_abs_W(3) / norm(left_bottom_abs_W) );
lat_right_bottom = asin(right_bottom_abs_W(3) / norm(right_bottom_abs_W) );

functionTestFlag =2;

% scale unitvectors
scale = 5;
switch functionTestFlag

    % @Thomas: only case 2 is relevant for you
    case 1 % Great Circle: From left top to right bottom
        
        e1 = [left_top_abs_W(2)*right_bottom_abs_W(3)-left_top_abs_W(3)*right_bottom_abs_W(2); 
              left_top_abs_W(3)*right_bottom_abs_W(1)-left_top_abs_W(1)*right_bottom_abs_W(3); 
              left_top_abs_W(1)*right_bottom_abs_W(2)-left_top_abs_W(2)*right_bottom_abs_W(1)];
        e1 = e1/norm(e1);

        e2 = [e1(2)*left_top_abs_W(3)-e1(3)*left_top_abs_W(2); 
        e1(3)*left_top_abs_W(1)-e1(1)*left_top_abs_W(3); 
        e1(1)*left_top_abs_W(2)-e1(2)*left_top_abs_W(1)];  
    
        e3 = left_top_abs_W;
        
        e1 = e1 * l_tether * scale; 
        e2 = e2 * l_tether* scale; 
        e3 = e3 * l_tether* scale; 
        he1 = quiver3( 0, 0, 0, e1(1), e1(2), e1(3),1,'red' ); 
        he2 = quiver3( 0, 0, 0, e2(1), e2(2), e2(3),1 ); 
        he3 = quiver3( 0, 0, 0, e3(1), e3(2), e3(3),1 ); 
        h_GC_base = [he1,he2,he3 ];
        set(h_GC_base, 'color', [0.5, 0.5, 0.5], 'Linewidth', 1.5); 
        h_tot = []; 
        for n = 1 : 100
            delete(h_tot); 
           % pause;
            [p_VT_W,p_kite_proj_W] = getVTOnGreatCircle(left_top_abs_W, right_bottom_abs_W, p_kite_W,deltaVTGreatCircle);
            long_VT = atan2( p_VT_W(2) , p_VT_W(1) );
            lat_VT = asin( p_VT_W(3) / norm(p_VT_W) );
            if long_VT > long_right_bottom
                p_VT_W = right_bottom_abs_W;
            end
            if long_VT < long_left_top
                p_VT_W = left_top_abs_W;
            end
            
           
            [ chi_K_des, bearing_vec_W ] = calcCourse2VT( p_VT_W, p_kite_W );
            
            long_test = atan2( p_kite_W(2) , p_kite_W(1) );
            lat_test = asin( p_kite_W(3) / norm(p_kite_W) );
            
            e_xT_W = [-sin(lat_test)*cos(long_test); -sin(lat_test)*sin(long_test); cos(lat_test)]; % x-unit vector of the tether frame
            
            p_VT_W = p_VT_W * l_tether;
            p_kite_proj_W = p_kite_proj_W * l_tether;
          
            % rotationaxis
            a_rot = cross( p_kite_W, bearing_vec_W);
            % third base
            a_3 = cross( a_rot, bearing_vec_W);
            %quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), a_rot(1), a_rot(2), a_rot(3),15, 'MaxHeadSize', 0.8);
            %quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), a_3(1), a_3(2), a_3(3),15, 'MaxHeadSize', 0.8);
            M_RotW = [a_rot/norm(a_rot),bearing_vec_W/norm(bearing_vec_W),a_3/norm(a_3)]';
            p_kite_Rot = M_RotW * p_kite_W;
            drehA = 5*pi/180;
            p_kite_W = p_kite_W * l_tether;
            
            
            h_pos = plot3( p_kite_W(1), p_kite_W(2), p_kite_W(3), '.r', 'Markersize', 15, 'Linewidth', 2);
            h_kite = plot3( [0 p_kite_W(1)], [0 p_kite_W(2)],[0 p_kite_W(3)], '--r', 'Linewidth', 2); hold on
            if n == 1
                pause; 
            end
            % Projection Vector 
            V = [e2/norm(e2), e3/norm(e3)]; 
            p_kite_projN_W = V*V'*p_kite_W;
            projection_direction = p_kite_projN_W - p_kite_W; 
            h_proj = quiver3( p_kite_W(1),p_kite_W(2),p_kite_W(3),projection_direction(1), projection_direction(2), projection_direction(3),1); 
            set(h_proj,'color', 'b','Linewidth',1.2); 
            h_tether =  plot3( [0 p_kite_proj_W(1)], [0 p_kite_proj_W(2)],[0 p_kite_proj_W(3)], '--b', 'Linewidth', 2); hold on
            h_proj =  plot3( p_kite_proj_W(1), p_kite_proj_W(2), p_kite_proj_W(3), '.b', 'Markersize', 15, 'Linewidth', 2); hold on
            if n == 1
                pause; 
            end   
            greenc = [    0.9290    0.6940    0.1250];
            h_VT = plot3( p_VT_W(1), p_VT_W(2), p_VT_W(3),'color', 'green','Marker', '.', 'Markersize', 15, 'Linewidth', 2); hold on
            e_1 = -[p_VT_W(2)*p_kite_W(3)-p_VT_W(3)*p_kite_W(2); 
                    p_VT_W(3)*p_kite_W(1)-p_VT_W(1)*p_kite_W(3); 
                    p_VT_W(1)*p_kite_W(2)-p_VT_W(2)*p_kite_W(1)];
            e_1 = e_1/norm(e_1) * l_tether; 
           % h_e1_bear = quiver3( 0, 0, 0, e_1(1), e_1(2), e_1(3),1);
           % set(h_e1_bear,'color', 'green', 'Linewidth', 1.2); 
            if n == 1
                pause; 
            end
            h_bearing = quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), bearing_vec_W(1)* scale, bearing_vec_W(2)* scale, bearing_vec_W(3)* scale,15, 'MaxHeadSize', 0.8);
            set( h_bearing, 'color','green', 'Linewidth', 1.5, 'Linestyle', '-');
            h_ref_bear = quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), e_xT_W(1)* scale, e_xT_W(2)* scale, e_xT_W(3)* scale,15, 'MaxHeadSize', 0.8);
            set(h_ref_bear, 'color', 'black', 'Linewidth', 1.5); hold on

            p_kite_W = M_RotW'*[1, 0, 0;
                0, cos(drehA), -sin(drehA);
                0, sin(drehA), cos(drehA)] * p_kite_Rot;
            %title(['Desired Course: ', num2str(chi_K_des*180/pi), ' (deg)'])
            
            h_tot = [h_pos, h_kite, h_tether,h_proj, h_VT,h_bearing,h_ref_bear,h_GC_base];
            
        end
        
    case 2 % @Thomas: This is relevant for you (Circle)
       
        deltaAlphaLeft = -10*pi/180; % moves the kite by this angle 
        axis([-100 200 -200 200 0 200])
        h_tot = []; 
        for n = 1 : 100
            delete(h_tot); 
            p_kite_W = p_kite_W/norm(p_kite_W);
            
            % ===== Calculate the virtual target on the circle ========== 
            [p_VT_W,p_kite_proj_W] = getVTOnCircle(M_CW_left,p_circO1_W, p_kite_W, r_SE, deltaAlphaLeft);
             % ============================================================

            % Orthonormal basis circle
            e_x_W = M_CW_left(1,:); e_y_W = M_CW_left(2,:); e_z_W = M_CW_left(3,:);
            e1 =  e_x_W' ; e2 = e_y_W'; 
            V = [e1, e2]; 
            p_ = (p_kite_W-p_circO1_W)*l_tether; % Relative vector between circle origin and kite position in W frame
            p_kite_proj_W_norm = V*V'*p_ + p_circO1_W*l_tether; % Projection of the relative vector into the circle frame

            % ===== Calculate the desired course =========================
            [ chi_K_des, bearing_vec_W ] = calcCourse2VT( p_VT_W, p_kite_W );
            % ============================================================
            long_test = atan2( p_kite_W(2) , p_kite_W(1) );
            lat_test = asin( p_kite_W(3) / norm(p_kite_W) );
            
            e_xT_W = [-sin(lat_test)*cos(long_test); -sin(lat_test)*sin(long_test); cos(lat_test)]; % x-unit vector of the tether frame
            
            p_VT_W = p_VT_W * l_tether;
            p_kite_proj_W = p_kite_proj_W * l_tether; % Projected onto the circle
            h_VT =  plot3( p_VT_W(1), p_VT_W(2), p_VT_W(3),'color', [0 0.5 0],'Marker','.', 'Markersize', 15, 'Linewidth', 2); hold on
            
            projection_direction = p_kite_proj_W_norm - p_kite_W*l_tether; 
            h_norm = quiver3( p_kite_W(1)*l_tether,p_kite_W(2)*l_tether,p_kite_W(3)*l_tether,projection_direction(1), projection_direction(2), projection_direction(3),1); 
            set(h_norm,'color', 'b','Linewidth',1.2); 

            h_kite =  plot3( p_kite_proj_W(1), p_kite_proj_W(2), p_kite_proj_W(3), '.b', 'Markersize', 15, 'Linewidth', 2); hold on
            h_proj = plot3( [p_kite_proj_W_norm(1) p_circO1_W(1)*l_tether], [p_kite_proj_W_norm(2) p_circO1_W(2)*l_tether],[p_kite_proj_W_norm(3) p_circO1_W(3)*l_tether], '--b', 'Linewidth', 2); hold on

            % rotationaxis
            a_rot = cross( p_kite_W, bearing_vec_W);
            % third base
            a_3 = cross( a_rot, bearing_vec_W);

            M_RotW = [a_rot/norm(a_rot),bearing_vec_W/norm(bearing_vec_W),a_3/norm(a_3)]';
            p_kite_Rot = M_RotW * p_kite_W;
            drehA = 3*pi/180;
            p_kite_W = p_kite_W * l_tether;
            
            h_bearing = quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), bearing_vec_W(1)* scale, bearing_vec_W(2)* scale, bearing_vec_W(3)* scale,15, 'MaxHeadSize', 0.8);
            set( h_bearing, 'color',[0 0.5 0], 'Linewidth', 1.5, 'Linestyle', '-');
            h_ref_bear = quiver3( p_kite_W(1), p_kite_W(2), p_kite_W(3), e_xT_W(1)* scale, e_xT_W(2)* scale, e_xT_W(3)* scale,15, 'MaxHeadSize', 0.8);
            set(h_ref_bear, 'color', 'black', 'Linewidth', 1.5); hold on
            h_pos=plot3( p_kite_W(1), p_kite_W(2), p_kite_W(3), '.r', 'Markersize', 15, 'Linewidth', 2);
            plot3( p_kite_W(1), p_kite_W(2), p_kite_W(3), '.r', 'Markersize', 10, 'Linewidth', 1);
            h_tether = plot3( [0 p_kite_W(1)], [0 p_kite_W(2)],[0 p_kite_W(3)], '--r', 'Linewidth', 2); hold on
            
            p_kite_W = M_RotW'*[1, 0, 0;
                0, cos(drehA), -sin(drehA);
                0, sin(drehA), cos(drehA)] * p_kite_Rot;
            title(['Desired Course= ', num2str(chi_K_des*180/pi), ' (deg)'])
            h_tot = [h_norm,h_pos, h_kite, h_tether,h_proj, h_VT,h_bearing,h_ref_bear];
            pause;
          %  print([eval('pwd'),'/video/','vidPic_',num2str(n)], '-dpng', '-r300');
        end
end

