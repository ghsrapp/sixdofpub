clear all
close all
clc

initCircle;
windDirection_rad = pi;
nav.gamma_t_cmd = 0;

lam = 0*pi/180;
phi = 30*pi/180;
longlat = [lam,phi];
pos_W = [cos(lam)*cos(phi); sin(lam)*cos(phi); sin(phi)]*200;
l = norm(pos_W);
pos_O = transformFromWtoO(windDirection_rad, pos_W);
%% draw the circle
theta = 0 : 0.01 : 2*pi;
%pos_W = pos_W/norm(pos_W);

r = CircleParam.radius;
p_circ_C = [cos(theta);
    sin(theta);
    0*theta]*CircleParam.radius;


alpha = asin(  CircleParam.radius/l ) ;
d = cos(alpha);

e_c_x = [-sin(CircleParam.mean_elevevation); 0; cos(CircleParam.mean_elevevation)];
e_c_y = [0; 1; 0];
e_c_z = -[cos(CircleParam.mean_elevevation); 0; sin(CircleParam.mean_elevevation)];

M_CW = [e_c_x'; e_c_y'; e_c_z'];
M_WC = M_CW';
p_co_W = d*[cos(CircleParam.mean_elevevation);0; sin(CircleParam.mean_elevevation)];

wp_1_C = [0;r;0]; 
wp_1_W = M_WC * wp_1_C; 

wp_4_C = [0;-r;0];
wp_4_W = M_WC * wp_4_C; 
%%
p_circ_W = M_WC * p_circ_C + p_co_W*l;
%%
figure;
view(90,30); hold on 
plot3( p_circ_W(1,:), p_circ_W(2,:), p_circ_W(3,:) ); hold on
plot3( pos_W(1), pos_W(2), pos_W(3), '*b'); hold on; 
plot3( p_circ_W(1), p_circ_W(2), pos_W(3), '*b');
plot3( p_circ_W(1), pos_W(2), pos_W(3), '*b');

axis equal;
plot3(0,0,0,'oK');

l_tether = 200;
h = [];
%% Test if the closest point on the sphere can be calcualted.
for n = 1 : 1000
    delete(h);
    [path_k,pos_target_W]  = uTestCircleNav2(pos_O, longlat, CircleParam,nav, windDirection_rad);
    %pos_target_W = pos_target_W/norm(pos_target_W)*l;
    
    bearing_O = [cos(path_k(1))*cos(path_k(2)); sin(path_k(1))*cos(path_k(2)); -sin(path_k(2))];
    bearing_W = transformFromOtoW(windDirection_rad, bearing_O );
    
    %pos_W = pos_W/norm(pos_W) + bearing_W/norm(bearing_W)*0.02;
     pos_W = pos_W + bearing_W/norm(bearing_W)*1;

    
    longlat = [atan2(pos_W(2), pos_W(1)), asin(pos_W(3)/norm(pos_W))];
    pos_O = transformFromWtoO(windDirection_rad, pos_W);
    plot3( pos_W(1), pos_W(2), pos_W(3), '+b');
    % pause;
    [x,y,z] = sphere; surf(x,y,z);
    h =  surf(x*l_tether, y*l_tether, z*l_tether);
    set(h, 'FaceAlpha', 0.5)
    p_circ_W = M_WC * p_circ_C + p_co_W*l_tether;
    plot3( p_circ_W(1,:), p_circ_W(2,:), p_circ_W(3,:), 'r' ); hold on

    axis equal;
    drawnow;
    
end

