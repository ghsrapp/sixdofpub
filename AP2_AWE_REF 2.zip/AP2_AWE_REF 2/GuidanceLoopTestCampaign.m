clear
close all
clc

addpath(genpath('AWESTRIM'));
addpath('Visualization_Offline/');
addpath(genpath('simFiles'))
addpath(genpath('MiscFiles'))

%%
lat_vec = 60*pi/180; %[30 : 10 : 80]*pi/180;
long_vec = [-45  : 5 : 45]*pi/180;
yout_mat = [];
for j = 1 : length( lat_vec )
    for k = 1 :  length( long_vec )
        lat_init = lat_vec(j);
        long_init = long_vec(k);
        
        l_tether = 300;
        chi_tau_init = -pi;
        v_tot = 25;
        v_R = 0;
        v_R_norm = v_R/v_tot;
        
        p_init_W = [cos(long_init)*cos(lat_init); sin(long_init)*cos(lat_init); sin(lat_init)]*l_tether;
        
        [act, aeroModel, base_windspeed, constr, crosswind_speed,...
            ENVMT, gs, Lbooth, loiterStates, nav, P_AP2, simInit, puntethered,...
            requ, sm, T, waypoints_fig8loit, winchParameter,params, noiseInput] = initAllSimParams_variable_p_init_W(p_init_W);
        params.a_booth = 0.7;
        params.b_booth = 200;
        
        gamma_tau = -asin( v_R_norm );
        v_k_tau = [ cos(chi_tau_init)*cos(gamma_tau );
            sin(chi_tau_init)*cos(gamma_tau);
            -v_R_norm]*v_tot;
        
        M_tauW = [-sin(lat_init)*cos(long_init), -sin(lat_init)*sin(long_init), cos(lat_init);
            -sin(long_init), cos(long_init), 0;
            -cos(lat_init)*cos(long_init), -cos(lat_init)*sin(long_init), -sin(lat_init)];
        
        M_Wtau = M_tauW';
        
        M_OW = [cos(ENVMT.windDirection_rad), sin(ENVMT.windDirection_rad), 0;
            sin(ENVMT.windDirection_rad), -cos(ENVMT.windDirection_rad), 0;
            0, 0, -1];
        
        v_k_W_init = M_Wtau * v_k_tau;
        v_k_O_init = M_OW * v_k_W_init;
        
        
        phi_trac = 30*pi/180;
        
        yout = sim('AWES3_CL_wTether_v3_onlyGuidance','ReturnWorkspaceOutputs','on');
        yout_mat = [yout_mat,yout];
        fprintf('j=%.f and k=%.f\n',j,k);
    end
end

%%
close all;
save_flag = 0;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
col4 =  [255/255, 102/255, 102/255];
params.phi0_booth = phi_trac;


h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
h2 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);

for j = 1 : numel( yout_mat)
    figure(1);
    tp = squeeze( yout_mat(j).target_pos.Data ) ;
    M_WP = [cos(phi_trac),0, -sin(phi_trac);0, 1, 0;  sin(phi_trac),0, cos(phi_trac)];
    p_W = [ yout_mat(j).pos_W.Data(:,1)';  yout_mat(j).pos_W.Data(:,2)';  yout_mat(j).pos_W.Data(:,3)'];; 
    p_P = M_WP'*p_W;
    pt_P = M_WP'*[tp(1,:);  tp(2,:);  tp(3,:)];
    %plot( p_P(2,:), p_P(3,:), 'color', col1, 'Linewidth', 1, 'Linestyle', '-' ); hold on
    %plot( p_P(2,1), p_P(3,1), 'color', col1,'Marker', 'x' ); hold on
    
    plot3( p_W(1,:), p_W(2,:), p_W(3,:), 'color', col1, 'Linewidth', 1, 'Linestyle', '--' ); hold on

    %plot( pt_P(2,:), pt_P(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on
    
    Lbooth.b = params.b_booth;
    Lbooth.a = params.b_booth*params.a_booth;
    [Lem] = updateBoothLemniscate(l_tether,Lbooth);
    s = 0 : 0.005 : 2*pi;
    long_P = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
    lat_P =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 );
    % transform into cartesian coordinates
    p_P = [ cos(long_P).*cos(lat_P);sin(long_P).*cos(lat_P);sin(lat_P)]*l_tether;
    p_W = M_WP*p_P;
   % plot( p_P(2,:), p_P(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on
     plot3( p_W(1,:), p_W(2,:), p_W(3,:), 'color', col2, 'Linewidth', 1, 'Linestyle', '--' ); hold on

    axis([-200 200 -100 300]);
    
    
    
    %
    xlabel('$y_P$ $(m)$');
    ylabel('$z_P$ $(m)$');
    axis equal
    if 0
    figure(2);
    p = squeeze( yout_mat(j).pos_W.Data(1:3, :) );
    l =   sqrt( sum(p'.*p' ,2 ) );
    l_t = sqrt( sum(tp'.*tp', 2 ) );
    cte = acos( ( sum( p'.*tp',2 ) )./l_t./l ) .* l;
    plot( yout_mat(j).pos_W.Time, cte, 'color', col1, 'Linewidth', 1.2, 'Linestyle', '-' ); hold on
    axis([0 100 0 50]);
    xlabel('$Time$ $(s)$');
    ylabel('$e_p$ $(m)$');
    end
    
end


if save_flag
    cd('Trim_results/');
    Plot2LaTeX(h1,['guidance_check_projected_path_big_',num2str(j)]);
    cd ..
end