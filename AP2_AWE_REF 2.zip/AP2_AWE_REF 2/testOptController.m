clear all 
close all 
clc

TSIM = 600; 
init_new;
%load('x_best_trac_tmp1.mat');
load('param_set_01.mat');

%x = current_best_ctrl;
max_bandwidth = aileron.w0;

%% ---------------------------- TRACTION ----------------------------
% Bandwidths
assignin('base','w0_mu_traction',param_set_01.w0_mu_traction);
assignin('base','w0_alpha_traction',param_set_01.w0_alpha_traction);
assignin('base','w0_beta_traction',param_set_01.w0_beta_traction);

assignin('base','w0_p_traction',param_set_01.w0_p_traction);
assignin('base','w0_q_traction',param_set_01.w0_q_traction);
assignin('base','w0_r_traction',param_set_01.w0_r_traction);

% Gains 
assignin('base','Kp_chi_tau_traction',param_set_01.Kp_chi_tau_traction);
assignin('base','Ki_chi_tau_traction',param_set_01.Ki_chi_tau_traction);
assignin('base','Kp_chi_tau_trans',param_set_01.Kp_chi_tau_trans);
assignin('base','Kp_gamma_tau_trans',param_set_01.Kp_gamma_tau_trans);
assignin('base','Kp_gamma_tau_traction',param_set_01.Kp_gamma_tau);
assignin('base','Ki_gamma_tau_traction',param_set_01.Ki_gamma_tau);

assignin('base','Kp_mu_traction',param_set_01.Kp_mu_traction);
assignin('base','Kp_alpha_traction',param_set_01.Kp_alpha_traction);
assignin('base','Kp_beta_traction',param_set_01.Kp_beta_traction);
assignin('base','Ki_mu_traction',param_set_01.Ki_mu_traction);
assignin('base','Ki_alpha_traction',param_set_01.Ki_alpha_traction);
assignin('base','Ki_beta_traction',param_set_01.Ki_beta_traction);

assignin('base','Kp_p_traction',param_set_01.Kp_p_traction/2);
assignin('base','Kp_q_traction',param_set_01.Kp_q_traction/2);
assignin('base','Kp_r_traction',param_set_01.Kp_r_traction/2);
assignin('base','Ki_p_traction',param_set_01.Ki_p_traction/2);
assignin('base','Ki_q_traction',param_set_01.Ki_q_traction/2);
assignin('base','Ki_r_traction',param_set_01.Ki_r_traction/2);

assignin('base','a_booth',param_set_01.a_booth); %0.7;
assignin('base','b_booth',param_set_01.b_booth);% 90/100;
assignin('base','phi0_booth',param_set_01.phi0_booth);
assignin('base','F_T_traction_set',param_set_01.F_T_traction_set)

%% ---------------------------- RE-TRACTION ----------------------------
% Bandwidths
assignin('base','w0_mu_retraction',param_set_01.w0_mu_retraction);
assignin('base','w0_alpha_retraction',param_set_01.w0_alpha_retraction);
assignin('base','w0_beta_retraction',param_set_01.w0_beta_retraction);

assignin('base','w0_chi_retraction',param_set_01.w0_chi_retraction);
assignin('base','w0_gamma_retraction',param_set_01.w0_gamma_retraction);

% Gains
assignin('base','Kp_chi_retraction',param_set_01.Kp_chi_retraction);
assignin('base','Ki_chi_retraction',param_set_01.Ki_chi_retraction);
assignin('base','Kp_gamma_retraction',param_set_01.Kp_gamma_retraction);
assignin('base','Ki_gamma_retraction',param_set_01.Ki_gamma_retraction);

assignin('base','Kp_mu_retraction',param_set_01.Kp_mu_traction);
assignin('base','Kp_alpha_retraction',param_set_01.Kp_alpha_traction);
assignin('base','Kp_beta_retraction',param_set_01.Kp_beta_traction);
assignin('base','Ki_mu_retraction',param_set_01.Ki_mu_traction);
assignin('base','Ki_alpha_retraction',param_set_01.Ki_alpha_traction);
assignin('base','Ki_beta_retraction',param_set_01.Ki_beta_traction);

assignin('base','Kp_p_retraction',param_set_01.Kp_p_retraction);
assignin('base','Kp_q_retraction',param_set_01.Kp_q_retraction);
assignin('base','Kp_r_retraction',param_set_01.Kp_r_retraction);
assignin('base','Ki_p_retraction',param_set_01.Ki_p_retraction);
assignin('base','Ki_q_retraction',param_set_01.Ki_q_retraction);
assignin('base','Ki_r_retraction',param_set_01.Ki_r_retraction);

assignin('base','v_retraction_opt',param_set_01.v_retraction_opt);
assignin('base','gamma_retract_opt',param_set_01.gamma_retract_opt);


F_T_traction_set = 2000;
FCS.AoA_Traction = 4; 
a_booth = 0.7;
b_booth = 120;
% Test
Lbooth.a = a_booth*b_booth;
Lbooth.b = b_booth;
sim('testAWE_Testbed_opt4');

%%
Lbooth.a = a_booth*b_booth;%x(20)*x(21);
Lbooth.b = b_booth;%x(21);
Lbooth.phi0 = phi0_booth*pi/180;
figure(10);clf;
addpath('Visualization_Offline/')
sim('visualize_offline_v2');
hold on 
drawBooth;
