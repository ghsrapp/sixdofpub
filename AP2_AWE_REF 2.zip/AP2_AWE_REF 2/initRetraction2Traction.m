l_tether_max = 600; % Distance of outmost path
l_tether_min = 250; % Distance of innermost path
lat_land = 30*pi/180; % as measured from the ground.
lat_transition = lat_land + 5*pi/180;
delta_x_flare = 50; % Start flare here
%T = 30; % time constant flare
gamma_t_star = 10*pi/180;
delta_end_z = 0;
delta_start_z = 0;
delta_up_z = 100;
ds = 10; %look ahead distance
%dt = 1; % time increment transitioon back to traction
T_trans = 1; % time constant filter transition
time = 0; % initial time
alpha_trans_tract2retract = 0.96; % exponentially weighted
alpha_retract = 0.95;
lambda_R2T = 5 * pi/180;
max_distance2Wp1 = 50;

% =========================================================================

[ LemPs ] = updateLissajous( l_tether_max, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * l_tether_max;
%plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;

t_1 = calculateTangentOnLissFig(pi/2, LemPs );

L_start = [Alambda * sin(blambda*pi/2');
    Aphi    * sin(bphi*pi/2') + phi0];
L_start = [cos(L_start(1,:)).*cos(L_start(2,:));
    sin(L_start(1,:)).*cos(L_start(2,:));
    sin(L_start(2,:))]* l_tether_max;

long_max = atan2( L_start(2), L_start(1) );

Delta0 = 0.5 * max( L_W_k(2,: ) );

% Path a min. tether length
[ LemPs ] = updateLissajous( l_tether_min, LemPsRef );
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;
theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];
L_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))];
L_W_k = L_W * l_tether_min;
%plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.5, 0.5 ,0.5]); hold on;

% horizontal reference line
p_end = [0; L_W_k(2); L_W_k(3) ];

t_2 = calculateTangentOnLissFig(pi/2, LemPs );

L_end = [Alambda * sin(blambda*pi/2');
    Aphi    * sin(bphi*pi/2') + phi0];
L_end = [cos(L_end(1,:)).*cos(L_end(2,:));
    sin(L_end(1,:)).*cos(L_end(2,:));
    sin(L_end(2,:))]* l_tether_min;

x_F = L_end(1); % flare parameter
x_0 = L_end(1)+delta_x_flare;

%===============================================================================
% Waypoints
% Wp0 =  [L_start(1)+t_1(1)*delta_start_z; L_start(2); L_start(3)+t_1(3)*delta_start_z];
% Wp1 =  [L_end(1)+t_2(1)*delta_end_z; L_end(2); L_end(3)+t_2(3)*delta_end_z];
% Wp2 =  [L_end(1)+t_2(1)*2*delta_up_z; L_end(2); L_end(3)+t_2(3)*2*delta_up_z];
% 
% retraction_direction = (Wp1-Wp0)/norm(Wp1-Wp0);
% 
% plot3([Wp0(1) Wp1(1)],[Wp0(2) Wp1(2)],[Wp0(3) Wp1(3)],'--', 'color', [0.5 0.5 0.5]);
% plot3([Wp1(1) Wp2(1)],[Wp1(2) Wp2(2)],[Wp1(3) Wp2(3)],'--', 'color', [0.5 0.5 0.5]);
% plot3(Wp0(1),Wp0(2),Wp0(3),'*r');
% plot3(Wp1(1),Wp1(2),Wp1(3),'*r');
% plot3(Wp2(1),Wp2(2),Wp2(3),'*r');
%===============================================================================
if 0
    %%
    %[x,y,z] = sphere(50);
  %  surf( x*l_tether_min, y*l_tether_min, z*l_tether_min );
    theta_circle = 0 : 0.01 : 2*pi;
    circ = [cos(theta_circle);
        sin(theta_circle);
        zeros(1,length(theta_circle))]*l_tether_min;
    s_reentry = 0;%-pi/2-0.4;
    
    L_end = [Alambda * sin(blambda*s_reentry);
        Aphi    * sin(bphi*s_reentry) + phi0];
    L_end = [cos(L_end(1,:)).*cos(L_end(2,:));
        sin(L_end(1,:)).*cos(L_end(2,:));
        sin(L_end(2,:))]* l_tether_min;
    plot3( L_end(1), L_end(2), L_end(3), '*g');
    t = calculateTangentOnLissFig(s_reentry, LemPs );
    z = cross(t,L_end);
    z = z/norm(z);
    x = t/norm(t);
    y = cross(z,x);
    transCircle.M_CW = [x';y';z'];
    circ_W = transCircle.M_CW'*circ;
    plot3( circ_W(1,:), circ_W(2,:), circ_W(3,:), '--b')
    
    
    
    
    %% point on circle 
    theta_test = 120*pi/180;
    circ_C = [cos(theta_test);
        sin(theta_test);
        zeros(1,length(theta_test))]*l_tether_min;
    circ_W =  transCircle.M_CW'*circ_C;
    plot3( circ_W(1,:), circ_W(2,:), circ_W(3,:), '*m')
    % tangent on circle 
    s = theta_test;
    t_circ_C = -[-sin(s);cos(s); 0];
    t_circ_W = transCircle.M_CW'*t_circ_C;
    lat_test = 70*pi/180;
    long_test = 0*pi/180;
    test_W = [cos(long_test)*cos(lat_test);
        sin(long_test)*cos(lat_test);
        sin(lat_test)]*l_tether_min;
    plot3(test_W(1), test_W(2), test_W(3), '*m');
    [pos_target_W, sol] = getTargetOnTransCircle( test_W, transCircle,l_tether_min );
    
    circ_C = [cos(sol);
        sin(sol);
        0]*l_tether_min;
    circ_W = transCircle.M_CW'*circ_C;
    plot3(circ_W(1), circ_W(2), circ_W(3), 'ok');
    plot3(pos_target_W(1), pos_target_W(2), pos_target_W(3), '+k');

end