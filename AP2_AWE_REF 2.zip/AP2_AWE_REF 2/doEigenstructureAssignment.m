function K_lat = doEigenstructureAssignment( A_lat_aug, B_lat_aug, opt_params )

% Define desired eigenvalues 
T_R_Des = opt_params(1); % Rolltime constant
T_S_Des = opt_params(2); %1/5; %1/w0s(end); % spiral mode
zeta_DR_des = opt_params(3); %1/sqrt(2); 
w0_DR_des = opt_params(4); %w0s(2); 

% Corresponding desired eigenvalues + integrator states 
Lambda_Des = [-1/T_R_Des; 
   w0_DR_des*(-zeta_DR_des+1i*sqrt(1-zeta_DR_des^2)); 
   w0_DR_des*(-zeta_DR_des-1i*sqrt(1-zeta_DR_des^2)); 
   -1/T_S_Des; 
   -opt_params(5); 
   -opt_params(6)]; % was -4.1

 v1 = [0;NaN; NaN; 1e-4; NaN; NaN]; % Rollmode
 v2 = [NaN;0; 1e-4; NaN; NaN; NaN]; % DR
 v3 = [NaN;0; 1e-4; NaN; NaN; NaN]; % DR
v4 = [0;NaN; NaN; 1e-4; NaN; NaN]; % Spiral
v5 = [1;0; NaN; NaN; NaN; NaN]; % betaI
v6 = [0;1; NaN; NaN; NaN; NaN]; % phi_tauI

%Vector_Des = [v1, v2, v3, v4, v5, v6, v7, v8]; 
Vector_Des = [v1, v2, v3, v4, v5, v6]; 

% Eigenstructure Assignment procedure
[n,m] = size(B_lat_aug); 
C = [eye(n-2), zeros(n-2,2)];
C = eye(n); 
[r,n] = size(C); 


K = zeros(m,r); 
V = zeros(n,r); 
Z = zeros(m,r); 

for Act_EV = 1 : r 
   ld = Lambda_Des(Act_EV); 
   vd = Vector_Des(:, Act_EV); 
   M = [ld*eye(n,n)-A_lat_aug, B_lat_aug]; 
   N_bar = null(M); % Nullspace 
   N = N_bar(1:n, :); %  corresponding to eigenvalues
   N_hat = N_bar(n+1:end,:); %  corresponding to input directions
   
   ps = find(~isnan(vd)); % selection 
   vd_s = vd(ps); % choose elements of desired eigenvector that are assinge d
   N_s = N(ps, :); % choose corresponding basis in nullspace 
   
   l = N_s\vd_s; % calculate parameter vector
   
   v = N*l; % calculate eigenvalue
   z = N_hat*l; % calculation of input direction 
   
   V(:, Act_EV) = v; 
   Z(:,Act_EV) = z; 
    
end

K_imag = ((C*V)'\(Z'))';  
% if (norm(imag(K)) > 100*eps)
%     error('Bad gain design'); 
% end

K_lat = real(K_imag); 