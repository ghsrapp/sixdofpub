close all;
figure;
subplot(311)
plot(airdata.Time, airdata.Data(:,1));axis([0 300 0 60])
ylabel('$V_a (m/s)$','interpreter', 'latex')
subplot(312)
plot(airdata.Time, airdata.Data(:,2)*180/pi);hold on
plot(airdata.Time, 0*airdata.Data(:,2)*180/pi+10, '--');axis([0 300 -10 15])
legend('\alpha','\alpha_{max}')
ylabel('\alpha (\circ)')
subplot(313)
plot(airdata.Time, airdata.Data(:,3)*180/pi);axis([0 300 -5 5])
ylabel('\beta (\circ)')
xlabel('time (s)','interpreter', 'latex')

print('airdata', '-dpng', '-r300');

close all;
figure;
subplot(311)
plot(path_angles.Time, path_angles.Data(:,1)*180/pi);axis([0 300 -180 180])

