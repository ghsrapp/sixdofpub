addpath('pics');
writerObj = VideoWriter('pumping.avi');
open(writerObj);
cnt = 1;
pauce=2;
for K = 1 : 1499*pauce
   
    filename = sprintf(['vidPic_','%d.png'], cnt);
    if mod(K,pauce) == 0
        cnt = cnt + 1;
    end
    
    thisimage = imread(filename);
    writeVideo(writerObj, thisimage);
    K
end
close(writerObj);
