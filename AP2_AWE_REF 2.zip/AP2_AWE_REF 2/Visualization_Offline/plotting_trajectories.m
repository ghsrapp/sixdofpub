close all
cnt1 =1;

cnt2 = 1; 
cnt3 = ;  
%batch_run_phi0 = phi_vec(cnt1); 
%batch_run_alambda = lambda_vec(cnt2); 
%batch_run_fac = fac_vec(cnt3);
load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 
%load(['power',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 

sig1 = power_vr_tether; 

cnt2 = 2; 
cnt3 = 5;  
batch_run_phi0 = phi_vec(cnt1); 
batch_run_alambda = lambda_vec(cnt2); 
batch_run_fac = fac_vec(cnt3);
%load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 
load(['power',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 

sig2 = power_vr_tether;  

cnt2 = 3; 
cnt3 = 5;  
batch_run_phi0 = phi_vec(cnt1); 
batch_run_alambda = lambda_vec(cnt2); 
batch_run_fac = fac_vec(cnt3);
%load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 
load(['power',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 

sig3 = power_vr_tether;

 plot_3_1D_Signals(1,sig1/1000, sig2/1000, sig3/1000, 'Time','(s)', 'P', '(kW)', 12,1,1, 'plots', 'power' )
%plot_3_1D_Signals(3,sig1, sig2, sig3, 'Time','(s)', 'F_T', '(N)', 12,1,1, 'plots', 'ft' )


lh = legend('$$s_1$$','$$s_2$$','$$s_3$$');
set(lh, 'interpreter', 'latex');
%% ******************************* 3D Flightpaths *******************************
cnt1 = 2;

cnt2 = 1; 
cnt3 = 5;  
batch_run_phi0 = phi_vec(cnt1); 
batch_run_alambda = lambda_vec(cnt2); 
batch_run_fac = fac_vec(cnt3);
load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 

sig1 = pos_W; 

cnt2 = 2; 
cnt3 = 5;  
batch_run_phi0 = phi_vec(cnt1); 
batch_run_alambda = lambda_vec(cnt2); 
batch_run_fac = fac_vec(cnt3);
load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 
sig2 = pos_W;  

cnt2 = 3; 
cnt3 = 5;  
batch_run_phi0 = phi_vec(cnt1); 
batch_run_alambda = lambda_vec(cnt2); 
batch_run_fac = fac_vec(cnt3);
load(['TrajFile',num2str(cnt1),'_',num2str(cnt2),'_',num2str(cnt3),'.mat']); 
sig3= pos_W;  


col1 =  [160/255, 160/255, 160/255 ];
col2 =  [112/255, 138/255, 144/255];
col3 =  [10/255, 10/255, 10/255 ];
figure; 
plot3( sig1.Data(:,1), sig1.Data(:,2), sig1.Data(:,3), 'color', col1 ); hold on 
plot3( sig2.Data(:,1), sig2.Data(:,2), sig2.Data(:,3), 'color', col2 );
plot3( sig3.Data(:,1), sig3.Data(:,2), sig3.Data(:,3), 'color', col3 ); 
ylabel(['$$','y_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' ); 
xlabel(['$$','x_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' ); 
zlabel(['$$','z_W', '$$',' ','$$','(m)','$$'], 'interpreter', 'latex' ); 

axis equal; 
set(gca,'FontSize',12,'TickLabelInterpreter','latex');
view(90, 30)
lh = legend('$$s_1$$','$$s_2$$','$$s_3$$');
set(lh, 'interpreter', 'latex');


