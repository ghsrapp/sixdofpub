function drawVehicle_v3c_trim_b(uu )
% process input to function
pn = -uu(1); % inertial North position
pe = uu(2); % inertial East position
pd = -uu(3); % inertial down position

phi = uu(4);
theta = uu(5);
psi = uu(6);

t = uu(7);

p_VT_W = []; %uu(8:10)';




%% TO-DO: activate deactive visualization of the complex tether and
% activate it also for multiple particles

complex_tether_flag = 0;



% Temp path
%temp_path_x = -uu(35:114);
%temp_path_y = uu(115:194);
%temp_path_z = -uu(195:274);

%%
%F_T = uu(275);
%F_T_avg = uu(276);


persistent vehicle_handle;
persistent Vertices
persistent Faces
persistent facecolors
persistent pathpoints
persistent pathpoints2
persistent tether_handle
persistent counter
persistent p_VT_W_handle
persistent referencePath
persistent handleParticles
persistent handleTempPath

persistent V_stab
persistent V_wing
persistent V_plane

persistent h_stab,
persistent h_wing
persistent h_plane

persistent Vert
persistent p

if t==0
    %figure(1), %clf
   % clf;
    counter = 1;
    % [Vertices, Faces, facecolors] = defineVehicleBody;
    %[V_stab,V_wing,V_plane] = defineVehicleBody;
    scale = 10; 
    [F, V, C] = rndread('kitemill2.stl');
    Vert = scale*V';
    if complex_tether_flag
        tether_handle = [];
        handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z,[]); hold on
    else
        tether_handle = drawTether(pn, pe, pd, []); hold on
        handleParticles = [];
    end
    pos_W = [-pn; pe; -pd];
    p_VT_W_handle = drawVirtualTarget(p_VT_W,pos_W,[]);
    
   % [h_stab,h_wing,h_plane] = drawVehicleBody2(V_stab,V_wing,V_plane,...
    %    pn, pe, pd, phi, theta, psi, ...
     %   [],[],[], 'normal');
     [p] = drawVehicleBody2(Vert,pn, pe, pd, phi, theta, psi,[],'normal');

    col1 =  [85/255, 85/255, 85/255 ];
    col2 =  [170/255, 170/255, 170/255];
    col3 =  [116/255, 136/255, 140/255 ];
    color = col1;%[   128, 128, 128   ]/255;
    pathpoints = animatedline('Linestyle','-','color', color, 'Linewidth', 1.5);
    %pathpoints = animatedline('Marker','.','color', [0.5 0 0], 'Linewidth', 1);
    pathpoints2 = animatedline('Marker','.','color', [0 0.5 0], 'Linewidth', 0.2);
        axis([-50 600 -300 300 0 500]);  hold on

    %======== lissajous figure ========
    if 0
        l_tether = norm(uu(1:3));
        [ LemPs ] = updateLissajous( l_tether, LemPsRef );
        Alambda = LemPs.Alambda ;
        Aphi = LemPs.Aphi;
        blambda = LemPs.blambda;
        bphi = LemPs.bphi;
        phi0 = LemPs.phi0;
        theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
        L = [Alambda * sin(blambda*theta_vec');
            Aphi    * sin(bphi*theta_vec') + phi0];
        L_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))]*l_tether;
    end
    %=================================
    %handleTempPath = drawTempPath(temp_path_x,temp_path_y,temp_path_z, []);
    
    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), []);
    %xlabel('$$Downwind$$ $$(m)$$', 'interpreter', 'latex')
    %ylabel('$$Crosswind$$ $$(m)$$', 'interpreter', 'latex')
    %zlabel('$$Up$$ $$(m)$$', 'interpreter', 'latex')
    xlabel('$$(m)$$', 'interpreter', 'latex')
    ylabel('$$(m)$$', 'interpreter', 'latex')
    zlabel('$$(m)$$', 'interpreter', 'latex')
    set(gca, 'Fontsize' ,14);
    grid on
    box on;
    axis equal; hold on;
    view(90,30); % set the vieew angle for figure
    view(50,30); % set the vieew angle for figure
    
    %axis([0 1000 -300 300 0 1000]);  hold on
    set(gca,'TickLabelInterpreter','latex');
    %drawLissajous;
else
        axis([-50 600 -300 300 0 500]);  hold on

    %    if mod(t,10) == 0 %|| t > 4
    %         drawVehicleBody(Vertices, Faces, facecolors,...
    %         pn, pe, pd, phi, theta, psi, ...
    %         []);
    %         drawParticleTether(p_t_x,p_t_y,p_t_z, []);
    %    end
    
    %title(['v_k= ' num2str(V_k_tot), ' (m/s)', ' \chi_{t,cmd}= ', num2str(course_t_cmd), ' (deg)']);
    drawVehicleBody2(Vert,pn, pe, pd, phi, theta, psi,p);
    color_traction = [34, 153, 84]/255;
    
    color =  [   128, 128, 128   ]/255;
    addpoints(pathpoints,-pn, pe, -pd);
    
    % plot3( -pn, pe, -pd, 'Linewidth', 2, 'Markersize', 3, 'color', 'blu);
    if complex_tether_flag
        handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles);
    else
        tether_handle = drawTether(pn, pe, pd, tether_handle);
    end
    pos_W = [-pn;pe;-pd];
    if norm(pos_W) > 1e-3
        p_VT_W_handle = [];drawVirtualTarget(p_VT_W,pos_W, p_VT_W_handle);
    else
        p_VT_W_handle = [];
    end
    if 0
        deltaC = 1;
        if mod(counter-1, deltaC) == 0
            if counter == 1
                print([eval('pwd'),'/video/','vidPic_',num2str(counter)], '-dpng', '-r300');
            else
                print([eval('pwd'),'/video/','vidPic_',num2str((counter-1)/deltaC)], '-dpng', '-r300');
            end
        end
    end
    
    %======== lissajous figure ========
    if 0
        l_tether = norm(uu(1:3));
        [ LemPs ] = updateLissajous( l_tether, LemPsRef );
        Alambda = LemPs.Alambda ;
        Aphi = LemPs.Aphi;
        blambda = LemPs.blambda;
        bphi = LemPs.bphi;
        phi0 = LemPs.phi0;
        theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
        L = [Alambda * sin(blambda*theta_vec');
            Aphi    * sin(bphi*theta_vec') + phi0];
        L_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))]*l_tether;
    end
    %=================================
    
    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), referencePath);
    handleTempPath = [];%drawTempPath(temp_path_x,temp_path_y,temp_path_z, handleTempPath);
    counter = counter + 1;
   
    %title(['$$State:$$ ', statestr, '$$.$$ $$Power:$$ ', num2str(power/1000), '$$ $$ $$kW.$$'],'Interpreter','latex');
    %title(['$$time:$$ ',num2str(t), '$$ $$ $$s.$$'],'Interpreter','latex');
    
end
end
function handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles)
if isempty(handleParticles)
    handleParticles = plot3( p_t_x, p_t_y,p_t_z , '-o', 'color', [0.1 0.1 0.1], 'Markersize',2, 'Linewidth', 1, 'MarkerFaceColor', [0.3 0.3 0.3]); hold on;
else
    set(handleParticles,'XData',p_t_x,'YData',p_t_y,'ZData',p_t_z);
end
drawnow;
end

function handleTempPath = drawTempPath(x,y,z, handleTempPath)
if isempty(handleTempPath)
    color =  [   128, 128, 128   ]/255;
    handleTempPath = plot3( x, y,z , '-', 'color', color,'Linewidth', 2); hold on;
else
    set(handleTempPath,'XData',x,'YData',y,'ZData',z);
end
drawnow;
end



function referencePath = drawReferencePath(x,y,z, referencePath)
if isempty(referencePath)
    referencePath = plot3( x, y,z , '-', 'color', [0.3 0.3 0.3],'Linewidth', 1.5); hold on;
else
    set(referencePath,'XData',x,'YData',y,'ZData',z);
end
drawnow;
end



function handleT = drawTether(pn, pe, pd, handleT)
M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
pts = M_EO * [pn;pe;pd];
if isempty(handleT),
    handleT = plot3([0 pts(1)], [0 pts(2)], [0 pts(3)], '-k');
else
    set(handleT,'XData',[0 pts(1)],'YData',[0 pts(2)],'ZData',[0 pts(3)] );
end
drawnow;
end

function p_VT_W_handle = drawVirtualTarget(p_VT_W,pos_W, p_VT_W_handle)
if isempty(p_VT_W_handle)
    p_VT_W_handle = [];%plot3(p_VT_W(1), p_VT_W(2), p_VT_W(3), '+b');
    %quiver3( pos_W(1), pos_W(2), pos_W(3), p_VT_W(1)*50, p_VT_W(2)*50,p_VT_W(3)*50,'b')%
else
    set(p_VT_W_handle,'XData',p_VT_W(1),'YData',p_VT_W(2),'ZData',p_VT_W(3));
end
drawnow;
end

function [p] = drawVehicleBody2(V,...
    pn, pe, pd, phi, theta, psi,p, mode)
%V = rotate( V, phi+pi, theta, psi+pi );
V = rotate( V, -phi-pi, -theta, psi+pi );
% Stabilizer
%V_stab = rotate(V_stab, phi, theta, psi); % body frame into NED frame
V = translate(V, pn , pe, pd);
M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
V = M_EO*V; % Transform from NED into E frame

if isempty(p)
    [F, ~, C] = rndread('kitemill2.stl');
    col =  [ 57/255, 106/255, 177/255  ];
    p = patch('faces', F, 'vertices' ,V');
    set(p, 'facec', 'b');              % Set the face color (force it)
   % set(p, 'facec', 'flat');            % Set the face color flat
    set(p, 'FaceVertexCData', C);       % Set the color (from file)
    %set(p, 'facealpha',.4)             % Use for transparency
    set(p, 'EdgeColor','none');
    set(p, 'FaceLighting', 'none'); 
    set(p, 'FaceColor', col ); 
   % light  
    %('Position',[0 0 1]);% add a default light
    view(45,45);
    daspect([1 1 1])   
else
    %set(p, 'Xdata', xstab, 'Ydata', ystab, 'Zdata', zstab);
    set(p, 'Vertices', V');
    %set(h_wing, 'Xdata', xwing, 'Ydata', ywing, 'Zdata', zwing);
    %set(h_plane, 'Xdata', xplane, 'Ydata', yplane, 'Zdata', zplane);
    drawnow
end
end

function pts = rotate(pts, phi, theta, psi)

% From B 2 O
pts = [ cos(psi)*cos(theta), cos(psi)*sin(phi)*sin(theta) - cos(phi)*sin(psi), sin(phi)*sin(psi) + cos(phi)*cos(psi)*sin(theta);
    cos(theta)*sin(psi), cos(phi)*cos(psi) + sin(phi)*sin(psi)*sin(theta), cos(phi)*sin(psi)*sin(theta) - cos(psi)*sin(phi);
    -sin(theta),                              cos(theta)*sin(phi),                              cos(phi)*cos(theta)] * pts;
end

function pts = translate(pts, pn, pe, pd)
pts = pts + repmat([pn;pe;pd], 1, size(pts,2));
end

function [V_stab,V_wing,V_plane] = defineVehicleBody
scale =5;
xplane = [];
yplane = [];
zplane = [];
R = [ acos([0;0.4;0.8;1]) ];
[x,y,z] = cylinder(R,10);
z(end,:) = [3.*z(end,:) + 4.*z(end-1,:)]./7;
aux=x;x=-z;z=aux;
x = x./max(max(abs(x)));
y = y./max(max(abs(y)));
z = z./max(max(abs(z)));
x = flipud(x);
y = flipud(y);
z = flipud(z);
xnose = x.*2.50 + 3.00;
ynose = y.*0.80 + 0.00;
znose = z.*0.85 + 3.15;
xplane = [ xplane; xnose ];
yplane = [ yplane; ynose ];
zplane = [ zplane; znose ];
xfus1 = x(end,:).*0.00 + 8.5;
yfus1 = ynose(end,:);
zfus1 = znose(end,:);
xplane = [ xplane; xfus1 ];
yplane = [ yplane; yfus1 ];
zplane = [ zplane; zfus1 ];
xfus2 = x(end,:).*0.00 + 12.5;
yfus2 = y(end,:).*0.30;
zfus2 = z(end,:).*0.55 + 3.7;
xplane = [ xplane; xfus2 ];
yplane = [ yplane; yfus2 ];
zplane = [ zplane; zfus2 ];
xtail = [13.8; 14.1; 14.8]*ones(size(x(end,:)));
ytail = [y(end,:).*0.10 + 0.00; y(end,:).*0.10 + 0.00; y(end,:).*0.00 + 0.00];
ztail = [z(end,:).*1.45 + 4.85; z(end,:).*1.40 + 4.90; z(end,:).*0.00 + 6.30];
xplane = [ xplane; xtail ];
yplane = [ yplane; ytail ];
zplane = [ zplane; ztail ];
% xwing = [ ...
%     7.0   7.25 8.0  7.25 7.0; ...
%     6.0   7.0  9.5 7.0  6.0; ...
%     7.0   7.25 8.0  7.25 7.0; ...
%     ];
xwing = [ ...
    7.0   7.25 8.0  7.25 7.0; ...
    6.5   7.0  9 7.0  6.5; ...
    7.0   7.25 8.0  7.25 7.0; ...
    ];
ywing = 1.5*[ ...
    -8.0 -8.0 -8.0 -8.0 -8.0; ...
    0.0   0.0  0.0  0.0  0.0; ...
    8.0   8.0  8.0  8.0  8.0];
zwing = 0.2 + [ ...
    3.0   3.0  3.0  3.0  3.0; ...
    2.6   2.55 2.4  2.45 2.6; ...
    3.0   3.0  3.0  3.0  3.0; ...
    ];
xstab = (xwing - 7.0).*(1.5/3.5) + 13;
ystab = (ywing - 0.0).*(3.0/8.0) +  0;
zstab = [ ...
    4.5   4.5  4.5  4.5  4.5; ...
    4.1   4.1  4.1  4.1  4.1; ...
    4.5   4.5  4.5  4.5  4.5; ...
    ];

% cg correction
x_cg   = 7;
xstab  = xstab  - x_cg;
xwing  = xwing  - x_cg;
xplane = xplane - x_cg;
y_cg   = 0;
ystab  = ystab  - y_cg;
ywing  = ywing  - y_cg;
yplane = yplane - y_cg;
z_cg   = 3.2;
zstab  = zstab  - z_cg;
zwing  = zwing  - z_cg;
zplane = zplane - z_cg;

V_stab = scale*[ reshape(-xstab, 1, 15);reshape(ystab, 1, 15);reshape(-zstab, 1, 15)];
V_wing = scale*[ reshape(-xwing, 1, 15);reshape(ywing, 1, 15);reshape(-zwing, 1, 15)];
V_plane = scale*[ reshape(-xplane, 1, 99);reshape(yplane, 1, 99);reshape(-zplane, 1, 99)];


end
