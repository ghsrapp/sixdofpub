figure; 
plot( power_output.Time, power_output.Data/1000, 'k');
xlabel('$$Time$$ $$[s]$$', 'interpreter', 'latex');
ylabel('$$P$$ $$[kW]$$', 'interpreter', 'latex');
set(gca,'TickLabelInterpreter','latex');