load('pos_W_save.mat');
load('pos_W2_save.mat');

%%
figure; 
drawLissajous
color = [0/255,200/255,0/255];
plot3( pos_W_save.Data(:,1), pos_W_save.Data(:,2), pos_W_save.Data(:,3),'color',color, 'Linewidth', 1.5); hold on 
color = [200/255,0*60/255,0*60/255];
plot3( pos_W2_save.Data(:,1), pos_W2_save.Data(:,2), pos_W2_save.Data(:,3),'color',color, 'Linewidth', 1.5); hold on 
color = [218/255,165/255,32/255];
plot3( pos_W0_save.Data(1:6e5,1), pos_W0_save.Data(1:6e5,2), pos_W0_save.Data(1:6e5,3),'color',color, 'Linewidth', 1.5); hold on 
view(90,30); grid on
set(gca, 'TickLabelInterpreter','latex')