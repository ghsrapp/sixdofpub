close all

figure; 
subplot(311)
plot(  mu_save.Time(1:end/2.5), mu_save.Data(1:end/2.5,2), 'color', [0, 0, 0]/255); hold on
%plot( mu_save.Time(1:end/2.5), mu_save.Data(1:end/2.5,1), 'k'); hold on
plot( mu_save.Time(1:end/2.5), mu_save.Data(1:end/2.5,3), 'color', [160, 160, 160]/255);
plot( [0 200], [60 60], '--k'); 
plot( [0 200], [-60 -60], '--k'); 
xlabel('$$Time$$ $$[s]$$', 'interpreter', 'latex');
ylabel('$$\mu_a$$ $$[^\circ]$$', 'interpreter', 'latex');
set(gca,'TickLabelInterpreter','latex');
axis([0 200 -65 65]);

subplot(312)
plot(  alpha_save.Time(1:end/2.5), alpha_save.Data(1:end/2.5,2), 'color', [0, 0, 0]/255); hold on
%plot( alpha_save.Time(1:end/2.5), alpha_save.Data(1:end/2.5,1), 'k'); hold on
plot( alpha_save.Time(1:end/2.5), alpha_save.Data(1:end/2.5,3), 'color', [160, 160, 160]/255);
plot( [0 200], [10 10], '--k'); 
plot( [0 200], [-10 -10], '--k'); 
xlabel('$$Time$$ $$[s]$$', 'interpreter', 'latex');
ylabel('$$\alpha$$ $$[^\circ]$$', 'interpreter', 'latex');
set(gca,'TickLabelInterpreter','latex');
axis([0 200 -15 15]);

subplot(313)
plot(  beta_save.Time(1:end/2.5), beta_save.Data(1:end/2.5,2), 'color', [0, 0, 0]/255); hold on
%plot( alpha_save.Time(1:end/2.5), alpha_save.Data(1:end/2.5,1), 'k'); hold on
plot( beta_save.Time(1:end/2.5), beta_save.Data(1:end/2.5,3), 'color', [160, 160, 160]/255);
%plot( [0 200], [10 10], '--k'); 
%plot( [0 200], [-10 -10], '--k'); 
xlabel('$$Time$$ $$[s]$$', 'interpreter', 'latex');
ylabel('$$\beta$$ $$[^\circ]$$', 'interpreter', 'latex');
set(gca,'TickLabelInterpreter','latex');
axis([0 200 -10 5]);