close all
delta_phi = pi/8;
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
l_tether_vec = [300 350 400 450 500 550 600];
params.b_booth = 200;
params.a_booth = 0.5;
params.phi0_booth = 30*pi/180;

l_tether_vec = [300 350 400 450 500 550 600];
phi_0_vec = [70*pi/180 52*pi/180 42*pi/180 35*pi/180 30*pi/180 30*pi/180 params.phi0_booth];
 
l_tether_vec = 300 : 10 : 600; 
phi_0_vec = linspace(70*pi/180,params.phi0_booth, length(l_tether_vec) ); 

u = params.phi0_booth; 
lam = 0.8; 
y = 70*pi/180; 
for l = 1 : length( l_tether_vec )
   phi_0_vec(l)=y;
   y = y*lam+(1-lam)*u; 
end

h =  figure(1);
for k = 1 : length(l_tether_vec)
    l_tether = l_tether_vec(k);
    %if k == 2
    %phi_0_vec = phi_0_vec(k);
    %end
    %for n = 1 : length( phi_0_vec )
    
    phi_p_mean = phi_0_vec(k);
    
    %l_tether = 600;
    Lbooth.b = params.b_booth;
    Lbooth.a = params.b_booth*params.a_booth;
    Lbooth.phi0 = params.phi0_booth;
    [Lem] = updateBoothLemniscate(l_tether,Lbooth);
    s = 0 : 0.005 : 2*pi;
    %a = a/l_tether;
    
    
    %s =  Lbooth.s_trans_retract
    %s = Lbooth.init_sol
    long_P = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
    lat_P =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 );
    
    s_trans_1 = pi/2;
    s_trans_2 = 3*pi/2;
    
    long_P_trans_1 = Lem.b * sin(s_trans_1) ./( 1+(Lem.a/Lem.b*cos(s_trans_1)).^2 );
    lat_P_trans_1 =   Lem.a * sin(s_trans_1).*cos(s_trans_1) ./ ( 1+(Lem.a/Lem.b*cos(s_trans_1)).^2 );
    
    long_P_trans_2 = Lem.b * sin(s_trans_2) ./( 1+(Lem.a/Lem.b*cos(s_trans_2)).^2 );
    lat_P_trans_2 =   Lem.a * sin(s_trans_2).*cos(s_trans_2) ./ ( 1+(Lem.a/Lem.b*cos(s_trans_2)).^2 );
    
    p_trans_P_1 = [ cos(long_P_trans_1).*cos(lat_P_trans_1);sin(long_P_trans_1).*cos(lat_P_trans_1);sin(lat_P_trans_1)]*l_tether;
    p_trans_P_2 = [ cos(long_P_trans_2).*cos(lat_P_trans_2);sin(long_P_trans_2).*cos(lat_P_trans_2);sin(lat_P_trans_2)]*l_tether;
    
    %long = Lem.a * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
    %lat =   Lem.a^2/Lem.b * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
    %%
    
    
    % transform into cartesian coordinates
    p_P = [ cos(long_P).*cos(lat_P);sin(long_P).*cos(lat_P);sin(lat_P)]*l_tether;
    p_P_middle = [ 1;0;0]*l_tether;
    
    %%
    M_WP = [cos(phi_p_mean),0, -sin(phi_p_mean);
        0, 1, 0;
        sin(phi_p_mean),0, cos(phi_p_mean)];
    
    p = M_WP * p_P;
    p_P_middle_W = M_WP*p_P_middle;
    
    p_trans_W_1 =  M_WP * p_trans_P_1;
    p_trans_W_2 =  M_WP * p_trans_P_2;
    % figure(1);
    %plot3(p(1,:), p(2,:), p(3,:),'color',  col2 ,'MarkerIndices',1:20:length(p)); hold on
    %if k == 1
      if  k == 1 || k == length(l_tether_vec)
           l = plot3(p(1,:), p(2,:), p(3,:),'-','color', col1 ,'Linewidth',2); hold on
           l.Color(4)=1;
      else
          s = plot3(p(1,:), p(2,:), p(3,:),'-','color', col1 ,'Linewidth',1); hold on
          s.Color(4)=0.3;
      end
      %  else
       %     plot3(p(1,:), p(2,:), p(3,:),'--','color', col1 ,'Linewidth',1.5); hold on
       % end
    %else
    %    plot3(p(1,:), p(2,:), p(3,:),'-','color', col1 ,'Linewidth',1.5); hold on
    %end
    if k == 1 || k == length(l_tether_vec)
        plot3(p_trans_W_1(1,:), p_trans_W_1(2,:), p_trans_W_1(3,:),'*','color', col2 ,'Linewidth',1.5); hold on
        plot3(p_trans_W_2(1,:), p_trans_W_2(2,:), p_trans_W_2(3,:),'*','color', col2 ,'Linewidth',1.5); hold on
    end
    if k == 1
        %if n == 1
            p_trans_W_1_save = p_trans_W_1;
            p_trans_W_2_save = p_trans_W_2;
       % end
        plot3([0 p_P_middle_W(1,:)], [0 p_P_middle_W(2,:)], [0 p_P_middle_W(3,:)],'--k','Linewidth',1.5); hold on
    elseif k == length(l_tether_vec)
        plot3([0 p_P_middle_W(1,:)], [0 p_P_middle_W(2,:)], [0 p_P_middle_W(3,:)],'--k','Linewidth',1.5); hold on
        plot3([p_trans_W_1(1) p_trans_W_1_save(1)], [p_trans_W_1(2) p_trans_W_1_save(2)], [p_trans_W_1(3) p_trans_W_1_save(3)],'-','color', col1 ,'Linewidth',2); hold on
        plot3([p_trans_W_2(1) p_trans_W_2_save(1)], [p_trans_W_2(2) p_trans_W_2_save(2)], [p_trans_W_2(3) p_trans_W_2_save(3)],'-','color', col1 ,'Linewidth',2); hold on
    end
    
    
    %plot3(p(1,:), p(2,:), p(3,:),'*r','Markersize',20); hold on
    % xlabel('$x_W$ $(m)$','interpreter', 'latex')
    % ylabel('$y_W$ $(m)$','interpreter', 'latex')
    % zlabel('$z_W$ $(m)$','interpreter', 'latex')
    % axis equal
    % axis([ 0 1550 -300 300 50 600])
    
    % s = Lbooth.init_sol;
    % long = Lem.b * sin(s) ./( 1+(Lem.a/Lem.b*cos(s)).^2 );
    % lat =   Lem.a * sin(s).*cos(s) ./ ( 1+(Lem.a/Lem.b*cos(s)).^2 ) + Lem.phi0;
    % Lbooth.p_init_VT_path = [ cos(long).*cos(lat);
    %       sin(long).*cos(lat);
    %       sin(lat)]*l_tether;
    % X = [-300;1000;1000;-300];
    % Y = [-600;-600;600;600];
    % v = [X,Y];
    % c = [0 1 0; % red
    %     0 1 0; % green
    %     0 1 0;
    %     0 1 0];
    % fill(X,Y, c(:,2),'EdgeColor','none','FaceColor',c(1,:),'FaceAlpha',0.1);
    % axis equal;
    %
    %view(90,25);
    
    
    
    %%
    if k == 1 || k == length(l_tether_vec)
        theta = 0 : 0.01 : 2*pi;
        circ = [ cos(theta)*l_tether; sin(theta)*l_tether ];
        plot3( circ(1,:)', zeros(length(circ),1) , circ(2,:)', '--k', 'Linewidth', 1.5 )
    end
end
% [x,y,z] = sphere(50);
r = l_tether;
%h = surf(x*r,y*r,z*r); hold on
% set(h, 'FaceColor', [0.5 0.5 0.5], 'FaceAlpha', 0.3, 'edgecolor','none');
%set(gca,'TickLabelInterpreter','latex')
axis equal

axis( [0 l_tether -l_tether l_tether 0 l_tether]);
xlabel('$x_W$ $(m)$');
ylabel('$y_W$ $(m)$');
zlabel('$z_W$ $(m)$');
% xlabel('$x_W$ $(m)$','interpreter', 'latex');
% ylabel('$y_W$ $(m)$','interpreter', 'latex');
% zlabel('$z_W$ $(m)$','interpreter', 'latex');
view(0,0)
set(figure(1), 'render', 'painters');

Plot2LaTeX( h, 'path_rotated' )

