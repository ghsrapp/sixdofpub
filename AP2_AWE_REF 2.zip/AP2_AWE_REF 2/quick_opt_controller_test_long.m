clear
close all
clc

load('sys_trim.mat');


load('list_old_individuals.mat');

[val,idx] = min( list_old_individuals(end,:) );

qs = list_old_individuals(1:4, idx);

Q_long = diag([0;qs]);
R_long = 1;

A_long = sys_trim.A_long;
B_long = sys_trim.B_long;

K_long = lqr( A_long, B_long, Q_long, R_long );

[time_domain_ref_long, frequ_domain_ref_long, time_domain_ref_lat, frequ_domain_ref_lat] = getRobustificationSettings(); 
opts = robOptions('VaryFrequency','off', 'Sensitivity', 'Off');
yOUTlog  = get_robustification_cost( time_domain_ref_long, frequ_domain_ref_long, A_long, B_long, K_long );

[stabmarg, CL] = getRobStabMargin_long( A_long, B_long, K_long, [0,1,0,0,0], opts, frequ_domain_ref_long);
step_info = stepinfo(CL.NominalValue,'RiseTimeLimits',[0,0.95]);
figure; 
step( CL );hold on 
step( CL.NominalValue ); 

save('K_long.mat', 'K_long'); 