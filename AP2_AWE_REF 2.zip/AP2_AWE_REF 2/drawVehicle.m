function drawVehicle(uu, V, F, patchcolors)
% process input to function
pn = uu(1); % inertial North position
pe = uu(2); % inertial East position
pd = uu(3); % inertial down position

phi = uu(4);
theta = uu(5);
psi = uu(6);

t = uu(7);

p_VT_W = uu(8:10);

V_k_tot = uu(11);
nP = uu(12);



%% TO-DO: activate deactive visualization of the complex tether and
% activate it also for multiple particles
p_t_x = [0;uu(13:17);-pn];
p_t_y = [0;uu(18:22);pe];
p_t_z = [0;uu(23:27);-pd];

complex_tether_flag = uu(28);

LemPsRef.AlambdaRef =  uu(29);
LemPsRef.AphiRef = uu(30);
LemPsRef.blambdaRef = uu(31);
LemPsRef.bphiRef =  uu(32);
LemPsRef.phi0 =  uu(33);
LemPsRef.deltaSol =  uu(34);

% Temp path
%temp_path_x = -uu(35:114);
%temp_path_y = uu(115:194);
%temp_path_z = -uu(195:274);

%%
%F_T = uu(275);
%F_T_avg = uu(276);
F_T = uu(35);
F_T_avg = uu(36);
v_ro = uu(37);

power = uu(38);
state = uu(39);



persistent vehicle_handle;
persistent Vertices
persistent Faces
persistent facecolors
persistent pathpoints
persistent pathpoints2
persistent tether_handle
persistent counter
persistent p_VT_W_handle
persistent referencePath
persistent handleParticles
persistent handleTempPath

if t==0
    figure(1), %clf
    counter = 1;
    [Vertices, Faces, facecolors] = defineVehicleBody;
    
    if complex_tether_flag
        tether_handle = [];
        handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z,[]); hold on
    else
        tether_handle = drawTether(pn, pe, pd, []); hold on
        handleParticles = [];
    end
    p_VT_W_handle = drawVirtualTarget(p_VT_W,[]);
    %p_VT_W_handle = animatedline('Marker','.','color','red');
    vehicle_handle = drawVehicleBody(Vertices, Faces, facecolors, ...
        pn, pe, pd, phi, theta, psi, ...
        [], 'normal');
    %pathpoints = animatedline('Marker','.','color', [0.6 0.6 0.6], 'Linewidth', 1);
    pathpoints = animatedline('Marker','.','color', [0.5 0 0], 'Linewidth', 1);
    pathpoints2 = animatedline('Marker','.','color', [0 0.5 0], 'Linewidth', 1);
    
    %======== lissajous figure ========
    if 0
        l_tether = norm(uu(1:3));
        [ LemPs ] = updateLissajous( l_tether, LemPsRef );
        Alambda = LemPs.Alambda ;
        Aphi = LemPs.Aphi;
        blambda = LemPs.blambda;
        bphi = LemPs.bphi;
        phi0 = LemPs.phi0;
        theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
        L = [Alambda * sin(blambda*theta_vec');
            Aphi    * sin(bphi*theta_vec') + phi0];
        L_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))]*l_tether;
    end
    %=================================
    %handleTempPath = drawTempPath(temp_path_x,temp_path_y,temp_path_z, []);
    
    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), []);
    xlabel('$$Downwind$$ $$(m)$$', 'interpreter', 'latex')
    % ylabel('East')
    zlabel('$$Up$$ $$(m)$$', 'interpreter', 'latex')
    set(gca, 'Fontsize' ,14); 
    grid on
    axis equal; hold on;
    view(90,30); % set the vieew angle for figure
    view(50,30); % set the vieew angle for figure

    axis([0 600 -200 200 0 500]); hold on
    set(gca,'TickLabelInterpreter','latex')
else
    
    %    if mod(t,10) == 0 %|| t > 4
    %         drawVehicleBody(Vertices, Faces, facecolors,...
    %         pn, pe, pd, phi, theta, psi, ...
    %         []);
    %         drawParticleTether(p_t_x,p_t_y,p_t_z, []);
    %    end
    
    %title(['v_k= ' num2str(V_k_tot), ' (m/s)', ' \chi_{t,cmd}= ', num2str(course_t_cmd), ' (deg)']);
    drawVehicleBody(Vertices, Faces, facecolors,...
        pn, pe, pd, phi, theta, psi, ...
        vehicle_handle);
    
    if v_ro > 0
        if F_T >= F_T_avg
            plot3(-pn, pe, -pd,'.','color', [1 128/255 0],'Markersize',6, 'Linewidth', 2);
        elseif norm(F_T-F_T_avg) < 100
            plot3(-pn, pe, -pd,'.','color', [0 0.7 0],'Markersize',6, 'Linewidth', 2);
        else
            plot3(-pn, pe, -pd,'.','color', [50/255 150/255 1],'Markersize',6, 'Linewidth', 2);
            %plot3(-pn, pe, -pd,'.','color', [0 0.7 0],'Markersize',10, 'Linewidth', 2);
        end
    else
        plot3(-pn, pe, -pd,'.','color', [0.7 0 0],'Markersize',6, 'Linewidth', 2);
        
    end
    
    % plot3( -pn, pe, -pd, 'Linewidth', 2, 'Markersize', 3, 'color', 'blu);
    if complex_tether_flag
        handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles);
    else
        tether_handle = drawTether(pn, pe, pd, tether_handle);
    end
    p_VT_W_handle = drawVirtualTarget(p_VT_W, p_VT_W_handle);
    if 0 
    deltaC = 1;
    if mod(counter-1, deltaC) == 0
        if counter == 1
                  print([eval('pwd'),'/video/','vidPic_',num2str(counter)], '-dpng', '-r300');
        else
                print([eval('pwd'),'/video/','vidPic_',num2str((counter-1)/deltaC)], '-dpng', '-r300');
        end
    end
    end
    %======== lissajous figure ========
    if 0
        l_tether = norm(uu(1:3));
        [ LemPs ] = updateLissajous( l_tether, LemPsRef );
        Alambda = LemPs.Alambda ;
        Aphi = LemPs.Aphi;
        blambda = LemPs.blambda;
        bphi = LemPs.bphi;
        phi0 = LemPs.phi0;
        theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';
        L = [Alambda * sin(blambda*theta_vec');
            Aphi    * sin(bphi*theta_vec') + phi0];
        L_W = [cos(L(1,:)).*cos(L(2,:));
            sin(L(1,:)).*cos(L(2,:));
            sin(L(2,:))]*l_tether;
    end
    %=================================
    
    %referencePath = drawReferencePath( L_W(1,:), L_W(2,:), L_W(3,:), referencePath);
    handleTempPath = [];%drawTempPath(temp_path_x,temp_path_y,temp_path_z, handleTempPath);
    counter = counter + 1;
    if state == 6
        statestr = '$$Retraction$$';
    elseif state == 10
        statestr = '$$Transition$$';
    else
        statestr = '$$Traction$$';
    end
    title(['$$State:$$ ', statestr, '$$.$$ $$Power:$$ ', num2str(power/1000), '$$ $$ $$kW.$$'],'Interpreter','latex');
    
end
end
function handleParticles = drawParticleTether(p_t_x,p_t_y,p_t_z, handleParticles)
if isempty(handleParticles)
    handleParticles = plot3( p_t_x, p_t_y,p_t_z , '-o', 'color', [0.1 0.1 0.1], 'Markersize',2, 'Linewidth', 1, 'MarkerFaceColor', [0.3 0.3 0.3]); hold on;
else
    set(handleParticles,'XData',p_t_x,'YData',p_t_y,'ZData',p_t_z);
end
drawnow;
end

function handleTempPath = drawTempPath(x,y,z, handleTempPath)
if isempty(handleTempPath)
    handleTempPath = plot3( x, y,z , '-', 'color', [0 0 0.6],'Linewidth', 2); hold on;
else
    set(handleTempPath,'XData',x,'YData',y,'ZData',z);
end
drawnow;
end



function referencePath = drawReferencePath(x,y,z, referencePath)
if isempty(referencePath)
    referencePath = plot3( x, y,z , '-', 'color', [0.3 0.3 0.3],'Linewidth', 1.5); hold on;
else
    set(referencePath,'XData',x,'YData',y,'ZData',z);
end
drawnow;
end



function handleT = drawTether(pn, pe, pd, handleT)
M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
pts = M_EO * [pn;pe;pd];
if isempty(handleT),
    handleT = plot3([0 pts(1)], [0 pts(2)], [0 pts(3)], '-k');
else
    set(handleT,'XData',[0 pts(1)],'YData',[0 pts(2)],'ZData',[0 pts(3)] );
end
drawnow;
end

function p_VT_W_handle = drawVirtualTarget(p_VT_W, p_VT_W_handle)
if isempty(p_VT_W_handle)
    p_VT_W_handle = [];%plot3(p_VT_W(1), p_VT_W(2), p_VT_W(3), '*g');
else
    set(p_VT_W_handle,'XData',p_VT_W(1),'YData',p_VT_W(2),'ZData',p_VT_W(3));
end
drawnow;
end

function handle = drawVehicleBody(V,F,patchcolors,...
    pn, pe, pd, phi, theta, psi,...
    handle,mode)
V = rotate(V, phi, theta, psi); % body frame into NED frame
V = translate(V, pn , pe, pd);

M_EO = [-1, 0, 0; 0, 1, 0; 0, 0, -1];
%V = M_ON * V; % Transform from N to NED frame
V = M_EO*V; % Transform from NED into E frame
if isempty(handle),
    handle = patch('Vertices', V', 'Faces', F, ....
        'FaceVertexCData', patchcolors,...
        'FaceColor', 'flat');%,...
    %'EraseMode', mode);
else
    set(handle,'Vertices', V', 'Faces', F);
    drawnow
end
end

function pts = rotate(pts, phi, theta, psi)

% From B 2 O
pts = [ cos(psi)*cos(theta), cos(psi)*sin(phi)*sin(theta) - cos(phi)*sin(psi), sin(phi)*sin(psi) + cos(phi)*cos(psi)*sin(theta);
    cos(theta)*sin(psi), cos(phi)*cos(psi) + sin(phi)*sin(psi)*sin(theta), cos(phi)*sin(psi)*sin(theta) - cos(psi)*sin(phi);
    -sin(theta),                              cos(theta)*sin(phi),                              cos(phi)*cos(theta)] * pts;
end

function pts = translate(pts, pn, pe, pd)
pts = pts + repmat([pn;pe;pd], 1, size(pts,2));
end

function [V,F,facecolors] = defineVehicleBody
scale = 12;
b_wing = 3.7*scale;
c_wing = 0.22*scale;
L_fuse = 1*scale;
b_fuse = 0.1*scale;
c_emp = 0.1*scale;
b_emp = 0.4*scale;
h_rud = 0.3*scale;
h_fuse = 0.1*scale;
x_nose = 0.5*scale;
x_tail = 1.5*scale;
b_fuse = 0.1*scale;
xp = 0.1*scale;
x_LE = 0.1*scale;
c_rud = 0.1*scale;
V = [...
    x_nose, 0, 0; %1
    x_nose-xp, b_fuse/2, -h_fuse/2; %2
    x_nose-xp, b_fuse/2, +h_fuse/2; %3
    x_nose-xp, -b_fuse/2, +h_fuse/2; %4
    x_nose-xp, -b_fuse/2, -h_fuse/2; %5
    -x_tail, 0, 0; %6
    x_LE, b_wing/2, 0;%7
    x_LE-c_wing, b_wing/2, 0;%8
    x_LE-c_wing, -b_wing/2, 0; %9
    x_LE, -b_wing/2, 0;  %10
    -x_tail, -b_emp/2, 0;... % 11
    -(x_tail+c_emp), -b_emp/2, 0;...% 12
    -(x_tail+c_emp), b_emp/2, 0;...% 13
    -x_tail, b_emp/2, 0;...% 14
    -(x_tail+c_emp), 0, 0;... % 15
    -(x_tail+c_emp+c_rud), 0, 0;...% 16
    -(x_tail+c_emp+c_rud), 0, -h_rud;...% 17
    -(x_tail+c_emp), 0, -h_rud;...% 18
    ]';
F = [...
    1,2,3,3;... % pyramid
    3,4,1,1;...
    1,4,5,5;...
    1,2,5,5;...
    3,4,6,6;...
    4,5,6,6;...
    2,5,6,6;...
    2,3,6,6;...
    2,5,6,6;...
    7,8,9,10;...
    11,12,13,14;...
    15,16,17,18;...
    ];
facecolors = [0,0,0];
end
