function scaled_features = doFeatureScaling( features )



%scaled_features = ( features - mean( features ) ) / (max( abs(features) )-min( abs(features) ));
scaled_features = ( features - min( abs(features) ) ) / (max( abs(features) )-min( abs(features) ));
%scaled_features = ( features - mean( features ) ) / sqrt( var( features ) );
