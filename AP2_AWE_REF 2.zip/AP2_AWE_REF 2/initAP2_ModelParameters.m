% Geometric properties
P_AP2.S_ref = 3; P_AP2.S_wing = P_AP2.S_ref;
P_AP2.b = 5.5;
P_AP2.c = 0.55; 
P_AP2.mass = 36.8; 
P_AP2.J = [25, 0, -0.47; 
           0,  32, 0; 
           -0.47, 0, 56];
P_AP2.Jx = P_AP2.J(1,1);
P_AP2.Jy = P_AP2.J(2,2); 
P_AP2.Jz = P_AP2.J(3,3); 
P_AP2.Jxz = -P_AP2.J(1,3); 

P_AP2.Jinv = inv( P_AP2.J ); 

       
P_AP2.d_tether = 0.0025; 
P_AP2.rho_tether = 0.0046; 
P_AP2.Cd_tether = 1.2; 
P_AP2.rho_air = 1.225;

% Aerodynamics 
P_AP2.Cx_0_0 = -0.0293; P_AP2.Cx_0_alpha = 0.4784; P_AP2.Cx_0_alpha2 = 2.5549;
P_AP2.Cx_q_0 = -0.6029; P_AP2.Cx_q_alpha = 4.4124;  P_AP2.Cx_q_alpha2 = 0;
P_AP2.Cx_deltaE_0 = -0.0106;    P_AP2.Cx_deltaE_alpha = 0.1115; P_AP2.Cx_deltaE_alpha2 = 0;

P_AP2.Cy_beta_0 = -0.1855;  P_AP2.Cy_beta_alpha =-0.0299;   P_AP2.Cy_beta_alpha2 = 0.0936;  
P_AP2.Cy_p_0 = -0.1022; P_AP2.Cy_p_alpha = -0.0140; P_AP2.Cy_p_alpha2 = 0.0496;
P_AP2.Cy_r_0 =0.1694;   P_AP2.Cy_r_alpha = 0.1368;  P_AP2.Cy_r_alpha2 = 0;
P_AP2.Cy_deltaA_0 = -0.0514;    P_AP2.Cy_deltaA_alpha = -0.0024;    P_AP2.Cy_deltaA_alpha2 = 0.0579;
P_AP2.Cy_deltaR_0 = 0.10325;    P_AP2.Cy_deltaR_alpha = 0.0268; P_AP2.Cy_deltaR_alpha2 = -0.1036;

P_AP2.Cz_0_0 = -0.5526; P_AP2.Cz_0_alpha  = -5.0676;    P_AP2.Cz_0_alpha2 = 5.7736;
P_AP2.Cz_q_0 = -7.5560; P_AP2.Cz_q_alpha = 0.1251;  P_AP2.Cz_q_alpha2 = 6.1486;
P_AP2.Cz_deltaE_0 = -0.315; P_AP2.Cz_deltaE_alpha = -0.0013;    P_AP2.Cz_deltaE_alpha2 = 0.2923;

P_AP2.Cm_0_0 = -0.0307; P_AP2.Cm_0_alpha = -0.6027; P_AP2.Cm_0_alpha2 = 0;
P_AP2.Cm_q_0 = -11.3022;    P_AP2.Cm_q_alpha =  -0.0026;    P_AP2.Cm_q_alpha2 = 5.2885;
P_AP2.Cm_deltaE_0 = -1.0427;    P_AP2.Cm_deltaE_alpha = -0.0061;    P_AP2.Cm_deltaE_alpha2 = 0.9974;

P_AP2.Cl_beta_0 = -0.063;   P_AP2.Cl_beta_alpha = -0.0003;  P_AP2.Cl_beta_alpha2 = 0.0312;
P_AP2.Cl_p_0 = -0.5632; P_AP2.Cl_p_alpha = -0.0247; P_AP2.Cl_p_alpha2 = 0.2813;
P_AP2.Cl_r_0 = 0.1811;  P_AP2.Cl_r_alpha = 0.6448;  P_AP2.Cl_r_alpha2 = 0;  
P_AP2.Cl_deltaA_0 = -0.2489;    P_AP2.Cl_deltaA_alpha  = -0.0087;   P_AP2.Cl_deltaA_alpha2 = 0.2383;
P_AP2.Cl_deltaR_0 = 0.00436;    P_AP2.Cl_deltaR_alpha = -0.0013;    P_AP2.Cl_deltaR_alpha2 = 0;

P_AP2.Cn_beta_0 = 0.0577;   P_AP2.Cn_beta_alpha = -0.0849;  P_AP2.Cn_beta_alpha2 = 0;
P_AP2.Cn_p_0 = -0.0565; P_AP2.Cn_p_alpha  = -0.9137;   P_AP2.Cn_p_alpha2  = 0;
P_AP2.Cn_r_0 = -0.0553; P_AP2.Cn_r_alpha = 0.0290;  P_AP2.Cn_r_alpha2 = 0.0257;
P_AP2.Cn_deltaA_0  = 0.01903;   P_AP2.Cn_deltaA_alpha = -0.1147;    P_AP2.Cn_deltaA_alpha2 =0;
P_AP2.Cn_deltaR_0 = -0.0404;    P_AP2.Cn_deltaR_alpha = -0.0117;    P_AP2.Cn_deltaR_alpha2  = 0.04089;

% Linear fit CL/CD 
P_AP2.CL0 = 0.4687; 
P_AP2.CL_alpha =  4.5619;

P_AP2.g = 9.81;

P_AP2.sampling_rate_fcs = 100; 