
%% save in struct
%% ---------------------------- TRACTION ----------------------------
% Bandwidths
paramStruct.w0_p_traction = evalin('base', 'w0_p_traction' ); 
paramStruct.w0_q_traction = evalin('base',' w0_q_traction '); 
paramStruct.w0_r_traction = evalin('base',' w0_r_traction '); 

paramStruct.w0_mu_traction = evalin('base',' w0_mu_traction'); 
paramStruct.w0_alpha_traction =evalin('base','  w0_alpha_traction'); 
paramStruct.w0_beta_traction = evalin('base',' w0_beta_traction'); 

% Gains 
paramStruct.Kp_chi_tau_traction = evalin('base',' Kp_chi_tau_traction'); 
paramStruct.Ki_chi_tau_traction = evalin('base',' Ki_chi_tau_traction'); 
paramStruct.Kp_chi_tau_trans = evalin('base',' Kp_chi_tau_trans'); 
paramStruct.Kp_gamma_tau_trans = evalin('base',' Kp_gamma_tau_trans'); 
paramStruct.Kp_gamma_tau_traction =evalin('base','  Kp_gamma_tau_traction'); 
paramStruct.Ki_gamma_tau_traction =evalin('base','  Ki_gamma_tau_traction'); 

paramStruct.Kp_mu_traction =evalin('base','  Kp_mu_traction'); 
paramStruct.Kp_alpha_traction =evalin('base','  Kp_alpha_traction'); 
paramStruct.Kp_beta_traction =evalin('base','  Kp_beta_traction'); 
paramStruct.Ki_mu_traction = evalin('base',' Ki_mu_traction'); 
paramStruct.Ki_alpha_traction =evalin('base','  Ki_alpha_traction'); 
paramStruct.Ki_beta_traction =evalin('base','  Ki_beta_traction'); 

paramStruct.Kp_p_traction =evalin('base','  Kp_p_traction'); 
paramStruct.Kp_q_traction = evalin('base',' Kp_q_traction'); 
paramStruct.Kp_r_traction = evalin('base',' Kp_r_traction'); 
paramStruct.Ki_p_traction = evalin('base',' Ki_p_traction'); 
paramStruct.Ki_q_traction = evalin('base',' Ki_q_traction'); 
paramStruct.Ki_r_traction = evalin('base',' Ki_r_traction'); 

paramStruct.a_booth = evalin('base',' a_booth'); 
paramStruct.b_booth = evalin('base',' b_booth'); 
paramStruct.phi0_booth = evalin('base',' phi0_booth'); 
paramStruct.F_T_traction_set = evalin('base',' F_T_traction_set'); 


%% ---------------------------- RE-TRACTION ----------------------------
% Bandwidths
paramStruct.w0_mu_retraction = evalin('base',' w0_mu_retraction');
paramStruct.w0_alpha_retraction = evalin('base',' w0_alpha_retraction'); 
paramStruct.w0_beta_retraction = evalin('base',' w0_beta_retraction'); 

paramStruct.w0_chi_retraction = evalin('base',' w0_chi_retraction'); 
paramStruct.w0_gamma_retraction = evalin('base',' w0_gamma_retraction'); 

% Gains
paramStruct.Kp_chi_retraction = evalin('base',' Kp_chi_retraction'); 
paramStruct.Ki_chi_retraction = evalin('base',' Ki_chi_retraction'); 
paramStruct.Kp_gamma_retraction = evalin('base',' Kp_gamma_retraction'); 
paramStruct.Ki_gamma_retraction = evalin('base',' Ki_gamma_retraction'); 

paramStruct.Kp_mu_retraction = evalin('base',' Kp_mu_retraction'); 
paramStruct.Kp_alpha_retraction = evalin('base',' Kp_alpha_retraction'); 
paramStruct.Kp_beta_retraction = evalin('base',' Kp_beta_retraction'); 
paramStruct.Ki_mu_retraction = evalin('base',' Ki_mu_retraction'); 
paramStruct.Ki_alpha_retraction = evalin('base',' Ki_alpha_retraction'); 
paramStruct.Ki_beta_retraction =evalin('base','  Ki_beta_retraction'); 

paramStruct.Kp_p_retraction =evalin('base','  Kp_p_retraction'); 
paramStruct.Kp_q_retraction =evalin('base','  Kp_q_retraction'); 
paramStruct.Kp_r_retraction =evalin('base','  Kp_r_retraction'); 
paramStruct.Ki_p_retraction =evalin('base','  Ki_p_retraction'); 
paramStruct.Ki_q_retraction =evalin('base','  Ki_q_retraction'); 
paramStruct.Ki_r_retraction =evalin('base','  Ki_r_retraction'); 

paramStruct.v_retraction_opt = -10; 
paramStruct.gamma_retract_opt = -30; 

save(['paramStruct.mat'],'paramStruct')
