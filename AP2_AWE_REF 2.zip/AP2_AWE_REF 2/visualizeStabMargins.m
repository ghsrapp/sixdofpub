function visualizeStabMargins( stabmarg_MM_save,u0_tmp_trim,x0_tmp_trim, name_file )
%%
col1 =  [ 57/255, 106/255, 177/255  ];
col2 =  [218/255, 124/255, 48/255 ];
col3 =  [62/255, 150/255, 81/255 ];
% lower bound
for k = 1 : size( stabmarg_MM_save, 1 )
    M(k,1) = u0_tmp_trim.u0_save(4,k);
    M(k,2) = x0_tmp_trim.x0_save(1,k);
    M(k,3) = x0_tmp_trim.x0_save(3,k)*180/pi;
end
lw = 1.2;

alpha_high = 0.3;
alpha_low = 1;

Ft_max = max( u0_tmp_trim.u0_save(4,:) );
Ft_min = min( u0_tmp_trim.u0_save(4,:) );
dF = 200; 
k_max = length( Ft_min : dF : Ft_max );

M_resh_Ft = reshape(M(:,1),size(M,1)/k_max, k_max);
M_resh_Va = reshape(M(:,2),size(M,1)/k_max, k_max);
M_resh_alpha = reshape(M(:,3),size(M,1)/k_max, k_max);
stabmarg_MM_save_resh_lb = reshape(stabmarg_MM_save(:,1),size(M,1)/k_max, k_max);
stabmarg_MM_save_resh_ub = reshape(stabmarg_MM_save(:,2),size(M,1)/k_max, k_max);
h1 = figure('Renderer', 'painters', 'Position', [100 100 300 200]);
for k = 1 : k_max
a_mks = (k-1)/(k_max-1);
alpha_lvl = (1-a_mks)*alpha_high + a_mks*alpha_low;
b_h = plot3( M_resh_alpha(:,k), M_resh_Va(:,k), stabmarg_MM_save_resh_lb(:,k), '-', 'color', col1, 'Linewidth', lw); hold on; drawnow
b_h.Color(4) = alpha_lvl;
plot3( M_resh_alpha(:,k), M_resh_Va(:,k),stabmarg_MM_save_resh_lb(:,k), 'x', 'color', 'k'); hold on; drawnow

%b_h = plot3( M_resh_alpha(:,k)*180/pi, M_resh_Va(:,k), stabmarg_MM_save_resh_ub(:,k), '-', 'color', col2, 'Linewidth', lw); hold on; drawnow
%b_h.Color(4) = alpha_lvl;
%plot3( M_resh_alpha(:,k)*180/pi, M_resh_Va(:,k),stabmarg_MM_save_resh_ub(:,k), 'x', 'color', 'k'); hold on; drawnow

end

xlabel('$\alpha$ (deg)');
ylabel('$v_\mathrm{a}$ (m/s)');
zlabel('$1/\mu_\mathrm{\Delta}$');
hs = surf( M_resh_alpha, M_resh_Va, stabmarg_MM_save_resh_lb );
set(hs,'edgecolor','none','facecolor',[0.8 0.8 0.8]);
%hs = surf( M_resh_alpha*180/pi, M_resh_Va, stabmarg_MM_save_resh_ub );
%set(hs,'edgecolor','none','facecolor',[0.8 0.8 0.8]);
box on 
view(100,10);
Plot2LaTeX2(h1,name_file);



