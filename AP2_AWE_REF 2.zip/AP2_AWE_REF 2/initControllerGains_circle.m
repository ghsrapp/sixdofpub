%% ======= Actuators ====
% The bandwidth of the system is restricted by the actuator bandwidth.
% The actuators are modeled as second order spring-damper elements.
zeta_actutaor = 1;%1.2;
omega_actuator = 35;%35;

omega_rates = omega_actuator;
omega_attitude = 10;


%% Chosen reference frequencies and damping
%factor_w0_chi = 1/2; 
%factor_w0_mu = 1/3; 
FCS.w0_p = 50;%factor_w0_p;
FCS.w0_mu = 1/3*FCS.w0_p;
FCS.w0_chi = 1/3*FCS.w0_mu;
FCS.w0_chi_retract = factor_w0_chi*FCS.w0_mu;

FCS.w0_q = 50;%factor_w0_q;
FCS.w0_alpha = factor_w0_alpha*FCS.w0_q ;
FCS.w0_gamma = factor_w0_gamma*FCS.w0_alpha;
FCS.w0_gamma_retract =factor_w0_gamma*FCS.w0_alpha;

%factor_w0_r = 25; 
%factor_w0_beta = 1/5;
FCS.w0_r = 50;%factor_w0_r;
FCS.w0_beta = factor_w0_beta*FCS.w0_r;

FCS.zeta_chi = 1;
FCS.zeta_gamma =1;
FCS.zeta_chi_retract  = 1;
FCS.zeta_gamma_retract  = 1;
FCS.zeta_mu = 1;
FCS.zeta_alpha = 1;
FCS.zeta_beta = 1;
FCS.zeta0_p = 1;
FCS.zeta0_q = 1;
FCS.zeta0_r = 1;

%% =====================================================
% P and I feedback gains
%
%% Factors are used for the tuning script/for now we use the same factors for the retraction and traction phase and same factor for P and I gain
FCS.Kp_chi = 1*1/factor_chi*factor_chi*FCS.w0_chi^2;
FCS.Ki_chi = 0*factor_chi*2*FCS.w0_chi*FCS.zeta_chi;

FCS.Kp_chi_retract = factor_chi*FCS.w0_chi_retract^2;
FCS.Ki_chi_retract = 0*factor_chi*2*FCS.w0_chi_retract*FCS.zeta_chi_retract;

%factor_mu = 1.5; 
FCS.Kp_mu = factor_mu*FCS.w0_mu^2;
FCS.Ki_mu = 0.1*factor_mu * 2 * FCS.zeta_mu * FCS.w0_mu;

FCS.Kp_p = factor_p*FCS.w0_p^2;
FCS.Ki_p = factor_p*FCS.w0_p*FCS.zeta0_p;
%
FCS.Kp_gamma = factor_gamma*FCS.w0_gamma^2;
FCS.Ki_gamma = 0*factor_gamma*2*FCS.w0_gamma*FCS.zeta_gamma;

FCS.Kp_gamma_retract = factor_gamma*FCS.w0_gamma_retract^2;
FCS.Ki_gamma_retract = factor_gamma*2*FCS.w0_gamma_retract*FCS.zeta_gamma_retract;

FCS.Kp_alpha =  factor_alpha*FCS.w0_alpha^2;
FCS.Ki_alpha =  factor_alpha*2 * FCS.zeta_alpha * FCS.w0_alpha;

FCS.Kp_q =  factor_q*FCS.w0_q^2;
FCS.Ki_q =  factor_q*2*FCS.w0_q*FCS.zeta0_q;
%
FCS.Kp_beta =  0.1*factor_beta*FCS.w0_beta^2;
FCS.Ki_beta = 0.01* factor_beta*2*FCS.zeta_beta * FCS.w0_beta;
FCS.Kd_beta = 0;

FCS.Kp_r =  1*factor_r*FCS.w0_r^2;
FCS.Ki_r = factor_r*2*FCS.w0_r*FCS.zeta0_r;
%% =====================================================

% FCS.omegaGammaDot = 25;
% FCS.zetaGammaDot = 0.8;

%% ======= Rate Controller Gains =======
% %FCS.Kp_rate = diag( [10,30,25] );
% FCS.Kp_rate = diag( [10,20,25] );
%
% FCS.Ki_rate = 0.5*diag( [10,10,10] );
% FCS.ARefRate = -omega_rates* eye(3);%5*FCS.ARefAttitude;
% FCS.BRefRate = omega_rates* eye(3);%5*FCS.BRefAttitude;
%

%% Control Allocation
FCS.C_A = [P.C_ell_delta_a, 0,P.C_ell_delta_r;
    0,P.C_m_delta_e ,0;
    P.C_n_delta_a, 0,P.C_n_delta_r];
FCS.C_A_inv = FCS.C_A \ eye(3);


%% Model parameters
FCS.J = P.J;
FCS.Jinv = P.Jinv;

%% Winch controller
omega_winch = 10;


P_gain_winch = 0.5;
Va_max = 80;
Va_min = 20;
hysteris_e = 5;

