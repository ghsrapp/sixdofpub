%% This script uses a defined grid for thector_mu_vec = 0.2 : 0.2 : 2;
% rate loop
factor_w0_p_vec = 25;
factor_w0_q_vec = 25;
factor_w0_r_vec = 25;
% attitude loop
factor_w0_mu_vec = 1/4; % times the current w0 of the rate loop
factor_w0_alpha_vec = 1/4;
factor_w0_beta_vec = 1/4;
% path loop
factor_w0_chi_vec =  1/2; % times the current w0 of the attitude loop
factor_w0_gamma_vec = 1/4;
yes_save_fig = 1;

d0_vec = 60; 
% mu_performance_metric = zeros(  6561, 11 );
% alpha_performance_metric = zeros(  6561, 11 );
% beta_performance_metric = zeros(  6561, 11 );
for iz = 1 : length( d0_vec)  
    CircleParam.d0 = d0_vec(iz);
    for ia = 1 : length( factor_w0_p_vec )
        factor_w0_p = factor_w0_p_vec(ia);
        for ib = 1 : length( factor_w0_q_vec )
            factor_w0_q = factor_w0_q_vec(ib);
            for ic = 1 : length( factor_w0_r_vec )
                factor_w0_r = factor_w0_r_vec(ic);
                for id = 1 : length( factor_w0_mu_vec )
                    factor_w0_mu = factor_w0_mu_vec(id);
                    for ie = 1 : length( factor_w0_alpha_vec )
                        factor_w0_alpha = factor_w0_alpha_vec(ie);
                        for iff = 1 : length( factor_w0_beta_vec )
                            factor_w0_beta = factor_w0_beta_vec(iff);
                            for ig = 1 : length( factor_w0_chi_vec )
                                factor_w0_chi = factor_w0_chi_vec(ig);
                                for ih = 1 : length( factor_w0_gamma_vec )
                                    factor_w0_gamma = factor_w0_gamma_vec(ih);
                                    %initControllerGains;
                                    initControllerGains_circle;
                                    sim('AWE_Testbed_06.slx');
                                    if yes_save_fig
                                        savefig(['.\tuning\path_',num2str(iz),'_',num2str(ia),'_',num2str(ib),'_',num2str(ic),'_',num2str(id),'_',...
                                            num2str(ie),'_',num2str(iff),'_',num2str(ig),'_',num2str(ih),'.fig'])
                                        clf
                                    end
                                    %                                 e_mu = mu_save.Data(:,2) - mu_save.Data(:,3);
                                    %                                 e_alpha = alpha_save.Data(:,2) - alpha_save.Data(:,3);
                                    %                                 e_beta = beta_save.Data(:,2) - beta_save.Data(:,3);
                                    
                                    %                                 mu_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_mu'*e_mu)./sqrt( mu_save.Data(:,2)'*mu_save.Data(:,2)),...
                                    %                                     max(abs(e_mu))/max( abs(mu_save.Data(:,2)) ),...
                                    %                                     ia,ib,ic,id,ie,iff,ig,ih];
                                    %                                 alpha_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_alpha'*e_alpha)./sqrt( alpha_save.Data(:,2)'*alpha_save.Data(:,2)),...
                                    %                                     max(abs(e_alpha))/max( abs(alpha_save.Data(:,2)) ),...
                                    %                                     ia,ib,ic,id,ie,iff,ig,ih];
                                    %                                 beta_performance_metric(cnt, :) = [mu_save.Time(end),sqrt(e_beta'*e_beta),...
                                    %                                     max(abs(e_beta)),...
                                    %                                     ia,ib,ic,id,ie,iff,ig,ih];
                                    %                                 figure(2);
                                    %                                 subplot(311)
                                    %                                 plot(mu_save.Time, mu_save.Data(:,1), 'b'); hold on
                                    %                                 plot(mu_save.Time, mu_save.Data(:,2), 'r'); hold on
                                    %                                 plot(mu_save.Time, mu_save.Data(:,3), 'g'); hold on
                                    %                                 ylabel('\mu (deg)')
                                    %                                 axis tight
                                    %                                 subplot(312)
                                    %                                 plot(mu_save.Time, alpha_save.Data(:,1), 'b'); hold on
                                    %                                 plot(mu_save.Time, alpha_save.Data(:,2), 'r'); hold on
                                    %                                 plot(mu_save.Time, alpha_save.Data(:,3), 'g'); hold on
                                    %                                 ylabel('\alpha (deg)')
                                    %                                 axis tight
                                    %                                 subplot(313)
                                    %                                 plot(mu_save.Time, beta_save.Data(:,1), 'b'); hold on
                                    %                                 plot(mu_save.Time, beta_save.Data(:,2), 'r'); hold on
                                    %                                 plot(mu_save.Time, beta_save.Data(:,3), 'g'); hold on
                                    %                                 ylabel('\beta (deg)')
                                    %                                 xlabel('t (s)');
                                    %                                 axis tight
                                    %                                 if yes_save_fig
                                    %                                     savefig(['.\tuning\eta_',num2str(ia),'_',num2str(ib),'_',num2str(ic),'_',num2str(id),'_',...
                                    %                                         num2str(ie),'_',num2str(iff),'_',num2str(ig),'_',num2str(ih),'.fig'])
                                    %                                 end
                                    cnt = cnt + 1;
                                    
                                end
                            end
                        end%q
                    end
                end
            end%p
        end
    end
    
    
end

