

% nominalF
FourWpConfig.d_nom_wps = 100;
FourWpConfig.h_nom_wps = 40;
l_init = 200;

wp_lat_mean = 30*pi/180;

FourWpConfig.dlong = 1*pi/180;
FourWpConfig.dlat = 1*pi/180;
FourWpConfig.wp_lat_mean= 30*pi/180;
FourWpConfig.exp_avg_const = 0.99;

cnt = 2;

l=l_init;
[wp_W_list] = update4WpList(l, FourWpConfig);
wp_plot = wp_W_list * l;

