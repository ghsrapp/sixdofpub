function [chi_tau, bearing_W] = calcBearingToWp(wp_infront_W, p_W)
%BEARINGTWOWP Summary of this function goes here
%   Detailed explanation goes here

p_W = p_W/norm(p_W); 
phi = asin( p_W(3) ); 
lamb = atan2( p_W(2), p_W(1) ); 

wp_infront_W = wp_infront_W/norm(wp_infront_W);

n = cross( wp_infront_W, p_W  ); 
n = n/norm(n);

bearing_W = cross( p_W, n ); 
bearing_W = bearing_W/norm(bearing_W); 

M_tauW = [-sin(phi)*cos(lamb), -sin(phi)*sin(lamb), cos(phi);
    -sin(lamb), cos(lamb), 0;
    -cos(phi)*cos(lamb), -cos(phi)*sin(lamb), -sin(phi)];

bearing_tau = M_tauW * bearing_W; 

chi_tau = atan2( bearing_tau(2), bearing_tau(1) ); 

end

