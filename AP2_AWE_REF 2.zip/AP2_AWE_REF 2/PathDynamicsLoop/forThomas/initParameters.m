clear all
close all
clc 

% span: 3.7m 
P.mass = 4.7780; 
P.S_wing = 0.7592;
P.g = 9.81; 
P.rho_air = 1.225;

% fourth order polynomial until 10 degrees
P.CL_Theta1_0 = 0.7455;
P.CL_Theta1_1 =  5.1798;
P.CL_Theta1_2 =  -2.6206;
P.CL_Theta1_3 = 0;
P.CL_Theta1_4 =  -105.4176; % fourth

% second order polynomial from 10 until 44 degrees.
P.CL_Theta2_0 =  1.3759;
P.CL_Theta2_1 =  0.7633;
P.CL_Theta2_2 =  -1.1266;

% drag full range
P.CD_Theta1_0 = 0.0527;
P.CD_Theta1_1 =  0.2370;
P.CD_Theta1_2 =   2.2131;
P.CD_Theta1_3 =  2.3448;
P.CD_Theta1_4 =  -3.8159; % fourth

P.CL_max =  1.4865; 

% For controller synthesis a second order polynomial can be used until 10
% degrees
P.CL_Theta_ctrl_0 = 0.7545;
P.CL_Theta_ctrl_1 = 5.1448;
P.CL_Theta_ctrl_2 = -5.4465;

% Tether
T.CD_tether = 1.0650; 
T.d_tether = 0.002;
T.c0 =  614600; 

%% Controller Parameter
alpha_a_star =  0.0349; 
alpha_a_min = -0.1745; 
alpha_a_max = 0.1745; 
mu_a_max = 1.0472; 
mu_a_min = -1.0472;

% gains: play around if you like
FCS.Kp_FlightPath_retraction = diag([2,5]);
FCS.Ki_FlightPath_retraction = diag([0,0.1]);
FCS.Kp_FlightPath = eye(2); 
FCS.Ki_FlightPath = zeros(2); 

omega_course =  2.1875; 
omega_gamma = 2.1875; 

windDirection_rad = pi;

initFourWps; 


plot3( wp_plot(1,1), wp_plot(1,2), wp_plot(1,3), 'ob'); hold on
plot3( wp_plot(2,1), wp_plot(2,2), wp_plot(2,3), 'ob');
plot3( wp_plot(3,1), wp_plot(3,2), wp_plot(3,3), 'ob');
plot3( wp_plot(4,1), wp_plot(4,2), wp_plot(4,3), 'ob');
