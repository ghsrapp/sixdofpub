function [stabmarg, CL] = getRobStabMargin_lat( A_lat, B_lat, K, C, opts, frequ_domain_ref_long )


upper_bound_A = A_lat; 
lower_bound_A = A_lat; 

upper_bound_B = B_lat; 
lower_bound_B = B_lat; 

upper_bound_A(1:4,1:4) = A_lat(1:4,1:4)*(1+frequ_domain_ref_long.unc_factor);
lower_bound_A(1:4,1:4) = A_lat(1:4,1:4)*(1-frequ_domain_ref_long.unc_factor);

upper_bound_B(1:4,1:2) = B_lat(1:4,1:2)*(1+frequ_domain_ref_long.unc_factor);
lower_bound_B(1:4,1:2) = B_lat(1:4,1:2)*(1-frequ_domain_ref_long.unc_factor);

mean_A = A_lat;
mean_B = B_lat;

for r = 1 : size( lower_bound_A, 1 )
    for c = 1 : size( lower_bound_A, 2)
        if abs( lower_bound_A(r,c) - upper_bound_A(r,c) ) < 1e-6
            A_unc(r,c) = mean_A(r,c);
        else
            if lower_bound_A(r,c) < upper_bound_A(r,c) % if sign is negative
                A_unc(r,c) = ureal(['A_',num2str(r),num2str(c)], mean_A(r,c) ,'Range',[lower_bound_A(r,c), upper_bound_A(r,c)]);
            else
                A_unc(r,c) = ureal(['A_',num2str(r),num2str(c)], mean_A(r,c) ,'Range',[upper_bound_A(r,c), lower_bound_A(r,c)]);
            end
            
        end
    end
end

for r = 1 : size( lower_bound_B, 1 )
    for c = 1 : size( lower_bound_B, 2)
        if abs( lower_bound_B(r,c) - upper_bound_B(r,c) ) < 1e-6
            B_unc(r,c) = mean_B(r,c);
        else
            if lower_bound_B(r,c) < upper_bound_B(r,c) % if sign is negative
                B_unc(r,c) = ureal(['B_',num2str(r),num2str(c)], mean_B(r,c) ,'Range',[lower_bound_B(r,c), upper_bound_B(r,c)]);
            else
                B_unc(r,c) = ureal(['B_',num2str(r),num2str(c)], mean_B(r,c) ,'Range',[ upper_bound_B(r,c), lower_bound_B(r,c)]);
            end
        end
    end
end
 
A_cl = A_unc - B_unc * K; 
B_cl = [zeros(size(A_unc,1)-size(B_unc,2),size(B_unc,2));eye(size(B_unc,2))]; 
C_cl = C; 
D_cl = zeros( size(C,1), size( B_unc,2) ); 
CL = ss( A_cl, B_cl, C_cl, D_cl ); 
[stabmarg,wcu,info] = robstab(CL,opts);

%% Test if wcu leads to an unstable system 
%CL_unst = usubs(CL, wcu ); 
1;




