%% Init all the retraction phase parameters 
gamma_retract_final = 0; 
delta_lat_init_retract_flare = 15; 