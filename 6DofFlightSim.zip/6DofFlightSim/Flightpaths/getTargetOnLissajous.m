function [ sol,p_C_W ] = getTargetOnLissajous(LemPs, p_kite_W, c0, l_tether)
%GETVTONLEMNISCATE Summary of this function goes here
%   Detailed explanation goes here
p_kite_W = p_kite_W/norm(p_kite_W); 
intervalInit = [c0-pi/8, c0+pi/8 ];
%[sol,FVAL,EXITFLAG] = fzero(@(c)func(c,p_kite_W,LemPs),c0);

%[ sol, res, f ] = bisectionMethod( @(s) func( s,p_kite_W, LemPs ), intervalInit, p_kite_W, LemPs);
[ sol, res, f ] = bisec( intervalInit, p_kite_W, LemPs );

if abs(sol-c0) > 10*pi/180
  1;% sol = c0 + 1*pi/180;
end


sol = mod(sol, 2*pi);

L = [LemPs.Alambda * sin(LemPs.blambda*sol');
    LemPs.Aphi    * sin(LemPs.bphi*sol') + LemPs.phi0];

p_C_W = [cos(L(1,:)).*cos(L(2,:));
    sin(L(1,:)).*cos(L(2,:));
    sin(L(2,:))]*l_tether;
end