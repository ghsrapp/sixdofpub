
windDirection_rad = 0; % as measured in the O frame (relative to north, positive)
x_K = transformFromOtoW( windDirection_rad, pos_O_init ); 

c_vec = linspace(0,2*pi,10);
delta_min = inf; 
mat_save = [];
f_vals = func(0:0.01:2*pi,x_K/norm(x_K), LemPs);

for c = 1 : length(c_vec)
    
    K = x_K / norm( x_K );
        
    % Determine closest point
    c0 = c_vec(c);
  
    [  sol, p_C_W ] = getTargetOnLissajous(LemPs, K, c0, l_tether);
     
    delta = acos( min( max( x_K' * p_C_W/norm(x_K)/norm(p_C_W), -1),1 ) ) * norm(x_K);
    mat_save = [mat_save;
                c0,sol, delta];
    if delta < delta_min
        delta_min = delta; 
        sol_tot = c0;
    end
end
sol_init = sol_tot; 