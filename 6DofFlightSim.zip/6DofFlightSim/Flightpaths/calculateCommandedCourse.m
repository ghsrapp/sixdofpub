function [Chi_cmd,Delta_chi] = calculateCommandedCourse(t,delta_vec, delta, delta0, chi_K_des, L_sol)
%CALCULATEDESIREDCOURSE Summary of this function goes here
%   Detailed explanation goes here


Delta_chi = atan2( -sign(L_sol' * cross( t, delta_vec  )) * delta , delta0 );
Chi_cmd = chi_K_des + Delta_chi;


if Chi_cmd > pi
    Chi_cmd = -pi + mod( Chi_cmd, pi );
elseif Chi_cmd < -pi
    Chi_cmd = pi + mod(Chi_cmd, -pi);
end




end

