function [ sol, res, f ] = bisectionMethod( interval, p_kite_W, LemPs )
%NEWTONMETHOD Summary of this function goes here
%   Detailed explanation goes here
res = 1; 
f=1;  
kk = 1; 
% Check interval bounds and adapt if necessary
%while sign( fun(interval(1))) == sign( fun(interval(2))) && kk < 100

while sign( func(interval(1),p_kite_W, LemPs )) == sign( func(interval(2),p_kite_W, LemPs ) ) && kk < 100
        interval(1) =  max( interval(1)-0.1,0);
        interval(2) =  min( interval(2)+0.1, 2*pi);
        kk = kk + 1;
end


m_prev = interval(1); 
m = m_prev;
k = 1; 
while res > 1e-6 && k < 100
    m = ( interval(1) + interval(2) )/2; 
    fm = func(m,p_kite_W, LemPs ); 
    fa = func(interval(1),p_kite_W, LemPs ); 
    if sign( fm ) ~= sign( fa )
        interval(2) = m;
    else 
        interval(1) = m;
    end
    f = func(m,p_kite_W, LemPs ); 
    res = abs( m - m_prev ); 
    m_prev = m; 
    k = k + 1;
end
if k >= 100
    disp('Max Iter.');
end
sol = m; 
end