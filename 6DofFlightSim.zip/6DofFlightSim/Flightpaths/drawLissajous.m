
Alambda = LemPs.Alambda ;
Aphi = LemPs.Aphi;
blambda = LemPs.blambda;
bphi = LemPs.bphi;
phi0 = LemPs.phi0;

theta_vec = 0 : 0.001 : 2*pi;theta_vec = theta_vec';

L = [Alambda * sin(blambda*theta_vec');
    Aphi    * sin(bphi*theta_vec') + phi0];

figure(1);
L_W = [cos(L(1,:)).*cos(L(2,:));
        sin(L(1,:)).*cos(L(2,:));
        sin(L(2,:))];

L_W_k = L_W * l_tether;
plot3(L_W_k(1,:), L_W_k(2,:),L_W_k(3,:), 'color', [0.3, 0.3 ,0.3]); hold on;
axis equal; grid on;hold on; view(90,0);