%% Defines the geometrical properties of the figure of 8
LemPsRef.AlambdaRef = 300;70;
factor = 5; 
LemPsRef.AphiRef = LemPsRef.AlambdaRef/factor;
LemPsRef.blambdaRef = 1;
LemPsRef.bphiRef = 2;
LemPsRef.phi0 = 30*pi/180;
LemPsRef.c0 = pi/4;

