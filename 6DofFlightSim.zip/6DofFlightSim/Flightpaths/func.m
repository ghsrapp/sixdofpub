function [f] = func(cc,K, LemPs)

L = [LemPs.Alambda * sin(LemPs.blambda*cc);
     LemPs.Aphi * sin(LemPs.bphi*cc)+LemPs.phi0];
 
dLds = [ LemPs.blambda*LemPs.Alambda*cos(LemPs.blambda*cc);...
         LemPs.bphi*LemPs.Aphi*cos(LemPs.bphi*cc)];
     
s_lambda = sin( L(1,:)  ); 
s_phi = sin( L(2,:) );
c_lambda = cos( L(1,:) ); 
c_phi = cos( L(2,:) ); 

f = K(1)*(-s_lambda.*dLds(1,:).*c_phi-s_phi.*dLds(2,:).*c_lambda)+...
    K(2)*( c_lambda.*dLds(1,:).*c_phi-s_phi.*dLds(2,:).*s_lambda)+...
    K(3)*c_phi.*dLds(2,:);


1;