
function [x_trim, u_trim, Va_trim, alpha_trim,beta_trim, A_long, B_long, A_lat, B_lat,FM] = trimAircraft( Va, gamma, R )


%% Trim routine

% Define the trim problem 

% Desired derivative of the system (trim goal)
DX = [0;0;-Va*sin(gamma); 0; 0; 0;0;0;Va/R;0;0;0]; 
%DX = [0;0;-Va*sin(gamma); 0; 0; 0;0;0;0;0;0;0]; 

% Define the derivatives that shall be kept fixed by defining its index
IDX = [3;4;5;6;7;8;9;10;11;12];

% Initalize the states
X0 = [0;0;0;Va;0;0;0;gamma;0;0;0;0];
IX = [];
U0 = [0;0;0;1];
IU = [];
Y0 = [Va;gamma;0]; % we specify these output variables since we want to asign constraints on them. They are specified in the Simulink model. 
IY = [1,3]; % Keep these outputs fixed

% Happy trimming 
disp('Trimming in progress...')
[X,U,Y,DX_trim, options] = trim('mavsim_trim', X0, U0,Y0, IX,IU,IY,DX, IDX); 
disp('Trimming completed. Residual: ')
norm(DX_trim(3:end)-DX(3:end))
disp('Do linearization around trim condition...'); 
x_trim = X; 
u_trim = U; 
Va_trim = Y(1); 
alpha_trim = Y(2); 
beta_trim = Y(3); 

% Linearization arount trim point 
[A,B,C,D] = linmod('mavsim_trim', x_trim, u_trim); 
disp('Linearization complete.'); 

% Extracting the state space models for the longitudinal and lateral
% motion
% x_lat = (v, p, r, phi, psi), u_lat = (delta_a, delta_r)
% x_long = (u, alpha, q, theta, h), u_long = (delta_e, delta_t)
% To get this structure and alpha as a state in the state space model we
% have to carry out transformations
% Structure in the model is: x = [x_n, x_e, x_d, u, v, w, phi, theta, psi,p, q, r]';
% and for the input: u = [delta_e, delta_a, delta_r, delta_t]';
% Transformation Latitude
%x_lat = T_A_lat * x
% u_lat = T_B_lat * u
T_A_lat = zeros(5,12); 
T_A_lat(1,5) = 1; 
T_A_lat(2,10) = 1; 
T_A_lat(3,12) = 1; 
T_A_lat(4,7) = 1; 
T_A_lat(5,9) = 1; 
T_B_lat = zeros(2,4);
T_B_lat(1,2) = 1; 
T_B_lat(2,3) = 1; 
% with T_A_lat^-1*x_dot = A * T_A_lat^1*x + B_  
% and wiht pinv(T_A_lat) = T_A_lat')
A_lat = T_A_lat * A * T_A_lat'; 
B_lat = T_A_lat * B * T_B_lat';

%% Transformation Longitude 
T_A_long = zeros(5,12); 
T_A_long(1,4) = 1; 
T_A_long(2,6) = 1/(Va_trim*cos(alpha_trim)); % results from linearization of w = Va*sin(alpha) => w_lin = Va_trim * cos(alpha_trim) * alpha_lin => we want alpha here
T_A_long(2,6) = 1; 
T_A_long(3,11) = 1; 
T_A_long(4,8) = 1; 
T_A_long(5,3) = 1;%Careful, we have here already w_dot = h_dot (that was a condition in the trim table, so don't use a minus sign)
T_B_long = zeros(2,4); 
T_B_long(1,1) = 1; 
T_B_long(2,4) = 1; 
A_long = T_A_long * A * T_A_long'; 
B_long = T_A_long * B * T_B_long';
% Extract short period state space model
% x_long = (u, alpha, q, theta, h), u_long = (delta_e, delta_t)
A_sp = A_long(2:3, 2:3); 
B_sp  = B_long(2:3,1); 

%% natural frequency, relative damping and poles for the longitudinal and lateral eigenmotions 
% Returns the undamped natural frequencies as well as the relative damping
% and the poles. 
[natural_frequ_long,relative_damping_long,poles_long]=damp(A_long);
[natural_frequ_lat,relative_damping_lat,poles_lat]=damp(A_lat);

natural_frequ_long(1) = []; 
relative_damping_long(1) = []; 

natural_frequ_lat(1:3) = []; 
relative_damping_lat(1:3) = []; 

% Time constant Short period mode and phygoid: 
FM.tau_sp = 1/(max( natural_frequ_long ) * max( relative_damping_long) ); 
FM.tau_phy = 1/(min( natural_frequ_long ) * min( relative_damping_long) ); 
% Time constant dutch roll 
FM.tau_DR = 1/( natural_frequ_lat(1) * relative_damping_lat(1) ); 

% The damped frequencies are then: 
omega_d_long = natural_frequ_long .* sqrt( 1 - relative_damping_long.^2 ); 
omega_d_lat = natural_frequ_lat .* sqrt( 1 - relative_damping_lat.^2 ); 

% Time constants for the real oscillations (using the damped
% eigenfrequencies)
FM.T_long = 2*pi./omega_d_long;
FM.T_lat = 2*pi./omega_d_lat; 

