function for_tether_G_B = calcTotalTetherForce( pos_O, vel_w_B, vel_K_B_mDs, tether_length, P, DCM,ENVMT )

%% Tether drag
% 1) Calculate component of the apparent windspeed vector that is
% perpendicular to the (straight) tether
% 2) Assume that the tether drag is acting in this direction
% 3) Transform drag vector into the B frame.
%pos_W = M_WO * pos_O; 
%pos_W(1) = -pos_W(1);
%pos_W(3) = -pos_W(3); 

vel_a_O = DCM * ( vel_K_B_mDs - vel_w_B );

V_app_parallel = (pos_O'*vel_a_O)/norm(pos_O)^2 * pos_O; % Projection of the apparent windspeed in tether direction
V_app_normal_O = vel_a_O - V_app_parallel ; % normal component of the apparent windspeed 

for_tetherdrag_O = 1/8 * ENVMT.rhos * P.Ctether * P.dTether * tether_length * norm(V_app_normal_O) * V_app_normal_O;  

%for_tetherdrag_O = F_td_W; for_tetherdrag_O(1) = -for_tetherdrag_O(1); for_tetherdrag_O(3) = -for_tetherdrag_O(3); 

% Tetherforce
e = norm( pos_O ) - tether_length; 
norm_pos = norm(pos_O); 
if norm_pos == 0
    e_t = [0;0;-1];
else
    e_t = pos_O/norm_pos; 
end 

for_tetherforce_O = -(e>=0)*( 2*P.c_spring /tether_length * ( e ) * e_t );

% Tetherforce
for_tether_G_B = DCM' * (for_tetherforce_O+ 0 * for_tetherdrag_O);





end