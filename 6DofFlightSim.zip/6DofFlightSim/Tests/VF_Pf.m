
if 0
    
    Wp1 = [0;0;0];
    Wp2 = [50;50;0];
    r_O = Wp1;
    
    figure;
    plot3( Wp1(1), Wp1(2), Wp1(3), 'ok'); hold on
    plot3( Wp2(1), Wp2(2), Wp2(3), 'ok'); hold on
    axis([-100 100 -100 100 -100 100])
    
    
    for m = 1 : 200
        
        
        p_O = 10*randn(3,1);
        b_O = Wp2-Wp1;
        b_O = b_O/norm(b_O);
        delta = 1;
        plot3( [Wp1(1) Wp2(1)], [Wp1(2) Wp2(2)], [Wp1(3) Wp2(3)], '-k'); hold on
        c = 0;
        while delta > 1e-3
            
            e_perp_O = p_O - r_O - b_O' *  ( p_O - r_O ) * b_O;
            delta = sqrt( e_perp_O'*e_perp_O );
            delta0 = 4;
            chi_q = atan( -delta/delta0 );
            V_p = [cos(chi_q); sin(chi_q); 0];
            M_OP = [b_O,e_perp_O/norm(e_perp_O), cross( b_O, e_perp_O/norm(e_perp_O) ) ];
            V_O = M_OP * V_p;
            
            %plot3( p_O(1), p_O(2), p_O(3), '+b'); hold on
            if mod(c, 2) == 0
                quiver3( p_O(1), p_O(2), p_O(3), V_O(1), V_O(2), V_O(3), '-b', 'Linewidth', 1.2, 'MaxHeadSize', 10); hold on
            end
            c = c  +1;
            % More in the direction
            p_O = p_O + V_O * 0.5;
            drawnow;
        end
        
    end
    
else
    %% Circle in NE plane (wrtg, if not in plane then M_PO is not the unity
    % matrix)
    figure;
    theta = 0 : 0.01 : 2*pi;
    r_circ_O = [10;10;10];
    R = 10;
    
    plot3( cos(theta)*R+r_circ_O(1), sin(theta)*R+r_circ_O(2), zeros(1,length(theta))+r_circ_O(3), '-b'); hold on
    %%
 for l = 1 : 100 
     
    p_O = 10*randn(3,1);p_0(3) = 0;  
    M_PO = eye(3);
    M_OP = M_PO';
    c = 0;
    delta = 1; 
    while delta > 1e-1
        M_OP = eye(3);  
        M_PO = eye(3);

        p_P = M_PO * (p_O - r_circ_O );
        
        %p_P(3) = 0; 
        V = [1, 0; 0, 1; 0, 0]; 
        p_P = V*((V'*V)\eye(2))*V'*p_P; 
        
        
        p_P = p_P / norm(p_P) * R;
        s_star = atan2( p_P(2), p_P(1) );
        t_P = [-sin(s_star); cos(s_star); 0]*R;
        t_O = M_OP * t_P;% + r_circ_O;
        p_proj_O = M_OP * p_P + r_circ_O;
        plot3( p_proj_O(1), p_proj_O(2), p_proj_O(3), 'or'); hold on
        %plot3( p_O(1), p_O(2), p_O(3), 'ok'); hold on
       % quiver3( p_proj_O(1), p_proj_O(2), p_proj_O(3), t_O(1), t_O(2), t_O(3), 'r');
        delta_O = p_O - p_proj_O;
       
        ex = t_O/norm(t_O);
        ey = delta_O/norm(delta_O);
        ez = cross( ex, ey );
        M_OP = [ex, ey, ez];
        delta = norm( delta_O );
        
        if delta < 1e-3
            V_O = t_O/norm(t_O);
        else
            delta0 = 4;
            chi_q = atan( -delta/delta0 );
            V_p = [cos(chi_q); sin(chi_q); 0];
            V_O = M_OP * V_p ;
        end
        %quiver3( p_O(1), p_O(2), p_O(3), V_O(1), V_O(2), V_O(3), '-b', 'Linewidth', 1.2, 'MaxHeadSize', 10); hold on
        
        if mod(c, 2) == 0
            quiver3( p_O(1), p_O(2), p_O(3), V_O(1), V_O(2), V_O(3), '-b', 'Linewidth', 1.2, 'MaxHeadSize', 10); hold on
        end
        c = c  +1;
        % More in the direction
        p_O = p_O + V_O * 0.5;
        drawnow;view(90,90); axis equal;
        1;
    end
end
end