%% Defines the environment according to ISO 2533
ENVMT.gs = 9.80665; 
ENVMT.R = 287.05; 
ENVMT.n = 1.235; 
ENVMT.Ts = 288.15; 
ENVMT.rhos = 1.225; 
ENVMT.ps = 1.01325e5; 
P.g = 9.81;
