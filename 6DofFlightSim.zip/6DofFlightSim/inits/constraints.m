mu_k_max = 80*pi/180; 
alpha_k_max = 20*pi/180; 