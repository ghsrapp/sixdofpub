%% Initialize the bus objects 

%% ========== Airframe Output Bus: Contains all the airframe states ============================== 
Airframe_Output_Bus = Simulink.Bus; % Create Bus Object
Airframe_Output_Bus_Elements = []; % Create Bus Elements Object

% Position of center of gravity in NED frame
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'pos_G_O_m', [3,1] );
% Kinematic Velocity
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'vel_K_B_mDs', [3,1] );
% % Attitude of the airframe in Euler angles
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'eta_OB_rad', [3,1] );
% Bodyrates
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'omega_OB_B_radDs', [3,1] );
% Airdata comprising airspeed, angle of attack and sideslip angle
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'airdata', [3,1] );
% DCM (M_OB)
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'DCM', [3,3] );
% Path angles (M_OB)
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'pathAngles', [2,1] );
% Quaternions
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'quaternions', [4,1] );
% Accelerations in the body frame
Airframe_Output_Bus_Elements = createBusElement(Airframe_Output_Bus_Elements,  'acc_B_mDs2', [3,1] );


Airframe_Output_Bus.Elements = Airframe_Output_Bus_Elements;

%% ========== Measurement Bus: Contains all the airframe states ============================== 
Airframe_Measurements_Bus = Simulink.Bus; % Create Bus Object
Airframe_Measurements_Bus_Elements = []; % Create Bus Elements Object

% Bodyrates as measured by the Gyros
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'omega_OB_B_meas_radDs', [3,1] );
% Acceleration of drone as measured by the accelerometers tube
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'acc_B_meas_mDs2', [3,1] );
% Differential pressure as measured by the Pitot tube
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'diffPressure_meas_NDm2', 1 );
% Static pressure as measured by pressure sensor
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'staticPressure_meas_NDm2', 1 );
% Heading as measured by the magnetometer
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'Psi_OB_meas_rad', 1 );
% Position as measured by the GPS
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'pos_G_O_GPS_meas_m', [3,1] );
% North-East velocity components as measured by the GPS
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'vel_O_GPS_meas_mDs', 1 );
% Course as measured by the GPS
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'Course_OK_GPS_meas_rad', 1 );
% Angle of attack 
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'alpha_a_meas_rad', 1 );
% Sideslip angle 
Airframe_Measurements_Bus_Elements = createBusElement(Airframe_Measurements_Bus_Elements,  'beta_a_meas_rad', 1 );

Airframe_Measurements_Bus.Elements = Airframe_Measurements_Bus_Elements;

%% ========== State estimation Bus: Contains all the processed sensor data ============================== 
Airframe_StateEstimation_Bus = Simulink.Bus; % Create Bus Object
Airframe_StateEstimation_Bus_Elements = []; % Create Bus Elements Object

% Bodyrates
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'omega_OB_B_radDs', [3,1] );
% Barometric height
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'h_barom', 1 );
% Airdata comprising airspeed, angle of attack and sideslip angle
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'airdata', [3,1] );
% Position of center of gravity in NED frame
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'pos_G_O_m', [3,1] );
% Kinematic Velocity
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'vel_K_B_mDs', [3,1] );
% Attitude of the airframe in Euler angles
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'eta_OB_rad', [3,1] );
% Path angles (M_OB)
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'pathAngles', [2,1] );
% Quaternions
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'quaternions', [4,1] );
% Accelerations in the body frame
Airframe_StateEstimation_Bus_Elements = createBusElement(Airframe_StateEstimation_Bus_Elements,  'acc_B_mDs2', [3,1] );

Airframe_StateEstimation_Bus.Elements = Airframe_StateEstimation_Bus_Elements;
