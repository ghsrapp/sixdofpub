%% ======= Flightpath reference models ====
FCS.ARefFlightPath = -0.5*eye(2); 
FCS.BRefFlightPath = -FCS.ARefFlightPath; 
FCS.ARefVel = -10; 
FCS.BRefVel = 10; 

FCS.Kp_FlightPath = diag( [0.1,0.1] ); 
FCS.Ki_FlightPath = diag( [0.01,0.01] ); 
FCS.Kp_Velocity = 0.1; 
FCS.Ki_Velocity = 0.1; 

%% ======= Attitude Controller Gains =======
FCS.Kp_attitude = diag( [10,10,10] ); % Euler
FCS.Kp_attitude = diag( [10,10,10] ); % Airdata

%% Attitude Reference Filter Parameter
FCS.ARefAttitude = -10*eye(3); 
FCS.BRefAttitude = -FCS.ARefAttitude; 
FCS.omegaGammaDot = 25;
FCS.zetaGammaDot = 0.8; 

%% ======= Rate Controller Gains =======
FCS.Kp_rate = diag( [10,10,10] ); 
FCS.Ki_rate = diag( [10,10,10] ); 
FCS.ARefRate = 5*FCS.ARefAttitude; 
FCS.BRefRate = 5*FCS.BRefAttitude; 



%% Control Allocation 
FCS.C_A = [P.C_ell_delta_a, 0,P.C_ell_delta_r;
           0,P.C_m_delta_e ,0;
           P.C_n_delta_a, 0,P.C_n_delta_r];
FCS.C_A_inv = FCS.C_A \ eye(3); 


%% Model parameters 
FCS.J = P.J; 
FCS.Jinv = P.Jinv; 

