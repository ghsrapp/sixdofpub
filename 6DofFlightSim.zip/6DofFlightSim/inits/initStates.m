DCM_init = eye(3); 
pos_O_init = [50;0;-200];
vel_B_init = [Va;0;0];
eta_init = [0;0;0];