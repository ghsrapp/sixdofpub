%% Lowpass filter init
% Bodyrates 
SensorData.Rates.omega = 100; 
SensorData.absP.omega = 50; 
SensorData.DiffPressure.omega = 50; 
SensorData.GPSPos.omega = 10; 