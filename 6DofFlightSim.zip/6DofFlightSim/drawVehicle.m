function drawVehicle(uu, V, F, patchcolors)
% process input to function
pn = uu(1); % inertial North position
pe = uu(2); % inertial East position
pd = uu(3); % inertial down position

phi = uu(4);
theta = uu(5);
psi = uu(6);

t = uu(7);

chi_k = uu(8); 
gamma_k = uu(9);

V_k = norm(uu(10:12));
bearing_W = 50*uu(13:15);
bearing_W(2) = -bearing_W(2);
bearing_W(3) = -bearing_W(3);

bearing_w = 50*uu(16:18);

quat= uu(19:22); %M_OB
q0 = quat(1); 
q1 = quat(2); 
q2 = quat(3); 
q3 = quat(4); 
DCM = [q0^2+q1^2-q2^2-q3^2,2*(q1*q2-q0*q3),2*(q0*q2+q1*q3); 
    2*(q1*q2+q0*q3),q0^2-q1^2+q2^2-q3^2,2*(q2*q3-q0*q1); 
    2*(q1*q3-q0*q2),2*(q2*q3+q0*q1),q0^2-q1^2-q2^2+q3^2];
R = uu(24);
alpha = uu(23);
%virtualTarget = uu(13:15); 
%bearing = uu(16:18);
%course_t_cmd = uu(12)*180/pi; 
% climbAng = uu(8);
% hFinal = uu(9);
% dFinal = uu(10);

% u_wind = uu(17);
% v_wind = uu(18);
% w_wind = uu(19);

% % Path parameters
% maxWidth = uu(20);
% lat = uu(21);
% l_tether = uu(22);
% r_d = uu(23);



% waypoint_mat =   [0,0,0;
%     0,0,-15; % clear height
%     (hFinal-15)/tan(climbAng)-cos(climbAng)*dFinal, 0, -(hFinal-sin(climbAng)*dFinal);
%     (hFinal-15)/tan(climbAng),0, -hFinal];
% waypoint_mat(:,1) = waypoint_mat(:,1) * (-1);
% define persistent variables
persistent vehicle_handle;
persistent Vertices
persistent Faces
persistent facecolors
persistent bearingH
persistent handleT
persistent counter
%persistent virtualTarget
%persistent referencePath
persistent handleCircle

if t==0
    figure(1), %clf
    counter = 1;
    [Vertices, Faces, facecolors] = defineVehicleBody;
    vehicle_handle = drawVehicleBody(Vertices, Faces, facecolors, ...
        pn, pe, pd, phi, theta, psi, DCM, ...
        [], 'normal');
    xlabel('North')
    ylabel('West')
    zlabel('Up')
    grid on
    axis equal; hold on;
    %view(90,20); % set the vieew angle for figure
    axis([-200 200 -200 200 0 300])
    
    handleT = drawTether(pn, pe, pd, []);
    handleCircle = drawCircle(R, alpha, []);
    bearingH = drawBearing(bearing_W,pn, pe, pd, []);
    
   distance = sqrt( pn^2 + pe^2 + pd^2 ); 
     [x,y,z] = sphere(50); 
    % sphere_h = surf(distance*x, distance*y, distance*z);
else 
   
    drawTether(pn, pe, pd, handleT);
    drawCircle(R, alpha, handleCircle);
    drawBearing(bearing_W,pn, pe, pd, bearingH);
    ht = title(['h= ' num2str(-pd), ' (m)', ' Course= ' num2str(chi_k), '(deg)', ' Climb= ' num2str(gamma_k), '(deg)']);
    set(ht, 'Fontsize', 10);
    drawVehicleBody(Vertices, Faces, facecolors,...
        pn, pe, pd, phi, theta, psi, DCM, ...
        vehicle_handle);
    plot3( pn, -pe, -pd,'.b', 'Linewidth', 2, 'Markersize', 5);
    %  plot3( p_c_w(1), p_c_w(2), p_c_w(3),'.r', 'Linewidth', 2, 'Markersize', 5);
    deltaC = 1;
    %quiver3( pn, -pe, -pd, bearing_w(1), bearing_w(2), bearing_w(3), '-b');
    %quiver3( pn, -pe, -pd, bearing_w2(1), bearing_w2(2), bearing_w2(3), '-r');

    
    
    %      distance = sqrt( pn^2 + pe^2 + pd^2 ); 
%      [x,y,z] = sphere(50); 
%      sphere_h = surf(distance*x, distance*y, distance*z);
     
    %quiver3( pn, -pe, -pd, bearing(1), -bearing(2), -bearing(3), 10 , '-r'); 
    if mod(counter-1, deltaC) == 0
        if counter == 1
         %      print([eval('pwd'),'/video/','vidPic_',num2str(counter)], '-dpng', '-r300');
        else
         %     print([eval('pwd'),'/video/','vidPic_',num2str((counter-1)/deltaC)], '-dpng', '-r300');
        end
    end
    counter = counter + 1;
end
end


function handleT = drawTether(pn, pe, pd, handleT)
pts =  [pn;-pe;-pd];
if isempty(handleT)
    handleT = plot3([0 pts(1)], [0 pts(2)], [0 pts(3)], '-k');
else
    set(handleT,'XData',[0 pts(1)],'YData',[0 pts(2)],'ZData',[0 pts(3)] );
end
drawnow;
end

function bearingH = drawBearing(bearing_W,pn, pe, pd, bearingH)
pts =  [pn;-pe;-pd];
if isempty(bearingH)
    bearingH = plot3([pts(1) pts(1)+bearing_W(1)], [pts(2) pts(2)+bearing_W(2)], [pts(3) pts(3)+bearing_W(3)], '-r');
else
    set(bearingH,'XData',[pts(1) pts(1)+bearing_W(1)],'YData',[pts(2) pts(2)+bearing_W(2)],'ZData',[pts(3) pts(3)+bearing_W(3)] );
end
drawnow;
end


function handleCircle = drawCircle(R, alpha, handleCircle)
    theta = 0 : 0.1 : 2*pi;
    circle = [cos(theta.'), sin(theta'), 0*theta']*R;
    M_OP = [cos(alpha), 0, -sin(alpha);
        0, 1, 0;
        sin(alpha), 0, cos(alpha)];
    circle_O = M_OP * circle';
    r_circ_P =[0;-0;-200]; 
    r_circ_O = M_OP*r_circ_P;
    circle_O = circle_O + r_circ_O;  
if isempty(handleCircle)
    handleCircle = plot3(circle_O(1,:), -circle_O(2,:), -circle_O(3,:), '-k');

else
    set(handleCircle,'XData',circle_O(1,:),'YData',-circle_O(2,:),'ZData',-circle_O(3,:) );
end
drawnow;
end


function handle = drawVehicleBody(V,F,patchcolors,...
    pn, pe, pd, phi, theta, psi, DCM,...
    handle,mode)
V = rotate(V, phi, theta, psi, DCM); % body frame into NED frame
V = translate(V, pn , pe, pd);

M_EO = [1, 0, 0; 0, -1, 0; 0, 0, -1];
%V = M_ON * V; % Transform from N to NED frame
V = M_EO*V; % Transform from NED into E frame
%axis([pn-150 pn+150 -pe-150 -pe+150 -pd-150 -pd+150])
if isempty(handle),
    handle = patch('Vertices', V', 'Faces', F, ....
        'FaceVertexCData', patchcolors,...
        'FaceColor', 'flat');%,...
    %'EraseMode', mode);
else
    set(handle,'Vertices', V', 'Faces', F);
    drawnow
end
end

function pts = rotate(pts, phi, theta, psi, DCM)

% From B 2 O
% pts = [ cos(psi)*cos(theta), cos(psi)*sin(phi)*sin(theta) - cos(phi)*sin(psi), sin(phi)*sin(psi) + cos(phi)*cos(psi)*sin(theta);
%     cos(theta)*sin(psi), cos(phi)*cos(psi) + sin(phi)*sin(psi)*sin(theta), cos(phi)*sin(psi)*sin(theta) - cos(psi)*sin(phi);
%     -sin(theta),                              cos(theta)*sin(phi),                              cos(phi)*cos(theta)] * pts;
pts = DCM * pts; 
end

function pts = translate(pts, pn, pe, pd)
pts = pts + repmat([pn;pe;pd], 1, size(pts,2));
end

function [V,F,facecolors] = defineVehicleBody
scale = 20;
b_wing = 3.7*scale;
c_wing = 0.22*scale;
L_fuse = 1*scale;
b_fuse = 0.1*scale;
c_emp = 0.1*scale;
b_emp = 0.4*scale;
h_rud = 0.5*scale;
h_fuse = 0.1*scale;
x_nose = 0.5*scale;
x_tail = 1.5*scale;
b_fuse = 0.1*scale;
xp = 0.1*scale;
x_LE = 0.1*scale;
c_rud = 0.1*scale;
V = [...
    x_nose, 0, 0; %1
    x_nose-xp, b_fuse/2, -h_fuse/2; %2
    x_nose-xp, b_fuse/2, +h_fuse/2; %3
    x_nose-xp, -b_fuse/2, +h_fuse/2; %4
    x_nose-xp, -b_fuse/2, -h_fuse/2; %5
    -x_tail, 0, 0; %6
    x_LE, b_wing/2, 0;%7
    x_LE-c_wing, b_wing/2, 0;%8
    x_LE-c_wing, -b_wing/2, 0; %9
    x_LE, -b_wing/2, 0;  %10
    -x_tail, -b_emp/2, 0;... % 11
    -(x_tail+c_emp), -b_emp/2, 0;...% 12
    -(x_tail+c_emp), b_emp/2, 0;...% 13
    -x_tail, b_emp/2, 0;...% 14
    -(x_tail+c_emp), 0, 0;... % 15
    -(x_tail+c_emp+c_rud), 0, 0;...% 16
    -(x_tail+c_emp+c_rud), 0, -h_rud;...% 17
    -(x_tail+c_emp), 0, -h_rud;...% 18
    ]';
F = [...
    1,2,3,3;... % pyramid
    3,4,1,1;...
    1,4,5,5;...
    1,2,5,5;...
    3,4,6,6;...
    4,5,6,6;...
    2,5,6,6;...
    2,3,6,6;...
    2,5,6,6;...
    7,8,9,10;...
    11,12,13,14;...
    15,16,17,18;...
    ];
facecolors = [1,0,0];
end
