clear all 
close all
clc

% Setup Simulation
dt = 0.002;
addpath('inits');
addpath('Trimroutine')
addpath('Flightpaths');

aircraftParametersAerosonde;
initControllerGains;
initEnvironment;
initBusObjects;
FlightPathDefinition;
constraints;
initLissajous; 
sensorsInit;

windDirection_rad = 0;

lissajousFlag = 0; 


trimFlag = 1; 

% do trim yes no
Va = 30;
if trimFlag
    % Trimstate
    gamma = 10*pi/180;
    R = 100; 
    X0 = [0;0;0;Va;0;0;0;0;0;0;0;0];
    [x_trim, u_trim, Va_trim, alpha_trim,beta_trim, A_long, B_long, A_lat, B_lat,FM] = trimAircraft( Va, gamma, R ); 
end

initStates;
l_tether = norm(pos_O_init);
[ LemPs ] = updateLissajous( l_tether, LemPsRef );
initSol;
if lissajousFlag 
   drawLissajous;
end

%%
initBusObjects;
initStates;
initEnvironment; 
sensorsInit;