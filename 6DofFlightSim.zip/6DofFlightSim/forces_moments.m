% forces_moments.m
%   Computes the forces and moments acting on the airframe.
%
%   Output is
%       F     - forces
%       M     - moments
%       Va    - airspeed
%       alpha - angle of attack
%       beta  - sideslip angle
%       wind  - wind vector in the inertial frame
%

function out = forces_moments(x, delta, wind, P)

% relabel the inputs
pn      = x(1);
pe      = x(2);
pd      = x(3);
u       = x(4);
v       = x(5);
w       = x(6);
phi     = x(7);
theta   = x(8);
psi     = x(9);
p       = x(10);
q       = x(11);
r       = x(12);
delta_e = delta(1);
delta_a = delta(2);
delta_r = delta(3);
delta_t = delta(4);
w_ns    = wind(1); % steady wind - North
w_es    = wind(2); % steady wind - East
w_ds    = wind(3); % steady wind - Down
u_wg    = wind(4); % gust along body x-axis
v_wg    = wind(5); % gust along body y-axis
w_wg    = wind(6); % gust along body z-axis

% Transoformation from B->O, O->B

% From B 2 O
M_OB = [ cos(psi)*cos(theta), cos(psi)*sin(phi)*sin(theta) - cos(phi)*sin(psi), sin(phi)*sin(psi) + cos(phi)*cos(psi)*sin(theta);
    cos(theta)*sin(psi), cos(phi)*cos(psi) + sin(phi)*sin(psi)*sin(theta), cos(phi)*sin(psi)*sin(theta) - cos(psi)*sin(phi);
    -sin(theta),                              cos(theta)*sin(phi),                              cos(phi)*cos(theta)];
gusts_vec = M_OB * [u_wg; v_wg; w_wg];

% compute wind data in NED
w_n = w_ns + gusts_vec(1);
w_e = w_es + gusts_vec(2);
w_d = w_ds + gusts_vec(3);

% compute air data
Va = norm( [u;v;w]-M_OB'*[w_n;w_e;w_d] );
alpha = atan( w / u );
beta = asin( v / Va );

% compute external forces and torques on aircraft
% Gravity
Fg = P.mass*9.81 * [-sin(theta); cos(theta)*sin(phi); cos(theta)*cos(phi)];
% Aerodynamic
AR = P.b^2/P.S_wing;

sigma = ( 1+exp(-P.M*(alpha-P.alpha0))+exp(P.M*(alpha+P.alpha0)) )./...
        ( (1 + exp(-P.M*(alpha-P.alpha0))).*(1+exp(P.M*(alpha+P.alpha0))));

CLalpha = (1-sigma).*(P.C_L_0 + P.C_L_alpha.*alpha)+...
    sigma .* ( 2 * sign(alpha).*sin(alpha).^2.*cos(alpha));

CDalpha = P.C_D_p + (P.C_L_0 + P.C_L_alpha * alpha).^2/(pi*P.e*AR);

% Transformation of the aerodynmic coefficients into the bodyfixed frame
CX = -CDalpha * cos(alpha) + CLalpha * sin(alpha); 
CXq = -P.C_D_q*cos(alpha)+P.C_L_q*sin(alpha);
CXdelta_e = -P.C_D_delta_e * cos(alpha)+ P.C_L_delta_e*sin(alpha);

CZ = -CDalpha*sin(alpha)-CLalpha*cos(alpha);
CZq = -P.C_D_q*sin(alpha)-P.C_L_q*cos(alpha);
CZdelta_e = -P.C_D_delta_e*sin(alpha)-P.C_L_delta_e*cos(alpha);

CX_tot = CX +...
         CXq*P.c/(2*Va)*q+...
         CXdelta_e*delta_e;

CY_tot = P.C_Y_0 +...
         P.C_Y_beta*beta +...
         P.C_Y_p*P.b/(2*Va)*p+...
         P.C_Y_r * P.b/(2*Va)*r+...
         P.C_Y_delta_a * delta_a +...
         P.C_Y_delta_r * delta_r;

CZ_tot = CZ +...
         CZq*P.c/(2*Va)*q +...
         CZdelta_e*delta_e;

Fa_x = 0.5 * 1.225 * Va^2 * P.S_wing * CX_tot;
Fa_y = 0.5 * 1.225 * Va^2 * P.S_wing * CY_tot;
Fa_z = 0.5 * 1.225 * Va^2 * P.S_wing * CZ_tot;

Fp_x = 0.5 * 1.225 * P.S_prop * P.C_prop * ((P.k_motor*delta_t)^2-Va^2); 

Force(1) =  Fg(1)+Fa_x + Fp_x;
Force(2) =  Fg(2)+Fa_y;
Force(3) =  Fg(3)+Fa_z;

% Torques
Cl_tot = P.b*(P.C_ell_0+...
              P.C_ell_beta*beta +...
              P.C_ell_p*P.b/(2*Va)*p+...
              P.C_ell_r*P.b/(2*Va)*r+...
              P.C_ell_delta_a*delta_a+...
              P.C_ell_delta_r*delta_r);
          
Cm_tot = P.c * ( P.C_m_0 +...
                 P.C_m_alpha * alpha +...
                 P.C_m_q * P.c/(2*Va)*q +...
                 P.C_m_delta_e * delta_e);
             
Cn_tot = P.b*(P.C_n_0 +...
              P.C_n_beta*beta +...
              P.C_n_p*P.b/(2*Va)*p+...
              P.C_n_r * P.b/(2*Va)*r+...
              P.C_n_delta_a*delta_a+...
              P.C_n_delta_r*delta_r);

M_x = 0.5*1.225*Va^2*P.S_wing*Cl_tot - P.k_T_P*(P.k_Omega*delta_t)^2;
M_y = 0.5*1.225*Va^2*P.S_wing*Cm_tot;
M_z = 0.5*1.225*Va^2*P.S_wing*Cn_tot;

Torque(1) = M_x;
Torque(2) = M_y;
Torque(3) = M_z;

out = [Force'; Torque'; Va; alpha; beta; w_n; w_e; w_d];
end



